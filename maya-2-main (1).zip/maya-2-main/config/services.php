<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'openai' => [
        'api_key'   =>  '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',
        // 'model'     =>  'gpt-4-1106-preview',
        'model'     =>  'gpt-4.1',
        'vision_model' => 'gpt-4.1',
    ],

    'whatsapp'  =>  [
        'access_token', env('WHATSAPP_ACCESS_TOKEN'),
    ],

    'google' => [
        'client_id' => env('GOOGLE_CLIENT_ID'),
        'client_secret' => env('GOOGLE_CLIENT_SECRET'),
        'redirect' => env('GOOGLE_REDIRECT_URI'),
        'gmail_redirect' => env('GMAIL_REDIRECT_URI'),
        'app_name' => 'Maya',
    ],

    'cloudinary' => [
        'cloud_name' => env('CLOUDINARY_CLOUD_NAME'),
        'api_key' => env('CLOUDINARY_API_KEY'),
        'api_secret' => env('CLOUDINARY_API_SECRET'),
    ],

    'serper' => [
        'api_key' => env('SERPER_API_KEY'),
    ],

    'weatherapi' => [
        'api_key'   => env('WEATHER_API_KEY'),
    ],

    'stripe' => [
        'key' => env('STRIPE_KEY'),
        'secret' => env('STRIPE_SECRET'),
        'webhook_secret' => env('STRIPE_WEBHOOK_SECRET'),
    ],
    
    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'resend' => [
        'key' => env('RESEND_KEY'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],


];
