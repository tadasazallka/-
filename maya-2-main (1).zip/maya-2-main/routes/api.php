<?php

use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Auth\AppleCalendarController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\GmailAuthController;
use App\Http\Controllers\Auth\GoogleAuthController;
use App\Http\Controllers\Dashboard\CalendarManagementController;
use App\Http\Controllers\Dashboard\GmailManagementController;
use App\Http\Controllers\Dashboard\PlanController;
use App\Http\Controllers\Dashboard\UserController;
use App\Http\Controllers\Dashboard\UserPreferencesController;
use App\Http\Controllers\ManyChatDynamicController;
use App\Http\Controllers\Subscription\StripeController;
use App\Http\Controllers\Subscription\StripeWebhookController;
use App\Http\Controllers\Sync\CalendarSyncController;
use App\Http\Controllers\WhatsappHookController;
use App\Http\Middleware\SyncCalendars;
use Illuminate\Support\Facades\Route;


Route::prefix('v1')->group(function () {
        
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/register', [AuthController::class, 'register']);
    Route::get('validateToken', [AuthController::class, 'validateToken'])->middleware('auth:sanctum');
    Route::post('/password/forgot', [AuthController::class, 'sendResetLink']);
    Route::post('/password/reset', [AuthController::class, 'resetPassword'])->name('password.reset');
    Route::post('/updatePassword', [AuthController::class, 'updatePassword'])->middleware('auth:sanctum');
    Route::get('/plans', [PlanController::class, 'plans']);


    // Protected API Routes
    Route::middleware('auth:sanctum')->group(function () {

        Route::post('/logout', [AuthController::class, 'logout']);

        Route::get('/plan/usage', [PlanController::class, 'getUserPlanUsage'])->middleware(SyncCalendars::class);

        // Purchase plan
        Route::post('/checkout/create-session', [StripeController::class, 'createCheckoutSession']);

        // User routes
        Route::put('/user/name', [UserController::class, 'updateName']);
        
        // Notification preferences routes
        Route::get('/preferences/notifications', [UserPreferencesController::class, 'getNotificationPreferences']);
        Route::post('/preferences/notifications', [UserPreferencesController::class, 'setNotificationPreferences']);
        Route::post('/preferences/event-notifications', [UserPreferencesController::class, 'updateEventNotifications']);
        Route::post('/preferences/other-notifications', [UserPreferencesController::class, 'updateOtherNotifications']);
        Route::post('/preferences/daily-agenda-overview', [UserPreferencesController::class, 'updateDailyAgendaOverview']);
        
        // Advanced preferences routes
        Route::get('/preferences/advanced', [UserPreferencesController::class, 'getAdvancedPreferences']);
        Route::post('/preferences/smart-timing', [UserPreferencesController::class, 'updateSmartTiming']);
        Route::post('/preferences/event-duration', [UserPreferencesController::class, 'updateEventDuration']);
        Route::post('/preferences/event-alert', [UserPreferencesController::class, 'updateEventAlert']);
        Route::post('/preferences/all-day-event-alert', [UserPreferencesController::class, 'updateAllDayEventAlert']);
        Route::post('/preferences/time-conflict-detection', [UserPreferencesController::class, 'updateTimeConflictDetection']);
        Route::post('/preferences/google-meet-links', [UserPreferencesController::class, 'updateGoogleMeetLinks']);

        // Calendar Connections
        Route::get('auth/google', [GoogleAuthController::class, 'getGoogleAuthUrl']);
        Route::post('auth/google/callback', [GoogleAuthController::class, 'handleGoogleCallback']);
        Route::post('/connect-apple-calendar', [AppleCalendarController::class, 'connect']);
        Route::post('/disconnect-apple-calendar/{id}', [AppleCalendarController::class, 'disconnect']);

        Route::post('/test-apple-calendar-event-creation', [AppleCalendarController::class, 'testConnection']);

        // Calendar Management
        Route::get('calendarsInfo', [CalendarManagementController::class, 'calendarsInfo']);
        Route::get('calendarEvents', [CalendarManagementController::class, 'getCalendarEvents']);
        Route::post('/calendars/{id}/setDefault', [CalendarManagementController::class, 'setDefaultCalendar']);
        Route::post('/calendars/{id}/activate', [CalendarManagementController::class, 'activateCalendar']);

        // Gmail Auth
        Route::get('gmailStatus', [GmailManagementController::class, 'gmailStatus']);
        Route::get('auth/gmail', [GmailAuthController::class, 'getAuthUrl']);
        Route::post('auth/gmail/callback', [GmailAuthController::class, 'handleCallback']);
        Route::post('disconnectGmail', [GmailAuthController::class, 'disconnectGmail']);

    });

});

Route::post('/webhooks/google-calendar', [CalendarSyncController::class, 'handleGoogleWebhook']);
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/calendars/{id}/sync', [CalendarSyncController::class, 'syncCalendar']);
    Route::post('/calendars/{id}/push/enable', [CalendarSyncController::class, 'enablePushNotifications']);
    Route::post('/calendars/{id}/push/disable', [CalendarSyncController::class, 'disablePushNotifications']);
});

Route::prefix('whatsapp')->group(function(){
    Route::get('/webhook', [WhatsappHookController::class, 'verify']);
    Route::post('/webhook', [WhatsappHookController::class, 'handle']);
});


Route::post('/webhook/stripe', [StripeWebhookController::class, 'handleWebhook'])->withoutMiddleware(['auth:sanctum', 'throttle']);


// Admin API Routes
Route::prefix('admin')->group(function () {
// Route::prefix('admin')->middleware(['auth:sanctum','role:admin'])->group(function () {

    Route::get('/overview', [AdminController::class, 'overview']);
    Route::get('/users', [AdminController::class, 'users']);
    Route::get('/events', [AdminController::class, 'events']);
    Route::get('/subscriptions', [AdminController::class, 'subscriptions']);
    Route::get('/revenue', [AdminController::class, 'revenue']);
    Route::get('/system-health', [AdminController::class, 'systemHealth']);
    Route::get('/user-activity', [AdminController::class, 'userActivity']);
    Route::get('/engagement', [AdminController::class, 'engagement']);
    Route::get('/plans', [AdminController::class, 'plans']);

});