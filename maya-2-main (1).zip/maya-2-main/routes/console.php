<?php

use Illuminate\Support\Facades\Schedule;

Schedule::command('app:expire-subscriptions')->hourly();
Schedule::command('app:reset-feature-tracking')->hourly();

Schedule::command('app:send-event-reminders')->everyFiveMinutes()->withoutOverlapping()->appendOutputTo(storage_path('logs/reminders.log'));
// Reset Reminders for Recurring Events
Schedule::command('app:reset-recurring-event-reminders')->daily();

// Calendar Sync
Schedule::command('calendar:sync-google')->everyMinute();
// Schedule::command('calendar:refresh-google-channels')->daily();
Schedule::command('calendar:sync-apple')->everyMinute();

// Email token refreshing
Schedule::command('gmail:refresh-tokens --minutes=60')->dailyAt('01:00')->appendOutputTo(storage_path('logs/gmail-token-refresh.log'));

// Email Schedules
Schedule::command('emails:send-scheduled')->everyMinute()->withoutOverlapping()->appendOutputTo(storage_path('logs/scheduled-emails.log'));

Schedule::command('app:send-daily-agendas')->everyFiveMinutes();

// Weather Schedules
Schedule::command('weather:process-schedules')->everyThreeMinutes()->appendOutputTo(storage_path('logs/weather-schedules.log'));