<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function(){
    dd("Maya is Cool, isn't it");
});