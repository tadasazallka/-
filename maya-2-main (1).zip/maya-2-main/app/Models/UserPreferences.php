<?php

namespace App\Models;

use App\Observers\UserPreferencesObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserPreferences extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'measurement_system',
        'event_notifications',      // events alert, if off, we wont send reminders
        'other_notifications', 
        'daily_agenda_overview',    // If user can use this feature and is set to true then Send daily agenda overview.
        'smart_timing',             // If user can use this feature and is set to true, AI will auto generate event duration and reminder in minutes, otherwise the value of this 'event_duration', column will be used for events duration and column of 'event_alert' will be used for reminders minutues value
        'event_duration',           // this event duration will be used for setting duration of events if smart_timing is off
        'event_alert',              // this column value will be used for setting reminder of events in minutes if smart_timing is off
        'all_day_event_alert',      // the time in mins before 12 pm noon to send event alert for all day event
        'time_conflict_detection',  // If user can use this feature and this feature is set to true, then when creating/updating events, we have to show a warning to user about this overlapping of time
        'google_meet_links',        // If user can use this feature in his plan and this feature is set to true, then we have to create google meets also, if the calendar being used is google, for events scheduling.
        'language',
        'language_auto_detect'
    ];

    protected $casts = [
        'event_notifications' => 'boolean',
        'other_notifications' => 'boolean',
        'daily_agenda_overview' => 'boolean',
        'smart_timing' => 'boolean',
        'event_duration' => 'integer',
        'event_alert' => 'integer',
        'all_day_event_alert' => 'integer',
        'time_conflict_detection' => 'boolean',
        'google_meet_links' => 'boolean',
        'language_auto_detect' => 'boolean',
    ];

    protected static function booted()
    {
        static::observe(UserPreferencesObserver::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
