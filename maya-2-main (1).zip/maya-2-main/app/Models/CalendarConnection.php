<?php

namespace App\Models;

use App\Observers\CalendarConnectionObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CalendarConnection extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'calendar_account_id',
        'provider', // 'default', 'google', 'apple', etc.
        'provider_calendar_id',
        'is_primary',
        'provider_metadata',
        'name', // Calendar name
        'color', // Optional color for UI
        'is_active' // To disable without deleting
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'provider_metadata' => 'array',
        'is_primary' => 'boolean',
        'is_active' => 'boolean'
    ];

    protected static function booted()
    {
        static::observe(CalendarConnectionObserver::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function calendarAccount()
    {
        return $this->belongsTo(CalendarAccount::class, 'calendar_account_id');
    }

    public function events()
    {
        return $this->hasMany(Event::class);
    }
}