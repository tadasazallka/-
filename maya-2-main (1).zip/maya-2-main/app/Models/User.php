<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Notifications\CustomResetPasswordNotification;
use App\Observers\UserObserver;
use App\Services\FeatureTrackingService;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasApiTokens;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'whatsapp_id',
        'is_signed_up',
        'email',
        'email_verified_at',
        'password',
        'google_id',
        'timezone',
        'token',
        'manychat_subscriber_id',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'is_signed_up' => 'boolean',
        ];
    }

    protected static function booted()
    {
        static::observe(UserObserver::class);
    }

    public function sendPasswordResetNotification($token)
    {
        $this->notify(new CustomResetPasswordNotification($token));
    }

    public function roles()
    {
        return $this->belongsToMany(Role::class);
    }

    public function preferences()
    {
        return $this->hasOne(UserPreferences::class);
    }

    public function calendars()
    {
        return $this->hasMany(CalendarConnection::class);
    }

    public function primaryCalendar()
    {
        return $this->hasOne(CalendarConnection::class)->where('is_primary', true);
    }

    public function events()
    {
        return $this->hasMany(Event::class);
    }

    // New relationships for subscriptions
    public function subscriptions()
    {
        return $this->hasMany(Subscription::class);
    }

    public function activeSubscription()
    {
        return $this->subscriptions()
            ->where(function ($query) {
                $query->where('status', 'active')
                    ->where(function ($q) {
                        $q->whereNull('ends_at')
                            ->orWhere('ends_at', '>', now());
                    });
            })
            ->orWhere(function ($query) {
                $query->where('trial_ends_at', '>', now());
            })
            ->latest('created_at')
            ->first();
    }

    // Check if user has an active subscription
    public function hasActiveSubscription()
    {
        return (bool) $this->activeSubscription();
    }

    // Check if user is on a premium plan
    public function isPremium()
    {
        $subscription = $this->activeSubscription();
        
        if (!$subscription) {
            return false;
        }
        
        // Assuming 'premium' is a slug in your plans table
        return $subscription->plan->slug === 'premium';
    }

    // Get user's current plan
    public function currentPlan()
    {
        $subscription = $this->activeSubscription();
        
        if (!$subscription) {
            // Return the free plan if no active subscription
            return Plan::where('slug', 'free')->first();
        }
        
        return $subscription->plan;
    }

    // Check if user can perform an action based on their plan limits
    public function canUseFeature($featureKey, $usage = 1)
    {
        $plan = $this->currentPlan();
        
        if (!$plan) {
            return false;
        }
        
        $limit = $plan->getFeatureLimit($featureKey);
        
        // If limit is -1 or null, it means unlimited
        if ($limit === -1 || $limit === null) {
            return true;
        }
        
        // Check against current usage
        // You would need to implement usage tracking for this to work
        $currentUsage = $this->getFeatureUsage($featureKey);
        
        return ($currentUsage + $usage) <= $limit;
    }

    // Get current usage of a feature
    public function getFeatureUsage($featureKey)
    {
        return app(FeatureTrackingService::class)->getUsage($this, $featureKey);
    }

    // Helper method to create or retrieve a default calendar
    public function getOrCreateDefaultCalendar()
    {
        Log::info('------------get or create default calendar--------------');
        $defaultCalendar = $this->calendars()
            ->where('provider', 'default')
            ->first();
            
        if (!$defaultCalendar) {
            // Create a default calendar
            $defaultCalendar = $this->calendars()->create([
                'provider' => 'default',
                'name' => 'Maya Calendar',
                'is_primary' => !$this->calendars()->where('is_primary', true)->exists(),
                'is_active' => true,
            ]);
        }

        return $defaultCalendar;
    }

    /**
     * Get all calendar accounts for this user
     */
    public function calendarAccounts()
    {
        return $this->hasMany(CalendarAccount::class);
    }

    /**
     * Get all calendar accounts for this user
     */
    public function gmailAccount()
    {
        return $this->hasOne(GmailAccount::class);
    }

    /**
     * Find a calendar account by provider
     * 
     * @param string $provider
     * @return CalendarAccount|null
     */
    public function findCalendarAccountByProvider($provider)
    {
        return $this->calendarAccounts()
            ->where('provider', $provider)
            ->where('is_active', true)
            ->first();
    }
    
}