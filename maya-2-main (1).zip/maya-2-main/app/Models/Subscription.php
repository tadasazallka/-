<?php

namespace App\Models;

use App\Observers\SubscriptionObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'plan_id',
        'starts_at',
        'ends_at',
        'trial_ends_at',
        'status', // 'active', 'cancelled', 'expired'
        'payment_method',
        'payment_id', // Reference to external payment system
        'metadata'
    ];

    protected $casts = [
        'starts_at' => 'datetime',
        'ends_at' => 'datetime',
        'trial_ends_at' => 'datetime',
        'metadata' => 'array'
    ];

    protected static function booted()
    {
        static::observe(SubscriptionObserver::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function plan()
    {
        return $this->belongsTo(Plan::class);
    }

    // Check if subscription is active
    public function isActive()
    {
        // Active if:
        // - Status is 'active'
        // - Current time is between starts_at and ends_at (or ends_at is null for lifetime)
        // - Or trial is active
        
        return $this->status === 'active' &&
               ($this->starts_at === null || $this->starts_at->isPast()) &&
               ($this->ends_at === null || $this->ends_at->isFuture()) ||
               ($this->trial_ends_at !== null && $this->trial_ends_at->isFuture());
    }

    // Check if on trial
    public function onTrial()
    {
        return $this->trial_ends_at !== null && $this->trial_ends_at->isFuture();
    }

    // Check if cancelled
    public function cancelled()
    {
        return $this->status === 'cancelled';
    }

    // Check if expired
    public function expired()
    {
        return $this->ends_at !== null && $this->ends_at->isPast();
    }
}