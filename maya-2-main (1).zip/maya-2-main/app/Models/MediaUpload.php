<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MediaUpload extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'media_type',
        'public_id',
        'url',
        'metadata',
        'is_processed',
        'is_deleted',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'metadata' => 'array',
        'is_processed' => 'boolean',
        'is_deleted' => 'boolean',
    ];

    /**
     * Get the user that owns the media.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
    
    /**
     * Mark the media as processed
     */
    public function markAsProcessed(): self
    {
        $this->update(['is_processed' => true]);
        return $this;
    }
    
    /**
     * Mark the media as deleted from Cloudinary
     */
    public function markAsDeleted(): self
    {
        $this->update(['is_deleted' => true]);
        return $this;
    }
}