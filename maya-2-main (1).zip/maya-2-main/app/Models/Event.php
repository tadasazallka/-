<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id', 
        'calendar_connection_id', // Link to the calendar
        'title', 
        'description', 
        'start_time', 
        'end_time',
        'is_all_day',
        'location',
        'provider_event_id', // ID from external calendar if synced
        'status', // 'scheduled', 'cancelled', etc.
        'reminder',     // in minutes
        'reminder_sent', // Track if reminders were sent
        'created_via', // 'whatsapp', 'web', etc.
        'attendees', // Could be JSON for simple implementation
        'recurrence',
        'metadata' // Additional data as JSON
    ];

    protected $casts = [
        'is_all_day' => 'boolean',
        'start_time' => 'datetime',
        'end_time' => 'datetime',
        'reminder' => 'integer',
        'reminder_sent' => 'boolean',
        'attendees' => 'array',
        'recurrence' => 'array',
        'metadata' => 'array'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function calendar()
    {
        return $this->belongsTo(CalendarConnection::class, 'calendar_connection_id');
    }
    
    // Scope for upcoming events
    public function scopeUpcoming($query)
    {
        return $query->where('start_time', '>', now())
                     ->where('status', '!=', 'cancelled')
                     ->orderBy('start_time', 'asc');
    }
    
    // Scope for past events
    public function scopePast($query)
    {
        return $query->where('start_time', '<', now())
                     ->orderBy('start_time', 'desc');
    }

    /**
     * Scope for non-recurring events needing reminders
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeNeedingReminders($query)
    {
        return $query->where('reminder_sent', false)
                    ->where('status', '!=', 'cancelled')
                    ->whereNotNull('reminder')
                    ->whereNull('recurrence')  // Only non-recurring events
                    ->where(function ($query) {
                        $query->where('start_time', '>', now())
                            ->where('start_time', '<', now()->addDay());
                    });
    }

    /**
     * Scope for recurring events that might need reminders
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeRecurringEventsForReminders($query)
    {
        return $query->where('status', '!=', 'cancelled')
                    ->whereNotNull('reminder')
                    ->whereNotNull('recurrence')
                    ->where(function ($query) {
                        // Original event start is within the next week
                        // OR original event is in the past (could have future occurrences)
                        $query->where('start_time', '<', now()->addWeek());
                    });
    }

    /**
     * Check if a reminder is due for this event
     * 
     * @param string $occurrenceDate Optional specific date for recurring events
     * @return bool
     */
    public function isReminderDue($occurrenceDate = null)
    {
        if ($this->status === 'cancelled' || is_null($this->reminder)) {
            return false;
        }
        
        // For non-recurring events, check if reminder has been sent
        if (!$this->recurrence && $this->reminder_sent) {
            return false;
        }
        
        // For recurring events with a specific occurrence date
        if ($this->recurrence && $occurrenceDate) {
            // Check if we've already sent a reminder for this occurrence
            if ($this->hasOccurrenceBeenReminded($occurrenceDate)) {
                return false;
            }
        }
        
        $user = $this->user;
        $preferences = $user->preferences;
        
        // Calculate when the reminder should be sent
        if ($this->is_all_day) {
            // For all-day events, reminder is sent at (noon - all_day_event_alert) on the event day
            $minutesBefore = $preferences->all_day_event_alert ?? 60; // Default to 60 minutes
            
            if ($occurrenceDate) {
                $reminderTime = \Carbon\Carbon::parse($occurrenceDate . ' 12:00:00', 'UTC')
                                            ->subMinutes($minutesBefore);
            } else {
                $reminderTime = \Carbon\Carbon::parse($this->start_time->format('Y-m-d') . ' 12:00:00', 'UTC')
                                            ->subMinutes($minutesBefore);
            }
        } else {
            // For regular events, reminder is sent (start_time - reminder minutes)
            $minutesBefore = $this->reminder ?? $preferences->event_alert ?? 30; // Default to 30 minutes
            
            if ($occurrenceDate) {
                // Calculate the time for this specific occurrence
                $occurrenceTime = \Carbon\Carbon::parse($occurrenceDate . ' ' . $this->start_time->format('H:i:s'), 'UTC');
                $reminderTime = $occurrenceTime->copy()->subMinutes($minutesBefore);
            } else {
                $reminderTime = $this->start_time->copy()->subMinutes($minutesBefore);
            }
        }
        
        return now()->gte($reminderTime);
    }

    /**
     * Check if a reminder has been sent for a specific occurrence of a recurring event
     * 
     * @param string $occurrenceDate
     * @return bool
     */
    public function hasOccurrenceBeenReminded($occurrenceDate)
    {
        if (!$this->metadata || !isset($this->metadata['reminded_occurrences'])) {
            return false;
        }
        
        return in_array($occurrenceDate, $this->metadata['reminded_occurrences']);
    }

    /**
     * Get all upcoming occurrences of this recurring event
     * 
     * @param int $daysAhead Number of days to look ahead
     * @return array Array of dates (Y-m-d format)
     */
    public function getUpcomingOccurrences($daysAhead = 30)
    {
        if (!$this->recurrence || !is_array($this->recurrence)) {
            return [];
        }
        
        $frequency = $this->recurrence['frequency'] ?? null;
        $interval = $this->recurrence['interval'] ?? 1;
        $count = $this->recurrence['count'] ?? null;
        $until = $this->recurrence['until'] ?? null;
        
        if (!$frequency) {
            return [];
        }
        
        // Start from the original event date
        $startDate = $this->start_time->copy();
        
        // If the original event is in the past, start from today instead
        $today = \Carbon\Carbon::today('UTC');
        if ($startDate->lt($today)) {
            $startDate = $today;
        }
        
        // End date for our occurrence calculation
        $endDate = $today->copy()->addDays($daysAhead);
        
        // If 'until' is set and is before our end date, use it
        if ($until) {
            $untilDate = \Carbon\Carbon::parse($until, 'UTC');
            if ($untilDate->lt($endDate)) {
                $endDate = $untilDate;
            }
        }
        
        $occurrences = [];
        $currentDate = $startDate->copy();
        $occurrenceCount = 0;
        
        // Generate occurrences until we reach the end date or count limit
        while ($currentDate->lte($endDate) && (!$count || $occurrenceCount < $count)) {
            $occurrences[] = $currentDate->format('Y-m-d');
            
            // Move to the next occurrence based on frequency
            switch ($frequency) {
                case 'daily':
                    $currentDate->addDays($interval);
                    break;
                case 'weekly':
                    $currentDate->addWeeks($interval);
                    break;
                case 'monthly':
                    $currentDate->addMonths($interval);
                    break;
                case 'yearly':
                    $currentDate->addYears($interval);
                    break;
            }
            
            $occurrenceCount++;
        }
        
        return $occurrences;
    }

    /**
     * Get the formatted reminder time for display
     * 
     * @param string $timezone Optional timezone for formatting (defaults to user's timezone)
     * @param string $occurrenceDate Optional specific date for recurring events
     * @return string|null
     */
    public function getFormattedReminderTime($timezone = null, $occurrenceDate = null)
    {
        if (is_null($this->reminder) || $this->status === 'cancelled') {
            return null;
        }
        
        $user = $this->user;
        $userTz = $timezone ?? $user->timezone ?? 'UTC';
        $preferences = $user->preferences;
        
        // Calculate when the reminder should be sent
        if ($this->is_all_day) {
            $minutesBefore = $preferences->all_day_event_alert ?? 60;
            
            if ($occurrenceDate) {
                $reminderTime = \Carbon\Carbon::parse($occurrenceDate . ' 12:00:00', 'UTC')
                                            ->subMinutes($minutesBefore);
            } else {
                $reminderTime = \Carbon\Carbon::parse($this->start_time->format('Y-m-d') . ' 12:00:00', 'UTC')
                                            ->subMinutes($minutesBefore);
            }
        } else {
            $minutesBefore = $this->reminder ?? $preferences->event_alert ?? 30;
            
            if ($occurrenceDate) {
                $occurrenceTime = \Carbon\Carbon::parse($occurrenceDate . ' ' . $this->start_time->format('H:i:s'), 'UTC');
                $reminderTime = $occurrenceTime->copy()->subMinutes($minutesBefore);
            } else {
                $reminderTime = $this->start_time->copy()->subMinutes($minutesBefore);
            }
        }
        
        return $reminderTime->setTimezone($userTz)->format('Y-m-d H:i:s');
    }

    /**
     * Mark an occurrence as reminded in the metadata
     *
     * @param string $occurrenceDate
     * @return void
     */
    public function markOccurrenceAsReminded($occurrenceDate)
    {
        // Get the current metadata or initialize it
        $metadata = $this->metadata ?? [];
        
        // Get the list of reminded occurrences or initialize it
        $remindedOccurrences = $metadata['reminded_occurrences'] ?? [];
        
        // Add this occurrence to the list if not already there
        if (!in_array($occurrenceDate, $remindedOccurrences)) {
            $remindedOccurrences[] = $occurrenceDate;
        }
        
        // Update the metadata
        $metadata['reminded_occurrences'] = $remindedOccurrences;
        $this->metadata = $metadata;
        
        // Save the event
        $this->save();
    }
}