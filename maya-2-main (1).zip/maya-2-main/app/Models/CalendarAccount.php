<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CalendarAccount extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'provider',
        'account_id',
        'access_token',
        'refresh_token',
        'expires_at',
        'provider_metadata',
        'is_active'
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'provider_metadata' => 'array',
        'is_active' => 'boolean'
    ];

    public function getAccessTokenAttribute($value)
    {
        return $value ? decrypt($value) : null;
    }

    public function setAccessTokenAttribute($value)
    {
        $this->attributes['access_token'] = $value ? encrypt($value) : null;
    }

    public function getRefreshTokenAttribute($value)
    {
        return $value ? decrypt($value) : null;
    }

    public function setRefreshTokenAttribute($value)
    {
        $this->attributes['refresh_token'] = $value ? encrypt($value) : null;
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function calendars()
    {
        return $this->hasMany(CalendarConnection::class, 'calendar_account_id');
    }
}
