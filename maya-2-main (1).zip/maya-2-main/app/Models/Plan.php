<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Plan extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'slug',
        'description',
        'price',
        'interval',
        'features',
        'is_active',
        'sort_order',
        'stripe_product_id',
        'stripe_month_price_id',
        'stripe_year_price_id',
    ];

    protected $casts = [
        'features' => 'array',
        'is_active' => 'boolean',
        'price' => 'float'
    ];

    public function subscriptions()
    {
        return $this->hasMany(Subscription::class);
    }

    // Get the limit for a specific feature
    public function getFeatureLimit($featureKey)
    {
        if (!isset($this->features[$featureKey])) {
            return null;
        }
        
        return $this->features[$featureKey];
    }
}