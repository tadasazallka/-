<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FeatureUsage extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'feature',
        'usage',
        'period_start',
    ];

    protected $casts = [
        'period_start' => 'datetime',
        'usage' => 'integer',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}