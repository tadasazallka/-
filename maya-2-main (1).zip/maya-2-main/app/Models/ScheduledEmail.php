<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ScheduledEmail extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'to',
        'cc',
        'bcc',
        'subject',
        'body',
        'is_html',
        'headers',
        'scheduled_for',
        'status',
    ];

    protected $casts = [
        'is_html' => 'boolean',
        'is_sent' => 'boolean',
        'headers' => 'array',
        'scheduled_for' => 'datetime',
        'sent_at' => 'datetime',
    ];

    /**
     * Get the user that owns the scheduled email.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}