<?php
// app/Models/WeatherScheduleLog.php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class WeatherScheduleLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'weather_schedule_id',
        'sent_at',
        'weather_data',
        'status',
        'error_message',
    ];

    protected $casts = [
        'sent_at' => 'datetime',
        'weather_data' => 'array',
    ];

    public function weatherSchedule(): BelongsTo
    {
        return $this->belongsTo(WeatherSchedule::class);
    }
}