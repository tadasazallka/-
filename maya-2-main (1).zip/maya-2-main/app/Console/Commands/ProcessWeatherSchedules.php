<?php
// app/Console/Commands/ProcessWeatherSchedules.php

namespace App\Console\Commands;

use App\Services\WeatherScheduleService;
use Illuminate\Console\Command;

class ProcessWeatherSchedules extends Command
{
    protected $signature = 'weather:process-schedules';
    protected $description = 'Process due weather schedules and send updates via ManyChat';
    
    protected $weatherScheduleService;
    
    public function __construct(WeatherScheduleService $weatherScheduleService)
    {
        parent::__construct();
        $this->weatherScheduleService = $weatherScheduleService;
    }
    
    public function handle()
    {
        $this->info('Processing weather schedules via ManyChat...');
        
        try {
            $this->weatherScheduleService->processDueSchedules();
            $this->info('Weather schedules processed successfully via ManyChat.');
        } catch (\Exception $e) {
            $this->error('Error processing weather schedules: ' . $e->getMessage());
        }
    }
}