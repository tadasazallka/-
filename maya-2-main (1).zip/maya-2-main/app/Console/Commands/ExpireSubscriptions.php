<?php

namespace App\Console\Commands;

use App\Models\Subscription;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;

class ExpireSubscriptions extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:expire-subscriptions';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Mark expired subscriptions as expired';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('Starting to check for expired subscriptions...');

        try {
            // Find active subscriptions that have ended
            $expiredSubscriptions = Subscription::where('status', 'active')
                ->where('ends_at', '<', Carbon::now())
                ->get();

            if ($expiredSubscriptions->isEmpty()) {
                $this->info('No expired subscriptions found');
                return;
            }

            $this->info("Found {$expiredSubscriptions->count()} expired subscriptions");

            // Mark them as expired
            foreach ($expiredSubscriptions as $subscription) {
                $this->line("Marking subscription ID {$subscription->id} for user ID {$subscription->user_id} as expired");
                
                $subscription->update([
                    'status' => 'expired'
                ]);
            }

            $this->info('Successfully marked expired subscriptions');
        } catch (\Exception $e) {
            $errorMessage = 'Error marking expired subscriptions: ' . $e->getMessage();
            $this->error($errorMessage);
            Log::error($errorMessage);
        }
    }
}