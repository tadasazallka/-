<?php

namespace App\Console\Commands;

use App\Models\ScheduledEmail;
use App\Models\User;
use App\Services\Gmail\GmailService;
use Google_Service_Gmail_Message;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SendScheduledEmails extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'emails:send-scheduled';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send emails that were scheduled for delivery';

    /**
     * Execute the console command.
     */
    public function handle(GmailService $gmailService)
    {
        $this->info('Checking for scheduled emails...');
        
        // Get emails scheduled for delivery (up to current time)
        $scheduledEmails = ScheduledEmail::where('is_sent', false)
            ->where('status', 'pending')
            ->where('scheduled_for', '<=', now())
            ->get();
        
        $this->info("Found {$scheduledEmails->count()} emails to send.");
        
        foreach ($scheduledEmails as $email) {
            $this->info("Processing email ID: {$email->id}, To: {$email->to}, Subject: {$email->subject}");
            
            try {
                // Get the user
                $user = User::find($email->user_id);
                
                if (!$user || !$user->gmailAccount || !$user->gmailAccount->is_active) {
                    $this->warn("- Skipping: User {$email->user_id} has no active Gmail account");
                    $email->update([
                        'status' => 'failed',
                        'error' => 'User has no active Gmail account'
                    ]);
                    continue;
                }
                
                // Get Gmail service
                $service = $gmailService->getGmailService($user);
                
                // Create email
                $encodedEmail = $gmailService->createEmailRaw(
                    $email->headers,
                    $email->body,
                    $email->is_html
                );
                
                // Create a message object
                $message = new Google_Service_Gmail_Message();
                $message->setRaw($encodedEmail);
                
                // Send email
                $sent = $service->users_messages->send('me', $message);
                
                // Update email record
                $email->update([
                    'is_sent' => true,
                    'sent_at' => now(),
                    'status' => 'sent'
                ]);
                
                $this->info("- Email sent successfully, Gmail Message ID: {$sent->getId()}");
                
            } catch (\Exception $e) {
                $this->error("- Failed to send email: {$e->getMessage()}");
                
                // Update status to failed
                $email->update([
                    'status' => 'failed',
                    'error' => $e->getMessage()
                ]);
                
                Log::error('Failed to send scheduled email', [
                    'email_id' => $email->id,
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
            }
        }
        
        $this->info('Scheduled email processing completed.');
    }
}