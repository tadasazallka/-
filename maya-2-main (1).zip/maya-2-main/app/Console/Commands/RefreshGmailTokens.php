<?php

namespace App\Console\Commands;

use App\Models\GmailAccount;
use App\Services\Gmail\GmailService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class RefreshGmailTokens extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'gmail:refresh-tokens {--minutes=60 : Minutes before expiration to refresh tokens}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Proactively refresh Gmail tokens that will expire soon';

    /**
     * The Gmail service instance.
     *
     * @var GmailService
     */
    protected $gmailService;

    /**
     * Create a new command instance.
     *
     * @param GmailService $gmailService
     * @return void
     */
    public function __construct(GmailService $gmailService)
    {
        parent::__construct();
        $this->gmailService = $gmailService;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $minutes = $this->option('minutes');
        $this->info("Starting proactive refresh of Gmail tokens expiring within $minutes minutes");
        
        // Find accounts with tokens expiring soon
        $expiresBeforeTime = Carbon::now()->addMinutes($minutes);
        
        $accounts = GmailAccount::where('is_active', true)
            ->where('token_expires_at', '<=', $expiresBeforeTime)
            ->get();
            
        $this->info("Found {$accounts->count()} Gmail accounts with tokens expiring soon");
        
        $successCount = 0;
        $failureCount = 0;
        
        foreach ($accounts as $account) {
            try {
                $this->info("Processing account #{$account->id} for user #{$account->user_id}");
                
                // Store original expiration time for logging
                $originalExpiryTime = $account->token_expires_at ? $account->token_expires_at->format('Y-m-d H:i:s') : 'unknown';
                
                // Refresh the token using the existing GmailService method
                $refreshedAccount = $this->gmailService->refreshToken($account);
                
                // Check if refresh was successful by comparing expiration times
                if ($refreshedAccount->token_expires_at && 
                    (!$account->token_expires_at || $refreshedAccount->token_expires_at->gt($account->token_expires_at))) {
                    
                    $newExpiryTime = $refreshedAccount->token_expires_at->format('Y-m-d H:i:s');
                    $this->info("Successfully refreshed token. New expiry: $newExpiryTime (was: $originalExpiryTime)");
                    $successCount++;
                } else {
                    $this->warn("Token refresh completed but expiry time did not change");
                    $failureCount++;
                }
            } catch (\Exception $e) {
                $this->error("Failed to refresh token for account #{$account->id}: " . $e->getMessage());
                Log::error('Gmail token refresh failed', [
                    'account_id' => $account->id,
                    'user_id' => $account->user_id,
                    'error' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
                $failureCount++;
            }
        }
        
        $this->info("Completed Gmail token refresh process");
        $this->info("Results: $successCount successful, $failureCount failed");
        
        return 0;
    }
}