<?php

namespace App\Console\Commands;

use App\Models\Event;
use Carbon\Carbon;
use Illuminate\Console\Command;

// app/Console/Commands/ResetRecurringEventReminders.php
class ResetRecurringEventReminders extends Command
{
    protected $signature = 'app:reset-recurring-event-reminders';
    
    public function handle()
    {
        // Find recurring events with reminder_sent = true
        $recurringEvents = Event::where('reminder_sent', true)
            ->whereNotNull('recurrence')
            ->whereNotNull('reminder')
            ->where('status', '!=', 'cancelled')
            ->get();
            
        foreach ($recurringEvents as $event) {
            // Get next occurrence
            $occurrences = $event->getUpcomingOccurrences(7); // Check next 7 days
            
            if (!empty($occurrences)) {
                $nextOccurrence = Carbon::parse($occurrences[0] . ' ' . $event->start_time->format('H:i:s'));
                
                // If next occurrence needs a reminder, reset the flag
                if ($nextOccurrence->gt(now())) {
                    $event->update(['reminder_sent' => false]);
                    $this->info("Reset reminder for recurring event ID: {$event->id}");
                }
            }
        }
    }
}
