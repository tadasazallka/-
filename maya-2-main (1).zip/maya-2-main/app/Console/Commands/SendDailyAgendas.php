<?php

namespace App\Console\Commands;

use App\Models\Event;
use App\Models\User;
use App\Resources\WhatsappMessages;
use App\Services\FeatureTrackingService;
use App\Services\TimezoneService;
use App\Services\ManyChatAPIService;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Log;

class SendDailyAgendas extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:send-daily-agendas';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send daily agenda of events to users according to their preferences';

    /**
     * TTL for Redis keys tracking agenda sends (seconds)
     * 
     * @var int
     */
    protected const REDIS_TTL = 86400; // 24 hours

    /**
     * Execute the console command.
     */
    public function handle(
        FeatureTrackingService $featureTracker, 
        ManyChatAPIService $manyChatService,
        TimezoneService $timezoneService
    ) {
        $this->info('Starting to send daily agendas via ManyChat...');

        // Get all users with ManyChat subscriber IDs and eager load their preferences
        $users = User::whereNotNull('manychat_subscriber_id')
                      ->with('preferences')
                      ->get();
                      
        $this->info("Found {$users->count()} users with ManyChat subscriber IDs");
        
        $sendCount = 0;
        $errorCount = 0;
        $skipCount = 0;

        foreach ($users as $user) {
            try {
                // Skip users who don't have timezone set
                if (empty($user->timezone)) {
                    $this->warn("User ID {$user->id} doesn't have a timezone set. Skipping agenda.");
                    $skipCount++;
                    continue;
                }
                
                // Skip users who haven't enabled daily agenda in their preferences
                if (!$user->preferences || !$user->preferences->daily_agenda_overview) {
                    $this->info("User ID {$user->id} hasn't enabled daily agenda overview. Skipping.");
                    $skipCount++;
                    continue;
                }
                
                // Skip users who can't use this feature based on their plan
                if (!$featureTracker->canUseFeature($user, 'daily_agenda')) {
                    $this->warn("User ID {$user->id} doesn't have access to daily agenda in their plan. Skipping.");
                    $skipCount++;
                    continue;
                }
                
                // Get current time in user's timezone
                $userNow = $timezoneService->nowUserTime($user->timezone);
                
                // Calculate when to send the agenda
                // Default to 30 minutes before noon if all_day_event_alert is not set
                $allDayAlertMinutes = $user->preferences->all_day_event_alert ?? 30;
                
                // Calculate noon today in user's timezone
                $userNoonToday = Carbon::create(
                    $userNow->year, $userNow->month, $userNow->day, 12, 0, 0, $user->timezone
                );
                
                // Calculate the agenda send time (noon minus alert minutes)
                $agendaSendTime = $userNoonToday->copy()->subMinutes($allDayAlertMinutes);
                
                // Get the current date for the user's timezone
                $todayDate = $userNow->format('Y-m-d');
                
                // Check if it's time to send the agenda (within a 5-minute window)
                $timeDiff = $userNow->diffInMinutes($agendaSendTime, false);
                if ($timeDiff < 0 || $timeDiff > 5) {
                    // Not time to send yet, or the time has passed by more than 5 minutes
                    continue;
                }
                
                // Check if we've already sent an agenda to this user today
                // Use the date in user's timezone for the Redis key
                $redisKey = "daily_agenda:{$user->id}:{$todayDate}";
                if (Redis::exists($redisKey)) {
                    $this->info("User ID {$user->id} already received agenda for {$todayDate}. Skipping.");
                    $skipCount++;
                    continue;
                }
                
                // Get all events for today in user's timezone
                $todayStart = Carbon::parse($todayDate . ' 00:00:00', $user->timezone);
                $todayEnd = Carbon::parse($todayDate . ' 23:59:59', $user->timezone);
                
                // Convert to UTC for database query
                $todayStartUtc = $timezoneService->userToUTC($todayStart, $user->timezone);
                $todayEndUtc = $timezoneService->userToUTC($todayEnd, $user->timezone);
                
                // Get events for today that aren't cancelled
                $events = Event::where('user_id', $user->id)
                    ->where('status', '!=', 'cancelled')
                    ->where(function ($query) use ($todayStartUtc, $todayEndUtc) {
                        // Events that start today
                        $query->whereBetween('start_time', [$todayStartUtc, $todayEndUtc])
                            // Or all-day events that occur today
                            ->orWhere(function ($query) use ($todayStartUtc, $todayEndUtc) {
                                $query->where('is_all_day', true)
                                    ->where('start_time', '<=', $todayEndUtc)
                                    ->where(function ($query) use ($todayStartUtc) {
                                        $query->whereNull('end_time')
                                            ->orWhere('end_time', '>=', $todayStartUtc);
                                    });
                            });
                    })
                    ->orderBy('start_time')
                    ->with('calendar')
                    ->get();
                
                // Even if no events, still send a message (saying there are no events)
                $message = $this->formatAgendaMessage($events, $user, $todayDate, $timezoneService);
                
                // Send the message via ManyChat
                $sent = $manyChatService->sendWhatsAppMessage($user->manychat_subscriber_id, $message);
                
                if ($sent) {
                    // Mark as sent in Redis with 24-hour expiration
                    Redis::setex($redisKey, self::REDIS_TTL, 1);
                    
                    // Track usage
                    $featureTracker->recordUsage($user, 'daily_agenda');
                    
                    $this->info("Sent daily agenda to user ID {$user->id} for {$todayDate} via ManyChat");
                    $sendCount++;
                } else {
                    $this->warn("Failed to send daily agenda to user ID {$user->id} via ManyChat");
                    $errorCount++;
                }
                
            } catch (\Exception $e) {
                $this->error("Error sending agenda to user ID {$user->id}: " . $e->getMessage());
                Log::error("Daily agenda error for user {$user->id}: " . $e->getMessage(), [
                    'trace' => $e->getTraceAsString()
                ]);
                $errorCount++;
            }
        }

        $this->info("Daily agenda process completed: {$sendCount} sent, {$skipCount} skipped, {$errorCount} errors");
    }
    
    /**
     * Format the agenda message with all events
     * 
     * @param \Illuminate\Support\Collection $events
     * @param User $user
     * @param string $todayDate
     * @param TimezoneService $timezoneService
     * @return string
     */
    protected function formatAgendaMessage($events, User $user, $todayDate, TimezoneService $timezoneService)
    {
        // Get user's preferred language (default to English if not set)
        $language = $user->preferences ? $user->preferences->language ?? 'en' : 'en';
        
        // Different title formats based on language
        $titleFormats = [
            'en' => "🗓️ *Your Agenda for {date}*",
            'he' => "🗓️ *סדר היום שלך ל-{date}*",
            'ur' => "🗓️ *{date} کے لیے آپ کا ایجنڈا*"
        ];
        
        // Different section headers based on language
        $sectionHeaders = [
            'en' => [
                'allDay' => "*All-day Events:*",
                'scheduled' => "*Scheduled Events:*",
                'noEvents' => "You have no events scheduled for today.",
                'footer' => "Have a great day! Reply with any changes you'd like to make to your schedule."
            ],
            'he' => [
                'allDay' => "*אירועים כל היום:*",
                'scheduled' => "*אירועים מתוזמנים:*",
                'noEvents' => "אין לך אירועים מתוכננים להיום.",
                'footer' => "שיהיה לך יום נהדר! השב עם כל שינוי שתרצה לבצע בלוח הזמנים שלך."
            ],
            'ur' => [
                'allDay' => "*پورے دن کے ایونٹس:*",
                'scheduled' => "*شیڈول شدہ ایونٹس:*",
                'noEvents' => "آج کے لیے آپ کا کوئی ایونٹ شیڈول نہیں ہے۔",
                'footer' => "آپ کا دن اچھا گزرے! اپنے شیڈول میں کوئی تبدیلی کرنا چاہتے ہیں تو جواب دیں۔"
            ]
        ];
        
        // Use default English if language not supported
        $titleFormat = $titleFormats[$language] ?? $titleFormats['en'];
        $headers = $sectionHeaders[$language] ?? $sectionHeaders['en'];
        
        // Format the date according to the user's language
        $formattedDate = Carbon::parse($todayDate)->locale($language)->format('l, F j, Y');
        $title = str_replace('{date}', $formattedDate, $titleFormat);
        
        $message = $title . "\n\n";
        
        // If no events, return a simple message
        if ($events->isEmpty()) {
            return $message . $headers['noEvents'] . "\n\n" . $headers['footer'];
        }
        
        $allDayEvents = $events->filter(function ($event) {
            return $event->is_all_day;
        });
        
        $timedEvents = $events->filter(function ($event) {
            return !$event->is_all_day;
        });
        
        // Add all-day events first
        if ($allDayEvents->isNotEmpty()) {
            $message .= $headers['allDay'] . "\n";
            
            foreach ($allDayEvents as $event) {
                $message .= "• {$event->title}";
                
                if (!empty($event->location)) {
                    $message .= " 📍 {$event->location}";
                }
                
                $message .= "\n";
            }
            
            $message .= "\n";
        }
        
        // Add timed events
        if ($timedEvents->isNotEmpty()) {
            $message .= $headers['scheduled'] . "\n";
            
            foreach ($timedEvents as $event) {
                // Format time in user's timezone
                $startTime = $timezoneService->utcToUser($event->start_time, $user->timezone)
                    ->format('g:i A');
                
                $endTime = null;
                if ($event->end_time) {
                    $endTime = $timezoneService->utcToUser($event->end_time, $user->timezone)
                        ->format('g:i A');
                }
                
                // Add the event
                $message .= "• {$startTime}";
                if ($endTime) {
                    $message .= " - {$endTime}";
                }
                
                $message .= ": {$event->title}";
                
                if (!empty($event->location)) {
                    $message .= " 📍 {$event->location}";
                }
                
                $message .= "\n";
            }
        }
        
        // Add helpful footer
        $message .= "\n" . $headers['footer'];
        
        return $message;
    }
}