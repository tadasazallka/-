<?php

namespace App\Console\Commands;

use App\Services\Calendars\Sync\GoogleCalendarSyncService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class RefreshGoogleChannelsCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'calendar:refresh-google-channels';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Refresh Google Calendar notification channels that are about to expire';

    /**
     * Google Calendar Sync Service
     * 
     * @var GoogleCalendarSyncService
     */
    protected $googleSyncService;

    /**
     * Create a new command instance.
     *
     * @param GoogleCalendarSyncService $googleSyncService
     * @return void
     */
    public function __construct(GoogleCalendarSyncService $googleSyncService)
    {
        parent::__construct();
        $this->googleSyncService = $googleSyncService;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('Refreshing Google Calendar notification channels...');
        
        try {
            $refreshed = $this->googleSyncService->refreshNotificationChannels();
            
            $this->info("Successfully refreshed {$refreshed} notification channels.");
            
            return 0;
        } catch (\Exception $e) {
            $this->error('Error refreshing notification channels: ' . $e->getMessage());
            
            Log::error('Error refreshing Google Calendar notification channels', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return 1;
        }
    }
}