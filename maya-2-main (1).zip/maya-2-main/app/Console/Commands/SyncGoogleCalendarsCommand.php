<?php

namespace App\Console\Commands;

use App\Services\Calendars\Sync\GoogleCalendarSyncService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SyncGoogleCalendarsCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'calendar:sync-google 
                            {--refresh-channels : Refresh notification channels that are about to expire}
                            {--force : Force a full sync regardless of last sync time}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Synchronize Google Calendars for all users';

    /**
     * Google Calendar Sync Service
     * 
     * @var GoogleCalendarSyncService
     */
    protected $googleSyncService;

    /**
     * Create a new command instance.
     *
     * @param GoogleCalendarSyncService $googleSyncService
     * @return void
     */
    public function __construct(GoogleCalendarSyncService $googleSyncService)
    {
        parent::__construct();
        $this->googleSyncService = $googleSyncService;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('Starting Google Calendar synchronization...');
        
        // Check if we need to refresh notification channels
        if ($this->option('refresh-channels')) {
            $this->info('Refreshing notification channels...');
            $refreshed = $this->googleSyncService->refreshNotificationChannels();
            $this->info("Refreshed {$refreshed} notification channels.");
        }
        
        // Sync all calendars
        $this->info('Synchronizing calendars...');
        $stats = $this->googleSyncService->syncAllCalendars();
        
        $this->info('Synchronization completed:');
        $this->table(
            ['Metric', 'Count'],
            [
                ['Calendars Processed', $stats['calendars_processed']],
                ['Successful Syncs', $stats['successes']],
                ['Failed Syncs', $stats['failures']],
                ['Events Created', $stats['events_created']],
                ['Events Updated', $stats['events_updated']],
                ['Events Deleted', $stats['events_deleted']],
            ]
        );
        
        return 0;
    }
}