<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class MonitorSystemPerformance extends Command
{
    protected $signature = 'monitor:performance {--duration=300} {--interval=5}';
    protected $description = 'Monitor system performance during load testing';

    public function handle()
    {
        $duration = $this->option('duration');
        $interval = $this->option('interval');
        $startTime = time();
        $endTime = $startTime + $duration;
        
        $this->info("Starting performance monitoring for {$duration} seconds...");
        
        $metricsData = [];
        
        while (time() < $endTime) {
            $currentTime = time();
            $metrics = $this->collectMetrics();
            
            $metricsData[] = array_merge(['timestamp' => $currentTime], $metrics);
            
            $this->displayMetrics($metrics);
            
            sleep($interval);
        }
        
        $this->generateReport($metricsData);
    }

    protected function collectMetrics(): array
    {
        $metrics = [
            'memory_usage_mb' => round(memory_get_usage(true) / 1024 / 1024, 2),
            'memory_peak_mb' => round(memory_get_peak_usage(true) / 1024 / 1024, 2),
            'redis_connections' => $this->getRedisConnections(),
            'database_connections' => $this->getDatabaseConnections(),
            'total_queued_messages' => $this->getTotalQueuedMessages(),
            'active_users' => $this->getActiveUsers(),
            'redis_memory_usage' => $this->getRedisMemoryUsage(),
            'job_queue_size' => $this->getJobQueueSize(),
            'processed_messages_rate' => $this->getProcessedMessagesRate(),
        ];

        return $metrics;
    }

    protected function getRedisConnections(): int
    {
        try {
            $info = Redis::info();
            return (int) ($info['connected_clients'] ?? 0);
        } catch (\Exception $e) {
            return 0;
        }
    }

    protected function getDatabaseConnections(): int
    {
        try {
            $connections = DB::select("SHOW PROCESSLIST");
            return count($connections);
        } catch (\Exception $e) {
            return 0;
        }
    }

    protected function getTotalQueuedMessages(): int
    {
        try {
            $keys = Redis::keys('whatsapp:message_queue:*');
            $total = 0;
            
            foreach ($keys as $key) {
                $total += Redis::llen($key);
            }
            
            return $total;
        } catch (\Exception $e) {
            return 0;
        }
    }

    protected function getActiveUsers(): int
    {
        try {
            $keys = Redis::keys('whatsapp:message_queue:*');
            return count($keys);
        } catch (\Exception $e) {
            return 0;
        }
    }

    protected function getRedisMemoryUsage(): string
    {
        try {
            $info = Redis::info('memory');
            return $info['used_memory_human'] ?? 'Unknown';
        } catch (\Exception $e) {
            return 'Unknown';
        }
    }

    protected function getJobQueueSize(): int
    {
        try {
            return (int) Redis::llen('queues:default');
        } catch (\Exception $e) {
            return 0;
        }
    }

    protected function getProcessedMessagesRate(): float
    {
        static $lastCount = 0;
        static $lastTime = 0;
        
        $currentTime = time();
        $currentCount = $this->getProcessedMessageCount();
        
        if ($lastTime === 0) {
            $lastTime = $currentTime;
            $lastCount = $currentCount;
            return 0.0;
        }
        
        $timeDiff = $currentTime - $lastTime;
        $countDiff = $currentCount - $lastCount;
        
        $rate = $timeDiff > 0 ? $countDiff / $timeDiff : 0;
        
        $lastTime = $currentTime;
        $lastCount = $currentCount;
        
        return round($rate, 2);
    }

    protected function getProcessedMessageCount(): int
    {
        try {
            $keys = Redis::keys('whatsapp:processed:*');
            return count($keys);
        } catch (\Exception $e) {
            return 0;
        }
    }

    protected function displayMetrics(array $metrics): void
    {
        $this->info("\n" . str_repeat("=", 80));
        $this->info("Performance Metrics - " . date('Y-m-d H:i:s'));
        $this->info(str_repeat("=", 80));
        
        $this->table([
            'Metric', 'Value'
        ], [
            ['Memory Usage (MB)', $metrics['memory_usage_mb']],
            ['Memory Peak (MB)', $metrics['memory_peak_mb']],
            ['Redis Connections', $metrics['redis_connections']],
            ['DB Connections', $metrics['database_connections']],
            ['Queued Messages', $metrics['total_queued_messages']],
            ['Active Users', $metrics['active_users']],
            ['Redis Memory', $metrics['redis_memory_usage']],
            ['Job Queue Size', $metrics['job_queue_size']],
            ['Processing Rate (msg/s)', $metrics['processed_messages_rate']],
        ]);
    }

    protected function generateReport(array $metricsData): void
    {
        if (empty($metricsData)) {
            return;
        }

        $this->info("\n" . str_repeat("=", 80));
        $this->info("PERFORMANCE REPORT SUMMARY");
        $this->info(str_repeat("=", 80));

        // Calculate averages, peaks, etc.
        $memoryUsages = array_column($metricsData, 'memory_usage_mb');
        $queueSizes = array_column($metricsData, 'total_queued_messages');
        $processingRates = array_column($metricsData, 'processed_messages_rate');

        $summary = [
            ['Average Memory Usage (MB)', round(array_sum($memoryUsages) / count($memoryUsages), 2)],
            ['Peak Memory Usage (MB)', max($memoryUsages)],
            ['Max Queue Size', max($queueSizes)],
            ['Average Processing Rate (msg/s)', round(array_sum($processingRates) / count($processingRates), 2)],
            ['Peak Processing Rate (msg/s)', max($processingRates)],
            ['Total Data Points', count($metricsData)],
        ];

        $this->table(['Metric', 'Value'], $summary);

        // Save detailed report to file
        $reportFile = storage_path('logs/performance_report_' . date('Y-m-d_H-i-s') . '.json');
        file_put_contents($reportFile, json_encode($metricsData, JSON_PRETTY_PRINT));
        
        $this->info("\nDetailed report saved to: {$reportFile}");
    }
}