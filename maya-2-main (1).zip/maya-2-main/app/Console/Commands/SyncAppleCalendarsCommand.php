<?php

namespace App\Console\Commands;

use App\Services\Calendars\Sync\AppleCalendarSyncService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SyncAppleCalendarsCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'calendar:sync-apple {--force : Force a full sync regardless of last sync time}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Synchronize Apple Calendars for all users';

    /**
     * Apple Calendar Sync Service
     * 
     * @var AppleCalendarSyncService
     */
    protected $appleSyncService;

    /**
     * Create a new command instance.
     *
     * @param AppleCalendarSyncService $appleSyncService
     * @return void
     */
    public function __construct(AppleCalendarSyncService $appleSyncService)
    {
        parent::__construct();
        $this->appleSyncService = $appleSyncService;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('Starting Apple Calendar synchronization...');
        
        try {
            // Sync all calendars
            $stats = $this->appleSyncService->syncAllCalendars();
            
            $this->info('Synchronization completed:');
            $this->table(
                ['Metric', 'Count'],
                [
                    ['Calendars Processed', $stats['calendars_processed']],
                    ['Successful Syncs', $stats['successes']],
                    ['Failed Syncs', $stats['failures']],
                    ['Events Created', $stats['events_created']],
                    ['Events Updated', $stats['events_updated']],
                    ['Events Deleted', $stats['events_deleted']],
                ]
            );
            
            return 0;
            
        } catch (\Exception $e) {
            $this->error('Error synchronizing Apple Calendars: ' . $e->getMessage());
            
            Log::error('Error in Apple Calendar sync command', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return 1;
        }
    }
}