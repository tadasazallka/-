<?php

namespace App\Console\Commands;

use App\Services\FeatureTrackingService;
use Illuminate\Console\Command;

class ResetFeatureTracking extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:reset-feature-tracking';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Reset feature usage tracking for expired periods';

    /**
     * Execute the console command.
     */
    public function handle(FeatureTrackingService $featureTrackingService)
    {
        $this->info('Starting to reset expired feature tracking periods...');

        try {
            $featureTrackingService->resetExpiredPeriods();
            $this->info('Feature tracking periods reset successfully');
        } catch (\Exception $e) {
            $this->error('Error resetting feature tracking periods: ' . $e->getMessage());
        }
    }
}