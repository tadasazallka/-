<?php

namespace App\Console\Commands;

use App\Models\Event;
use App\Models\User;
use App\Resources\WhatsappMessages;
use App\Services\FeatureTrackingService;
use App\Services\ManyChatAPIService;
use Illuminate\Console\Command;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class SendEventReminders extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:send-event-reminders';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send WhatsApp reminders for upcoming events via ManyChat, including missed reminders from the last 24 hours';

    /**
     * Execute the console command.
     */
    public function handle(
        FeatureTrackingService $featureTracker, 
        ManyChatAPIService $manyChatService
    )
    {
        $this->info('Starting to send event reminders via ManyChat...');
        
        // Get current time in UTC
        $nowUTC = now();
        Log::info("Current time in UTC: " . $nowUTC->toDateTimeString());
        
        // Process all events that need reminders
        $this->processEvents($featureTracker, $manyChatService, $nowUTC);
        
        $this->info('Event reminder process completed');
    }
    
    /**
     * Process events that need reminders
     */
    private function processEvents(
        FeatureTrackingService $featureTracker,
        ManyChatAPIService $manyChatService,
        $nowUTC
    ) {
        // Process standard events
        $this->processStandardEvents($featureTracker, $manyChatService, $nowUTC);
        
        // Process all-day events
        $this->processAllDayEvents($featureTracker, $manyChatService, $nowUTC);
    }
    
    /**
     * Process standard (non all-day) events
     */
    private function processStandardEvents(
        FeatureTrackingService $featureTracker,
        ManyChatAPIService $manyChatService,
        $nowUTC
    ) {
        $this->info('Processing standard events...');
        
        // Find all non-all-day events that:
        // 1. Haven't had reminders sent
        // 2. Aren't cancelled
        // 3. Have a reminder setting
        // 4. Start within the next day
        $events = Event::where('is_all_day', false)
                    ->where('reminder_sent', false)
                    ->where('status', '!=', 'cancelled')
                    ->whereNotNull('reminder')
                    ->where('start_time', '>', $nowUTC->copy()->subDay())
                    ->where('start_time', '<', $nowUTC->copy()->addDay())
                    ->with(['user', 'user.preferences', 'calendar'])
                    ->get();
        
        Log::info("Found {$events->count()} standard events to check for reminders");
        
        foreach ($events as $event) {
            // Calculate when the reminder should be sent
            $reminderTime = $event->start_time->copy()->subMinutes($event->reminder);
            
            // Check if it's time to send the reminder (now or missed within last 24 hours)
            // Within 5 minutes window for upcoming reminders OR
            // Missed reminders from the last 24 hours
            $minutesUntilReminder = $nowUTC->diffInMinutes($reminderTime, false);
            $shouldSendReminder = ($minutesUntilReminder >= 0 && $minutesUntilReminder <= 5) || 
                                 ($minutesUntilReminder < 0 && $minutesUntilReminder > -1440);
            
            if ($shouldSendReminder) {
                $this->sendEventReminder($event, $featureTracker, $manyChatService, $nowUTC, $minutesUntilReminder);
            }
        }
    }
    
    /**
     * Process all-day events
     */
    private function processAllDayEvents(
        FeatureTrackingService $featureTracker,
        ManyChatAPIService $manyChatService,
        $nowUTC
    ) {
        $this->info('Processing all-day events...');
        
        // Find all all-day events from today and tomorrow (to cover all time zones)
        $events = Event::where('is_all_day', true)
                    ->where('reminder_sent', false)
                    ->where('status', '!=', 'cancelled')
                    ->whereNotNull('reminder')
                    ->where('start_time', '>=', $nowUTC->copy()->subDay()->startOfDay())
                    ->where('start_time', '<=', $nowUTC->copy()->addDay()->endOfDay())
                    ->with(['user', 'user.preferences', 'calendar'])
                    ->get();
        
        Log::info("Found {$events->count()} all-day events to check for reminders");
        
        foreach ($events as $event) {
            $user = $event->user;
            
            // Skip if user doesn't have ManyChat subscriber ID
            if (empty($user->manychat_subscriber_id)) {
                continue;
            }
            
            // Skip if user has disabled notifications
            if ($user->preferences && !$user->preferences->event_notifications) {
                continue;
            }
            
            // For all-day events, reminders are sent at a fixed time before noon on the event day
            // Get the minutes before from the user preferences or use a default
            $minutesBefore = $event->reminder ?? 
                            ($user->preferences->all_day_event_alert ?? 60);
            
            // Calculate noon on the event day (in UTC since all times are stored in UTC)
            $eventDay = Carbon::parse($event->start_time->format('Y-m-d') . ' 12:00:00', 'UTC');
            $reminderTime = $eventDay->copy()->subMinutes($minutesBefore);
            
            // Check if it's time to send the reminder
            $minutesUntilReminder = $nowUTC->diffInMinutes($reminderTime, false);
            $shouldSendReminder = ($minutesUntilReminder >= 0 && $minutesUntilReminder <= 5) || 
                                 ($minutesUntilReminder < 0 && $minutesUntilReminder > -1440);
            
            if ($shouldSendReminder) {
                $this->sendEventReminder($event, $featureTracker, $manyChatService, $nowUTC, $minutesUntilReminder);
            }
        }
    }
    
    /**
     * Send a reminder for a specific event
     */
    private function sendEventReminder(
        Event $event,
        FeatureTrackingService $featureTracker,
        ManyChatAPIService $manyChatService,
        $nowUTC,
        $minutesUntilReminder
    ) {
        $user = $event->user;
        
        // Skip if user doesn't have ManyChat subscriber ID
        if (empty($user->manychat_subscriber_id)) {
            Log::info("Skipping event ID {$event->id}: user has no ManyChat subscriber ID");
            return;
        }
        
        // Skip if user has disabled notifications
        if ($user->preferences && !$user->preferences->event_notifications) {
            Log::info("Skipping event ID {$event->id}: user has disabled event notifications");
            return;
        }
        
        // Check if user can send reminders based on their plan
        if (!$featureTracker->canUseFeature($user, 'whatsapp_reminders')) {
            Log::warning("User ID {$user->id} has reached their reminder limit. Skipping event ID {$event->id}.");
            return;
        }
        
        try {
            // Get user's timezone (default to UTC if not set)
            $userTimezone = $user->timezone ?? 'UTC';
            
            // Convert event time to user's timezone for display purposes
            $eventTimeInUserTz = $event->start_time->copy()->setTimezone($userTimezone);
            
            // Check if event is in the past
            $isPastEvent = $event->start_time->isPast();
            
            // Format event time according to user's timezone
            $eventTimeFormatted = $event->is_all_day 
                ? $eventTimeInUserTz->format('l, F j, Y') . ' (All day)'
                : $eventTimeInUserTz->format('l, F j, Y \a\t g:i A');
            
            // Get user's preferred language
            $language = $user->preferences ? $user->preferences->language ?? 'en' : 'en';
            
            // Prepare event data for message formatting
            $eventData = [
                'title' => $event->title,
                'time' => $eventTimeFormatted,
                'location' => $event->location,
                'description' => $event->description
            ];
            
            // Generate the reminder message
            $message = WhatsappMessages::formatEventReminderMessage($eventData, $language);
            
            // Add a note for past events
            if ($isPastEvent) {
                $pastNote = $language === 'he' ? 
                    "\n\n⚠️ שים לב: אירוע זה כבר התחיל." : 
                    ($language === 'ur' ? 
                        "\n\n⚠️ نوٹ: یہ ایونٹ پہلے سے شروع ہو چکا ہے۔" : 
                        "\n\n⚠️ Note: This event has already started.");
                
                $message .= $pastNote;
                Log::info("Sending a late reminder for past event: {$event->id}, User: {$user->id}");
            }
            
            // Send the reminder via ManyChat
            $sent = $manyChatService->sendWhatsAppMessage($user->manychat_subscriber_id, $message);
            
            if ($sent) {
                // Record that we sent the reminder
                $event->update(['reminder_sent' => true]);
                
                // Track usage
                $featureTracker->recordUsage($user, 'whatsapp_reminders');
                
                $allDayText = $event->is_all_day ? "all-day " : "";
                $status = $isPastEvent ? "late " : "";
                $this->info("Sent {$status}{$allDayText}reminder for event ID {$event->id} to user ID {$user->id} in {$language} via ManyChat");
                Log::info("Successfully sent {$status}{$allDayText}reminder for event ID {$event->id} to user ID {$user->id} via ManyChat");
            } else {
                Log::warning("Failed to send reminder for event ID {$event->id} to user ID {$user->id} via ManyChat");
            }
            
        } catch (\Exception $e) {
            $this->error("Error sending reminder for event ID {$event->id}: " . $e->getMessage());
            Log::error("Error sending reminder for event ID {$event->id}: " . $e->getMessage(), [
                'exception' => $e,
                'event_id' => $event->id,
                'user_id' => $user->id,
                'stack_trace' => $e->getTraceAsString()
            ]);
        }
    }
}