<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class OpenAIService
{
    protected $apiKey;
    protected $baseUrl;
    protected $model;
    
    public function __construct()
    {
        $this->apiKey = config('services.openai.api_key');
        $this->baseUrl = config('services.openai.base_url', 'https://api.openai.com/v1');
        $this->model = config('services.openai.vision_model', 'gpt-4-turbo');
    }
    
    /**
     * Generate a response using OpenAI's chat completion API
     */
    public function generateResponse(array $messages, array $options = []): ?string
    {
        try {
            // Default options
            $defaultOptions = [
                'model' => $this->model,
                'temperature' => 0.7,
                'max_tokens' => 500,
            ];
            
            // Merge with provided options, with provided options taking precedence
            $finalOptions = array_merge($defaultOptions, $options);
            
            // Add messages separately
            $finalOptions['messages'] = $messages;
            
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
            ])->post($this->baseUrl . '/chat/completions', $finalOptions);
            
            if ($response->successful()) {
                $responseData = $response->json();
                return $responseData['choices'][0]['message']['content'] ?? null;
            } else {
                Log::error('OpenAI API error: ' . $response->body());
                return null;
            }
        } catch (\Exception $e) {
            Log::error('Failed to get response from OpenAI: ' . $e->getMessage());
            return null;
        }
    }
        
    /**
     * Transcribe audio to text using OpenAI's whisper API with Cloudinary URL
     */
    public function transcribeAudio(string $audioUrl): ?string
    {
        try {
            // Download the file from Cloudinary
            $audioContent = Http::get($audioUrl)->body();
            
            if (!$audioContent) {
                Log::error('Failed to download audio from Cloudinary URL: ' . $audioUrl);
                return null;
            }
            
            // Create a temporary file
            $tempFile = tempnam(sys_get_temp_dir(), 'audio');
            $tempFileWithExt = $tempFile . '.mp3';
            rename($tempFile, $tempFileWithExt);
            
            // Write the audio content to the temp file
            file_put_contents($tempFileWithExt, $audioContent);
            
            // Send to OpenAI Whisper API
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
            ])->attach(
                'file', file_get_contents($tempFileWithExt), 'audio.mp3'
            )->post($this->baseUrl . '/audio/transcriptions', [
                'model' => 'whisper-1',
            ]);
            
            // Clean up the temp file
            @unlink($tempFileWithExt);
            
            if ($response->successful()) {
                $responseData = $response->json();
                return $responseData['text'] ?? null;
            } else {
                Log::error('OpenAI Whisper API error: ' . $response->body());
                return null;
            }
        } catch (\Exception $e) {
            Log::error('Failed to transcribe audio: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Extract text from an image using OpenAI's vision API with Cloudinary URL
     */
    public function extractTextFromImage(string $imageUrl): ?string
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
            ])->post($this->baseUrl . '/chat/completions', [
                'model' => $this->model,
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => [
                            [
                                'type' => 'text',
                                'text' => 'Extract all the text content from this image. If there are details about an event (dates, times, location, title), please format them as follows:
                                
                                Event Title: [title]
                                Date: [date]
                                Time: [start time] - [end time]
                                Location: [location]
                                
                                If any information is missing, just omit that line. If this is not an event, just extract all visible text.',
                            ],
                            [
                                'type' => 'image_url',
                                'image_url' => [
                                    'url' => $imageUrl,
                                ],
                            ],
                        ],
                    ],
                ],
                'max_tokens' => 500,
            ]);
            
            if ($response->successful()) {
                $responseData = $response->json();
                return $responseData['choices'][0]['message']['content'] ?? null;
            } else {
                Log::error('OpenAI Vision API error: ' . $response->body());
                return null;
            }
        } catch (\Exception $e) {
            Log::error('Failed to extract text from image: ' . $e->getMessage());
            return null;
        }
    }
    
}