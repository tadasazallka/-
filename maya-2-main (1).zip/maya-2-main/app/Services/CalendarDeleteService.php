<?php

namespace App\Services;

use App\Models\Event;
use App\Services\Calendars\CalendarProviderFactory;
use App\Services\TimezoneService;
use Illuminate\Support\Facades\Log;

class CalendarDeleteService
{
    protected $calendarProviderFactory;
    protected $timezoneService;
    
    public function __construct(
        CalendarProviderFactory $calendarProviderFactory,
        TimezoneService $timezoneService
    ) {
        $this->calendarProviderFactory = $calendarProviderFactory;
        $this->timezoneService = $timezoneService;
    }
    
   
    /**
     * Delete an event from both our database and the provider's calendar
     * 
     * @param Event $event The event to delete
     * @param bool $deleteRecurringInstances Whether to delete all instances of recurring events
     * @return bool Success or failure
     */
    public function deleteEvent(Event $event, bool $deleteRecurringInstances = false): bool
    {
        try {
            Log::info('Deleting event', [
                'event_id' => $event->id,
                'title' => $event->title,
                'start_time_utc' => $event->start_time->toIso8601String(),
                'end_time_utc' => $event->end_time->toIso8601String()
            ]);
            
            // Get user's timezone for logging purposes
            $userTz = $event->user->timezone ?? 'UTC';
            
            // First, delete from provider's calendar if applicable
            if ($event->calendar && $event->provider_event_id) {
                $calendarProvider = $this->calendarProviderFactory->getProvider($event->calendar);
                
                $deleteOptions = [];
                if ($deleteRecurringInstances) {
                    $deleteOptions['delete_recurring_instances'] = true;
                }
                
                // Delete from provider's system
                if (!$calendarProvider->deleteEventById($event->calendar, $event, $deleteOptions)) {
                    Log::warning('Failed to delete event from provider calendar', [
                        'event_id' => $event->id,
                        'provider' => $event->calendar->provider
                    ]);
                    // We'll still try to delete from our database
                }
            }
            
            // Delete from our database
            $event->delete();
            
            Log::info('Successfully deleted event', [
                'event_id' => $event->id,
                'title' => $event->title
            ]);
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('Failed to delete event: ' . $e->getMessage(), [
                'exception' => $e,
                'trace' => $e->getTraceAsString(),
                'event_id' => $event->id ?? 'unknown'
            ]);
            return false;
        }
    }
}