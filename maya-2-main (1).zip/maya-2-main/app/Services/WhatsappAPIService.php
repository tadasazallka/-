<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class WhatsappAPIService
{

    protected $token;
    protected $phoneNumberId;

    public function __construct()
    {
        $this->token = 'EAAOn9GVypjMBOZBkIlbARhT0O1iswZB2UjFAMOjI9ZBsZCo5s1V6k3taOuYSZBV8CBPMTrABlQqMCu3XQhf7WSKZBoNqqcr5ssNNKuSpafSfLPZA2NcbLZAZAFWOSbKGUEM3E5u0QvYR3xMO1Oj3NTqdjjKeZAET5Hht32usJElteZB9p2OZBY5gPJXXuZCOAyLFlxujuYyMYb5mgXyqhydPWh2Y0WABecZBdF71sZD';
        // Log::info('whatsapp token'. $this->token);
        $this->phoneNumberId = "602078976333041";
    }

    function sendWhatsAppMessage($to, $message) {

        // if (app()->environment('testing') || request()->has('test_mode')) {
        //     Log::info('Sending WhatsApp message in test mode', [
        //         'to' => $to,
        //         'message' => $message
        //     ]);
            
        //     return [
        //         'success' => true,
        //         'test_mode' => true,
        //         'message_id' => 'test_' . uniqid(),
        //         'recipient' => $to,
        //         'content' => $message
        //     ];
        // }
    
        Log::info('message sent -------------->>>>>>>>>>  '.$message);
        $response = Http::withToken($this->token)->post("https://graph.facebook.com/v23.0/{$this->phoneNumberId}/messages", [
            "messaging_product" => "whatsapp",
            "to" => $to,
            "type" => "text",
            "text" => ["body" => $message],
        ]);

        return $response->json();
    }


    public function downloadMedia($mediaId)
    {
        try {
            
            // Step 1: Get the media URL
            $response = Http::withToken($this->token)
                ->get("https://graph.facebook.com/v22.0/{$mediaId}");
            
            if (!$response->successful()) {
                Log::error('Failed to get media URL', [
                    'media_id' => $mediaId,
                    'response' => $response->json()
                ]);
                return null;
            }
            
            $mediaData = $response->json();
            $mediaUrl = $mediaData['url'] ?? null;
            
            if (!$mediaUrl) {
                Log::error('Media URL not found in response', [
                    'media_id' => $mediaId,
                    'response' => $mediaData
                ]);
                return null;
            }
            
            // Step 2: Download the actual media using the URL
            $mediaResponse = Http::withToken($this->token)->get($mediaUrl);
            
            if (!$mediaResponse->successful()) {
                Log::error('Failed to download media content', [
                    'media_id' => $mediaId,
                    'media_url' => $mediaUrl,
                    'response' => $mediaResponse->status()
                ]);
                return null;
            }
            
            return $mediaResponse->body();
        } catch (\Exception $e) {
            Log::error('Error downloading media: ' . $e->getMessage(), [
                'media_id' => $mediaId
            ]);
            return null;
        }
    }

}