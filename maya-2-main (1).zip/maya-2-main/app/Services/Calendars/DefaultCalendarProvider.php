<?php

namespace App\Services\Calendars;

use App\Models\CalendarConnection;
use App\Models\Event;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Carbon;

class DefaultCalendarProvider implements CalendarProviderInterface
{
    /**
     * Create an event in the default calendar
     * For default calendar, we create a more complete implementation to handle all data properly
     * 
     * @param CalendarConnection $calendar
     * @param array $eventData
     * @return array|null [provider_event_id, provider_metadata]
     */
    public function createEvent(CalendarConnection $calendar, array $eventData): ?array
    {
        Log::info('Default Calendar: Creating Event', [
            'calendar_id' => $calendar->id, 
            'title' => $eventData['title'],
            'start_time' => $eventData['start_time']->format('Y-m-d H:i:s')
        ]);
        
        // Generate a unique identifier for the event in our system
        $localEventId = 'default_' . uniqid();
        
        // Extract timezone information
        $userTimezone = $eventData['metadata']['user_timezone'] ?? 'UTC';
        
        // Create metadata with all the necessary information
        $metadata = [
            'created_at' => now()->timestamp,
            'type' => 'default',
            'local_id' => $localEventId,
            'calendar_name' => $calendar->name ?? 'Default Calendar',
            'user_timezone' => $userTimezone,
            'is_all_day' => $eventData['is_all_day'] ?? false,
            'start_timezone' => $eventData['start_time']->tzName,
            'end_timezone' => $eventData['end_time']->tzName
        ];
        
        // Add Google Meet data if requested
        $googleMeetLink = null;
        if (!empty($eventData['add_google_meet'])) {
            $metadata['has_google_meet'] = false;
            $metadata['google_meet_error'] = 'Google Meet is not available with default calendar';
        }
        
        // Handle attendees if provided
        if (!empty($eventData['attendees'])) {
            $metadata['attendees_count'] = count($eventData['attendees']);
        }
        
        // Handle reminders if provided
        if (!empty($eventData['reminders'])) {
            $metadata['reminders'] = $eventData['reminders'];
        }
        
        // Handle recurrence if provided
        if (!empty($eventData['recurrence'])) {
            $metadata['recurrence'] = $eventData['recurrence'];
        }

        return [
            'provider_event_id' => $localEventId,
            'provider_metadata' => $metadata,
            'google_meet_link' => $googleMeetLink
        ];
    }

    /**
     * Delete an event from the default calendar
     * 
     * @param CalendarConnection $calendar
     * @param Event $event
     * @return array|null
     */
    public function deleteEventById(CalendarConnection $calendar, Event $event): ?array
    {
        Log::info('Default Calendar: Deleting event', [
            'calendar_id' => $calendar->id,
            'event_id' => $event->id,
            'event_title' => $event->title
        ]);
        
        // For default calendar, just return success since the actual deletion
        // will be handled by the CalendarDeleteService in the database
        return [
            'success' => true,
            'provider_metadata' => [
                'deleted_at' => now()->timestamp,
                'type' => 'default'
            ]
        ];
    }

    /**
     * Update an event in the default calendar
     * 
     * @param CalendarConnection $calendar
     * @param Event $event
     * @param array $updateData Optional array of fields to update
     * @return array|null
     */
    public function updateEventById(CalendarConnection $calendar, Event $event, array $updateData = []): ?array
    {
        Log::info('Default Calendar: Updating event', [
            'calendar_id' => $calendar->id,
            'event_id' => $event->id,
            'event_title' => $event->title
        ]);
        
        // Get existing metadata or initialize new array
        $existingMetadata = $event->metadata['provider_metadata'] ?? [];
        
        // Create updated metadata
        $metadata = array_merge($existingMetadata, [
            'updated_at' => now()->timestamp,
            'type' => 'default',
            'calendar_name' => $calendar->name ?? 'Default Calendar'
        ]);
        
        // Extract timezone information
        $userTimezone = $event->metadata['user_timezone'] ?? 'UTC';
        $metadata['user_timezone'] = $userTimezone;
        $metadata['start_timezone'] = $event->start_time->tzName;
        $metadata['end_timezone'] = $event->end_time->tzName;
        
        // Update Google Meet data if requested
        $googleMeetLink = null;
        if (!empty($updateData['add_google_meet'])) {
            $metadata['has_google_meet'] = false;
            $metadata['google_meet_error'] = 'Google Meet is not available with default calendar';
        }
        
        // Handle attendees if modified
        if (isset($updateData['attendees'])) {
            $metadata['attendees_count'] = count($updateData['attendees']);
        } elseif (isset($event->attendees)) {
            $metadata['attendees_count'] = count($event->attendees);
        }
        
        // Use the existing provider_event_id or generate a new one if missing
        $providerId = $event->provider_event_id ?? ('default_' . uniqid());
        
        return [
            'provider_event_id' => $providerId,
            'provider_metadata' => $metadata,
            'google_meet_link' => $googleMeetLink
        ];
    }
    
    /**
     * No token to refresh for default calendar
     * 
     * @param CalendarConnection $calendar
     * @return bool
     */
    public function refreshAccessTokenIfNeeded(CalendarConnection $calendar): bool
    {
        // Default calendar doesn't need authentication
        return true;
    }
}