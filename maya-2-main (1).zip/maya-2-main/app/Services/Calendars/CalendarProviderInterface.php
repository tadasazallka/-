<?php

namespace App\Services\Calendars;

use App\Models\Event;
use App\Models\CalendarConnection;
use Carbon\Carbon;

interface CalendarProviderInterface
{
   
     /**
     * Create an event in the provider's calendar
     * 
     * @param CalendarConnection $calendar
     * @param array $eventData
     * @return array|null [provider_event_id, provider_metadata]
     */
    public function createEvent(CalendarConnection $calendar, array $eventData): ?array;
    
    public function deleteEventById(CalendarConnection $calendar, Event $event): ?array;

    public function updateEventById(CalendarConnection $calendar, Event $event): ?array;

    public function refreshAccessTokenIfNeeded(CalendarConnection $calendar): bool;
}