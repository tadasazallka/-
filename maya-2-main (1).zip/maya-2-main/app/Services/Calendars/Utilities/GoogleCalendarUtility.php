<?php

namespace App\Services\Calendars\Utilities;

use App\Models\CalendarAccount;
use App\Models\CalendarConnection;
use Carbon\Carbon;
use Google_Client;
use Google_Service_Calendar;
use Illuminate\Support\Facades\Log;

class GoogleCalendarUtility
{
    /**
     * Initialize a Google API client with default configuration
     * 
     * @return Google_Client
     */
    public static function createGoogleClient(): Google_Client
    {
        $client = new Google_Client();
        $client->setClientId(config('services.google.client_id'));
        $client->setClientSecret(config('services.google.client_secret'));
        $client->setScopes([Google_Service_Calendar::CALENDAR, Google_Service_Calendar::CALENDAR_EVENTS]);
        $client->setAccessType('offline');
        $client->setApplicationName(config('services.google.app_name', 'Calendar App'));
        
        return $client;
    }

    /**
     * Set up authentication for the Google API client
     * 
     * @param Google_Client $client
     * @param CalendarAccount $account
     * @return bool
     */
    public static function setupAuthentication(Google_Client $client, CalendarAccount $account): bool
    {
        try {
            // Set up token data
            $tokenData = [
                'access_token' => $account->access_token,
                'refresh_token' => $account->refresh_token,
                'expires_in' => $account->expires_at ? Carbon::now()->diffInSeconds($account->expires_at) : 3600
            ];
            
            $client->setAccessToken($tokenData);
            
            // Refresh token if needed
            if ($client->isAccessTokenExpired()) {
                Log::info('Google Calendar: Refreshing access token', [
                    'account_id' => $account->id
                ]);
                
                $newToken = $client->fetchAccessTokenWithRefreshToken();
                
                if (isset($newToken['error'])) {
                    throw new \Exception('Failed to refresh token: ' . $newToken['error']);
                }
                
                // Update account with new token data
                $account->access_token = $newToken['access_token'];
                if (isset($newToken['refresh_token'])) {
                    $account->refresh_token = $newToken['refresh_token'];
                }
                
                $expiresIn = $newToken['expires_in'] ?? 3600;
                $account->expires_at = Carbon::now()->addSeconds($expiresIn);
                $account->save();
                
                Log::info('Google Calendar: Access token refreshed', [
                    'account_id' => $account->id
                ]);
            }
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('Google Calendar: Failed to set up authentication', [
                'account_id' => $account->id,
                'error' => $e->getMessage()
            ]);
            
            return false;
        }
    }

    /**
     * Build a recurrence rule (RRULE) string for Google Calendar
     * 
     * @param array $recurrence
     * @return string|null
     */
    public static function buildRecurrenceRule(array $recurrence): ?string
    {
        if (empty($recurrence['frequency'])) {
            return null;
        }
        
        $freq = strtoupper($recurrence['frequency']); // DAILY, WEEKLY, MONTHLY, YEARLY
        $rrule = "RRULE:FREQ={$freq}";
        
        // Add interval if provided
        if (!empty($recurrence['interval']) && $recurrence['interval'] > 1) {
            $rrule .= ";INTERVAL=" . $recurrence['interval'];
        }
        
        // Add count if provided
        if (!empty($recurrence['count'])) {
            $rrule .= ";COUNT=" . $recurrence['count'];
        }
        
        // Add until date if provided
        if (!empty($recurrence['until'])) {
            try {
                $untilDate = Carbon::parse($recurrence['until'])->format('Ymd\THis\Z');
                $rrule .= ";UNTIL=" . $untilDate;
            } catch (\Exception $e) {
                Log::warning('Google Calendar: Invalid until date in recurrence', [
                    'until' => $recurrence['until'],
                    'error' => $e->getMessage()
                ]);
            }
        }
        
        // Add BYDAY if provided (for day-of-week recurrences)
        if (!empty($recurrence['byday'])) {
            $rrule .= ";BYDAY=" . $recurrence['byday'];
        }
        
        // Add BYMONTHDAY if provided (for day-of-month recurrences)
        if (!empty($recurrence['bymonthday'])) {
            $rrule .= ";BYMONTHDAY=" . $recurrence['bymonthday'];
        }
        
        // Add BYMONTH if provided (for month-of-year recurrences)
        if (!empty($recurrence['bymonth'])) {
            $rrule .= ";BYMONTH=" . $recurrence['bymonth'];
        }
        
        return $rrule;
    }
    
    /**
     * Parse Google Calendar recurrence rule into our format
     * 
     * @param array $recurrenceRules
     * @return array|null
     */
    public static function parseGoogleRecurrence(array $recurrenceRules): ?array
    {
        foreach ($recurrenceRules as $rule) {
            if (strpos($rule, 'RRULE:') === 0) {
                // Remove the 'RRULE:' prefix
                $ruleContent = substr($rule, 6);
                
                // Split the rule into parts
                $ruleParts = explode(';', $ruleContent);
                $ruleData = [];
                
                // Parse each rule part
                foreach ($ruleParts as $part) {
                    $keyValue = explode('=', $part);
                    if (count($keyValue) === 2) {
                        $ruleData[$keyValue[0]] = $keyValue[1];
                    }
                }
                
                // Check for frequency
                if (!isset($ruleData['FREQ'])) {
                    continue;
                }
                
                $frequency = strtolower($ruleData['FREQ']);
                
                // Map Google's frequency to our format
                $frequencyMap = [
                    'daily' => 'daily',
                    'weekly' => 'weekly',
                    'monthly' => 'monthly',
                    'yearly' => 'yearly'
                ];
                
                if (!isset($frequencyMap[$frequency])) {
                    continue; // Skip unsupported frequencies
                }
                
                $recurrence = [
                    'frequency' => $frequencyMap[$frequency],
                    'interval' => isset($ruleData['INTERVAL']) ? (int)$ruleData['INTERVAL'] : 1,
                ];
                
                // Handle COUNT
                if (!empty($ruleData['COUNT'])) {
                    $recurrence['count'] = (int)$ruleData['COUNT'];
                }
                
                // Handle UNTIL
                if (!empty($ruleData['UNTIL'])) {
                    // Convert from iCal format (20240630T150000Z) to Y-m-d
                    $untilDate = Carbon::createFromFormat('Ymd\THis\Z', $ruleData['UNTIL']);
                    $recurrence['until'] = $untilDate->format('Y-m-d');
                }
                
                // Handle BYDAY (for day-of-week recurrences)
                if (!empty($ruleData['BYDAY'])) {
                    $recurrence['byday'] = $ruleData['BYDAY'];
                }
                
                // Handle BYMONTHDAY (for day-of-month recurrences)
                if (!empty($ruleData['BYMONTHDAY'])) {
                    $recurrence['bymonthday'] = $ruleData['BYMONTHDAY'];
                }
                
                // Handle BYMONTH (for month-of-year recurrences)
                if (!empty($ruleData['BYMONTH'])) {
                    $recurrence['bymonth'] = $ruleData['BYMONTH'];
                }
                
                return $recurrence;
            }
        }
        
        return null;
    }
    
    /**
     * Extract timezone information from event data
     * 
     * @param object $start Google event start time
     * @param object $end Google event end time
     * @return string
     */
    public static function extractTimezone($start, $end): string
    {
        // First try to get timezone from the event
        if (!empty($start->timeZone)) {
            return $start->timeZone;
        }
        
        if (!empty($end->timeZone)) {
            return $end->timeZone;
        }
        
        // Default to UTC if no timezone info is available
        return 'UTC';
    }
    
    /**
     * Get sync parameters for Google Calendar API
     * 
     * @param CalendarConnection $calendar
     * @return array
     */
    public static function getSyncParameters(CalendarConnection $calendar): array
    {
        $metadata = $calendar->provider_metadata ?: [];
        
        // If we have a sync token, use it
        if (!empty($metadata['sync']['token'])) {
            return [
                'syncToken' => $metadata['sync']['token'],
                'maxResults' => 100, // Increased from 100 to handle more events
                // 'singleEvents' => false, // Keep as false to get recurring events as master events
                'fields' => 'nextPageToken,nextSyncToken,items(id,status,summary,description,location,start,end,recurrence,recurringEventId,extendedProperties)'
            ];
        }
        
        // Otherwise, use timeMin based on last sync or a default (1 month ago)
        $lastSync = !empty($metadata['sync']['last_sync'])
            ? Carbon::createFromTimestamp($metadata['sync']['last_sync'])
            : Carbon::now()->subMonth();
        
        return [
            'timeMin' => $lastSync->toRfc3339String(),
            'maxResults' => 100, // Increased from 100
            // 'singleEvents' => false, // Keep as false to get recurring events as master events
            'orderBy' => 'updated',
            'fields' => 'nextPageToken,nextSyncToken,items(id,status,summary,description,location,start,end,recurrence,recurringEventId,extendedProperties)'
        ];
    }
}