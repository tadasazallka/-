<?php

namespace App\Services\Calendars;

use App\Models\CalendarConnection;
use App\Models\Event;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Exception;
use GuzzleHttp\Client as HttpClient;
use Sabre\DAV\Client as DavClient;
use Sabre\VObject\Component\VCalendar;
use Sabre\VObject\Reader;

class AppleCalendarProvider implements CalendarProviderInterface
{
    protected $httpClient;
    
    // iCloud CalDAV endpoint
    protected const ICLOUD_CALDAV_URL = 'https://caldav.icloud.com';
    
    /**
     * Initialize the HTTP client
     */
    public function __construct()
    {
        $this->httpClient = new HttpClient([
            'timeout' => 30,
            'connect_timeout' => 10,
            'verify' => true
        ]);
    }
    
    /**
     * Create a CalDAV client instance for iCloud
     * 
     * @param CalendarConnection $calendar
     * @return DavClient
     */
    protected function getDavClient(CalendarConnection $calendar): DavClient
    {
        $settings = $this->getCalendarSettings($calendar);
        
        return new DavClient([
            'baseUri' => $settings['base_url'],
            'userName' => $settings['apple_id'],
            'password' => $settings['app_password'],
            'authType' => DavClient::AUTH_BASIC
        ]);
    }
    
    /**
     * Get calendar settings from the connection and account metadata
     * 
     * @param CalendarConnection $calendar
     * @return array
     * @throws Exception
     */
    protected function getCalendarSettings(CalendarConnection $calendar): array
    {
        // Get calendar account
        $calendarAccount = $calendar->calendarAccount;
        
        if (!$calendarAccount) {
            throw new Exception('Calendar account not found for this calendar connection');
        }
        
        $accountMetadata = $calendarAccount->provider_metadata ?? [];
        $connectionMetadata = $calendar->provider_metadata ?? [];
        
        // Check for required fields
        if (empty($calendarAccount->account_id) || empty($calendarAccount->access_token)) {
            throw new Exception('Missing required Apple Calendar settings in calendar account');
        }

        return [
            'base_url' => self::ICLOUD_CALDAV_URL,
            'apple_id' => $calendarAccount->account_id,
            'app_password' => $calendarAccount->access_token, // App password is stored in the account's access_token
            'calendar_path' => $connectionMetadata['calendar_path'] ?? $calendar->provider_calendar_id,
            'principal_url' => $accountMetadata['principal_url'] ?? null,
        ];
    }

    /**
     * Helper method to construct event URL
     * 
     * @param string $calendarPath
     * @param string $eventId
     * @return string
     */
    protected function getEventUrl(string $calendarPath, string $eventId): string
    {
        if (!str_ends_with($calendarPath, '/')) {
            $calendarPath .= '/';
        }
        
        return $calendarPath . $eventId . '.ics';
    }
    
    /**
     * Helper method to set event timezone properties
     * 
     * @param mixed $vevent The VEVENT component
     * @param Carbon $startTime
     * @param Carbon $endTime
     */
    protected function setEventTimezones($vevent, Carbon $startTime, Carbon $endTime): void
    {
        // Get timezone information
        $startTz = $startTime->tzName;
        $endTz = $endTime->tzName;
        
        // Add start time with timezone
        $dtstart = $vevent->add('DTSTART');
        $dtstart->setValue($startTime->format('Ymd\THis'));
        if ($startTz) {
            $dtstart->add('TZID', $startTz);
        }
        
        // Add end time with timezone
        $dtend = $vevent->add('DTEND');
        $dtend->setValue($endTime->format('Ymd\THis'));
        if ($endTz) {
            $dtend->add('TZID', $endTz);
        }
    }
    
    /**
     * Create VCalendar object for an event
     * 
     * @param array $eventData
     * @return array Contains VCalendar object and eventUid
     */
    protected function createVCalendarForEvent(array $eventData): array
    {
        // Generate a unique ID for the event
        $uuid = Str::uuid()->toString();
        $eventUid = $uuid . '@' . (config('app.name', 'maya') . '.com');
        
        // Create iCalendar object
        $vcalendar = new VCalendar();
        
        // Add the event with basic properties
        $vevent = $vcalendar->add('VEVENT', [
            'SUMMARY' => $eventData['title'],
            'UID' => $eventUid,
            'DTSTAMP' => gmdate('Ymd\THis\Z'),
            'CREATED' => gmdate('Ymd\THis\Z'),
        ]);
        
        // Add event description if available
        if (!empty($eventData['description'])) {
            $vevent->add('DESCRIPTION', $eventData['description']);
        }
        
        // Add location if available
        if (!empty($eventData['location'])) {
            $vevent->add('LOCATION', $eventData['location']);
        }
        
        // Store user's timezone in event metadata for reference
        if (!empty($eventData['metadata']['user_timezone'])) {
            $vevent->add('X-USER-TIMEZONE', $eventData['metadata']['user_timezone']);
        }
        
        // Clone Carbon instances to avoid modifying the original objects
        $startTime = clone $eventData['start_time'];
        $endTime = clone $eventData['end_time'];
        
        // Check if this is an all-day event
        if (!empty($eventData['is_all_day'])) {
            // For all-day events, use DATE values without time component
            $dtstart = $vevent->add('DTSTART', $startTime->format('Ymd'));
            $dtstart->add('VALUE', 'DATE');
            
            // For all-day events, the end date should be the day after the last day
            // (per iCalendar spec)
            $dtend = $vevent->add('DTEND', $endTime->addDay()->format('Ymd'));
            $dtend->add('VALUE', 'DATE');
        } else {
            // For regular events, set timezone information
            $this->setEventTimezones($vevent, $startTime, $endTime);
        }
        
        // Add recurrence rule if available
        if (!empty($eventData['recurrence'])) {
            $recurrence = $eventData['recurrence'];
            
            if (is_array($recurrence) && !empty($recurrence['frequency'])) {
                $rruleStr = 'FREQ=' . strtoupper($recurrence['frequency']);
                
                // Add optional recurrence parameters
                if (!empty($recurrence['interval'])) {
                    $rruleStr .= ';INTERVAL=' . $recurrence['interval'];
                }
                
                if (!empty($recurrence['count'])) {
                    $rruleStr .= ';COUNT=' . $recurrence['count'];
                }
                
                if (!empty($recurrence['until'])) {
                    // Format the until date properly
                    if ($recurrence['until'] instanceof Carbon) {
                        $untilDate = $recurrence['until']->format('Ymd\THis\Z');
                    } else {
                        $untilDate = Carbon::parse($recurrence['until'])->format('Ymd\THis\Z');
                    }
                    $rruleStr .= ';UNTIL=' . $untilDate;
                }
                
                if (!empty($recurrence['days']) && is_array($recurrence['days'])) {
                    $rruleStr .= ';BYDAY=' . implode(',', array_map('strtoupper', $recurrence['days']));
                }
                
                $vevent->add('RRULE', $rruleStr);
            }
        }
        
        // Add attendees if available
        if (!empty($eventData['attendees']) && is_array($eventData['attendees'])) {
            foreach ($eventData['attendees'] as $attendee) {
                if (empty($attendee['email'])) {
                    continue;
                }
                
                $attendeeProps = [
                    'PARTSTAT' => 'NEEDS-ACTION',
                    'RSVP' => 'TRUE',
                    'ROLE' => 'REQ-PARTICIPANT',
                    'CUTYPE' => 'INDIVIDUAL'
                ];
                
                // Add attendee name if available
                if (!empty($attendee['name'])) {
                    $attendeeProps['CN'] = $attendee['name'];
                }
                
                $vevent->add('ATTENDEE', 'mailto:' . $attendee['email'], $attendeeProps);
            }
        }
        
        // Add reminders if available
        if (!empty($eventData['reminders']) && is_array($eventData['reminders'])) {
            foreach ($eventData['reminders'] as $reminder) {
                if (empty($reminder['minutes'])) {
                    continue;
                }
                
                $valarm = $vevent->add('VALARM', [
                    'ACTION' => 'DISPLAY',
                    'DESCRIPTION' => $eventData['title'],
                    'TRIGGER' => '-PT' . $reminder['minutes'] . 'M'
                ]);
            }
        }
        
        return [
            'vcalendar' => $vcalendar,
            'event_uid' => $eventUid
        ];
    }
    
    /**
     * Process CalDAV response and prepare result
     * 
     * @param array $response DAV client response
     * @param string $action Type of action (create, update, delete)
     * @param array $additionalData Additional data to include in result
     * @return array|null
     */
    protected function processCalDavResponse(array $response, string $action, array $additionalData = []): ?array
    {
        $isSuccess = $response['statusCode'] >= 200 && $response['statusCode'] < 300;
        
        if ($isSuccess) {
            Log::info("Apple Calendar: Event {$action}d successfully", $additionalData);
            
            $result = [];
            
            if (isset($additionalData['provider_event_id'])) {
                $result['provider_event_id'] = $additionalData['provider_event_id'];
            }
            
            // Add metadata based on action type
            $metadata = [
                "{$action}d_at" => now()->timestamp
            ];
            
            if (isset($additionalData['caldav_url'])) {
                $metadata['caldav_url'] = $additionalData['caldav_url'];
            }
            
            if (isset($response['headers']['etag'][0])) {
                $metadata['etag'] = $response['headers']['etag'][0];
            }
            
            $result['provider_metadata'] = $metadata;
            
            if ($action === 'delete') {
                $result['success'] = true;
            }
            
            return $result;
        } else {
            Log::error("Apple Calendar: Failed to {$action} event", [
                'status_code' => $response['statusCode'],
                'response' => $response['body'] ?? null,
                'context' => $additionalData
            ]);
            
            return null;
        }
    }
    
    /**
     * Execute a CalDAV operation with error handling
     * 
     * @param string $operation Description of the operation
     * @param callable $callback The operation to execute
     * @param array $context Context data for logging
     * @return array|null
     */
    protected function executeCalDavOperation(string $operation, callable $callback, array $context = []): ?array
    {
        try {
            Log::info("Apple Calendar: {$operation} via CalDAV", $context);
            return $callback();
        } catch (Exception $e) {
            Log::error("Apple Calendar: Error {$operation}", [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'context' => $context
            ]);
            
            return null;
        }
    }

    /**
     * Create an event in Apple Calendar via CalDAV
     * 
     * @param CalendarConnection $calendar
     * @param array $eventData
     * @return array|null [provider_event_id, provider_metadata]
     */
    public function createEvent(CalendarConnection $calendar, array $eventData): ?array
    {
        return $this->executeCalDavOperation('creating event', function() use ($calendar, $eventData) {
            $settings = $this->getCalendarSettings($calendar);
            $davClient = $this->getDavClient($calendar);
            
            // Create VCalendar object
            $vcalendarData = $this->createVCalendarForEvent($eventData);
            $vcalendar = $vcalendarData['vcalendar'];
            $eventUid = $vcalendarData['event_uid'];
            
            // Determine the URL where the event will be stored
            $eventUrl = $this->getEventUrl($settings['calendar_path'], $eventUid);
            
            // Convert to iCalendar string
            $icalData = $vcalendar->serialize();
            
            Log::debug('iCalendar data being sent:', ['data' => $icalData]);
            
            // Send the event to the CalDAV server
            $response = $davClient->request('PUT', $eventUrl, $icalData, [
                'Content-Type' => 'text/calendar; charset=utf-8',
                'If-None-Match' => '*' // Ensure we don't overwrite existing events
            ]);
            
            return $this->processCalDavResponse($response, 'create', [
                'provider_event_id' => $eventUid,
                'caldav_url' => $eventUrl,
                'calendar_id' => $calendar->id,
                'event_title' => $eventData['title']
            ]);
        }, [
            'calendar_id' => $calendar->id, 
            'calendar_name' => $calendar->name,
            'event_title' => $eventData['title']
        ]);
    }

    /**
     * Delete an event in Apple Calendar via CalDAV
     * 
     * @param CalendarConnection $calendar
     * @param Event $event
     * @return array|null
     */
    public function deleteEventById(CalendarConnection $calendar, Event $event): ?array
    {
        if (empty($event->provider_event_id)) {
            Log::warning('Apple Calendar: Cannot delete event without provider_event_id', [
                'event_id' => $event->id
            ]);
            return null;
        }
        
        return $this->executeCalDavOperation('deleting event', function() use ($calendar, $event) {
            $davClient = $this->getDavClient($calendar);
            $metadata = $event->metadata['provider_metadata'] ?? [];
            
            // Get the event URL
            if (!empty($metadata['caldav_url'])) {
                $eventUrl = $metadata['caldav_url'];
            } else {
                $settings = $this->getCalendarSettings($calendar);
                $eventUrl = $this->getEventUrl($settings['calendar_path'], $event->provider_event_id);
            }
            
            // Delete the event from the CalDAV server
            $response = $davClient->request('DELETE', $eventUrl);
            
            return $this->processCalDavResponse($response, 'delete', [
                'event_id' => $event->id,
                'provider_event_id' => $event->provider_event_id
            ]);
        }, [
            'calendar_id' => $calendar->id,
            'event_id' => $event->id,
            'provider_event_id' => $event->provider_event_id
        ]);
    }

    /**
     * Update an event in Apple Calendar via CalDAV
     * 
     * @param CalendarConnection $calendar
     * @param Event $event
     * @return array|null
     */
    public function updateEventById(CalendarConnection $calendar, Event $event): ?array
    {
        if (empty($event->provider_event_id)) {
            Log::warning('Apple Calendar: Cannot update event without provider_event_id', [
                'event_id' => $event->id
            ]);
            return null;
        }
        
        return $this->executeCalDavOperation('updating event', function() use ($calendar, $event) {
            $davClient = $this->getDavClient($calendar);
            $settings = $this->getCalendarSettings($calendar);
            
            // Get the event URL from metadata or construct it
            $eventMetadata = $event->metadata['provider_metadata'] ?? [];
            $eventUrl = $eventMetadata['caldav_url'] ?? $this->getEventUrl($settings['calendar_path'], $event->provider_event_id);
            
            // First, get the current event to preserve any properties we don't want to change
            $response = $davClient->request('GET', $eventUrl);
            
            if ($response['statusCode'] !== 200) {
                Log::error('Apple Calendar: Failed to get existing event for update', [
                    'event_id' => $event->id,
                    'status_code' => $response['statusCode'],
                    'response' => $response['body'] ?? null
                ]);
                return null;
            }
            
            // Get the current ETag from the response
            $currentEtag = isset($response['headers']['etag'][0]) ? $response['headers']['etag'][0] : null;
            
            // Parse the existing iCalendar data
            try {
                $vcalendar = Reader::read($response['body']);
                $vevent = $vcalendar->VEVENT;
            } catch (Exception $e) {
                Log::error('Apple Calendar: Failed to parse iCalendar data', [
                    'event_id' => $event->id,
                    'error' => $e->getMessage()
                ]);
                return null;
            }
            
            // Update the basic event properties
            $vevent->SUMMARY = $event->title;
            
            // Update description if available
            if (isset($vevent->DESCRIPTION)) {
                $vevent->DESCRIPTION = $event->description ?? '';
            } elseif (!empty($event->description)) {
                $vevent->add('DESCRIPTION', $event->description);
            }
            
            // Update location if available
            if (isset($vevent->LOCATION)) {
                $vevent->LOCATION = $event->location ?? '';
            } elseif (!empty($event->location)) {
                $vevent->add('LOCATION', $event->location);
            }
            
            // Store user's timezone in metadata if available
            if (!empty($event->metadata['user_timezone'])) {
                if (isset($vevent->{'X-USER-TIMEZONE'})) {
                    $vevent->{'X-USER-TIMEZONE'} = $event->metadata['user_timezone'];
                } else {
                    $vevent->add('X-USER-TIMEZONE', $event->metadata['user_timezone']);
                }
            }
            
            // Update times and timezones
            if ($event->is_all_day) {
                // Remove existing time properties
                if (isset($vevent->DTSTART)) unset($vevent->DTSTART);
                if (isset($vevent->DTEND)) unset($vevent->DTEND);
                
                // Add all-day format dates
                $dtstart = $vevent->add('DTSTART', $event->start_time->format('Ymd'));
                $dtstart->add('VALUE', 'DATE');
                
                $dtend = $vevent->add('DTEND', $event->end_time->addDay()->format('Ymd'));
                $dtend->add('VALUE', 'DATE');
            } else {
                // Remove existing time properties
                if (isset($vevent->DTSTART)) unset($vevent->DTSTART);
                if (isset($vevent->DTEND)) unset($vevent->DTEND);
                
                // Add regular time format with timezones
                $this->setEventTimezones($vevent, $event->start_time, $event->end_time);
            }
            
            // Add or update LAST-MODIFIED property
            $vevent->{'LAST-MODIFIED'} = gmdate('Ymd\THis\Z');
            
            // Convert to iCalendar string
            $icalData = $vcalendar->serialize();
            
            // Send the updated event to the CalDAV server
            // Use the current ETag we just received for a proper If-Match
            $headers = ['Content-Type' => 'text/calendar; charset=utf-8'];
            if ($currentEtag) {
                $headers['If-Match'] = $currentEtag;
            }
            
            $response = $davClient->request('PUT', $eventUrl, $icalData, $headers);
            
            return $this->processCalDavResponse($response, 'update', [
                'provider_event_id' => $event->provider_event_id,
                'caldav_url' => $eventUrl,
                'event_id' => $event->id,
                'timezone' => $event->start_time->tzName,
                'user_timezone' => $event->metadata['user_timezone'] ?? null
            ]);
        }, [
            'calendar_id' => $calendar->id,
            'event_id' => $event->id,
            'provider_event_id' => $event->provider_event_id
        ]);
    }

    /**
     * Refresh access token if needed - not applicable for iCloud CalDAV
     * 
     * @param CalendarConnection $calendar
     * @return bool
     */
    public function refreshAccessTokenIfNeeded(CalendarConnection $calendar): bool
    {
       return true;
    }
    
}