<?php

namespace App\Services\Calendars;

use App\Models\CalendarConnection;
use App\Services\Calendars\DefaultCalendarProvider;
use App\Services\Calendars\GoogleCalendarProviders;
use App\Services\Calendars\AppleCalendarProvider;
use Illuminate\Support\Facades\Log;

class CalendarProviderFactory
{
    protected $defaultProvider;
    protected $googleProvider;
    protected $appleProvider;

    public function __construct(
        DefaultCalendarProvider $defaultProvider,
        GoogleCalendarProvider $googleProvider,
        AppleCalendarProvider $appleProvider
    ) {
        $this->defaultProvider = $defaultProvider;
        $this->googleProvider = $googleProvider;
        $this->appleProvider = $appleProvider;
    }

    /**
     * Get the appropriate calendar provider based on the calendar's provider type
     *
     * @param CalendarConnection $calendar
     * @return mixed
     */
    public function getProvider(CalendarConnection $calendar)
    {
        Log::info('Getting calendar provider', [
            'provider' => $calendar->provider
        ]);

        return match ($calendar->provider) {
            'google' => $this->googleProvider,
            'apple'  => $this->appleProvider,
            'default' => $this->defaultProvider,
        };
    }
}
