<?php

namespace App\Services\Calendars\Sync;

use App\Models\CalendarConnection;

interface CalendarSyncInterface
{
    /**
     * Sync events for a specific calendar
     * 
     * @param CalendarConnection $calendar
     * @return array Statistics about the sync operation
     */
    public function syncCalendarEvents(CalendarConnection $calendar): array;
    
    /**
     * Sync all active calendars for all users
     * 
     * @return array Statistics about the sync operation
     */
    public function syncAllCalendars(): array;
    
    /**
     * Register for real-time updates (if supported by provider)
     * 
     * @param CalendarConnection $calendar
     * @return bool Success status
     */
    public function registerPushNotifications(CalendarConnection $calendar): bool;
    
    /**
     * Stop receiving real-time updates (if supported by provider)
     * 
     * @param CalendarConnection $calendar
     * @return bool Success status
     */
    public function stopPushNotifications(CalendarConnection $calendar): bool;
}