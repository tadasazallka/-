<?php

namespace App\Services\Calendars\Sync;

use App\Models\CalendarConnection;
use App\Models\Event;
use App\Services\Calendars\Utilities\GoogleCalendarUtility;
use Carbon\Carbon;
use Google_Client;
use Google_Service_Calendar;
use Google_Service_Calendar_Channel;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class GoogleCalendarSyncService
{
    /**
     * The Google API client
     * 
     * @var Google_Client
     */
    protected $client;

    /**
     * The webhook notification URL
     * 
     * @var string
     */
    protected $notificationUrl;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->client = GoogleCalendarUtility::createGoogleClient();
        
        // Set up the notification URL for webhooks
        $this->notificationUrl = config('app.url') . '/api/webhooks/google-calendar';
    }

    /**
     * Register a push notification channel for a calendar
     * 
     * @param CalendarConnection $calendar
     * @return bool
     */
    public function registerPushNotifications(CalendarConnection $calendar): bool
    {
        try {
            // Get the calendar account
            $account = $calendar->calendarAccount;
            if (!$account || !$account->is_active) {
                Log::warning('Google Calendar Sync: Cannot register push notifications - inactive account', [
                    'calendar_connection_id' => $calendar->id
                ]);
                return false;
            }

            // Set up authentication
            GoogleCalendarUtility::setupAuthentication($this->client, $account);
            
            // Create a new notification channel
            $service = new Google_Service_Calendar($this->client);
            $channel = new Google_Service_Calendar_Channel();
            
            // Generate a unique channel ID
            $channelId = 'calendar-sync-' . $calendar->id . '-' . Str::random(8);
            
            $channel->setId($channelId);
            $channel->setType('web_hook');
            $channel->setAddress($this->notificationUrl);
            
            // Set expiration to 7 days (maximum allowed by Google)
            $expirationTime = (time() + (7 * 24 * 60 * 60)) * 1000; // Convert to milliseconds
            $channel->setExpiration($expirationTime);
            
            // Register the watch
            $calendarId = $calendar->provider_calendar_id ?: 'primary';
            $response = $service->events->watch($calendarId, $channel);
            
            // Store channel information in calendar metadata
            $metadata = $calendar->provider_metadata ?: [];
            $metadata['sync'] = [
                'channel_id' => $response->getId(),
                'resource_id' => $response->getResourceId(),
                'expiration' => $response->getExpiration(),
                'created_at' => now()->timestamp
            ];
            
            $calendar->provider_metadata = $metadata;
            $calendar->save();
            
            Log::info('Google Calendar Sync: Push notifications registered', [
                'calendar_connection_id' => $calendar->id,
                'channel_id' => $response->getId(),
                'expiration' => Carbon::createFromTimestampMs($response->getExpiration())->toDateTimeString()
            ]);
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('Google Calendar Sync: Failed to register push notifications', [
                'calendar_connection_id' => $calendar->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return false;
        }
    }
    
    /**
     * Stop push notifications for a calendar
     * 
     * @param CalendarConnection $calendar
     * @return bool
     */
    public function stopPushNotifications(CalendarConnection $calendar): bool
    {
        try {
            // Check if there's a channel to stop
            $metadata = $calendar->provider_metadata ?: [];
            if (empty($metadata['sync']['channel_id']) || empty($metadata['sync']['resource_id'])) {
                return true; // No channel to stop
            }
            
            // Get the calendar account
            $account = $calendar->calendarAccount;
            if (!$account) {
                // Remove sync metadata even if we can't stop the channel properly
                $this->removeSyncMetadata($calendar);
                return false;
            }
            
            // Set up authentication
            GoogleCalendarUtility::setupAuthentication($this->client, $account);
            
            // Create service and stop the channel
            $service = new Google_Service_Calendar($this->client);
            $service->channels->stop(new Google_Service_Calendar_Channel([
                'id' => $metadata['sync']['channel_id'],
                'resourceId' => $metadata['sync']['resource_id']
            ]));
            
            // Remove sync metadata
            $this->removeSyncMetadata($calendar);
            
            Log::info('Google Calendar Sync: Push notifications stopped', [
                'calendar_connection_id' => $calendar->id,
                'channel_id' => $metadata['sync']['channel_id']
            ]);
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('Google Calendar Sync: Failed to stop push notifications', [
                'calendar_connection_id' => $calendar->id,
                'error' => $e->getMessage()
            ]);
            
            // Still remove sync metadata to prevent further issues
            $this->removeSyncMetadata($calendar);
            
            return false;
        }
    }
    
    /**
     * Remove sync metadata from a calendar
     * 
     * @param CalendarConnection $calendar
     */
    protected function removeSyncMetadata(CalendarConnection $calendar): void
    {
        $metadata = $calendar->provider_metadata ?: [];
        if (isset($metadata['sync'])) {
            unset($metadata['sync']);
            $calendar->provider_metadata = $metadata;
            $calendar->save();
        }
    }
    
    /**
     * Refresh notification channels that are about to expire
     * 
     * @return int Number of channels refreshed
     */
    public function refreshNotificationChannels(): int
    {
        try {
            // Find calendars with channels that expire in the next 24 hours
            $calendars = CalendarConnection::where('provider', 'google')
                ->where('is_active', true)
                ->get();
            
            $refreshed = 0;
            
            foreach ($calendars as $calendar) {
                $metadata = $calendar->provider_metadata ?: [];
                
                // Skip if no sync data or calendar is inactive
                if (empty($metadata['sync']['expiration'])) {
                    continue;
                }
                
                // Check if channel is expiring in the next 24 hours
                $expirationTime = Carbon::createFromTimestampMs($metadata['sync']['expiration']);
                $expiresIn = Carbon::now()->diffInHours($expirationTime);
                
                if ($expiresIn <= 24) {
                    // Stop the existing channel
                    $this->stopPushNotifications($calendar);
                    
                    // Create a new channel
                    if ($this->registerPushNotifications($calendar)) {
                        $refreshed++;
                    }
                }
            }
            
            return $refreshed;
            
        } catch (\Exception $e) {
            Log::error('Google Calendar Sync: Failed to refresh notification channels', [
                'error' => $e->getMessage()
            ]);
            
            return 0;
        }
    }
    
    /**
     * Process a notification received from Google
     * 
     * @param array $headers
     * @return array
     */
    public function processNotification(array $headers): array
    {
        try {
            // Extract relevant headers
            $channelId = $headers['X-Goog-Channel-ID'] ?? null;
            $resourceId = $headers['X-Goog-Resource-ID'] ?? null;
            $resourceState = $headers['X-Goog-Resource-State'] ?? null;
            $messageNumber = $headers['X-Goog-Message-Number'] ?? null;
            
            Log::info('Google Calendar Sync: Received notification', [
                'channel_id' => $channelId,
                'resource_state' => $resourceState,
                'message_number' => $messageNumber
            ]);
            
            // Validate headers
            if (!$channelId || !$resourceId || !$resourceState) {
                throw new \Exception('Missing required notification headers');
            }
            
            // Find the calendar based on channel ID
            $calendar = CalendarConnection::whereRaw('JSON_EXTRACT(provider_metadata, "$.sync.channel_id") = ?', [$channelId])
                ->where('provider', 'google')
                ->where('is_active', true)
                ->first();
            
            if (!$calendar) {
                throw new \Exception('Calendar not found for channel ID: ' . $channelId);
            }
            
            // Process based on resource state
            switch ($resourceState) {
                case 'sync':
                    // Initial sync message, no action needed
                    return [
                        'success' => true,
                        'message' => 'Sync notification received',
                        'calendar_connection_id' => $calendar->id
                    ];
                
                case 'exists':
                case 'change':
                    // Process calendar changes
                    $result = $this->syncCalendarEvents($calendar);
                    return [
                        'success' => true,
                        'message' => 'Calendar changes processed',
                        'calendar_connection_id' => $calendar->id,
                        'stats' => $result
                    ];
                
                case 'not_exists':
                    // This is a specific notification that a resource was deleted
                    // For calendar notifications, this typically means the calendar was deleted
                    // We need to perform a full sync to detect which events were deleted
                    Log::info('Resource no longer exists notification received - performing full sync', [
                        'calendar_id' => $calendar->id
                    ]);
                    
                    // Clear the sync token to force a full sync
                    $this->clearSyncToken($calendar);
                    $result = $this->syncCalendarEvents($calendar, true); // force=true for full sync
                    
                    return [
                        'success' => true,
                        'message' => 'Resource no longer exists - full sync performed',
                        'calendar_connection_id' => $calendar->id,
                        'stats' => $result
                    ];
                
                default:
                    return [
                        'success' => false,
                        'message' => 'Unknown resource state: ' . $resourceState,
                        'calendar_connection_id' => $calendar->id
                    ];
            }
            
        } catch (\Exception $e) {
            Log::error('Google Calendar Sync: Failed to process notification', [
                'error' => $e->getMessage(),
                'headers' => $headers
            ]);
            
            return [
                'success' => false,
                'message' => 'Error processing notification: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Sync all active Google calendars
     * 
     * @return array
     */
    public function syncAllCalendars(bool $force = false): array
    {
        $stats = [
            'calendars_processed' => 0,
            'successes' => 0,
            'failures' => 0,
            'events_created' => 0,
            'events_updated' => 0,
            'events_deleted' => 0
        ];
        
        try {
            // Get all active Google calendar connections
            $calendars = CalendarConnection::where('provider', 'google')
                ->where('is_active', true)
                ->get();
            
            $stats['calendars_processed'] = $calendars->count();
            
            foreach ($calendars as $calendar) {
                try {
                    // Determine if we need to force a full sync
                    $shouldForceFullSync = $force;
                    
                    if (!$shouldForceFullSync) {
                        $metadata = $calendar->provider_metadata ?: [];
                        $lastFullSync = $metadata['last_full_sync'] ?? null;
                        
                        if ($lastFullSync) {
                            // Force a full sync every 7 days
                            $daysSinceFullSync = Carbon::now()->diffInDays(Carbon::createFromTimestamp($lastFullSync));
                            $shouldForceFullSync = $daysSinceFullSync >= 7;
                        } else {
                            // No record of a full sync, so do one now
                            $shouldForceFullSync = true;
                        }
                    }
                    
                    if ($shouldForceFullSync) {
                        // Clear sync token to force full sync
                        $this->clearSyncToken($calendar);
                        
                        // Update last full sync time
                        $metadata = $calendar->provider_metadata ?: [];
                        $metadata['last_full_sync'] = Carbon::now()->timestamp;
                        $calendar->provider_metadata = $metadata;
                        $calendar->save();
                        
                        Log::info('Performing full sync', [
                            'calendar_id' => $calendar->id,
                            'force' => $force,
                            'days_since_last_full_sync' => $daysSinceFullSync ?? 'never'
                        ]);
                    }
                    
                    $result = $this->syncCalendarEvents($calendar, $shouldForceFullSync);
                    
                    $stats['successes']++;
                    $stats['events_created'] += $result['created'] ?? 0;
                    $stats['events_updated'] += $result['updated'] ?? 0;
                    $stats['events_deleted'] += $result['deleted'] ?? 0;
                    
                } catch (\Exception $e) {
                    $stats['failures']++;
                    
                    Log::error('Google Calendar Sync: Failed to sync calendar', [
                        'calendar_id' => $calendar->id,
                        'error' => $e->getMessage()
                    ]);
                }
            }
            
            Log::info('Google Calendar Sync Status', $stats);
            return $stats;
            
        } catch (\Exception $e) {
            Log::error('Google Calendar Sync: Failed to sync all calendars', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return $stats;
        }
    }
    
    /**
     * Sync events for a specific calendar
     * 
     * @param CalendarConnection $calendar
     * @return array
     */
    public function syncCalendarEvents(CalendarConnection $calendar, bool $force = false): array
    {
        try {
            // Get the calendar account
            $account = $calendar->calendarAccount;
            if (!$account || !$account->is_active) {
                throw new \Exception('Calendar account is inactive or not found');
            }
            
            // Set up authentication
            GoogleCalendarUtility::setupAuthentication($this->client, $account);
            
            // Create Google Calendar service
            $service = new Google_Service_Calendar($this->client);
            
            // Calculate sync token or timeMin
            $calendarId = $calendar->provider_calendar_id ?: 'primary';

            Log::info('Using Google Calendar ID', [
                'calendar_id' => $calendar->id,
                'provider_calendar_id' => $calendarId,
                'is_primary' => $calendarId === 'primary' ? 'yes' : 'no'
            ]);
            
            $syncParams = GoogleCalendarUtility::getSyncParameters($calendar);

            Log::info('Starting calendar sync with parameters', [
                'calendar_id' => $calendar->id,
                'provider_calendar_id' => $calendarId,
                'sync_params' => json_encode($syncParams)
            ]);
            
            // Fetch events
            $events = [];
            $pageToken = null;
            
            do {
                $optParams = $syncParams;
                if ($pageToken) {
                    $optParams['pageToken'] = $pageToken;
                }
                
                Log::info('Sync params for calendar', [
                    'calendar_id' => $calendar->id,
                    'sync_token' => $syncParams['syncToken'] ?? 'none',
                    'time_min' => $syncParams['timeMin'] ?? 'none'
                ]);
                // Get events from Google Calendar
                $results = $service->events->listEvents($calendarId, $optParams);
                Log::info('Events fetched from Google', [
                    'calendar_id' => $calendar->id,
                    'count' => count($results->getItems()),
                    'has_sync_token' => $results->getNextSyncToken() ? 'yes' : 'no'
                ]);
                
                Log::info('Fetched events from Google', [
                    'calendar_id' => $calendar->id,
                    'page' => $pageToken ? 'next page' : 'first page',
                    'count' => count($results->getItems()),
                    'has_more_pages' => $results->getNextPageToken() ? 'yes' : 'no',
                    'has_sync_token' => $results->getNextSyncToken() ? 'yes' : 'no'
                ]);
                
                $events = array_merge($events, $results->getItems());
                $pageToken = $results->getNextPageToken();
                
                // Save sync token if available
                if ($results->getNextSyncToken()) {
                    $this->updateSyncToken($calendar, $results->getNextSyncToken());
                }
                
            } while ($pageToken);

            Log::info('Total events fetched from Google', [
                'calendar_id' => $calendar->id,
                'total_events' => count($events)
            ]);

            $isFullSync = $force || empty($calendar->provider_metadata['sync']['token']);
            
            // Check for events that exist in our database but not in Google (deleted events)
            $stats = $this->processDeletedEvents($calendar, $events, $isFullSync);
            
            // Process the events
            $eventStats = $this->processGoogleEvents($calendar, $events);
            
            // Merge stats
            $stats = array_merge($stats, $eventStats);
            
            // Update the last sync time
            $this->updateLastSyncTime($calendar);
            
            return $stats;
            
        } catch (\Exception $e) {
            // Check if this is a sync token expired error
            if (strpos($e->getMessage(), 'Sync token is no longer valid') !== false) {
                // Clear the sync token and retry with a full sync
                $this->clearSyncToken($calendar);
                return $this->syncCalendarEvents($calendar);
            }
            
            Log::info('Google API Error', [
                'calendar_id' => $calendar->id,
                'error_message' => $e->getMessage(),
                'is_sync_token_error' => strpos($e->getMessage(), 'Sync token is no longer valid') !== false ? 'yes' : 'no'
            ]);
            
            throw $e;
        }
    }
    
    /**
     * Find events that exist in our database but not in Google (deleted events)
     * 
     * @param CalendarConnection $calendar
     * @param array $googleEvents
     * @return array Stats about deleted events
     */
    protected function processDeletedEvents(CalendarConnection $calendar, array $googleEvents, bool $isFullSync = false): array
    {
        $stats = [
            'deleted' => 0
        ];
        
        try {
            // Get Google event IDs from the fetched events
            $googleEventIds = [];
            foreach ($googleEvents as $googleEvent) {
                $googleEventIds[] = $googleEvent->getId();
            }
            
            // Only check for deletions during full syncs
            if ($isFullSync) {
                Log::info('Performing deletion check during full sync', [
                    'calendar_id' => $calendar->id,
                    'event_count' => count($googleEventIds)
                ]);
                
                // Get our events for this calendar that have Google IDs
                $ourEvents = Event::where('calendar_connection_id', $calendar->id)
                    ->whereNotNull('provider_event_id')
                    ->get();
                
                foreach ($ourEvents as $ourEvent) {
                    // Skip if this event's ID is in the Google response
                    if (in_array($ourEvent->provider_event_id, $googleEventIds)) {
                        continue;
                    }
                    
                    // This event exists in our DB but not in Google - it was deleted
                    Log::info('Google Calendar Sync: Event exists in DB but not in Google - deleting', [
                        'event_id' => $ourEvent->id,
                        'provider_event_id' => $ourEvent->provider_event_id
                    ]);
                    
                    $ourEvent->delete();
                    $stats['deleted']++;
                }
            } else {
                Log::info('Skipping deletion check - using incremental sync', [
                    'calendar_id' => $calendar->id
                ]);
            }
            
            return $stats;
        } catch (\Exception $e) {
            Log::error('Google Calendar Sync: Failed to process deleted events', [
                'calendar_id' => $calendar->id,
                'error' => $e->getMessage()
            ]);
            
            return $stats;
        }
    }
    
    /**
     * Process Google Calendar events and update local database
     * 
     * @param CalendarConnection $calendar
     * @param array $googleEvents
     * @return array Stats about processed events
     */
    protected function processGoogleEvents(CalendarConnection $calendar, array $googleEvents): array
    {
        $stats = [
            'created' => 0,
            'updated' => 0,
            'deleted' => 0,
            'skipped' => 0
        ];
        
        try {
            // First pass: Process all master recurring events and cancelled events
            foreach ($googleEvents as $googleEvent) {
                Log::info('Processing Google event', [
                    'event_id' => $googleEvent->getId(),
                    'summary' => $googleEvent->getSummary(),
                    'status' => $googleEvent->getStatus(),
                    'is_recurring_instance' => $googleEvent->getRecurringEventId() ? 'yes' : 'no'
                ]);

                // Check if the event is cancelled (deleted)
                if ($googleEvent->getStatus() === 'cancelled') {
                    if ($this->handleDeletedEvent($calendar, $googleEvent)) {
                        $stats['deleted']++;
                    }
                    continue;
                }
                
                // Skip if this is an instance of a recurring event
                // We only store the master event with recurrence rules
                if ($googleEvent->getRecurringEventId()) {
                    $stats['skipped']++;
                    continue;
                }
                
                // Check if the event already exists in our database
                $existingEvent = Event::where('calendar_connection_id', $calendar->id)
                    ->where('provider_event_id', $googleEvent->getId())
                    ->first();
                
                if ($existingEvent) {
                    // Update existing event
                    if ($this->updateExistingEvent($existingEvent, $googleEvent)) {
                        $stats['updated']++;
                    } else {
                        $stats['skipped']++;
                    }
                } else {
                    // Create new event
                    if ($this->createNewEvent($calendar, $googleEvent)) {
                        $stats['created']++;
                    } else {
                        $stats['skipped']++;
                    }
                
                }
            }

            Log::info('Google event Stats', $stats);
            
            return $stats;
            
        } catch (\Exception $e) {
            Log::error('Google Calendar Sync: Failed to process Google events', [
                'calendar_connection_id' => $calendar->id,
                'error' => $e->getMessage()
            ]);
            
            throw $e;
        }
    }
    
    /**
     * Handle a deleted Google event
     * 
     * @param CalendarConnection $calendar
     * @param \Google_Service_Calendar_Event $googleEvent
     * @return bool
     */
    protected function handleDeletedEvent(CalendarConnection $calendar, $googleEvent): bool
    {
        try {
            // Find the event in our database
            $existingEvent = Event::where('calendar_connection_id', $calendar->id)
                ->where('provider_event_id', $googleEvent->getId())
                ->first();
            
            if ($existingEvent) {
                // Delete the event from our database
                $existingEvent->delete();
                
                Log::info('Google Calendar Sync: Deleted event based on cancelled status', [
                    'event_id' => $existingEvent->id,
                    'google_event_id' => $googleEvent->getId()
                ]);
                
                return true;
            }
            
            // Also check if this is an instance of a recurring event that was deleted
            if ($googleEvent->getRecurringEventId()) {
                $masterEvent = Event::where('calendar_connection_id', $calendar->id)
                    ->where('provider_event_id', $googleEvent->getRecurringEventId())
                    ->first();
                
                if ($masterEvent) {
                    // For recurring event instances, store the exception in the master event's metadata
                    $metadata = $masterEvent->metadata ?: [];
                    $exceptions = $metadata['recurrence_exceptions'] ?? [];
                    
                    // Add this instance ID to exceptions if not already there
                    if (!in_array($googleEvent->getId(), $exceptions)) {
                        $exceptions[] = $googleEvent->getId();
                        $metadata['recurrence_exceptions'] = $exceptions;
                        $masterEvent->metadata = $metadata;
                        $masterEvent->save();
                        
                        Log::info('Google Calendar Sync: Added exception for recurring event instance', [
                            'master_event_id' => $masterEvent->id,
                            'instance_id' => $googleEvent->getId()
                        ]);
                    }
                    
                    return true;
                }
            }
            
            return false;
            
        } catch (\Exception $e) {
            Log::error('Google Calendar Sync: Failed to handle deleted event', [
                'calendar_connection_id' => $calendar->id,
                'google_event_id' => $googleEvent->getId(),
                'error' => $e->getMessage()
            ]);
            
            return false;
        }
    }
    
    /**
     * Update an existing event with data from Google Calendar
     * 
     * @param Event $event
     * @param \Google_Service_Calendar_Event $googleEvent
     * @return bool
     */
    protected function updateExistingEvent(Event $event, $googleEvent): bool
    {
        try {
            // Get event data
            $eventData = $this->extractEventData($googleEvent);
            
            // Update event properties
            $event->title = $eventData['title'];
            $event->description = $eventData['description'];
            $event->location = $eventData['location'];
            $event->start_time = $eventData['start_time'];
            $event->end_time = $eventData['end_time'];
            $event->is_all_day = $eventData['is_all_day'];
            
            // Update recurrence data
            if (!empty($eventData['recurrence'])) {
                $event->recurrence = $eventData['recurrence'];
            } else {
                $event->recurrence = null;
            }
            
            // Update metadata
            $metadata = $event->metadata ?: [];
            $metadata['provider_metadata'] = array_merge($metadata['provider_metadata'] ?? [], [
                'updated_at' => now()->timestamp,
                'etag' => $googleEvent->getEtag(),
                'html_link' => $googleEvent->getHtmlLink(),
                'synced_at' => now()->timestamp,
                'is_recurring' => !empty($eventData['recurrence']),
                'original_timezone' => $eventData['original_timezone'] ?? 'UTC'
            ]);
            
            $event->metadata = $metadata;
            $event->save();
            
            Log::info('Google Calendar Sync: Updated event', [
                'event_id' => $event->id,
                'google_event_id' => $googleEvent->getId(),
                'is_recurring' => !empty($eventData['recurrence'])
            ]);
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('Google Calendar Sync: Failed to update event', [
                'event_id' => $event->id,
                'google_event_id' => $googleEvent->getId(),
                'error' => $e->getMessage()
            ]);
            
            return false;
        }
    }
    
    /**
     * Create a new event from Google Calendar data
     * 
     * @param CalendarConnection $calendar
     * @param \Google_Service_Calendar_Event $googleEvent
     * @return bool
     */
    protected function createNewEvent(CalendarConnection $calendar, $googleEvent): bool
    {
        try {
            // Skip if this is an instance of a recurring event
            if ($googleEvent->getRecurringEventId()) {
                Log::info('Google Calendar Sync: Skipping recurring event instance', [
                    'event_id' => $googleEvent->getId(),
                    'recurring_event_id' => $googleEvent->getRecurringEventId()
                ]);
                return false;
            }
            
            // Get event data
            $eventData = $this->extractEventData($googleEvent);
            
            // Create new event in our database
            $event = new Event();
            $event->user_id = $calendar->user_id;
            $event->calendar_connection_id = $calendar->id;
            $event->provider_event_id = $googleEvent->getId();
            $event->title = $eventData['title'];
            $event->description = $eventData['description'];
            $event->location = $eventData['location'];
            $event->start_time = $eventData['start_time'];
            $event->end_time = $eventData['end_time'];
            $event->is_all_day = $eventData['is_all_day'];
            $event->recurrence = $eventData['recurrence']; // Store recurrence data
            $event->status = 'scheduled';
            
            $event->metadata = [
                'provider_metadata' => [
                    'created_at' => now()->timestamp,
                    'html_link' => $googleEvent->getHtmlLink(),
                    'etag' => $googleEvent->getEtag(),
                    'i_cal_uid' => $googleEvent->getICalUID(),
                    'synced_at' => now()->timestamp,
                    'synced_from_google' => true,
                    'is_recurring' => !empty($eventData['recurrence']),
                    'original_timezone' => $eventData['original_timezone'] ?? 'UTC'
                ]
            ];
            
            $event->save();
            
            Log::info('Google Calendar Sync: Created new event', [
                'event_id' => $event->id,
                'google_event_id' => $googleEvent->getId(),
                'is_recurring' => !empty($eventData['recurrence'])
            ]);
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('Google Calendar Sync: Failed to create new event', [
                'calendar_connection_id' => $calendar->id,
                'google_event_id' => $googleEvent->getId(),
                'error' => $e->getMessage()
            ]);
            
            return false;
        }
    }
    
    /**
     * Extract event data from a Google Calendar event
     * 
     * @param \Google_Service_Calendar_Event $googleEvent
     * @return array
     */
    protected function extractEventData($googleEvent): array
    {
        // Check if this is an all-day event
        $start = $googleEvent->getStart();
        $end = $googleEvent->getEnd();
        
        $isAllDay = !empty($start->date);
        $originalTimezone = GoogleCalendarUtility::extractTimezone($start, $end);
        
        if ($isAllDay) {
            // For all-day events, use dates without times
            $startTime = Carbon::parse($start->date);
            $endTime = Carbon::parse($end->date);
            
            // Adjust end time for all-day events (Google stores end date as the day after)
            $endTime = $endTime->subDay();

            Log::info('All-day event sync details', [
                'event_id' => $googleEvent->getId(),
                'google_start_date' => $start->date,
                'google_end_date' => $end->date,
                'calculated_start_utc' => $startTime->toIsoString(),
                'calculated_end_utc' => $endTime->toIsoString(),
                'is_all_day' => $isAllDay,
                'original_timezone' => $originalTimezone
            ]);

        } else {
            // For regular events with times, use dateTime
            $startTime = Carbon::parse($start->dateTime);
            $endTime = Carbon::parse($end->dateTime);
            
            // Ensure times are in UTC for database storage
            if ($startTime->timezone->getName() !== 'UTC') {
                $startTime = $startTime->setTimezone('UTC');
            }
            
            if ($endTime->timezone->getName() !== 'UTC') {
                $endTime = $endTime->setTimezone('UTC');
            }
        }

        Log::info('Event time data', [
            'event_id' => $googleEvent->getId(),
            'start_time' => $isAllDay ? $startTime->format('Y-m-d') : $startTime->toISOString(),
            'end_time' => $isAllDay ? $endTime->format('Y-m-d') : $endTime->toISOString(),
            'is_all_day' => $isAllDay,
            'original_timezone' => $originalTimezone
        ]);
        
        $data = [
            'title' => $googleEvent->getSummary() ?? 'Untitled Event',
            'description' => $googleEvent->getDescription() ?? '',
            'location' => $googleEvent->getLocation() ?? '',
            'start_time' => $startTime,
            'end_time' => $endTime,
            'is_all_day' => $isAllDay,
            'recurrence' => null,
            'original_timezone' => $originalTimezone
        ];
        
        // Handle recurrence
        if ($googleEvent->getRecurrence()) {
            $recurrenceData = GoogleCalendarUtility::parseGoogleRecurrence($googleEvent->getRecurrence());
            if ($recurrenceData) {
                $data['recurrence'] = $recurrenceData;
            }
        }
        
        return $data;
    }
    
    /**
     * Update the sync token for a calendar
     * 
     * @param CalendarConnection $calendar
     * @param string $syncToken
     */
    protected function updateSyncToken(CalendarConnection $calendar, string $syncToken): void
    {

        Log::info('Updating sync token', [
            'calendar_id' => $calendar->id,
            'sync_token' => $syncToken
        ]);
        
        $metadata = $calendar->provider_metadata ?: [];
        
        if (!isset($metadata['sync'])) {
            $metadata['sync'] = [];
        }
        
        $metadata['sync']['token'] = $syncToken;
        $metadata['sync']['token_updated_at'] = now()->timestamp;
        
        $calendar->provider_metadata = $metadata;
        $calendar->save();
    }
    
    /**
     * Clear the sync token for a calendar
     * 
     * @param CalendarConnection $calendar
     */
    protected function clearSyncToken(CalendarConnection $calendar): void
    {
        $metadata = $calendar->provider_metadata ?: [];
        
        if (isset($metadata['sync']['token'])) {
            unset($metadata['sync']['token']);
            $metadata['sync']['token_cleared_at'] = now()->timestamp;
            
            $calendar->provider_metadata = $metadata;
            $calendar->save();
        }
    }
    
    /**
     * Update the last sync time for a calendar
     * 
     * @param CalendarConnection $calendar
     */
    protected function updateLastSyncTime(CalendarConnection $calendar): void
    {
        $metadata = $calendar->provider_metadata ?: [];
        
        if (!isset($metadata['sync'])) {
            $metadata['sync'] = [];
        }
        
        $metadata['sync']['last_sync'] = now()->timestamp;
        
        $calendar->provider_metadata = $metadata;
        $calendar->save();
    }
}