<?php

namespace App\Services\Calendars\Sync;

use App\Models\CalendarAccount;
use App\Models\CalendarConnection;
use App\Models\Event;
use App\Models\User;
use App\Services\PlanLimitService;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Sabre\DAV\Client as DavClient;
use Sabre\VObject\Reader;
use Exception;

class AppleCalendarSyncService implements CalendarSyncInterface
{
    /**
     * iCloud CalDAV endpoint
     */
    protected const ICLOUD_CALDAV_URL = 'https://caldav.icloud.com';

    /**
     * Sync a single calendar by fetching all events from Apple Calendar
     * 
     * @param CalendarConnection $calendar
     * @return array Statistics about the sync operation
     */
    public function syncCalendarEvents(CalendarConnection $calendar): array
    {
        try {
            Log::info('Apple Calendar Sync: Starting sync for calendar', [
                'calendar_connection_id' => $calendar->id,
                'calendar_name' => $calendar->name
            ]);
            
            // Get calendar settings
            $settings = $this->getCalendarSettings($calendar);
            
            // Create DAV client
            $davClient = $this->getDavClient($settings);
            
            // Get calendar metadata to check if we have stored CTag
            $metadata = $calendar->provider_metadata ?: [];
            $lastCTag = $metadata['sync']['ctag'] ?? null;
            
            // First, get the current CTag to see if the calendar has changed
            $currentCTag = $this->getCurrentCTag($davClient, $settings['calendar_path']);
            
            // If CTag hasn't changed and we've synced before, no changes are needed
            if ($lastCTag && $lastCTag === $currentCTag && !empty($metadata['sync']['last_sync'])) {
                Log::info('Apple Calendar Sync: No changes detected (CTag unchanged)', [
                    'calendar_connection_id' => $calendar->id,
                    'ctag' => $currentCTag
                ]);
                
                // Update last sync time
                $this->updateSyncMetadata($calendar, [
                    'last_sync' => now()->timestamp,
                    'ctag' => $currentCTag
                ]);
                
                return [
                    'created' => 0,
                    'updated' => 0,
                    'deleted' => 0,
                    'skipped' => 0,
                    'unchanged' => true
                ];
            }
            
            // Fetch the event list with ETags
            $eventList = $this->fetchEventList($davClient, $settings['calendar_path']);
            
            // Fetch and process the events
            $stats = $this->processCalendarEvents($calendar, $davClient, $eventList);
            
            // Update sync metadata with new CTag
            $this->updateSyncMetadata($calendar, [
                'last_sync' => now()->timestamp,
                'ctag' => $currentCTag,
                'last_event_count' => count($eventList)
            ]);
            
            Log::info('Apple Calendar Sync: Completed sync for calendar', [
                'calendar_connection_id' => $calendar->id,
                'stats' => $stats
            ]);
            
            return $stats;
            
        } catch (Exception $e) {
            Log::error('Apple Calendar Sync: Error syncing calendar', [
                'calendar_connection_id' => $calendar->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            throw $e;
        }
    }
    
    /**
     * Sync all active Apple calendars
     * 
     * @return array Statistics about the sync operation
     */

    public function syncAllCalendars(): array
    {
        $stats = [
            'calendars_processed' => 0,
            'successes' => 0,
            'failures' => 0,
            'events_created' => 0,
            'events_updated' => 0,
            'events_deleted' => 0,
            'users_skipped' => 0
        ];
        
        try {
            // Get all active Apple calendar connections
            $calendars = CalendarConnection::where('provider', 'apple')
                ->where('is_active', true)
                ->get();
            
            $stats['calendars_processed'] = $calendars->count();
            
            // Group calendars by user_id
            $calendarsByUser = $calendars->groupBy('user_id');
            
            // Inject PlanLimitService
            $planLimitService = app(PlanLimitService::class);
            
            foreach ($calendarsByUser as $userId => $userCalendars) {
                try {
                    // Get the user
                    $user = User::find($userId);
                    if (!$user) {
                        $stats['failures'] += $userCalendars->count();
                        continue;
                    }
                    
                    // Check if user can create events
                    [$canCreate, $limitMessage] = $planLimitService->canCreateEvent($user);
                    if (!$canCreate) {
                        Log::warning('Apple Calendar Sync: Skipping user due to plan limits', [
                            'user_id' => $userId,
                            'message' => $limitMessage
                        ]);
                        
                        $stats['users_skipped']++;
                        $stats['failures'] += $userCalendars->count();
                        continue; // Skip this user entirely
                    }
                    
                    // Process all calendars for this user
                    foreach ($userCalendars as $calendar) {
                        try {
                            $result = $this->syncCalendarEvents($calendar);
                            
                            $stats['successes']++;
                            $stats['events_created'] += $result['created'] ?? 0;
                            $stats['events_updated'] += $result['updated'] ?? 0;
                            $stats['events_deleted'] += $result['deleted'] ?? 0;
                            
                        } catch (Exception $e) {
                            $stats['failures']++;
                            
                            Log::error('Apple Calendar Sync: Failed to sync calendar', [
                                'calendar_connection_id' => $calendar->id,
                                'error' => $e->getMessage()
                            ]);
                        }
                    }
                    
                } catch (Exception $e) {
                    $stats['failures'] += $userCalendars->count();
                    
                    Log::error('Apple Calendar Sync: Failed to process user calendars', [
                        'user_id' => $userId,
                        'error' => $e->getMessage()
                    ]);
                }
            }
            
            return $stats;
            
        } catch (Exception $e) {
            Log::error('Apple Calendar Sync: Failed to sync all calendars', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return $stats;
        }
    }
    
    /**
     * Not supported for Apple Calendar (returns false)
     * 
     * @param CalendarConnection $calendar
     * @return bool Always returns false
     */
    public function registerPushNotifications(CalendarConnection $calendar): bool
    {
        // Apple Calendar does not support push notifications via CalDAV
        return false;
    }
    
    /**
     * Not supported for Apple Calendar (returns true)
     * 
     * @param CalendarConnection $calendar
     * @return bool Always returns true
     */
    public function stopPushNotifications(CalendarConnection $calendar): bool
    {
        // Apple Calendar does not support push notifications via CalDAV
        return true;
    }
    
    /**
     * Get the current calendar collection CTag (collection tag)
     * 
     * @param DavClient $davClient
     * @param string $calendarPath
     * @return string|null
     */
    protected function getCurrentCTag(DavClient $davClient, string $calendarPath): ?string
    {
        try {
            $response = $davClient->propFind($calendarPath, [
                '{http://calendarserver.org/ns/}getctag'
            ], 0);
            
            if (isset($response['{http://calendarserver.org/ns/}getctag'])) {
                return $response['{http://calendarserver.org/ns/}getctag'];
            }
            
            return null;
            
        } catch (Exception $e) {
            Log::error('Apple Calendar Sync: Error getting CTag', [
                'calendar_path' => $calendarPath,
                'error' => $e->getMessage()
            ]);
            
            return null;
        }
    }
    
    /**
     * Fetch list of all events in a calendar with their ETags
     * 
     * @param DavClient $davClient
     * @param string $calendarPath
     * @return array
     */
    protected function fetchEventList(DavClient $davClient, string $calendarPath): array
    {
        try {
            // WebDAV properties we want to fetch
            $properties = [
                '{DAV:}getetag',
                '{http://apple.com/ns/ical/}calendar-color',
                '{DAV:}getcontenttype',
                '{DAV:}resourcetype',
                '{DAV:}getlastmodified'
            ];
            
            // Get all calendar objects
            $response = $davClient->propFind($calendarPath, $properties, 1);
            
            $eventList = [];
            
            // Process results
            foreach ($response as $uri => $props) {
                // Skip the calendar itself
                if ($uri === $calendarPath) {
                    continue;
                }
                
                // Only include .ics files
                if (isset($props['{DAV:}getcontenttype']) && 
                    strpos($props['{DAV:}getcontenttype'], 'text/calendar') !== false) {
                    
                    $etag = isset($props['{DAV:}getetag']) ? trim($props['{DAV:}getetag'], '"') : null;
                    $lastModified = isset($props['{DAV:}getlastmodified']) ? strtotime($props['{DAV:}getlastmodified']) : null;
                    
                    $eventList[] = [
                        'uri' => $uri,
                        'etag' => $etag,
                        'last_modified' => $lastModified
                    ];
                }
            }
            
            Log::info('Apple Calendar Sync: Found events', [
                'calendar_path' => $calendarPath,
                'event_count' => count($eventList)
            ]);
            
            return $eventList;
            
        } catch (Exception $e) {
            Log::error('Apple Calendar Sync: Error fetching event list', [
                'calendar_path' => $calendarPath,
                'error' => $e->getMessage()
            ]);
            
            throw $e;
        }
    }
    
    /**
     * Process calendar events and update database
     * 
     * @param CalendarConnection $calendar
     * @param DavClient $davClient
     * @param array $eventList
     * @return array Stats about processed events
     */
    protected function processCalendarEvents(CalendarConnection $calendar, DavClient $davClient, array $eventList): array
    {
        $stats = [
            'created' => 0,
            'updated' => 0,
            'deleted' => 0,
            'skipped' => 0
        ];
        
        try {
            // Get existing events for this calendar
            $existingEvents = Event::where('calendar_connection_id', $calendar->id)->get()->keyBy('provider_event_id');
            
            // Keep track of processed event IDs to detect deleted events
            $processedEventIds = [];
            
            // Process each event
            foreach ($eventList as $eventInfo) {
                try {
                    // Fetch the event data
                    $response = $davClient->request('GET', $eventInfo['uri']);
                    
                    if ($response['statusCode'] !== 200) {
                        Log::warning('Apple Calendar Sync: Failed to fetch event', [
                            'uri' => $eventInfo['uri'],
                            'status_code' => $response['statusCode']
                        ]);
                        continue;
                    }
                    
                    // Parse the iCalendar data
                    $vcalendar = Reader::read($response['body']);
                    
                    // Extract event data
                    $eventData = $this->extractEventData($vcalendar);
                    
                    if (empty($eventData)) {
                        $stats['skipped']++;
                        continue;
                    }
                    
                    // Skip events created by our app
                    if ($this->isEventCreatedByApp($eventData)) {
                        $stats['skipped']++;
                        continue;
                    }
                    
                    // Add provider metadata
                    $eventData['provider_metadata'] = [
                        'etag' => $eventInfo['etag'],
                        'uri' => $eventInfo['uri'],
                        'last_modified' => $eventInfo['last_modified'],
                        'synced_at' => now()->timestamp,
                        'synced_from_apple' => true
                    ];
                    
                    // Check if the event already exists in our database
                    $existingEvent = $existingEvents->get($eventData['provider_event_id']);
                    
                    if ($existingEvent) {
                        // Check if the event has been modified
                        $needsUpdate = $this->doesEventNeedUpdate($existingEvent, $eventData, $eventInfo);
                        
                        if ($needsUpdate) {
                            // Update existing event
                            $this->updateExistingEvent($existingEvent, $eventData);
                            $stats['updated']++;
                        } else {
                            $stats['skipped']++;
                        }
                    } else {
                        // Create new event
                        $this->createNewEvent($calendar, $eventData);
                        $stats['created']++;
                    }
                    
                    // Mark this event as processed
                    $processedEventIds[] = $eventData['provider_event_id'];
                    
                } catch (Exception $e) {
                    Log::error('Apple Calendar Sync: Error processing event', [
                        'uri' => $eventInfo['uri'],
                        'error' => $e->getMessage()
                    ]);
                }
            }
            
            // Find deleted events (events in our database but not in the calendar)
            $deletedEventIds = array_diff(
                $existingEvents->keys()->toArray(),
                $processedEventIds
            );
            
            // Delete events that no longer exist in the calendar
            if (!empty($deletedEventIds)) {
                $deleted = Event::where('calendar_connection_id', $calendar->id)
                    ->whereIn('provider_event_id', $deletedEventIds)
                    ->delete();
                
                $stats['deleted'] = $deleted;
                
                Log::info('Apple Calendar Sync: Deleted events', [
                    'calendar_connection_id' => $calendar->id,
                    'deleted_count' => $deleted
                ]);
            }
            
            return $stats;
            
        } catch (Exception $e) {
            Log::error('Apple Calendar Sync: Error processing calendar events', [
                'calendar_connection_id' => $calendar->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            throw $e;
        }
    }

    /**
     * Parse iCalendar recurrence rule into our format
     * 
     * @param string $rrule
     * @return array|null
     */
    protected function parseICalRecurrence(string $rrule): ?array
    {
        // Parse RRULE format
        $pattern = '/FREQ=([A-Z]+)(?:;INTERVAL=(\d+))?(?:;COUNT=(\d+))?(?:;UNTIL=([^;]+))?/';
        if (preg_match($pattern, $rrule, $matches)) {
            $frequency = strtolower($matches[1]);
            
            // Map iCal frequency to our format
            $frequencyMap = [
                'daily' => 'daily',
                'weekly' => 'weekly',
                'monthly' => 'monthly',
                'yearly' => 'yearly'
            ];
            
            if (!isset($frequencyMap[$frequency])) {
                Log::warning('Apple Calendar Sync: Unsupported recurrence frequency', [
                    'frequency' => $frequency,
                    'rrule' => $rrule
                ]);
                return null; // Skip unsupported frequencies
            }
            
            $recurrence = [
                'frequency' => $frequencyMap[$frequency],
                'interval' => isset($matches[2]) ? (int)$matches[2] : 1,
            ];
            
            // Handle COUNT
            if (!empty($matches[3])) {
                $recurrence['count'] = (int)$matches[3];
            }
            
            // Handle UNTIL
            if (!empty($matches[4])) {
                // Convert from iCal format (20240630T150000Z) to Y-m-d
                try {
                    $untilDate = Carbon::createFromFormat('Ymd\THis\Z', $matches[4]);
                    $recurrence['until'] = $untilDate->format('Y-m-d');
                } catch (\Exception $e) {
                    // Try alternative format without Z
                    try {
                        $untilDate = Carbon::createFromFormat('Ymd\THis', $matches[4]);
                        $recurrence['until'] = $untilDate->format('Y-m-d');
                    } catch (\Exception $e2) {
                        Log::warning('Apple Calendar Sync: Failed to parse UNTIL date', [
                            'until' => $matches[4],
                            'error' => $e2->getMessage()
                        ]);
                    }
                }
            }
            
            return $recurrence;
        }
        
        return null;
    }
    
    /**
     * Check if an event needs to be updated based on ETag and modification time
     * 
     * @param Event $existingEvent
     * @param array $eventData
     * @param array $eventInfo
     * @return bool
     */
    protected function doesEventNeedUpdate(Event $existingEvent, array $eventData, array $eventInfo): bool
    {
        $metadata = $existingEvent->metadata['provider_metadata'] ?? [];
        
        // If we have an ETag and it hasn't changed, no update needed
        if (!empty($metadata['etag']) && !empty($eventInfo['etag']) && $metadata['etag'] === $eventInfo['etag']) {
            return false;
        }
        
        // Compare modification times if available
        if (!empty($metadata['last_modified']) && !empty($eventInfo['last_modified'])) {
            if ($metadata['last_modified'] >= $eventInfo['last_modified']) {
                return false;
            }
        }
        
        // Check basic properties for changes
        if ($existingEvent->title === $eventData['title'] &&
            $existingEvent->description === $eventData['description'] &&
            $existingEvent->location === $eventData['location'] &&
            $existingEvent->start_time->eq($eventData['start_time']) &&
            $existingEvent->end_time->eq($eventData['end_time']) &&
            $existingEvent->is_all_day === $eventData['is_all_day']) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Extract event data from a VCalendar object
     * 
     * @param \Sabre\VObject\Component\VCalendar $vcalendar
     * @return array|null
     */
    protected function extractEventData($vcalendar): ?array
    {
        try {
            // Get the first VEVENT component
            $vevent = $vcalendar->VEVENT;
            
            if (empty($vevent)) {
                return null;
            }
            
            // Get UID (required for identification)
            $uid = (string)$vevent->UID;
            if (empty($uid)) {
                return null;
            }
            
            // Skip if this is a recurrence instance (has RECURRENCE-ID property)
            if (isset($vevent->{'RECURRENCE-ID'})) {
                Log::info('Apple Calendar Sync: Skipping recurrence instance', [
                    'uid' => $uid,
                    'recurrence_id' => (string)$vevent->{'RECURRENCE-ID'}
                ]);
                return null;
            }
            
            // Get summary (title)
            $title = (string)($vevent->SUMMARY ?? 'Untitled Event');
            
            // Get description
            $description = (string)($vevent->DESCRIPTION ?? '');
            
            // Get location
            $location = (string)($vevent->LOCATION ?? '');
            
            // Check if this is an all-day event
            $isAllDay = false;
            $startTime = null;
            $endTime = null;
            
            if (isset($vevent->DTSTART)) {
                // Get the DTSTART property
                $dtstart = $vevent->DTSTART;
                
                // Check if this is an all-day event (value will be just a date without time component)
                // All-day events usually have DATE as the value type
                $isAllDay = false;
                if ($dtstart instanceof \Sabre\VObject\Property) {
                    $valueType = $dtstart['VALUE'] ?? null;
                    $isAllDay = $valueType === 'DATE';
                } else {
                    // Alternative way to check for all-day event - looking at the value format
                    $value = (string)$dtstart;
                    $isAllDay = (strlen($value) === 8) || (strpos($value, 'T') === false);
                }
                
                if ($isAllDay) {
                    // All-day event
                    $startDate = Carbon::parse((string)$dtstart);
                    
                    // Get end date
                    if (isset($vevent->DTEND)) {
                        $dtend = $vevent->DTEND;
                        $endDate = Carbon::parse((string)$dtend);
                        
                        // For all-day events, DTEND is exclusive, so subtract 1 day
                        $endDate = $endDate->subDay();
                    } else {
                        // If no end time, assume same day as start
                        $endDate = $startDate->copy();
                    }
                    
                    // Get the user's timezone or default to UTC
                    $userTz = $calendar->user->timezone ?? 'UTC';
                    
                    // Convert to full day boundaries in the user's timezone
                    $startTime = Carbon::parse($startDate->format('Y-m-d') . ' 00:00:00', $userTz)->setTimezone('UTC');
                    $endTime = Carbon::parse($endDate->format('Y-m-d') . ' 23:59:59', $userTz)->setTimezone('UTC');
                } else {
                    // Regular event with time
                    $startTime = Carbon::parse((string)$dtstart);
                    
                    // Check for timezone information
                    $tzid = null;
                    if ($dtstart instanceof \Sabre\VObject\Property) {
                        $tzid = $dtstart['TZID'] ?? null;
                    }
                    
                    if ($tzid) {
                        try {
                            $startTime->setTimezone((string)$tzid);
                        } catch (\Exception $e) {
                            // Invalid timezone, ignore
                            Log::warning('Invalid timezone in Apple Calendar event', [
                                'timezone' => (string)$tzid,
                                'error' => $e->getMessage()
                            ]);
                        }
                    }
                    
                    // Get end time
                    if (isset($vevent->DTEND)) {
                        $dtend = $vevent->DTEND;
                        $endTime = Carbon::parse((string)$dtend);
                        
                        // Check for timezone information
                        $tzid = null;
                        if ($dtend instanceof \Sabre\VObject\Property) {
                            $tzid = $dtend['TZID'] ?? null;
                        }
                        
                        if ($tzid) {
                            try {
                                $endTime->setTimezone((string)$tzid);
                            } catch (\Exception $e) {
                                // Invalid timezone, ignore
                                Log::warning('Invalid timezone in Apple Calendar event', [
                                    'timezone' => (string)$tzid,
                                    'error' => $e->getMessage()
                                ]);
                            }
                        }
                    } else {
                        // If no end time, assume same as start time
                        $endTime = $startTime->copy();
                    }
                }
            }
            
            if (!$startTime || !$endTime) {
                return null;
            }
            
            // Check for recurrence
            $recurrence = null;
            if (isset($vevent->RRULE)) {
                $recurrence = $this->parseICalRecurrence((string)$vevent->RRULE);
            }
            
            return [
                'provider_event_id' => $uid,
                'title' => $title,
                'description' => $description,
                'location' => $location,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'is_all_day' => $isAllDay,
                'recurrence' => $recurrence
            ];
            
        } catch (Exception $e) {
            Log::error('Apple Calendar Sync: Error extracting event data', [
                'error' => $e->getMessage()
            ]);
            
            return null;
        }
    }
    
    /**
     * Check if an event was created by our application
     * 
     * @param array $eventData
     * @return bool
     */
    protected function isEventCreatedByApp(array $eventData): bool
    {
        // For Apple Calendar, we need to check the event UID
        // Events created by our app should have a specific pattern in the UID
        // e.g., "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx@maya.com"
        $uid = $eventData['provider_event_id'] ?? '';
        
        return strpos($uid, '@' . config('app.name', 'maya') . '.com') !== false;
    }
    
    /**
     * Update an existing event with data from Apple Calendar
     * 
     * @param Event $event
     * @param array $eventData
     * @return bool
     */
    protected function updateExistingEvent(Event $event, array $eventData): bool
    {
        try {
            // Update event properties
            $event->title = $eventData['title'];
            $event->description = $eventData['description'];
            $event->location = $eventData['location'];
            $event->start_time = $eventData['start_time'];
            $event->end_time = $eventData['end_time'];
            $event->is_all_day = $eventData['is_all_day'];
            $event->recurrence = $eventData['recurrence']; // Update recurrence data
            
            // Update metadata
            $metadata = $event->metadata ?: [];
            $metadata['provider_metadata'] = array_merge($metadata['provider_metadata'] ?? [], $eventData['provider_metadata']);
            $metadata['provider_metadata']['is_recurring'] = !empty($eventData['recurrence']);
            
            $event->metadata = $metadata;
            $event->save();
            
            Log::info('Apple Calendar Sync: Updated event', [
                'event_id' => $event->id,
                'provider_event_id' => $event->provider_event_id,
                'is_recurring' => !empty($eventData['recurrence'])
            ]);
            
            return true;
            
        } catch (Exception $e) {
            Log::error('Apple Calendar Sync: Failed to update event', [
                'event_id' => $event->id,
                'error' => $e->getMessage()
            ]);
            
            return false;
        }
    }
    
    /**
     * Create a new event from Apple Calendar data
     * 
     * @param CalendarConnection $calendar
     * @param array $eventData
     * @return bool
     */
    protected function createNewEvent(CalendarConnection $calendar, array $eventData): bool
    {
        try {
            // Create new event in our database
            $event = new Event();
            $event->user_id = $calendar->user_id;
            $event->calendar_connection_id = $calendar->id;
            $event->provider_event_id = $eventData['provider_event_id'];
            $event->title = $eventData['title'];
            $event->description = $eventData['description'];
            $event->location = $eventData['location'];
            $event->start_time = $eventData['start_time'];
            $event->end_time = $eventData['end_time'];
            $event->is_all_day = $eventData['is_all_day'];
            $event->recurrence = $eventData['recurrence']; // Store recurrence data
            
            $event->metadata = [
                'provider_metadata' => array_merge($eventData['provider_metadata'], [
                    'is_recurring' => !empty($eventData['recurrence'])
                ])
            ];
            
            $event->save();
            
            Log::info('Apple Calendar Sync: Created new event', [
                'event_id' => $event->id,
                'provider_event_id' => $event->provider_event_id,
                'is_recurring' => !empty($eventData['recurrence'])
            ]);
            
            return true;
            
        } catch (Exception $e) {
            Log::error('Apple Calendar Sync: Failed to create new event', [
                'calendar_connection_id' => $calendar->id,
                'provider_event_id' => $eventData['provider_event_id'],
                'error' => $e->getMessage()
            ]);
            
            return false;
        }
    }
    
    /**
     * Get calendar settings from the connection
     * 
     * @param CalendarConnection $calendar
     * @return array
     * @throws Exception
     */
    protected function getCalendarSettings(CalendarConnection $calendar): array
    {
        // Get calendar account
        $calendarAccount = $calendar->calendarAccount;
        
        if (!$calendarAccount) {
            throw new Exception('Calendar account not found for this calendar connection');
        }
        
        $accountMetadata = $calendarAccount->provider_metadata ?? [];
        $connectionMetadata = $calendar->provider_metadata ?? [];
        
        // Check for required fields
        if (empty($calendarAccount->account_id) || empty($calendarAccount->access_token)) {
            throw new Exception('Missing required Apple Calendar settings in calendar account');
        }

        return [
            'base_url' => self::ICLOUD_CALDAV_URL,
            'apple_id' => $calendarAccount->account_id,
            'app_password' => $calendarAccount->access_token, // App password is stored in the account's access_token
            'calendar_path' => $connectionMetadata['calendar_path'] ?? $calendar->provider_calendar_id,
            'principal_url' => $accountMetadata['principal_url'] ?? null,
        ];
    }

    /**
     * Create a CalDAV client for Apple Calendar
     * 
     * @param array $settings
     * @return DavClient
     */
    protected function getDavClient(array $settings): DavClient
    {
        return new DavClient([
            'baseUri' => $settings['base_url'],
            'userName' => $settings['apple_id'],
            'password' => $settings['app_password'],
            'authType' => DavClient::AUTH_BASIC
        ]);
    }
    
    /**
     * Update sync metadata for a calendar
     * 
     * @param CalendarConnection $calendar
     * @param array $data
     */
    protected function updateSyncMetadata(CalendarConnection $calendar, array $data): void
    {
        $metadata = $calendar->provider_metadata ?: [];
        
        if (!isset($metadata['sync'])) {
            $metadata['sync'] = [];
        }
        
        $metadata['sync'] = array_merge($metadata['sync'], $data);
        
        $calendar->provider_metadata = $metadata;
        $calendar->save();
    }
}