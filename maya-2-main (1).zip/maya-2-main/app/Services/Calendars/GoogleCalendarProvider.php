<?php

namespace App\Services\Calendars;

use App\Models\CalendarConnection;
use App\Models\Event;
use App\Services\Calendars\Utilities\GoogleCalendarUtility;
use Carbon\Carbon;
use Google_Client;
use Google_Service_Calendar;
use Google_Service_Calendar_Event;
use Google_Service_Calendar_EventDateTime;
use Google_Service_Calendar_ConferenceData;
use Google_Service_Calendar_CreateConferenceRequest;
use Google_Service_Calendar_ConferenceSolutionKey;
use Illuminate\Support\Facades\Log;
use Exception;

class GoogleCalendarProvider implements CalendarProviderInterface
{
    protected $client;
    
    /**
     * Initialize the Google client
     */
    public function __construct()
    {
        $this->client = GoogleCalendarUtility::createGoogleClient();
        $this->client->setRedirectUri(config('services.google.redirect_uri'));
        $this->client->setPrompt('select_account consent');
    }

    /**
     * Get access token from calendar or calendar account
     * 
     * @param CalendarConnection $calendar
     * @return array|null
     */
    protected function getAccessToken(CalendarConnection $calendar): ?array
    {
        // Check if calendar has an associated account
        if ($calendar->calendarAccount) {
            return [
                'access_token' => $calendar->calendarAccount->access_token,
                'refresh_token' => $calendar->calendarAccount->refresh_token,
                'expires_in' => Carbon::now()->diffInSeconds($calendar->calendarAccount->expires_at)
            ];
        }
        
        // Fallback to the calendar's token (for backward compatibility)
        return [
            'access_token' => $calendar->access_token ?? null,
            'refresh_token' => $calendar->refresh_token ?? null,
            'expires_in' => $calendar->expires_at ? Carbon::now()->diffInSeconds($calendar->expires_at) : 0
        ];
    }

    /**
     * Create an event in Google Calendar
     * 
     * @param CalendarConnection $calendar
     * @param array $eventData
     * @return array|null [provider_event_id, provider_metadata]
     */
    public function createEvent(CalendarConnection $calendar, array $eventData): ?array
    {
        try {
            Log::info('Google Calendar: Creating Event', [
                'calendar_id' => $calendar->id, 
                'calendar_name' => $calendar->name,
                'event_title' => $eventData['title']
            ]);
            
            // Set access token and handle refresh if needed
            if (!$this->refreshAccessTokenIfNeeded($calendar)) {
                Log::error('Google Calendar: Failed to refresh token', [
                    'calendar_id' => $calendar->id
                ]);
                return null;
            }
            
            $tokenData = $this->getAccessToken($calendar);
            if (!$tokenData['access_token']) {
                Log::error('Google Calendar: No access token available', [
                    'calendar_id' => $calendar->id
                ]);
                return null;
            }
            
            $this->client->setAccessToken($tokenData);
            
            // Create Google Calendar service
            $service = new Google_Service_Calendar($this->client);
            
            // Get the user's timezone from metadata
            $userTz = $eventData['metadata']['user_timezone'] ?? 'UTC';
            
            // For all-day events, handle differently
            if ($eventData['is_all_day'] ?? false) {
                $startDateTimeData = [
                    'date' => $eventData['start_time']->format('Y-m-d'),
                    'timeZone' => $userTz
                ];
                
                $endDateTimeData = [
                    'date' => $eventData['end_time']->format('Y-m-d'),
                    'timeZone' => $userTz
                ];
            } else {
                // Convert UTC times to user's timezone for Google Calendar
                $startTimeUserTz = clone $eventData['start_time'];
                $startTimeUserTz->setTimezone(new \DateTimeZone($userTz));
                
                $endTimeUserTz = clone $eventData['end_time'];
                $endTimeUserTz->setTimezone(new \DateTimeZone($userTz));
                
                $startDateTimeData = [
                    'dateTime' => $startTimeUserTz->format('Y-m-d\TH:i:s'),
                    'timeZone' => $userTz
                ];
                
                $endDateTimeData = [
                    'dateTime' => $endTimeUserTz->format('Y-m-d\TH:i:s'),
                    'timeZone' => $userTz
                ];
                
                // Log the timezone information for debugging
                Log::debug('Google Calendar: Event time data', [
                    'user_timezone' => $userTz,
                    'event_start_utc' => $eventData['start_time']->toISOString(),
                    'event_start_user_tz' => $startTimeUserTz->format('Y-m-d H:i:s T'),
                    'start_time_data' => $startDateTimeData,
                    'end_time_data' => $endDateTimeData
                ]);
            }
            
            // Create the event
            $googleEvent = new Google_Service_Calendar_Event([
                'summary' => $eventData['title'],
                'description' => $eventData['description'] ?? '',
                'location' => $eventData['location'] ?? '',
                'start' => new Google_Service_Calendar_EventDateTime($startDateTimeData),
                'end' => new Google_Service_Calendar_EventDateTime($endDateTimeData),
                'reminders' => [
                    'useDefault' => true
                ]
            ]);
            
            // Add user's timezone as an extended property to maintain this information
            $extendedProperties = new \Google_Service_Calendar_EventExtendedProperties();
            $privateProps = ['user_timezone' => $userTz];
            $extendedProperties->setPrivate($privateProps);
            $googleEvent->setExtendedProperties($extendedProperties);
            
            // Add attendees if provided
            if (!empty($eventData['attendees'])) {
                $attendees = [];
                foreach ($eventData['attendees'] as $email) {
                    $attendees[] = ['email' => $email];
                }
                $googleEvent->setAttendees($attendees);
            }
            
            // Add recurrence if provided
            if (!empty($eventData['recurrence'])) {
                $recurrenceRule = GoogleCalendarUtility::buildRecurrenceRule($eventData['recurrence']);
                if ($recurrenceRule) {
                    $googleEvent->setRecurrence([$recurrenceRule]);
                }
            }
            
            // Add Google Meet if requested and there are attendees
            $googleMeetLink = null;
            if (isset($eventData['add_google_meet']) && $eventData['add_google_meet'] === true) {
                // Create conference data
                $conferenceRequest = new Google_Service_Calendar_CreateConferenceRequest();
                $solutionKey = new Google_Service_Calendar_ConferenceSolutionKey();
                $solutionKey->setType("hangoutsMeet");
                $conferenceRequest->setConferenceSolutionKey($solutionKey);
                $conferenceRequest->setRequestId(uniqid('meet_'));
                
                $conferenceData = new Google_Service_Calendar_ConferenceData();
                $conferenceData->setCreateRequest($conferenceRequest);
                
                $googleEvent->setConferenceData($conferenceData);
                
                Log::info('Google Calendar: Adding Google Meet to event', [
                    'event_title' => $eventData['title']
                ]);
            }
            
            // Add the event to the calendar
            $calendarId = $calendar->provider_calendar_id ?: 'primary';
            $optParams = [];
            
            // Set conferenceDataVersion if we're adding Google Meet
            if (isset($eventData['add_google_meet']) && $eventData['add_google_meet'] === true) {
                $optParams['conferenceDataVersion'] = 1;
            }
            
            $createdEvent = $service->events->insert($calendarId, $googleEvent, $optParams);
            
            // Extract Google Meet link if available
            if ($createdEvent->getConferenceData()) {
                $entryPoints = $createdEvent->getConferenceData()->getEntryPoints();
                foreach ($entryPoints as $entryPoint) {
                    if ($entryPoint->getEntryPointType() === 'video') {
                        $googleMeetLink = $entryPoint->getUri();
                        break;
                    }
                }
            }
            
            Log::info('Google Calendar: Event created successfully', [
                'google_event_id' => $createdEvent->getId(),
                'calendar_id' => $calendar->id,
                'google_meet_link' => $googleMeetLink
            ]);
            
            // Store timezone information in metadata
            $metadata = [
                'created_at' => now()->timestamp,
                'html_link' => $createdEvent->getHtmlLink(),
                'calendar_id' => $calendarId,
                'i_cal_uid' => $createdEvent->getICalUID(),
                'etag' => $createdEvent->getEtag(),
                'timezone' => $eventData['start_time']->tzName, // Store timezone info
                'user_timezone' => $userTz, // Store user's timezone
            ];
            
            return [
                'provider_event_id' => $createdEvent->getId(),
                'provider_metadata' => $metadata,
                'google_meet_link' => $googleMeetLink
            ];
            
        } catch (Exception $e) {
            Log::error('Google Calendar: Error creating event', [
                'calendar_id' => $calendar->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return null;
        }
    }

    /**
     * Delete an event in Google Calendar
     * 
     * @param CalendarConnection $calendar
     * @param Event $event
     * @return array|null
     */
    public function deleteEventById(CalendarConnection $calendar, Event $event): ?array
    {
        try {
            Log::info('Google Calendar: Deleting event', [
                'calendar_id' => $calendar->id,
                'event_id' => $event->id,
                'provider_event_id' => $event->provider_event_id
            ]);
            
            if (empty($event->provider_event_id)) {
                Log::warning('Google Calendar: Cannot delete event without provider_event_id', [
                    'event_id' => $event->id
                ]);
                return null;
            }
            
            // Set access token and handle refresh if needed
            if (!$this->refreshAccessTokenIfNeeded($calendar)) {
                return null;
            }
            
            $tokenData = $this->getAccessToken($calendar);
            $this->client->setAccessToken($tokenData);
            
            // Create Google Calendar service
            $service = new Google_Service_Calendar($this->client);
            
            // Delete the event
            $calendarId = $calendar->provider_calendar_id ?: 'primary';
            $service->events->delete($calendarId, $event->provider_event_id);
            
            Log::info('Google Calendar: Event deleted successfully', [
                'event_id' => $event->id,
                'provider_event_id' => $event->provider_event_id
            ]);
            
            return [
                'success' => true,
                'provider_metadata' => [
                    'deleted_at' => now()->timestamp
                ]
            ];
            
        } catch (Exception $e) {
            Log::error('Google Calendar: Error deleting event', [
                'event_id' => $event->id,
                'error' => $e->getMessage()
            ]);
            
            return null;
        }
    }

    /**
     * Update an event in Google Calendar
     * 
     * @param CalendarConnection $calendar
     * @param Event $event
     * @param array $updateData Optional array of fields to update
     * @return array|null
     */
    public function updateEventById(CalendarConnection $calendar, Event $event, array $updateData = []): ?array
    {
        try {
            Log::info('Google Calendar: Updating event', [
                'calendar_id' => $calendar->id,
                'event_id' => $event->id,
                'provider_event_id' => $event->provider_event_id
            ]);
            
            if (empty($event->provider_event_id)) {
                Log::warning('Google Calendar: Cannot update event without provider_event_id', [
                    'event_id' => $event->id
                ]);
                return null;
            }
            
            // Set access token and handle refresh if needed
            if (!$this->refreshAccessTokenIfNeeded($calendar)) {
                return null;
            }
            
            $tokenData = $this->getAccessToken($calendar);
            $this->client->setAccessToken($tokenData);
            
            // Create Google Calendar service
            $service = new Google_Service_Calendar($this->client);
            
            // First get the existing event
            $calendarId = $calendar->provider_calendar_id ?: 'primary';
            $googleEvent = $service->events->get($calendarId, $event->provider_event_id);
            
            // Update the event properties
            $googleEvent->setSummary($event->title);
            $googleEvent->setDescription($event->description ?? '');
            $googleEvent->setLocation($event->location ?? '');
            
            // Get the user's timezone from metadata or default to UTC
            $userTz = $event->metadata['user_timezone'] ?? 'UTC';
            
            // For all-day events, use date format without time component
            if ($event->is_all_day) {
                $startDate = $event->start_time->format('Y-m-d');
                $endDate = $event->end_time->format('Y-m-d');
                
                $googleEvent->setStart(new Google_Service_Calendar_EventDateTime([
                    'date' => $startDate,
                    'timeZone' => $userTz
                ]));
                
                $googleEvent->setEnd(new Google_Service_Calendar_EventDateTime([
                    'date' => $endDate,
                    'timeZone' => $userTz
                ]));
            } else {
                // Convert UTC times to user's timezone for Google Calendar
                $startTimeUserTz = clone $event->start_time;
                $startTimeUserTz->setTimezone(new \DateTimeZone($userTz));
                
                $endTimeUserTz = clone $event->end_time;
                $endTimeUserTz->setTimezone(new \DateTimeZone($userTz));
                
                $googleEvent->setStart(new Google_Service_Calendar_EventDateTime([
                    'dateTime' => $startTimeUserTz->format('Y-m-d\TH:i:s'),
                    'timeZone' => $userTz
                ]));
                
                $googleEvent->setEnd(new Google_Service_Calendar_EventDateTime([
                    'dateTime' => $endTimeUserTz->format('Y-m-d\TH:i:s'),
                    'timeZone' => $userTz
                ]));
                
                // Log the timezone information for debugging
                Log::debug('Google Calendar: Update event time data', [
                    'user_timezone' => $userTz,
                    'event_start_utc' => $event->start_time->toISOString(),
                    'event_start_user_tz' => $startTimeUserTz->format('Y-m-d H:i:s T'),
                    'event_id' => $event->id
                ]);
            }
            
            // Update attendees if provided
            if (is_array($event->attendees) && !empty($event->attendees)) {
                $attendees = [];
                foreach ($event->attendees as $email) {
                    $attendees[] = ['email' => $email];
                }
                $googleEvent->setAttendees($attendees);
            }
            
            // Update recurrence if provided
            if (!empty($event->recurrence)) {
                $recurrenceRule = GoogleCalendarUtility::buildRecurrenceRule($event->recurrence);
                if ($recurrenceRule) {
                    $googleEvent->setRecurrence([$recurrenceRule]);
                }
            }
            
            // Check if we need to add Google Meet
            $addGoogleMeet = $updateData['add_google_meet'] ?? false;
            $googleMeetLink = null;
            
            if ($addGoogleMeet) {
                // Create conference data if it doesn't exist
                if (!$googleEvent->getConferenceData()) {
                    $conferenceRequest = new Google_Service_Calendar_CreateConferenceRequest();
                    $solutionKey = new Google_Service_Calendar_ConferenceSolutionKey();
                    $solutionKey->setType("hangoutsMeet");
                    $conferenceRequest->setConferenceSolutionKey($solutionKey);
                    $conferenceRequest->setRequestId(uniqid('meet_'));
                    
                    $conferenceData = new Google_Service_Calendar_ConferenceData();
                    $conferenceData->setCreateRequest($conferenceRequest);
                    
                    $googleEvent->setConferenceData($conferenceData);
                    
                    Log::info('Google Calendar: Adding Google Meet to event during update', [
                        'event_id' => $event->id
                    ]);
                }
            }
            
            // Add user timezone to extended properties
            $extendedProperties = $googleEvent->getExtendedProperties();
            if (!$extendedProperties) {
                $extendedProperties = new \Google_Service_Calendar_EventExtendedProperties();
            }
            
            $privateProps = $extendedProperties->getPrivate() ?: [];
            $privateProps['user_timezone'] = $userTz;
            $extendedProperties->setPrivate($privateProps);
            
            $googleEvent->setExtendedProperties($extendedProperties);
            
            // Update the event
            $optParams = [];
            
            // Set conferenceDataVersion if we're adding Google Meet
            if ($addGoogleMeet) {
                $optParams['conferenceDataVersion'] = 1;
            }
            
            $updatedEvent = $service->events->update($calendarId, $event->provider_event_id, $googleEvent, $optParams);
            
            // Extract Google Meet link if available
            if ($updatedEvent->getConferenceData()) {
                $entryPoints = $updatedEvent->getConferenceData()->getEntryPoints();
                if ($entryPoints) {
                    foreach ($entryPoints as $entryPoint) {
                        if ($entryPoint->getEntryPointType() === 'video') {
                            $googleMeetLink = $entryPoint->getUri();
                            break;
                        }
                    }
                }
            }
            
            Log::info('Google Calendar: Event updated successfully', [
                'event_id' => $event->id,
                'provider_event_id' => $updatedEvent->getId(),
                'google_meet_link' => $googleMeetLink
            ]);
            
            return [
                'provider_event_id' => $updatedEvent->getId(),
                'provider_metadata' => [
                    'updated_at' => now()->timestamp,
                    'html_link' => $updatedEvent->getHtmlLink(),
                    'etag' => $updatedEvent->getEtag(),
                    'timezone' => $event->start_time->tzName,
                    'user_timezone' => $userTz
                ],
                'google_meet_link' => $googleMeetLink
            ];
            
        } catch (Exception $e) {
            Log::error('Google Calendar: Error updating event', [
                'event_id' => $event->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return null;
        }
    }

    /**
     * Refresh access token if needed
     * 
     * @param CalendarConnection $calendar
     * @return bool
     */
    public function refreshAccessTokenIfNeeded(CalendarConnection $calendar): bool
    {
        try {
            // Get the account that contains the tokens
            $account = $calendar->calendarAccount;
            
            // If no account is found, try to use the calendar's tokens (for backward compatibility)
            if (!$account) {
                // Check if token is expired or about to expire (within 5 minutes)
                if ($calendar->expires_at && $calendar->expires_at->subMinutes(5)->isPast()) {
                    Log::info('Google Calendar: Refreshing token from calendar', ['calendar_id' => $calendar->id]);
                    
                    if (empty($calendar->refresh_token)) {
                        Log::error('Google Calendar: No refresh token available', ['calendar_id' => $calendar->id]);
                        return false;
                    }
                    
                    // Set the refresh token AND access token
                    $this->client->setAccessToken([
                        'access_token' => $calendar->access_token,
                        'refresh_token' => $calendar->refresh_token,
                        'expires_in' => $calendar->expires_at ? Carbon::now()->diffInSeconds($calendar->expires_at) : 3600
                    ]);
                    
                    $newToken = $this->client->fetchAccessTokenWithRefreshToken();
                    
                    if (isset($newToken['error'])) {
                        Log::error('Google Calendar: Error refreshing token', [
                            'calendar_id' => $calendar->id,
                            'error' => $newToken['error']
                        ]);
                        return false;
                    }
                    
                    // Update the calendar connection with the new token
                    $calendar->access_token = $newToken['access_token'];
                    if (isset($newToken['refresh_token'])) {
                        $calendar->refresh_token = $newToken['refresh_token'];
                    }
                    
                    // Set new expiration time
                    $expiresIn = $newToken['expires_in'] ?? 3600; // Default to 1 hour
                    $calendar->expires_at = now()->addSeconds($expiresIn);
                    
                    $calendar->save();
                    
                    Log::info('Google Calendar: Token refreshed successfully in calendar', ['calendar_id' => $calendar->id]);
                }
                
                return true;
            }
            
            // Check if token is expired or about to expire (within 5 minutes)
            if ($account->expires_at && $account->expires_at->subMinutes(5)->isPast()) {
                Log::info('Google Calendar: Refreshing token for account', [
                    'calendar_id' => $calendar->id,
                    'account_id' => $account->id
                ]);
                
                if (empty($account->refresh_token)) {
                    Log::error('Google Calendar: No refresh token available for account', [
                        'account_id' => $account->id
                    ]);
                    return false;
                }
                
                // Set the complete token data
                $this->client->setAccessToken([
                    'access_token' => $account->access_token,
                    'refresh_token' => $account->refresh_token,
                    'expires_in' => $account->expires_at ? Carbon::now()->diffInSeconds($account->expires_at) : 3600
                ]);
                
                $newToken = $this->client->fetchAccessTokenWithRefreshToken();
                
                if (isset($newToken['error'])) {
                    Log::error('Google Calendar: Error refreshing token for account', [
                        'account_id' => $account->id,
                        'error' => $newToken['error']
                    ]);
                    return false;
                }
                
                // Update the account with the new token
                $account->access_token = $newToken['access_token'];
                if (isset($newToken['refresh_token'])) {
                    $account->refresh_token = $newToken['refresh_token'];
                }
                
                // Set new expiration time
                $expiresIn = $newToken['expires_in'] ?? 3600; // Default to 1 hour
                $account->expires_at = now()->addSeconds($expiresIn);
                
                $account->save();
                
                Log::info('Google Calendar: Token refreshed successfully for account', [
                    'account_id' => $account->id
                ]);
            }
            
            return true;
            
        } catch (Exception $e) {
            Log::error('Google Calendar: Error refreshing token', [
                'calendar_id' => $calendar->id,
                'error' => $e->getMessage()
            ]);
            
            return false;
        }
    }
}