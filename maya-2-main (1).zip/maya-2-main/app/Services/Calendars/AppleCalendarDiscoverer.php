<?php

namespace App\Services\Calendars;

use Illuminate\Support\Facades\Log;
use Exception;
use Sabre\DAV\Client as DavClient;

class AppleCalendarDiscoverer
{
    // iCloud CalDAV endpoint
    protected const ICLOUD_CALDAV_URL = 'https://caldav.icloud.com';
    
    /**
     * Discover available CalDAV calendars for an Apple ID
     * 
     * @param string $appleId
     * @param string $appPassword
     * @return array|null
     */
    public function discoverCalendars(string $appleId, string $appPassword): ?array
    {
        try {
            Log::info('Apple Calendar: Discovering calendars for Apple ID', [
                'apple_id' => $appleId
            ]);
            
            // Create a DAV client for iCloud
            $davClient = new DavClient([
                'baseUri' => self::ICLOUD_CALDAV_URL,
                'userName' => $appleId,
                'password' => $appPassword
            ]);
            
            // Step 1: Find the principal URL
            $response = $davClient->request('PROPFIND', '/', <<<XML
            <?xml version="1.0"?>
            <d:propfind xmlns:d="DAV:">
                <d:prop>
                    <d:current-user-principal />
                </d:prop>
            </d:propfind>
            XML
            , ['Depth' => '0']);
            
            if ($response['statusCode'] !== 207) {
                throw new Exception('Failed to discover principal URL: ' . $response['statusCode']);
            }
            
            // Parse principal URL
            $xml = new \SimpleXMLElement($response['body']);
            $xml->registerXPathNamespace('d', 'DAV:');
            $principalNodes = $xml->xpath('//d:current-user-principal/d:href');
            
            if (empty($principalNodes)) {
                throw new Exception('No principal URL found in response');
            }
            
            $principalUrl = (string)$principalNodes[0];
            Log::info('Found principal URL', ['url' => $principalUrl]);
            
            // Step 2: Find calendar home set
            $response = $davClient->request('PROPFIND', $principalUrl, <<<XML
            <?xml version="1.0"?>
            <d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">
                <d:prop>
                    <c:calendar-home-set />
                </d:prop>
            </d:propfind>
            XML
            , ['Depth' => '0']);
            
            if ($response['statusCode'] !== 207) {
                throw new Exception('Failed to discover calendar home set: ' . $response['statusCode']);
            }
            
            // Parse calendar home set
            $xml = new \SimpleXMLElement($response['body']);
            $xml->registerXPathNamespace('d', 'DAV:');
            $xml->registerXPathNamespace('c', 'urn:ietf:params:xml:ns:caldav');
            $homeNodes = $xml->xpath('//c:calendar-home-set/d:href');
            
            if (empty($homeNodes)) {
                throw new Exception('No calendar home set found in response');
            }
            
            $calendarHomeSet = (string)$homeNodes[0];
            Log::info('Found calendar home set', ['home' => $calendarHomeSet]);
            
            // Step 3: List all calendars in the home set
            $response = $davClient->request('PROPFIND', $calendarHomeSet, <<<XML
            <?xml version="1.0"?>
            <d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav" xmlns:cs="http://calendarserver.org/ns/" xmlns:ic="http://apple.com/ns/ical/">
                <d:prop>
                    <d:resourcetype />
                    <d:displayname />
                    <cs:getctag />
                    <c:supported-calendar-component-set />
                    <ic:calendar-color />
                </d:prop>
            </d:propfind>
            XML
            , ['Depth' => '1']);
            
            if ($response['statusCode'] !== 207) {
                throw new Exception('Failed to list calendars: ' . $response['statusCode']);
            }
            
            // Parse calendars - carefully register all namespaces
            $calendarXml = new \SimpleXMLElement($response['body']);
            
            // Register all namespaces on the root element
            $calendarXml->registerXPathNamespace('d', 'DAV:');
            $calendarXml->registerXPathNamespace('c', 'urn:ietf:params:xml:ns:caldav');
            $calendarXml->registerXPathNamespace('cs', 'http://calendarserver.org/ns/');
            $calendarXml->registerXPathNamespace('ic', 'http://apple.com/ns/ical/');
            
            // Find all response elements
            $responseElements = $calendarXml->xpath('//d:response');
            Log::info('Found response elements', ['count' => count($responseElements)]);
            
            $calendars = [];
            
            foreach ($responseElements as $i => $responseElement) {
                // Register namespaces on each response element
                $responseElement->registerXPathNamespace('d', 'DAV:');
                
                // Get href
                $hrefNodes = $responseElement->xpath('./d:href');
                if (empty($hrefNodes)) {
                    Log::warning('No href found for response', ['index' => $i]);
                    continue;
                }
                
                $href = (string)$hrefNodes[0];
                
                // Skip the calendar home itself
                if ($href === $calendarHomeSet) {
                    continue;
                }
                
                // Register namespaces for resourcetype check
                $responseElement->registerXPathNamespace('d', 'DAV:');
                $responseElement->registerXPathNamespace('c', 'urn:ietf:params:xml:ns:caldav');
                
                // Check if this is a calendar (has resourcetype calendar)
                $propstatNodes = $responseElement->xpath('./d:propstat/d:prop');
                if (empty($propstatNodes)) {
                    continue;
                }
                
                $propNode = $propstatNodes[0];
                $propNode->registerXPathNamespace('d', 'DAV:');
                $propNode->registerXPathNamespace('c', 'urn:ietf:params:xml:ns:caldav');
                
                $resourceTypeNodes = $propNode->xpath('./d:resourcetype');
                if (empty($resourceTypeNodes)) {
                    continue;
                }
                
                $resourceTypeNode = $resourceTypeNodes[0];
                $resourceTypeNode->registerXPathNamespace('c', 'urn:ietf:params:xml:ns:caldav');
                
                $calendarTypeNodes = $resourceTypeNode->xpath('./c:calendar');
                $isCalendar = !empty($calendarTypeNodes);
                
                if (!$isCalendar) {
                    continue;
                }
                
                // Check if it supports VEVENT
                $propNode->registerXPathNamespace('c', 'urn:ietf:params:xml:ns:caldav');
                $compSetNodes = $propNode->xpath('./c:supported-calendar-component-set/c:comp');
                
                $supportsEvents = false;
                if (!empty($compSetNodes)) {
                    foreach ($compSetNodes as $comp) {
                        if ((string)$comp->attributes()->name === 'VEVENT') {
                            $supportsEvents = true;
                            break;
                        }
                    }
                }
                
                if (!$supportsEvents) {
                    continue;
                }
                
                // Get properties
                $propNode->registerXPathNamespace('d', 'DAV:');
                $propNode->registerXPathNamespace('cs', 'http://calendarserver.org/ns/');
                $propNode->registerXPathNamespace('ic', 'http://apple.com/ns/ical/');
                
                $displayNameNodes = $propNode->xpath('./d:displayname');
                $displayName = !empty($displayNameNodes) ? (string)$displayNameNodes[0] : 'Unnamed Calendar';
                
                $ctagNodes = $propNode->xpath('./cs:getctag');
                $ctag = !empty($ctagNodes) ? (string)$ctagNodes[0] : null;
                
                $colorNodes = $propNode->xpath('./ic:calendar-color');
                $color = !empty($colorNodes) ? (string)$colorNodes[0] : '#4a86e8';
                
                $calendars[] = [
                    'url' => $href,
                    'name' => $displayName,
                    'ctag' => $ctag,
                    'color' => $color,
                    'supports_events' => $supportsEvents
                ];
                
                Log::info('Found calendar', [
                    'name' => $displayName,
                    'url' => $href
                ]);
            }
            
            Log::info('Calendar discovery complete', ['count' => count($calendars)]);
            
            return [
                'principal_url' => $principalUrl,
                'calendar_home' => $calendarHomeSet,
                'calendars' => $calendars
            ];
            
        } catch (Exception $e) {
            Log::error('Apple Calendar: Error discovering calendars', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return null;
        }
    }

    /**
     * Test Apple Calendar credentials by attempting to create a test event
     * 
     * @param string $appleId
     * @param string $appPassword
     * @param string $calendarUrl
     * @return array
     */
    public function testCredentials(string $appleId, string $appPassword, string $calendarUrl): array
    {
        try {
            Log::info('Testing Apple Calendar credentials', [
                'apple_id' => $appleId,
                'calendar_url' => $calendarUrl
            ]);
            
            // Create a test DAV client
            $davClient = new DavClient([
                'baseUri' => self::ICLOUD_CALDAV_URL,
                'userName' => $appleId,
                'password' => $appPassword,
                'authType' => DavClient::AUTH_BASIC
            ]);
            
            // First test: Simple PROPFIND to check access
            $response = $davClient->request('PROPFIND', $calendarUrl, null, [
                'Depth' => '0',
            ]);
            
            if ($response['statusCode'] < 200 || $response['statusCode'] >= 300) {
                return [
                    'success' => false,
                    'message' => 'Failed to access calendar. Check credentials and calendar URL.',
                    'status_code' => $response['statusCode']
                ];
            }
            
            return [
                'success' => true,
                'message' => 'Successfully verified Apple Calendar credentials.'
            ];
            
        } catch (Exception $e) {
            Log::error('Error testing Apple Calendar credentials', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ];
        }
    }
}