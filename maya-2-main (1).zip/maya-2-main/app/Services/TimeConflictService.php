<?php

namespace App\Services;

use App\Models\User;
use App\Models\Event;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class TimeConflictService
{
    /**
     * Check for time conflicts with existing events
     * All times should be in UTC for consistent comparison
     * 
     * @param User $user The user to check events for
     * @param Carbon $startTime Start time of the new event in UTC
     * @param Carbon $endTime End time of the new event in UTC
     * @param int|null $excludeEventId Optional event ID to exclude from conflict check (for updates)
     * @return array Array of conflicting events
     */
    public function checkTimeConflicts(User $user, Carbon $startTime, Carbon $endTime, ?int $excludeEventId = null): array
    {
        try {
            // Ensure times are in UTC for comparison
            if ($startTime->timezone->getName() !== 'UTC') {
                $startTime = $startTime->copy()->setTimezone('UTC');
            }
            
            if ($endTime->timezone->getName() !== 'UTC') {
                $endTime = $endTime->copy()->setTimezone('UTC');
            }
            
            Log::info('Checking time conflicts in UTC', [
                'user_id' => $user->id,
                'start_time_utc' => $startTime->toIso8601String(),
                'end_time_utc' => $endTime->toIso8601String(),
                'exclude_event_id' => $excludeEventId
            ]);

            // Query for overlapping events
            $query = Event::where('user_id', $user->id)
                ->where('status', '!=', 'cancelled')
                ->where(function ($query) use ($startTime, $endTime) {
                    // Event starts during the new event time range
                    $query->where(function ($q) use ($startTime, $endTime) {
                        $q->where('start_time', '>=', $startTime)
                          ->where('start_time', '<', $endTime);
                    })
                    // Event ends during the new event time range
                    ->orWhere(function ($q) use ($startTime, $endTime) {
                        $q->where('end_time', '>', $startTime)
                          ->where('end_time', '<=', $endTime);
                    })
                    // Event encompasses the new event's time range
                    ->orWhere(function ($q) use ($startTime, $endTime) {
                        $q->where('start_time', '<=', $startTime)
                          ->where('end_time', '>=', $endTime);
                    });
                });

            // Exclude the event being updated if provided
            if ($excludeEventId) {
                $query->where('id', '!=', $excludeEventId);
            }

            // Get the conflicts
            $conflicts = $query->get();

            Log::info('Time conflict check results', [
                'conflicts_found' => $conflicts->count(),
                'user_id' => $user->id
            ]);

            return $conflicts->toArray();

        } catch (\Exception $e) {
            Log::error('Error checking time conflicts', [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return [];
        }
    }

    /**
     * Format conflict information for display to the user
     * 
     * @param array $conflicts Array of conflicting events
     * @param string $timezone User's timezone for display
     * @return array Formatted conflict information
     */
    public function formatConflictInfo(array $conflicts, string $timezone): array
    {
        $formattedConflicts = [];
        
        foreach ($conflicts as $conflict) {
            // Convert times from UTC to user's timezone for display
            $startTime = Carbon::parse($conflict['start_time'], 'UTC')->setTimezone($timezone);
            $endTime = Carbon::parse($conflict['end_time'], 'UTC')->setTimezone($timezone);
            
            $formattedConflicts[] = [
                'id' => $conflict['id'],
                'title' => $conflict['title'],
                'start_time' => $startTime->format('g:i A'),
                'end_time' => $endTime->format('g:i A'),
                'date' => $startTime->format('l, F j, Y'),
                'location' => $conflict['location'] ?? null,
                'start_utc' => Carbon::parse($conflict['start_time'], 'UTC')->toIso8601String(),
                'end_utc' => Carbon::parse($conflict['end_time'], 'UTC')->toIso8601String()
            ];
        }
        
        return [
            'count' => count($formattedConflicts),
            'events' => $formattedConflicts,
            'display_timezone' => $timezone
        ];
    }
}