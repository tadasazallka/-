<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ManyChatAPIService
{
    protected $apiKey;
    protected $baseUrl;

    public function __construct()
    {
        $this->apiKey = env('MANYCHAT_API_KEY'); // Add this to your .env file
        $this->baseUrl = 'https://api.manychat.com';
    }

    /**
     * Send a text message to a ManyChat subscriber
     */
    public function sendMessage($subscriberId, $message)
    {
        // Log the message being sent
        Log::info('ManyChat message sent -------------->>>>>>>>>>  ' . $message);
        
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Content-Type' => 'application/json',
            'Accept' => 'application/json'
        ])->post($this->baseUrl . '/fb/sending/sendContent', [
            'subscriber_id' => $subscriberId,
            'data' => [
                'version' => 'v2',
                'content' => [
                    'type' => 'whatsapp',
                    'messages' => [
                        [
                            'type' => 'text',
                            'text' => $message
                        ]
                    ]
                ]
            ]
        ]);

        if ($response->successful()) {
            Log::info('ManyChat message sent successfully', [
                'subscriber_id' => $subscriberId,
                'response' => $response->json()
            ]);
        } else {
            Log::error('Failed to send ManyChat message', [
                'subscriber_id' => $subscriberId,
                'status' => $response->status(),
                'response' => $response->json()
            ]);
        }

        return $response->json();
    }

    /**
     * Send a WhatsApp message through ManyChat (for WhatsApp Business accounts)
     */
    public function sendWhatsAppMessage($subscriberId, $message)
    {
        Log::info('ManyChat WhatsApp message sent -------------->>>>>>>>>>  ' . $message);
        
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Content-Type' => 'application/json',
            'Accept' => 'application/json'
        ])->post($this->baseUrl . '/fb/sending/sendContent', [
            'subscriber_id' => $subscriberId,
            'data' => [
                'version' => 'v2',
                'content' => [
                    'type' => 'whatsapp', // Specify WhatsApp as the channel
                    'messages' => [
                        [
                            'type' => 'text',
                            'text' => $message
                        ]
                    ]
                ]
            ]
        ]);

        if ($response->successful()) {
            Log::info('ManyChat WhatsApp message sent successfully', [
                'subscriber_id' => $subscriberId,
                'response' => $response->json()
            ]);
        } else {
            Log::error('Failed to send ManyChat WhatsApp message', [
                'subscriber_id' => $subscriberId,
                'status' => $response->status(),
                'response' => $response->json()
            ]);
        }

        return $response->json();
    }

    /**
     * Get subscriber information
     */
    public function getSubscriber($subscriberId)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Accept' => 'application/json'
            ])->get($this->baseUrl . '/fb/subscriber/getInfo', [
                'subscriber_id' => $subscriberId
            ]);

            if (!$response->successful()) {
                Log::error('Failed to get subscriber info', [
                    'subscriber_id' => $subscriberId,
                    'status' => $response->status(),
                    'response' => $response->json()
                ]);
                return null;
            }

            return $response->json();
        } catch (\Exception $e) {
            Log::error('Error getting subscriber info: ' . $e->getMessage(), [
                'subscriber_id' => $subscriberId
            ]);
            return null;
        }
    }

    /**
     * Create a new subscriber
     */
    public function createSubscriber($phone, $firstName = null, $lastName = null, $customFields = [])
    {
        try {
            $data = [
                'phone' => $phone
            ];

            if ($firstName) {
                $data['first_name'] = $firstName;
            }

            if ($lastName) {
                $data['last_name'] = $lastName;
            }

            if (!empty($customFields)) {
                $data['custom_fields'] = $customFields;
            }

            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ])->post($this->baseUrl . '/fb/subscriber/createSubscriber', $data);

            if ($response->successful()) {
                Log::info('ManyChat subscriber created successfully', [
                    'phone' => $phone,
                    'response' => $response->json()
                ]);
            } else {
                Log::error('Failed to create ManyChat subscriber', [
                    'phone' => $phone,
                    'status' => $response->status(),
                    'response' => $response->json()
                ]);
            }

            return $response->json();
        } catch (\Exception $e) {
            Log::error('Error creating subscriber: ' . $e->getMessage(), [
                'phone' => $phone
            ]);
            return null;
        }
    }

    /**
     * Add tag to subscriber
     */
    public function addTag($subscriberId, $tagId)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ])->post($this->baseUrl . '/fb/subscriber/addTag', [
                'subscriber_id' => $subscriberId,
                'tag_id' => $tagId
            ]);

            if ($response->successful()) {
                Log::info('Tag added to subscriber successfully', [
                    'subscriber_id' => $subscriberId,
                    'tag_id' => $tagId
                ]);
            } else {
                Log::error('Failed to add tag to subscriber', [
                    'subscriber_id' => $subscriberId,
                    'tag_id' => $tagId,
                    'status' => $response->status(),
                    'response' => $response->json()
                ]);
            }

            return $response->json();
        } catch (\Exception $e) {
            Log::error('Error adding tag to subscriber: ' . $e->getMessage(), [
                'subscriber_id' => $subscriberId,
                'tag_id' => $tagId
            ]);
            return null;
        }
    }

    /**
     * Set custom field for subscriber
     */
    public function setCustomField($subscriberId, $fieldName, $fieldValue)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ])->post($this->baseUrl . '/fb/subscriber/setCustomField', [
                'subscriber_id' => $subscriberId,
                'field_name' => $fieldName,
                'field_value' => $fieldValue
            ]);

            if ($response->successful()) {
                Log::info('Custom field set for subscriber successfully', [
                    'subscriber_id' => $subscriberId,
                    'field_name' => $fieldName,
                    'field_value' => $fieldValue
                ]);
            } else {
                Log::error('Failed to set custom field for subscriber', [
                    'subscriber_id' => $subscriberId,
                    'field_name' => $fieldName,
                    'field_value' => $fieldValue,
                    'status' => $response->status(),
                    'response' => $response->json()
                ]);
            }

            return $response->json();
        } catch (\Exception $e) {
            Log::error('Error setting custom field for subscriber: ' . $e->getMessage(), [
                'subscriber_id' => $subscriberId,
                'field_name' => $fieldName,
                'field_value' => $fieldValue
            ]);
            return null;
        }
    }

    /**
     * Download media (this method may not be directly available in ManyChat API)
     * You might need to handle media differently based on how ManyChat provides media URLs
     */
    public function downloadMedia($mediaId)
    {
        // ManyChat typically provides direct media URLs in webhooks
        // This method might not be needed or work differently
        Log::warning('downloadMedia method called - ManyChat handles media URLs differently than WhatsApp API');
        return null;
    }
}