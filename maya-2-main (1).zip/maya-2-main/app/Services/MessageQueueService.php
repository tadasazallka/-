<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;

class MessageQueueService
{
    // Redis key prefixes
    const USER_QUEUE_PREFIX = 'whatsapp:message_queue:';
    const USER_LOCK_PREFIX = 'whatsapp:processing_lock:';
    const MESSAGE_LOCK_PREFIX = 'whatsapp:message_lock:';
    
    // Lock durations
    const USER_LOCK_TTL = 300; // 5 minutes
    const MESSAGE_LOCK_TTL = 180; // 3 minutes
    
    /**
     * Add a message to a user's queue
     *
     * @param User $user
     * @param array $messageData Message data including type, content, etc.
     * @return bool
     */
    public function addMessageToQueue(User $user, array $messageData): bool
    {
        try {
            $queueKey = $this->getUserQueueKey($user->id);
            
            // Add timestamp to track when the message was added
            $messageData['queued_at'] = now()->timestamp;
            $messageData['id'] = $messageData['id'] ?? uniqid();
            
            // Add message to the queue (right push to maintain order - FIFO)
            Redis::rpush($queueKey, json_encode($messageData));
            
            // Set expiration on the queue if it's new (24 hours)
            if (Redis::ttl($queueKey) < 0) {
                Redis::expire($queueKey, 86400);
            }
            
            Log::info('Message added to queue', [
                'user_id' => $user->id,
                'message_id' => $messageData['id'],
                'queue_length' => Redis::llen($queueKey)
            ]);
            
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to add message to queue: ' . $e->getMessage(), [
                'user_id' => $user->id,
                'exception' => $e->getTraceAsString()
            ]);
            
            return false;
        }
    }
    
    /**
     * Get the next message from a user's queue without removing it
     *
     * @param User $user
     * @return array|null
     */
    public function peekNextMessage(User $user): ?array
    {
        $queueKey = $this->getUserQueueKey($user->id);
        $messageJson = Redis::lindex($queueKey, 0);
        
        if (!$messageJson) {
            return null;
        }
        
        return json_decode($messageJson, true);
    }
    
    /**
     * Get and lock the next message for processing
     *
     * @param User $user
     * @return array|null
     */
    public function getNextMessageForProcessing(User $user): ?array
    {
        try {
            $queueKey = $this->getUserQueueKey($user->id);
            
            // Get the next message without removing it first
            $messageJson = Redis::lindex($queueKey, 0);
            
            if (!$messageJson) {
                return null; // Queue is empty
            }
            
            $message = json_decode($messageJson, true);
            
            // Try to acquire a lock for this specific message
            $messageLockKey = $this->getMessageLockKey($user->id, $message['id']);
            
            // Use Redis SETNX to ensure only one process locks the message
            if (!Redis::setnx($messageLockKey, 1)) {
                Log::info('Message already being processed', [
                    'user_id' => $user->id,
                    'message_id' => $message['id']
                ]);
                
                return null; // Message is already being processed
            }
            
            // Set lock expiration
            Redis::expire($messageLockKey, self::MESSAGE_LOCK_TTL);
            
            // Now we can safely remove the message from the queue
            Redis::lpop($queueKey);
            
            Log::info('Message locked for processing', [
                'user_id' => $user->id,
                'message_id' => $message['id'],
                'remaining_in_queue' => Redis::llen($queueKey)
            ]);
            
            return $message;
        } catch (\Exception $e) {
            Log::error('Error getting next message: ' . $e->getMessage(), [
                'user_id' => $user->id,
                'exception' => $e->getTraceAsString()
            ]);
            
            return null;
        }
    }
    
    /**
     * Mark a message as processed and release the lock
     *
     * @param User $user
     * @param string $messageId
     * @return bool
     */
    public function markMessageAsProcessed(User $user, string $messageId): bool
    {
        try {
            $messageLockKey = $this->getMessageLockKey($user->id, $messageId);
            
            // Release the message lock
            Redis::del($messageLockKey);
            
            Log::info('Message marked as processed', [
                'user_id' => $user->id,
                'message_id' => $messageId
            ]);
            
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to mark message as processed: ' . $e->getMessage(), [
                'user_id' => $user->id,
                'message_id' => $messageId
            ]);
            
            return false;
        }
    }
    
    /**
     * Release a message lock in case of errors
     *
     * @param User $user
     * @param string $messageId
     * @return bool
     */
    public function releaseMessageLock(User $user, string $messageId): bool
    {
        try {
            $messageLockKey = $this->getMessageLockKey($user->id, $messageId);
            
            // Release the message lock
            Redis::del($messageLockKey);
            
            Log::info('Message lock released', [
                'user_id' => $user->id,
                'message_id' => $messageId
            ]);
            
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to release message lock: ' . $e->getMessage(), [
                'user_id' => $user->id,
                'message_id' => $messageId
            ]);
            
            return false;
        }
    }
    
    /**
     * Check if there are any messages in the user's queue
     *
     * @param User $user
     * @return bool
     */
    public function hasQueuedMessages(User $user): bool
    {
        $queueKey = $this->getUserQueueKey($user->id);
        return Redis::llen($queueKey) > 0;
    }
    
    /**
     * Count messages in a user's queue
     *
     * @param User $user
     * @return int
     */
    public function countQueuedMessages(User $user): int
    {
        $queueKey = $this->getUserQueueKey($user->id);
        return (int) Redis::llen($queueKey);
    }
    
    /**
     * Try to acquire a lock for processing a user's queue
     *
     * @param User $user
     * @return bool
     */
    public function acquireUserLock(User $user): bool
    {
        $lockKey = $this->getUserLockKey($user->id);
        
        // Try to set the lock only if it doesn't exist
        if (!Redis::setnx($lockKey, now()->timestamp)) {
            // Lock already exists, check if it's stale
            $lockTimestamp = (int) Redis::get($lockKey);
            $lockAge = now()->timestamp - $lockTimestamp;
            
            if ($lockAge < self::USER_LOCK_TTL) {
                // Lock is still valid
                return false;
            }
            
            // Lock is stale, override it
            Log::warning('Overriding stale lock', [
                'user_id' => $user->id,
                'lock_age' => $lockAge
            ]);
        }
        
        // Set lock expiration
        Redis::expire($lockKey, self::USER_LOCK_TTL);
        
        Log::info('User lock acquired', [
            'user_id' => $user->id
        ]);
        
        return true;
    }
    
    /**
     * Release the user lock
     *
     * @param User $user
     * @return bool
     */
    public function releaseUserLock(User $user): bool
    {
        try {
            $lockKey = $this->getUserLockKey($user->id);
            Redis::del($lockKey);
            
            Log::info('User lock released', [
                'user_id' => $user->id
            ]);
            
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to release user lock: ' . $e->getMessage(), [
                'user_id' => $user->id
            ]);
            
            return false;
        }
    }
    
    /**
     * Check if a user lock exists
     *
     * @param User $user
     * @return bool
     */
    public function userLockExists(User $user): bool
    {
        $lockKey = $this->getUserLockKey($user->id);
        return Redis::exists($lockKey) === 1;
    }
    
    /**
     * Get all queued messages for a user (for debugging)
     *
     * @param User $user
     * @return array
     */
    public function getAllQueuedMessages(User $user): array
    {
        $queueKey = $this->getUserQueueKey($user->id);
        $messages = Redis::lrange($queueKey, 0, -1);
        
        return array_map(function ($messageJson) {
            return json_decode($messageJson, true);
        }, $messages);
    }
    
    /**
     * Generate a Redis key for a user's message queue
     *
     * @param int $userId
     * @return string
     */
    private function getUserQueueKey(int $userId): string
    {
        return self::USER_QUEUE_PREFIX . $userId;
    }
    
    /**
     * Generate a Redis key for a user's processing lock
     *
     * @param int $userId
     * @return string
     */
    private function getUserLockKey(int $userId): string
    {
        return self::USER_LOCK_PREFIX . $userId;
    }
    
    /**
     * Generate a Redis key for a specific message lock
     *
     * @param int $userId
     * @param string $messageId
     * @return string
     */
    private function getMessageLockKey(int $userId, string $messageId): string
    {
        return self::MESSAGE_LOCK_PREFIX . $userId . ':' . $messageId;
    }
}