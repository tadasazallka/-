<?php

namespace App\Services;

use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Log;

class UserInfoRefreshService
{
    const REFRESH_FLAG_TTL = 86400; // 24 hours
    
    /**
     * Mark that a user's information has been updated
     * 
     * @param int|object $userId User ID or User object
     * @return void
     */
    public function markUserInfoUpdated($userId)
    {
        if (is_object($userId) && property_exists($userId, 'id')) {
            $userId = $userId->id;
        }
        
        try {
            // Set a flag in Redis indicating user info needs refresh
            $redisKey = "user:{$userId}:info_updated";
            Redis::set($redisKey, time());
            Redis::expire($redisKey, self::REFRESH_FLAG_TTL);
            
            Log::info('Marked user info as updated', [
                'user_id' => $userId,
                'timestamp' => time()
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to mark user info as updated: ' . $e->getMessage(), [
                'user_id' => $userId
            ]);
        }
    }
    
    /**
     * Check if user info needs to be refreshed
     * 
     * @param int $userId
     * @return bool
     */
    public function needsInfoRefresh($userId)
    {
        try {
            $redisKey = "user:{$userId}:info_updated";
            return Redis::exists($redisKey);
        } catch (\Exception $e) {
            Log::error('Failed to check if user info needs refresh: ' . $e->getMessage(), [
                'user_id' => $userId
            ]);
            return false;
        }
    }
    
    /**
     * Clear the refresh flag for a user
     * 
     * @param int $userId
     * @return void
     */
    public function clearInfoRefreshFlag($userId)
    {
        try {
            $redisKey = "user:{$userId}:info_updated";
            Redis::del($redisKey);
            
            Log::info('Cleared user info refresh flag', [
                'user_id' => $userId
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to clear info refresh flag: ' . $e->getMessage(), [
                'user_id' => $userId
            ]);
        }
    }
}