<?php

namespace App\Services;

use App\Models\Event;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ReminderService
{
    protected $whatsappService;

    public function __construct(WhatsappAPIService $whatsappService)
    {
        $this->whatsappService = $whatsappService;
    }
    
    /**
     * Process and send reminders for upcoming events
     */
    public function processReminders()
    {
        Log::info('Starting reminder processing');
        
        // Process non-recurring events
        $this->processNonRecurringEventReminders();
        
        // Process recurring events
        $this->processRecurringEventReminders();
        
        Log::info('Completed reminder processing');
    }
    
    /**
     * Process non-recurring events
     */
    protected function processNonRecurringEventReminders()
    {
        // Get all non-recurring events that have reminders set but not yet sent
        $events = Event::where('reminder_sent', false)
            ->where('status', '!=', 'cancelled')
            ->whereNotNull('reminder')
            ->whereNull('recurrence')
            ->get();
            
        foreach ($events as $event) {
            try {
                $this->processEventReminder($event);
            } catch (\Exception $e) {
                Log::error('Error processing reminder for non-recurring event: ' . $e->getMessage(), [
                    'event_id' => $event->id,
                    'exception' => $e
                ]);
            }
        }
    }
    
    /**
     * Process recurring events
     */
    protected function processRecurringEventReminders()
    {
        // Get all recurring events that have reminders set
        $events = Event::where('status', '!=', 'cancelled')
            ->whereNotNull('reminder')
            ->whereNotNull('recurrence')
            ->get();
            
        foreach ($events as $event) {
            try {
                $this->processRecurringEventReminder($event);
            } catch (\Exception $e) {
                Log::error('Error processing reminder for recurring event: ' . $e->getMessage(), [
                    'event_id' => $event->id,
                    'exception' => $e
                ]);
            }
        }
    }
    
    /**
     * Process a single event reminder
     */
    protected function processEventReminder(Event $event)
    {
        $user = $event->user;
        
        // Check if user has notifications enabled
        if (!$user->preferences || !$user->preferences->event_notifications) {
            Log::info('User has event notifications disabled', ['user_id' => $user->id]);
            return;
        }
        
        // Calculate when the reminder should be sent
        $reminderTime = $this->calculateReminderTime($event);
        $now = Carbon::now('UTC');
        
        Log::info('Checking event reminder', [
            'event_id' => $event->id,
            'event_start' => $event->start_time->toDateTimeString(),
            'reminder_time' => $reminderTime->toDateTimeString(),
            'now' => $now->toDateTimeString()
        ]);
        
        // If it's time to send the reminder (or past time but not sent yet)
        if ($now->gte($reminderTime)) {
            // Send the reminder
            $this->sendReminder($event);
            
            Log::info('Reminder sent for event', ['event_id' => $event->id]);
        }
    }
    
    /**
     * Process reminders for a recurring event
     */
    protected function processRecurringEventReminder(Event $event)
    {
        $user = $event->user;
        
        // Check if user has notifications enabled
        if (!$user->preferences || !$user->preferences->event_notifications) {
            Log::info('User has event notifications disabled', ['user_id' => $user->id]);
            return;
        }
        
        // Get future occurrences of this event within the reminder window
        $occurrences = $this->getUpcomingEventOccurrences($event);
        $now = Carbon::now('UTC');
        
        foreach ($occurrences as $occurrenceDate) {
            // Check if we've already sent a reminder for this occurrence
            if ($this->hasReminderBeenSent($event, $occurrenceDate)) {
                continue;
            }
            
            // Calculate when the reminder should be sent for this occurrence
            $reminderTime = $this->calculateReminderTime($event, $occurrenceDate);
            
            Log::info('Checking recurring event reminder', [
                'event_id' => $event->id,
                'occurrence_date' => $occurrenceDate,
                'reminder_time' => $reminderTime->toDateTimeString(),
                'now' => $now->toDateTimeString()
            ]);
            
            // If it's time to send the reminder
            if ($now->gte($reminderTime)) {
                // Send the reminder
                $this->sendReminder($event, $occurrenceDate);
                
                Log::info('Reminder sent for recurring event occurrence', [
                    'event_id' => $event->id,
                    'occurrence_date' => $occurrenceDate
                ]);
            }
        }
    }
    
    /**
     * Get upcoming occurrences of a recurring event
     * 
     * @param Event $event
     * @return array Array of occurrence dates (Y-m-d format)
     */
    protected function getUpcomingEventOccurrences(Event $event)
    {
        if (!$event->recurrence || !is_array($event->recurrence)) {
            return [];
        }
        
        $frequency = $event->recurrence['frequency'] ?? null;
        $interval = $event->recurrence['interval'] ?? 1;
        $count = $event->recurrence['count'] ?? null;
        $until = $event->recurrence['until'] ?? null;
        
        if (!$frequency) {
            return [];
        }
        
        // Start from the original event date
        $startDate = $event->start_time->copy();
        
        // If the original event is in the past, start from today instead
        $today = Carbon::today('UTC');
        if ($startDate->lt($today)) {
            $startDate = $today;
        }
        
        // End date for our occurrence calculation
        // Look ahead a reasonable amount of time (7 days)
        $endDate = $today->copy()->addDays(7);
        
        // If 'until' is set and is before our end date, use it
        if ($until) {
            $untilDate = Carbon::parse($until, 'UTC');
            if ($untilDate->lt($endDate)) {
                $endDate = $untilDate;
            }
        }
        
        $occurrences = [];
        $currentDate = $startDate->copy();
        $occurrenceCount = 0;
        
        // Generate occurrences until we reach the end date or count limit
        while ($currentDate->lte($endDate) && (!$count || $occurrenceCount < $count)) {
            $occurrences[] = $currentDate->format('Y-m-d');
            
            // Move to the next occurrence based on frequency
            switch ($frequency) {
                case 'daily':
                    $currentDate->addDays($interval);
                    break;
                case 'weekly':
                    $currentDate->addWeeks($interval);
                    break;
                case 'monthly':
                    $currentDate->addMonths($interval);
                    break;
                case 'yearly':
                    $currentDate->addYears($interval);
                    break;
            }
            
            $occurrenceCount++;
        }
        
        return $occurrences;
    }
    
    /**
     * Check if a reminder has already been sent for a specific occurrence
     * 
     * @param Event $event
     * @param string $occurrenceDate
     * @return bool
     */
    protected function hasReminderBeenSent(Event $event, $occurrenceDate)
    {
        // Get the list of occurrences that have already had reminders sent
        $remindedOccurrences = $event->metadata['reminded_occurrences'] ?? [];
        
        // Check if this occurrence is in the list
        return in_array($occurrenceDate, $remindedOccurrences);
    }
    
    /**
     * Track that a reminder has been sent for a specific occurrence
     * 
     * @param Event $event
     * @param string $occurrenceDate
     */
    protected function trackReminderForOccurrence(Event $event, $occurrenceDate)
    {
        // Get the current metadata
        $metadata = $event->metadata ?? [];
        
        // Get the list of reminded occurrences or initialize it
        $remindedOccurrences = $metadata['reminded_occurrences'] ?? [];
        
        // Add this occurrence to the list if not already there
        if (!in_array($occurrenceDate, $remindedOccurrences)) {
            $remindedOccurrences[] = $occurrenceDate;
        }
        
        // Update the metadata
        $metadata['reminded_occurrences'] = $remindedOccurrences;
        $event->metadata = $metadata;
        
        // Save the event
        $event->save();
        
        Log::info('Tracked reminder for occurrence', [
            'event_id' => $event->id,
            'occurrence_date' => $occurrenceDate
        ]);
    }
    
    /**
     * Calculate when the reminder should be sent based on event type and user preferences
     * 
     * @param Event $event
     * @return Carbon
     */
    protected function calculateReminderTime(Event $event, $occurrenceDate = null)
    {
        $user = $event->user;
        $userPreferences = $user->preferences;
        
        // If this is a recurring event with a specific occurrence date
        if ($occurrenceDate && $event->recurrence) {
            // Get the start time for this specific occurrence
            $occurrenceStartTime = $this->calculateOccurrenceTime($event->start_time, $event->end_time, $occurrenceDate);
        } else {
            // For non-recurring events, use the actual event start time
            $occurrenceStartTime = $event->start_time->copy();
        }
        
        // If this is an all-day event
        if ($event->is_all_day) {
            // Get the all-day event alert time from user preferences (minutes before 12pm)
            $minutesBefore = $userPreferences->all_day_event_alert ?? 60; // Default to 60 minutes if not set
            
            // All-day events span midnight to midnight, so we need to set the time to noon
            // and then subtract the alert time
            $reminderTime = Carbon::parse($occurrenceStartTime->format('Y-m-d') . ' 12:00:00', 'UTC');
            $reminderTime->subMinutes($minutesBefore);
        } else {
            // For regular events, use the event's reminder minutes if set
            // Otherwise, use the user's preferred reminder time
            $minutesBefore = $event->reminder ?? $userPreferences->event_alert ?? 30; // Default to 30 minutes if not set
            
            $reminderTime = $occurrenceStartTime->copy()->subMinutes($minutesBefore);
        }
        
        return $reminderTime;
    }
    
    /**
     * Calculate the start/end time for a specific occurrence of a recurring event
     * 
     * @param Carbon $baseTime Base time from the original event
     * @param Carbon $baseDuration Duration of the original event
     * @param string $occurrenceDate The date of the occurrence in Y-m-d format
     * @return Carbon
     */
    protected function calculateOccurrenceTime($baseTime, $baseDuration, $occurrenceDate)
    {
        // Parse the occurrence date
        $occurrenceDateTime = Carbon::parse($occurrenceDate . ' ' . $baseTime->format('H:i:s'), 'UTC');
        
        // Return the properly calculated time for this occurrence
        return $occurrenceDateTime;
    }
    
    /**
     * Send a reminder via WhatsApp
     */
    protected function sendReminder(Event $event, $occurrenceDate = null)
    {
        $user = $event->user;
        
        // If user doesn't have a WhatsApp ID, we can't send a reminder
        if (!$user->whatsapp_id) {
            Log::info('User has no WhatsApp ID, cannot send reminder', ['user_id' => $user->id]);
            return;
        }
        
        // Format the message based on the event
        $message = $this->formatReminderMessage($event, $occurrenceDate);
        
        // Send the message via WhatsApp
        $result = $this->whatsappService->sendWhatsAppMessage($user->whatsapp_id, $message);
        
        Log::info('WhatsApp reminder sent', [
            'user_id' => $user->id,
            'event_id' => $event->id,
            'occurrence_date' => $occurrenceDate,
            'result' => $result
        ]);
        
        // For recurring events with an occurrence date, track it in the metadata
        if ($occurrenceDate && $event->recurrence) {
            $this->trackReminderForOccurrence($event, $occurrenceDate);
        } else {
            // For non-recurring events, mark reminder as sent
            $event->reminder_sent = true;
            $event->save();
        }
    }
    
    /**
     * Format the reminder message based on event details
     */
    protected function formatReminderMessage(Event $event, $occurrenceDate = null)
    {
        $user = $event->user;
        $userTimezone = $user->timezone ?? 'UTC';
        
        // If this is a recurring event with a specific occurrence date
        if ($occurrenceDate && $event->recurrence) {
            // Calculate the start and end times for this occurrence
            $startTime = $this->calculateOccurrenceTime($event->start_time, $event->end_time, $occurrenceDate);
            $endTime = $this->calculateOccurrenceTime($event->end_time, $event->end_time, $occurrenceDate);
        } else {
            // For non-recurring events, use the actual event times
            $startTime = $event->start_time->copy();
            $endTime = $event->end_time->copy();
        }
        
        // Convert times to user's timezone for display
        $startTime = $startTime->setTimezone($userTimezone);
        $endTime = $endTime->setTimezone($userTimezone);
        
        if ($event->is_all_day) {
            $timeString = "all day";
            
            // If multi-day event
            if ($startTime->format('Y-m-d') !== $endTime->format('Y-m-d')) {
                $timeString .= " from " . $startTime->format('l, F j') . 
                               " to " . $endTime->format('l, F j');
            } else {
                $timeString .= " on " . $startTime->format('l, F j');
            }
        } else {
            $timeString = $startTime->format('l, F j \a\t g:i A');
            
            // If same day event
            if ($startTime->format('Y-m-d') === $endTime->format('Y-m-d')) {
                $timeString .= " - " . $endTime->format('g:i A');
            } else {
                $timeString .= " - " . $endTime->format('l, F j \a\t g:i A');
            }
        }
        
        // Build the reminder message
        $message = "🔔 *Reminder:* " . $event->title . "\n\n";
        $message .= "📅 " . $timeString . "\n";
        
        // Add recurrence information if applicable
        if ($event->recurrence) {
            $recurrenceInfo = $this->getRecurrenceString($event->recurrence);
            if ($recurrenceInfo) {
                $message .= "🔄 " . $recurrenceInfo . "\n";
            }
        }
        
        if ($event->location) {
            $message .= "📍 " . $event->location . "\n";
        }
        
        if ($event->description) {
            $message .= "\n" . $event->description . "\n";
        }
        
        // Add Google Meet link if available
        if (isset($event->metadata['google_meet_link']) && $event->metadata['google_meet_link']) {
            $message .= "\n🎥 Google Meet: " . $event->metadata['google_meet_link'] . "\n";
        }
        
        return $message;
    }
    
    /**
     * Get a human-readable string describing the recurrence pattern
     * 
     * @param array $recurrence
     * @return string
     */
    protected function getRecurrenceString($recurrence)
    {
        if (!is_array($recurrence) || empty($recurrence)) {
            return null;
        }
        
        $frequency = $recurrence['frequency'] ?? null;
        $interval = $recurrence['interval'] ?? 1;
        $count = $recurrence['count'] ?? null;
        $until = $recurrence['until'] ?? null;
        
        if (!$frequency) {
            return null;
        }
        
        $strings = [
            'daily' => 'day',
            'weekly' => 'week',
            'monthly' => 'month',
            'yearly' => 'year'
        ];
        
        $base = $interval > 1 ? "Every $interval {$strings[$frequency]}s" : "Every {$strings[$frequency]}";
        
        if ($count) {
            return "$base, $count times in total";
        } else if ($until) {
            $untilDate = Carbon::parse($until)->format('F j, Y');
            return "$base until $untilDate";
        }
        
        return $base;
    }
}