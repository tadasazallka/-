<?php

namespace App\Services;

use Cloudinary\Cloudinary as CloudinaryCloudinary;
use Illuminate\Support\Facades\Log;

class CloudinaryService
{
    protected $cloudinary;
    
    public function __construct()
    {
        $this->cloudinary = new CloudinaryCloudinary([
            'cloud' => [
                'cloud_name' => config('services.cloudinary.cloud_name'),
                'api_key' => config('services.cloudinary.api_key'),
                'api_secret' => config('services.cloudinary.api_secret'),
            ],
        ]);
    }
    
    /**
     * Upload a file to Cloudinary
     *
     * @param string $filePath Local path to the file
     * @param string $folder Folder in Cloudinary to store the file
     * @param string $resourceType Type of resource (image, video, raw, auto)
     * @return array|null Upload result or null on failure
     */
    public function uploadFile(string $filePath, string $folder = 'whatsapp', string $resourceType = 'auto')
    {
        try {
            // Check file size before uploading
            $fileSize = filesize($filePath);
            $maxSizeBytes = ($resourceType === 'video') ? 2 * 1024 * 1024 : 5 * 1024 * 1024;
            
            if ($fileSize > $maxSizeBytes) {
                Log::warning("File too large for upload: {$fileSize} bytes", [
                    'path' => $filePath,
                    'max_size' => $maxSizeBytes
                ]);
                return ['error' => 'file_too_large', 'size' => $fileSize];
            }
            
            $result = $this->cloudinary->uploadApi()->upload($filePath, [
                'folder' => $folder,
                'resource_type' => $resourceType,
            ]);
            
            Log::info('File uploaded to Cloudinary', [
                'public_id' => $result['public_id'], 
                'url' => $result['secure_url']
            ]);
            
            return $result;

        } catch (\Exception $e) {
            Log::error('Failed to upload file to Cloudinary: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Upload a file from binary data to Cloudinary
     *
     * @param string $binaryData Binary content of the file
     * @param string $folder Folder in Cloudinary to store the file
     * @param string $resourceType Type of resource (image, video, raw, auto)
     * @param string $filename Optional filename
     * @return array|null Upload result or null on failure
     */
    public function uploadFromBinary(string $binaryData, string $folder = 'whatsapp', string $resourceType = 'auto', string $filename = null)
    {
        try {
            // Check binary data size before proceeding
            $dataSize = strlen($binaryData);
            $maxSizeBytes = ($resourceType === 'video') ? 2 * 1024 * 1024 : 5 * 1024 * 1024;
            
            if ($dataSize > $maxSizeBytes) {
                Log::warning("Binary data too large for upload: {$dataSize} bytes", [
                    'max_size' => $maxSizeBytes
                ]);
                return ['error' => 'file_too_large', 'size' => $dataSize];
            }
            
            // Create a temporary file
            $tempFile = tempnam(sys_get_temp_dir(), 'cloudinary');
            file_put_contents($tempFile, $binaryData);
            
            // Add file extension if filename is provided
            if ($filename) {
                $ext = pathinfo($filename, PATHINFO_EXTENSION);
                if ($ext) {
                    $newTempFile = $tempFile . '.' . $ext;
                    rename($tempFile, $newTempFile);
                    $tempFile = $newTempFile;
                }
            }
            
            // Upload the file
            $result = $this->uploadFile($tempFile, $folder, $resourceType);
            
            // Clean up the temporary file
            @unlink($tempFile);
            
            return $result;
        } catch (\Exception $e) {
            Log::error('Failed to upload binary data to Cloudinary: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Get a Cloudinary URL for a public ID
     *
     * @param string $publicId The public ID of the resource
     * @param array $options Transformation options
     * @return string The URL
     */
    public function getUrl(string $publicId, array $options = []): string
    {
        try {
            return $this->cloudinary->image($publicId)->toUrl($options);
        } catch (\Exception $e) {
            Log::error('Failed to generate Cloudinary URL: ' . $e->getMessage());
            return '';
        }
    }
    
    /**
     * Get information about a resource in Cloudinary
     *
     * @param string $publicId The public ID of the resource
     * @param string $resourceType Type of resource (image, video, raw)
     * @return array Resource information or empty array on failure
     */
    public function getResourceInfo(string $publicId, string $resourceType = 'image')
    {
        try {
            $result = $this->cloudinary->adminApi()->asset($publicId, [
                'resource_type' => $resourceType
            ]);
            
            return $result ?? [];
        } catch (\Exception $e) {
            Log::error('Failed to get resource info from Cloudinary: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Delete a file from Cloudinary
     *
     * @param string $publicId The public ID of the resource
     * @param string $resourceType Type of resource (image, video, raw)
     * @return bool Success or failure
     */
    public function deleteFile(string $publicId, string $resourceType = 'image'): bool
    {
        try {
            $result = $this->cloudinary->uploadApi()->destroy($publicId, [
                'resource_type' => $resourceType
            ]);
            
            return $result['result'] === 'ok';
        } catch (\Exception $e) {
            Log::error('Failed to delete file from Cloudinary: ' . $e->getMessage());
            return false;
        }
    }
}