<?php
// app/Services/Tools/ManageWeatherScheduleTools.php

namespace App\Services\Tools;

use App\Models\User;
use App\Models\WeatherSchedule;
use App\Services\WeatherScheduleService;
use Illuminate\Support\Facades\Log;

class ManageWeatherScheduleTools implements ToolInterface
{
    protected $weatherScheduleService;
    
    public function __construct(WeatherScheduleService $weatherScheduleService)
    {
        $this->weatherScheduleService = $weatherScheduleService;
    }
    
    public function getName()
    {
        return 'manage_weather_schedule';
    }
    
    public function getDescription()
    {
        return 'Create, update, delete, or list weather update schedules';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'action' => [
                    'type' => 'string',
                    'description' => 'Action to perform',
                    'enum' => ['create', 'update', 'delete', 'list'],
                ],
                'location' => [
                    'type' => 'string',
                    'description' => 'Location for weather updates (required for create/update)',
                ],
                'schedule_time' => [
                    'type' => 'string',
                    'description' => 'Time to send updates in 24-hour format (HH:MM)',
                ],
                'frequency' => [
                    'type' => 'string',
                    'description' => 'Frequency of updates',
                    'enum' => ['daily', 'weekly', 'monthly'],
                    'default' => 'daily',
                ],
                'schedule_id' => [
                    'type' => 'integer',
                    'description' => 'ID of schedule to update/delete',
                ],
            ],
            'required' => ['action'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            $action = $arguments['action'];
            
            switch ($action) {
                case 'create':
                    return $this->createSchedule($arguments, $user);
                case 'update':
                    return $this->updateSchedule($arguments, $user);
                case 'delete':
                    return $this->deleteSchedule($arguments, $user);
                case 'list':
                    return $this->listSchedules($user);
                default:
                    return [
                        'success' => false,
                        'error' => 'Invalid action'
                    ];
            }
        } catch (\Exception $e) {
            Log::error('Error managing weather schedule', [
                'error' => $e->getMessage(),
                'action' => $arguments['action'] ?? null
            ]);
            
            return [
                'success' => false,
                'error' => 'Failed to manage weather schedule: ' . $e->getMessage()
            ];
        }
    }
    
    protected function createSchedule(array $arguments, User $user)
    {
        if (!isset($arguments['location']) || !isset($arguments['schedule_time'])) {
            return [
                'success' => false,
                'error' => 'Location and schedule time are required'
            ];
        }
        
        $schedule = $this->weatherScheduleService->createSchedule(
            $user,
            $arguments['location'],
            $arguments['schedule_time'],
            $arguments['frequency'] ?? 'daily'
        );
        
        return [
            'success' => true,
            'message' => 'Weather schedule created successfully',
            'schedule' => [
                'id' => $schedule->id,
                'location' => $schedule->location,
                'schedule_time' => $schedule->schedule_time,
                'frequency' => $schedule->frequency,
            ]
        ];
    }
    
    protected function updateSchedule(array $arguments, User $user)
    {
        if (!isset($arguments['schedule_id'])) {
            return [
                'success' => false,
                'error' => 'Schedule ID is required'
            ];
        }
        
        $schedule = WeatherSchedule::where('user_id', $user->id)
            ->where('id', $arguments['schedule_id'])
            ->first();
            
        if (!$schedule) {
            return [
                'success' => false,
                'error' => 'Schedule not found'
            ];
        }
        
        $updateData = [];
        if (isset($arguments['location'])) {
            $updateData['location'] = $arguments['location'];
        }
        if (isset($arguments['schedule_time'])) {
            $updateData['schedule_time'] = $arguments['schedule_time'];
        }
        if (isset($arguments['frequency'])) {
            $updateData['frequency'] = $arguments['frequency'];
        }
        
        $schedule = $this->weatherScheduleService->updateSchedule($schedule, $updateData);
        
        return [
            'success' => true,
            'message' => 'Weather schedule updated successfully',
            'schedule' => [
                'id' => $schedule->id,
                'location' => $schedule->location,
                'schedule_time' => $schedule->schedule_time,
                'frequency' => $schedule->frequency,
            ]
        ];
    }
    
    protected function deleteSchedule(array $arguments, User $user)
    {
        if (!isset($arguments['schedule_id'])) {
            return [
                'success' => false,
                'error' => 'Schedule ID is required'
            ];
        }
        
        $schedule = WeatherSchedule::where('user_id', $user->id)
            ->where('id', $arguments['schedule_id'])
            ->first();
            
        if (!$schedule) {
            return [
                'success' => false,
                'error' => 'Schedule not found'
            ];
        }
        
        $schedule->delete();
        
        return [
            'success' => true,
            'message' => 'Weather schedule deleted successfully'
        ];
    }
    
    protected function listSchedules(User $user)
    {
        $schedules = WeatherSchedule::where('user_id', $user->id)->get();
        
        return [
            'success' => true,
            'schedules' => $schedules->map(function ($schedule) {
                return [
                    'id' => $schedule->id,
                    'location' => $schedule->location,
                    'schedule_time' => $schedule->schedule_time,
                    'frequency' => $schedule->frequency,
                    'last_sent_at' => $schedule->last_sent_at,
                ];
            })
        ];
    }
}