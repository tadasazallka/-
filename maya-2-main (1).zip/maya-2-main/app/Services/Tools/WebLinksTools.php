<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Services\Tools\ToolInterface;
use Illuminate\Support\Facades\Log;

class WebLinksTools implements ToolInterface
{
    // Define our URLs in one place for easy management
    private $links = [
        'pricing' => 'https://maya-landing-hebrew.vercel.app/pricing',
        'login' => 'https://maya-landing-hebrew.vercel.app/login',
        'signup' => 'https://maya-landing-hebrew.vercel.app/signup',
        'notification-settings' => 'https://maya-dashboard-latest.vercel.app/notifications',
        'event-settings' => 'https://maya-dashboard-latest.vercel.app/new-events',
        'about' => 'https://maya-dashboard-latest.vercel.app/about',
        'faq' => 'https://maya-landing-hebrew.vercel.app/#faqs',
        'homepage' => 'https://maya-landing-hebrew.vercel.app',
        'privacy' => 'https://maya-landing-hebrew.vercel.app/privacy',
        'terms' => 'https://maya-landing-hebrew.vercel.app/terms',
    ];

    public function getName()
    {
        return 'get_web_links';
    }
    
    public function getDescription()
    {
        return 'Get links to important web pages like login, pricing, about, etc.';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'page_type' => [
                    'type' => 'string',
                    'description' => 'Type of page to get link for: pricing, login, signup, notification-settings, event-settings, about, faq, homepage, etc.',
                    'enum' => array_keys($this->links),
                ],
            ],
            'required' => ['page_type'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            Log::info('Executing get_web_links', ['user_id' => $user->id, 'arguments' => $arguments]);
            
            $pageType = $arguments['page_type'] ?? null;
            
            if (!$pageType) {
                return [
                    'success' => false,
                    'error' => 'Missing page type',
                    'message' => 'Please specify a page type to get link for',
                    'available_types' => array_keys($this->links)
                ];
            }
            
            if (!isset($this->links[$pageType])) {
                return [
                    'success' => false,
                    'error' => 'Invalid page type',
                    'message' => 'The specified page type is not valid',
                    'available_types' => array_keys($this->links)
                ];
            }
            
            $link = $this->links[$pageType];
            
            // For signup and pricing links, add UTM parameters for tracking
            if (in_array($pageType, ['pricing', 'signup'])) {
                $link .= "?utm_source=maya_assistant&utm_medium=chat&utm_campaign=upgrade_cta";
            }
            
            return [
                'success' => true,
                'link' => $link,
                'page_type' => $pageType,
                'description' => $this->getPageDescription($pageType)
            ];
            
        } catch (\Exception $e) {
            Log::error('Error in get_web_links', [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'System error',
                'message' => 'An unexpected error occurred: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Get a description for a page type
     */
    private function getPageDescription(string $pageType): string
    {
        $descriptions = [
            'pricing' => 'View and compare different subscription plans and features',
            'login' => 'Log in to your existing Maya account',
            'signup' => 'Create a new Maya account',
            'notification-settings' => 'Manage your notification preferences and settings',
            'event-settings' => 'Configure your default event creation preferences',
            'about' => 'Learn more about Maya and our team',
            'faq' => 'View frequently asked questions about Maya',
            'homepage' => 'Maya main website',
            'privacy' => 'View our privacy policy',
            'terms' => 'View our terms of service',
        ];
        
        return $descriptions[$pageType] ?? 'Link to ' . $pageType . ' page';
    }
}