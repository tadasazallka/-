<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Models\Event;
use App\Models\Calendar;
use App\Services\CalendarDeleteService;
use App\Services\TimezoneService;
use App\Services\Tools\ToolInterface;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class DeleteEventTools implements ToolInterface
{
    protected $calendarDeleteService;
    protected $timezoneService;
    
    public function __construct(
        CalendarDeleteService $calendarDeleteService,
        TimezoneService $timezoneService
    ) {
        $this->calendarDeleteService = $calendarDeleteService;
        $this->timezoneService = $timezoneService;
    }

    public function getName()
    {
        return 'calendar_delete_event';
    }
    
    public function getDescription()
    {
        return 'Delete events from the user\'s calendar';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'event_ids' => [
                    'type' => 'array',
                    'description' => 'IDs of specific events to delete',
                    'items' => [
                        'type' => 'string',
                    ],
                ],
                'date_range' => [
                    'type' => 'object',
                    'description' => 'Delete all events in a date range',
                    'properties' => [
                        'start_date' => [
                            'type' => 'string',
                            'description' => 'Start of range in ISO 8601 UTC format (e.g. "2025-05-15T00:00:00Z")',
                            'format' => 'date-time',
                        ],
                        'end_date' => [
                            'type' => 'string',
                            'description' => 'End of range in ISO 8601 UTC format (e.g. "2025-05-16T23:59:59Z")',
                            'format' => 'date-time',
                        ],
                    ],
                    'required' => ['start_date', 'end_date'],
                ],
                'query' => [
                    'type' => 'string',
                    'description' => 'Delete events matching this query',
                ],
                'delete_all_upcoming' => [
                    'type' => 'boolean',
                    'description' => 'Delete all upcoming events',
                ],
                'delete_recurring_instances' => [
                    'type' => 'boolean',
                    'description' => 'For recurring events, whether to delete all instances or just the specified ones',
                ],
                'delete_method' => [
                    'type' => 'string',
                    'description' => 'Method to use for deletion: by_ids, by_date_range, or all_upcoming',
                    'enum' => ['by_ids', 'by_date_range', 'all_upcoming'],
                ],
            ],
            'required' => ['delete_method'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            Log::info('Executing calendar_delete_event', ['user_id' => $user->id, 'arguments' => $arguments]);
            
            // Get the user's timezone
            $userTz = $user->timezone ?? 'UTC';
            
            $deleteMethod = $arguments['delete_method'];
            $deleteRecurringInstances = $arguments['delete_recurring_instances'] ?? false;
            
            // Currently doing it like deleting from all calendars of user
            $calendar = null;
            
            $deletedEvents = [];
            $deletedCount = 0;
            
            // Handle deletion by event IDs
            if ($deleteMethod === 'by_ids') {
                if (empty($arguments['event_ids']) || !is_array($arguments['event_ids'])) {
                    return [
                        'success' => false,
                        'error' => 'Missing event IDs',
                        'message' => 'No event IDs were provided for deletion'
                    ];
                }
                
                $eventIds = $arguments['event_ids'];
                $query = Event::where('user_id', $user->id);
                
                if ($calendar) {
                    $query->where('calendar_id', $calendar->id);
                }
                
                $events = $query->whereIn('id', $eventIds)->get();
                
                if ($events->isEmpty()) {
                    return [
                        'success' => false,
                        'error' => 'No events found',
                        'message' => 'Could not find any events with the provided IDs'
                    ];
                }
                
                foreach ($events as $event) {
                    // Delete the event
                    $result = $this->deleteEvent($event, $deleteRecurringInstances);
                    
                    if ($result) {
                        // Convert the start_time to user's timezone for display
                        $localStartTime = $event->start_time->copy()->setTimezone($userTz);
                        
                        $deletedEvents[] = [
                            'id' => $event->id, 
                            'title' => $event->title,
                            'start_utc' => $event->start_time->toIso8601String(),
                            'start_local' => $localStartTime->toIso8601String()
                        ];
                        $deletedCount++;
                        
                        Log::info('Deleted event', [
                            'event_id' => $event->id,
                            'title' => $event->title,
                            'start_time_utc' => $event->start_time->toIso8601String()
                        ]);
                    }
                }
            }
            // Handle deletion by date range
            else if ($deleteMethod === 'by_date_range') {
                if (empty($arguments['date_range']) || 
                    empty($arguments['date_range']['start_date']) || 
                    empty($arguments['date_range']['end_date'])) {
                    return [
                        'success' => false,
                        'error' => 'Invalid date range',
                        'message' => 'Start and end dates are required for date range deletion'
                    ];
                }
                
                try {
                    // Parse dates in UTC from ISO 8601 format
                    $startDateUtc = Carbon::parse($arguments['date_range']['start_date'], 'UTC');
                    $endDateUtc = Carbon::parse($arguments['date_range']['end_date'], 'UTC');
                    
                    // Log the date range for debugging
                    Log::info('Date range for event deletion', [
                        'start_date_utc' => $startDateUtc->toIso8601String(),
                        'end_date_utc' => $endDateUtc->toIso8601String()
                    ]);
                } catch (\Exception $e) {
                    Log::error('Failed to parse date range', [
                        'start_date' => $arguments['date_range']['start_date'] ?? null,
                        'end_date' => $arguments['date_range']['end_date'] ?? null,
                        'error' => $e->getMessage()
                    ]);
                    
                    return [
                        'success' => false,
                        'error' => 'Invalid date format',
                        'message' => 'Could not parse the provided dates. Please use ISO 8601 UTC format (e.g. "2025-05-15T00:00:00Z").'
                    ];
                }
                
                $query = Event::where('user_id', $user->id)
                    ->where('start_time', '>=', $startDateUtc)
                    ->where('end_time', '<=', $endDateUtc);
                
                if ($calendar) {
                    $query->where('calendar_id', $calendar->id);
                }
                
                // Add title query if provided
                if (!empty($arguments['query'])) {
                    $query->where('title', 'like', '%' . $arguments['query'] . '%');
                }
                
                $events = $query->get();
                
                if ($events->isEmpty()) {
                    return [
                        'success' => false,
                        'error' => 'No events found',
                        'message' => 'No events found in the specified date range'
                    ];
                }
                
                foreach ($events as $event) {
                    $result = $this->deleteEvent($event, $deleteRecurringInstances);
                    
                    if ($result) {
                        // Convert the start_time to user's timezone for display
                        $localStartTime = $event->start_time->copy()->setTimezone($userTz);
                        
                        $deletedEvents[] = [
                            'id' => $event->id, 
                            'title' => $event->title,
                            'start_utc' => $event->start_time->toIso8601String(),
                            'start_local' => $localStartTime->toIso8601String()
                        ];
                        $deletedCount++;
                        
                        Log::info('Deleted event in date range', [
                            'event_id' => $event->id,
                            'title' => $event->title,
                            'start_time_utc' => $event->start_time->toIso8601String()
                        ]);
                    }
                }
            }
            // Handle deletion of all upcoming events
            else if ($deleteMethod === 'all_upcoming') {
                if (empty($arguments['delete_all_upcoming']) || $arguments['delete_all_upcoming'] !== true) {
                    return [
                        'success' => false,
                        'error' => 'Confirmation required',
                        'message' => 'Please confirm deletion of all upcoming events by setting delete_all_upcoming to true'
                    ];
                }
                
                // Use UTC time for database queries
                $nowUtc = Carbon::now('UTC');
                
                $query = Event::where('user_id', $user->id)
                    ->where('start_time', '>=', $nowUtc);
                
                // Add title query if provided
                if (!empty($arguments['query'])) {
                    $query->where('title', 'like', '%' . $arguments['query'] . '%');
                }
                
                $events = $query->get();
                
                if ($events->isEmpty()) {
                    return [
                        'success' => false,
                        'error' => 'No events found',
                        'message' => 'No upcoming events found'
                    ];
                }
                
                foreach ($events as $event) {
                    $result = $this->deleteEvent($event, $deleteRecurringInstances);
                    
                    if ($result) {
                        // Convert the start_time to user's timezone for display
                        $localStartTime = $event->start_time->copy()->setTimezone($userTz);
                        
                        $deletedEvents[] = [
                            'id' => $event->id, 
                            'title' => $event->title,
                            'start_utc' => $event->start_time->toIso8601String(),
                            'start_local' => $localStartTime->toIso8601String()
                        ];
                        $deletedCount++;
                        
                        Log::info('Deleted upcoming event', [
                            'event_id' => $event->id,
                            'title' => $event->title,
                            'start_time_utc' => $event->start_time->toIso8601String()
                        ]);
                    }
                }
            } else {
                return [
                    'success' => false,
                    'error' => 'Invalid delete method',
                    'message' => 'The specified delete method is not valid'
                ];
            }
            
            if ($deletedCount > 0) {
                return [
                    'success' => true,
                    'deleted_count' => $deletedCount,
                    'deleted_events' => $deletedEvents,
                    'message' => "Successfully deleted {$deletedCount} event(s)",
                    'timezone' => $userTz
                ];
            } else {
                return [
                    'success' => false,
                    'error' => 'No events deleted',
                    'message' => 'No events were deleted'
                ];
            }
            
        } catch (\Exception $e) {
            Log::error('Error in calendar_delete_event', [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'System error',
                'message' => 'An unexpected error occurred: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Delete an event from both database and provider's calendar
     */
    private function deleteEvent(Event $event, bool $deleteRecurringInstances = false): bool
    {
        try {
            // Leverage the CalendarDeleteService for the actual deletion
            $result = $this->calendarDeleteService->deleteEvent($event, $deleteRecurringInstances);
            
            return $result;
        } catch (\Exception $e) {
            Log::error('Failed to delete event', [
                'event_id' => $event->id,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }
}