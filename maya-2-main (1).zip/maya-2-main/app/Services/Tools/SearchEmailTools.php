<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Services\Gmail\GmailService;
use Illuminate\Support\Facades\Log;

class SearchEmailTools implements ToolInterface
{
    protected $gmailService;
    
    public function __construct(GmailService $gmailService)
    {
        $this->gmailService = $gmailService;
    }
    
    public function getName()
    {
        return 'gmail_search_emails';
    }
    
    public function getDescription()
    {
        return 'Search for specific emails in Gmail using various criteria';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'search_type' => [
                    'type' => 'string',
                    'description' => 'Type of search to perform',
                    'enum' => ['by_query', 'by_sender', 'by_recipient', 'by_subject', 'by_attachment', 'by_date_range'],
                ],
                'query' => [
                    'type' => 'string',
                    'description' => 'Gmail search query (supports Gmail advanced search operators)',
                ],
                'from' => [
                    'type' => 'string',
                    'description' => 'Search for emails from a specific sender',
                ],
                'to' => [
                    'type' => 'string',
                    'description' => 'Search for emails sent to a specific recipient',
                ],
                'subject' => [
                    'type' => 'string',
                    'description' => 'Search for emails with specific text in the subject',
                ],
                'has_attachment' => [
                    'type' => 'boolean',
                    'description' => 'Search for emails with attachments',
                ],
                'date_range' => [
                    'type' => 'object',
                    'properties' => [
                        'start_date' => [
                            'type' => 'string',
                            'description' => 'Start date for search range (YYYY-MM-DD format or relative like "1d", "1w", "1m")',
                        ],
                        'end_date' => [
                            'type' => 'string',
                            'description' => 'End date for search range (YYYY-MM-DD format or relative)',
                        ],
                    ],
                ],
                'labels' => [
                    'type' => 'array',
                    'description' => 'Search within specific Gmail labels',
                    'items' => [
                        'type' => 'string',
                    ],
                ],
                'max_results' => [
                    'type' => 'integer',
                    'description' => 'Maximum number of results to return',
                    'default' => 5, // Changed from 10 to 5
                ],
                'include_body' => [
                    'type' => 'boolean',
                    'description' => 'Include email body content in results',
                    'default' => false,
                ],
            ],
            'required' => ['search_type'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            // Check if the user has an active Gmail account
            if (!$user->gmailAccount || !$user->gmailAccount->is_active) {
                return [
                    'success' => false,
                    'error' => 'No active Gmail account found for this user',
                    'call to action' => 'User can connect the gmail account from maya dashboard'
                ];
            }
            
            $service = $this->gmailService->getGmailService($user);
            
            // Build search query based on search type
            $searchType = $arguments['search_type'];
            $query = [];
            
            switch ($searchType) {
                case 'by_query':
                    if (isset($arguments['query'])) {
                        $query[] = $arguments['query'];
                    } else {
                        return [
                            'success' => false,
                            'error' => 'Query parameter is required for by_query search type',
                        ];
                    }
                    break;
                    
                case 'by_sender':
                    if (isset($arguments['from'])) {
                        $query[] = 'from:' . $arguments['from'];
                    } else {
                        return [
                            'success' => false,
                            'error' => 'From parameter is required for by_sender search type',
                        ];
                    }
                    break;
                    
                case 'by_recipient':
                    if (isset($arguments['to'])) {
                        $query[] = 'to:' . $arguments['to'];
                    } else {
                        return [
                            'success' => false,
                            'error' => 'To parameter is required for by_recipient search type',
                        ];
                    }
                    break;
                    
                case 'by_subject':
                    if (isset($arguments['subject'])) {
                        $query[] = 'subject:' . $arguments['subject'];
                    } else {
                        return [
                            'success' => false,
                            'error' => 'Subject parameter is required for by_subject search type',
                        ];
                    }
                    break;
                    
                case 'by_attachment':
                    $query[] = 'has:attachment';
                    break;
                    
                case 'by_date_range':
                    if (isset($arguments['date_range'])) {
                        if (isset($arguments['date_range']['start_date'])) {
                            $query[] = 'after:' . $arguments['date_range']['start_date'];
                        }
                        if (isset($arguments['date_range']['end_date'])) {
                            $query[] = 'before:' . $arguments['date_range']['end_date'];
                        }
                    } else {
                        return [
                            'success' => false,
                            'error' => 'Date range parameter is required for by_date_range search type',
                        ];
                    }
                    break;
                
                default:
                    return [
                        'success' => false,
                        'error' => 'Invalid search type specified',
                    ];
            }
            
            // Add labels if specified
            if (isset($arguments['labels']) && is_array($arguments['labels'])) {
                foreach ($arguments['labels'] as $label) {
                    $query[] = 'label:' . $label;
                }
            }
            
            $maxResults = min($arguments['max_results'] ?? 5, 15); // Changed from 50 to 15 max
            $includeBody = $arguments['include_body'] ?? false;
            
            // Perform search
            $options = [
                'q' => implode(' ', $query),
                'maxResults' => $maxResults,
            ];
            
            try {
                $messageList = $service->users_messages->listUsersMessages('me', $options);
                $messages = $messageList->getMessages() ?: [];
                
                $emails = [];
                $totalResults = $messageList->getResultSizeEstimate() ?? 0;
                
                if ($totalResults > 0) {
                    foreach ($messages as $message) {
                        $fullMessage = $service->users_messages->get('me', $message->getId(), [
                            'format' => $includeBody ? 'full' : 'metadata',
                        ]);
                        $emails[] = $this->gmailService->parseMessage($fullMessage, $includeBody);
                    }
                }
                
                return [
                    'success' => true,
                    'total_results' => $totalResults,
                    'showing' => count($emails),
                    'has_more' => ($totalResults > count($emails)),
                    'search_criteria' => [
                        'query' => implode(' ', $query),
                        'search_type' => $searchType,
                    ],
                    'emails' => $emails,
                ];
            } catch (\Exception $e) {
                Log::error('Error in Gmail search: ' . $e->getMessage());
                return [
                    'success' => false,
                    'error' => 'Error executing search: ' . $e->getMessage(),
                ];
            }
        } catch (\Exception $e) {
            Log::error('Error searching emails: ' . $e->getMessage(), [
                'user_id' => $user->id,
                'arguments' => $arguments,
            ]);
            
            return [
                'success' => false,
                'error' => 'Failed to search emails: ' . $e->getMessage(),
            ];
        }
    }
}