<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Models\ScheduledEmail;
use App\Services\TimezoneService;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class ScheduledEmailTools implements ToolInterface
{
    protected $timezoneService;
    
    public function __construct(TimezoneService $timezoneService)
    {
        $this->timezoneService = $timezoneService;
    }
    
    public function getName()
    {
        return 'scheduled_email_tools';
    }
    
    public function getDescription()
    {
        return 'Manage scheduled emails stored in the database (list, get, update, delete)';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'action' => [
                    'type' => 'string',
                    'description' => 'Action to perform on scheduled emails',
                    'enum' => ['list', 'get', 'update', 'delete'],
                ],
                'scheduled_id' => [
                    'type' => 'integer',
                    'description' => 'ID of the scheduled email for get, update, or delete actions',
                ],
                'to' => [
                    'type' => 'string',
                    'description' => 'New recipient email address(es) when updating, comma-separated for multiple',
                ],
                'cc' => [
                    'type' => 'string',
                    'description' => 'New CC recipient email address(es) when updating, comma-separated for multiple',
                ],
                'bcc' => [
                    'type' => 'string',
                    'description' => 'New BCC recipient email address(es) when updating, comma-separated for multiple',
                ],
                'subject' => [
                    'type' => 'string',
                    'description' => 'New email subject line when updating',
                ],
                'body' => [
                    'type' => 'string',
                    'description' => 'New email body content when updating',
                ],
                'html_body' => [
                    'type' => 'boolean',
                    'description' => 'Whether the new body content is HTML formatted',
                ],
                'scheduled_for' => [
                    'type' => 'string',
                    'description' => 'New scheduled time in ISO 8601 UTC format (e.g. "2025-05-15T10:00:00Z")',
                    'format' => 'date-time',
                ],
            ],
            'required' => ['action'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        // Log all incoming arguments to see what the AI is sending
        Log::info('ScheduledEmailTools received arguments', $arguments);
        
        try {
            $action = $arguments['action'];
            
            switch ($action) {
                case 'list':
                    return $this->listScheduledEmails($user);
                
                case 'get':
                    if (!isset($arguments['scheduled_id'])) {
                        return [
                            'success' => false,
                            'error' => "The 'scheduled_id' parameter is required for get action",
                        ];
                    }
                    return $this->getScheduledEmail($user, $arguments['scheduled_id']);
                
                case 'update':
                    if (!isset($arguments['scheduled_id'])) {
                        return [
                            'success' => false,
                            'error' => "The 'scheduled_id' parameter is required for update action",
                        ];
                    }
                    return $this->updateScheduledEmail($user, $arguments);
                
                case 'delete':
                    if (!isset($arguments['scheduled_id'])) {
                        return [
                            'success' => false,
                            'error' => "The 'scheduled_id' parameter is required for delete action",
                        ];
                    }
                    return $this->deleteScheduledEmail($user, $arguments['scheduled_id']);
                
                default:
                    return [
                        'success' => false,
                        'error' => 'Invalid action specified',
                    ];
            }
        } catch (\Exception $e) {
            Log::error('Error managing scheduled emails: ' . $e->getMessage(), [
                'user_id' => $user->id,
                'action' => $arguments['action'] ?? 'unknown',
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'Failed to manage scheduled emails: ' . $e->getMessage(),
            ];
        }
    }
    
    /**
     * Update a scheduled email
     */
    private function updateScheduledEmail(User $user, array $arguments)
    {
        $scheduledId = $arguments['scheduled_id'];
        
        // First, get the email to update
        $email = ScheduledEmail::where('user_id', $user->id)
            ->where('id', $scheduledId)
            ->first();
        
        if (!$email) {
            return [
                'success' => false,
                'error' => 'Scheduled email not found',
            ];
        }
        
        // Store the original scheduled time - we'll preserve this unless explicitly changed
        $originalScheduledTime = $email->scheduled_for;
        
        // Get current headers - ensure we're working with an array
        $currentHeaders = [];
        if ($email->headers) {
            if (is_array($email->headers)) {
                $currentHeaders = $email->headers;
            } else if (is_string($email->headers)) {
                $decodedHeaders = json_decode($email->headers, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($decodedHeaders)) {
                    $currentHeaders = $decodedHeaders;
                }
            }
        }
        
        Log::info('Starting scheduled email update', [
            'id' => $email->id,
            'original_scheduled_time' => $originalScheduledTime->toIso8601String(),
            'fields_to_update' => array_keys(array_diff_key($arguments, ['action' => 1, 'scheduled_id' => 1])),
            'scheduled_for_present' => isset($arguments['scheduled_for']),
            'scheduled_for_value' => $arguments['scheduled_for'] ?? 'not provided',
            'current_headers_type' => gettype($email->headers),
            'headers_after_decode' => $currentHeaders
        ]);
        
        // Create update data array for all fields except scheduled_for (we'll handle that separately)
        $updateData = [];
        
        if (isset($arguments['to'])) {
            // Validate email addresses
            if (!$this->validateEmailAddresses($arguments['to'])) {
                return [
                    'success' => false,
                    'error' => 'Invalid recipient email address format',
                ];
            }
            $updateData['to'] = $arguments['to'];
            // Update header in the array
            $currentHeaders['To'] = $arguments['to'];
        }
        
        if (isset($arguments['cc'])) {
            if (!empty($arguments['cc']) && !$this->validateEmailAddresses($arguments['cc'])) {
                return [
                    'success' => false,
                    'error' => 'Invalid CC email address format',
                ];
            }
            $updateData['cc'] = $arguments['cc'];
            // Update header in the array
            if (empty($arguments['cc'])) {
                unset($currentHeaders['Cc']);
            } else {
                $currentHeaders['Cc'] = $arguments['cc'];
            }
        }
        
        if (isset($arguments['bcc'])) {
            if (!empty($arguments['bcc']) && !$this->validateEmailAddresses($arguments['bcc'])) {
                return [
                    'success' => false,
                    'error' => 'Invalid BCC email address format',
                ];
            }
            $updateData['bcc'] = $arguments['bcc'];
            // Update header in the array
            if (empty($arguments['bcc'])) {
                unset($currentHeaders['Bcc']);
            } else {
                $currentHeaders['Bcc'] = $arguments['bcc'];
            }
        }
        
        if (isset($arguments['subject'])) {
            $updateData['subject'] = $arguments['subject'];
            // Update header in the array
            $currentHeaders['Subject'] = $arguments['subject'];
        }
        
        if (isset($arguments['body'])) {
            $updateData['body'] = $arguments['body'];
        }
        
        if (isset($arguments['html_body'])) {
            $updateData['is_html'] = (bool)$arguments['html_body'];
        }
        
        // Set the updated headers array to the update data
        $updateData['headers'] = $currentHeaders;
        
        // Handle scheduled time VERY explicitly
        if (isset($arguments['scheduled_for']) && !empty($arguments['scheduled_for'])) {
            Log::info('New scheduled time requested', [
                'email_id' => $email->id,
                'requested_time' => $arguments['scheduled_for']
            ]);
            
            try {
                // Parse ISO 8601 UTC input directly
                $scheduledTimeInUTC = Carbon::parse($arguments['scheduled_for'], 'UTC');
                
                // Get current time in UTC
                $nowUTC = Carbon::now('UTC');
                
                // Check if scheduled time is in the future
                if ($scheduledTimeInUTC->lte($nowUTC)) {
                    return [
                        'success' => false,
                        'error' => 'Scheduled time must be in the future',
                        'message' => 'You cannot schedule an email to be sent in the past. The scheduled time must be in the future.',
                        'current_time' => $nowUTC->toIso8601String(),
                        'requested_time' => $scheduledTimeInUTC->toIso8601String()
                    ];
                }
                
                Log::info('Updating scheduled email time', [
                    'old_scheduled_time_utc' => $originalScheduledTime->toIso8601String(),
                    'new_scheduled_time_utc' => $scheduledTimeInUTC->toIso8601String()
                ]);
                
                $updateData['scheduled_for'] = $scheduledTimeInUTC; // Store in UTC
            } catch (\Exception $e) {
                return [
                    'success' => false,
                    'error' => 'Invalid scheduled_for date format: ' . $e->getMessage(),
                    'message' => 'Please use ISO 8601 UTC format (e.g. "2025-05-15T10:00:00Z")'
                ];
            }
        } else {
            // IMPORTANT: If no scheduled time provided OR scheduled_for is empty string, 
            // EXPLICITLY set it to the original value to prevent defaults
            $updateData['scheduled_for'] = $email->scheduled_for;
            
            Log::info('Preserving original scheduled time', [
                'email_id' => $email->id,
                'original_scheduled_for' => $email->scheduled_for->toIso8601String(),
                'scheduled_for_argument' => $arguments['scheduled_for'] ?? 'not set'
            ]);
        }
        
        // Log update data before applying it
        Log::info('Updating scheduled email with data', [
            'id' => $email->id,
            'update_data' => $updateData,
            'headers_type' => gettype($updateData['headers']),
            'scheduled_for_in_update' => $updateData['scheduled_for']->toIso8601String()
        ]);
        
        $email->update($updateData);
        
        // Get the updated email for response
        $email = $email->fresh();
        $userTimezone = $user->timezone ?? 'UTC';
        
        // Double-check scheduled time preservation
        Log::info('After update scheduled time verification', [
            'id' => $email->id,
            'original_time' => $originalScheduledTime->toIso8601String(),
            'new_time' => $email->scheduled_for->toIso8601String(),
            'is_unchanged' => $email->scheduled_for->eq($originalScheduledTime),
            'headers_type_after_update' => gettype($email->headers)
        ]);
        
        // Convert UTC stored time to user's timezone for display
        $scheduledTimeInUserTz = $email->scheduled_for->copy()->setTimezone($userTimezone);
        $nowInUserTz = Carbon::now($userTimezone);
        
        return [
            'success' => true,
            'action' => 'update',
            'message' => 'Scheduled email updated successfully',
            'scheduled_email' => [
                'id' => $email->id,
                'to' => $email->to,
                'cc' => $email->cc,
                'bcc' => $email->bcc,
                'subject' => $email->subject,
                'scheduled_for_utc' => $email->scheduled_for->toIso8601String(),
                'scheduled_for_local' => $scheduledTimeInUserTz->toIso8601String(),
                'scheduled_for_display' => $scheduledTimeInUserTz->format('Y-m-d H:i:s') . ' (' . $userTimezone . ')',
                'status' => $email->status,
                'updated_at' => $email->updated_at->toIso8601String(),
                'time_remaining' => $nowInUserTz->diffForHumans($scheduledTimeInUserTz, true) . ' from now',
            ],
        ];
    }
    
    /**
     * List all scheduled emails for a user
     */
    private function listScheduledEmails(User $user)
    {
        // Get all pending scheduled emails for this user
        $scheduledEmails = ScheduledEmail::where('user_id', $user->id)
            ->where('status', 'pending')
            ->orderBy('scheduled_for', 'asc')
            ->get();
        
        $result = [];
        $userTimezone = $user->timezone ?? 'UTC';
        $nowInUserTz = Carbon::now($userTimezone);
        
        foreach ($scheduledEmails as $email) {
            // Convert UTC stored time to user's timezone for display
            $scheduledTimeInUserTz = $email->scheduled_for->copy()->setTimezone($userTimezone);
            
            $result[] = [
                'id' => $email->id,
                'to' => $email->to,
                'cc' => $email->cc,
                'bcc' => $email->bcc,
                'subject' => $email->subject,
                'scheduled_for_utc' => $email->scheduled_for->toIso8601String(),
                'scheduled_for_local' => $scheduledTimeInUserTz->toIso8601String(),
                'scheduled_for_display' => $scheduledTimeInUserTz->format('Y-m-d H:i:s') . ' (' . $userTimezone . ')',
                'is_html' => (bool)$email->is_html,
                'status' => $email->status,
                'created_at' => $email->created_at->toIso8601String(),
                'updated_at' => $email->updated_at->toIso8601String(),
                'time_remaining' => $nowInUserTz->diffForHumans($scheduledTimeInUserTz, true) . ' from now',
            ];
        }
        
        return [
            'success' => true,
            'action' => 'list',
            'count' => count($result),
            'scheduled_emails' => $result,
        ];
    }
    
    /**
     * Get a specific scheduled email
     */
    private function getScheduledEmail(User $user, int $scheduledId)
    {
        $email = ScheduledEmail::where('user_id', $user->id)
            ->where('id', $scheduledId)
            ->first();
        
        if (!$email) {
            return [
                'success' => false,
                'error' => 'Scheduled email not found',
            ];
        }
        
        $userTimezone = $user->timezone ?? 'UTC';
        
        // Convert UTC stored time to user's timezone for display
        $scheduledTimeInUserTz = $email->scheduled_for->copy()->setTimezone($userTimezone);
        $nowInUserTz = Carbon::now($userTimezone);
        
        return [
            'success' => true,
            'action' => 'get',
            'scheduled_email' => [
                'id' => $email->id,
                'to' => $email->to,
                'cc' => $email->cc,
                'bcc' => $email->bcc,
                'subject' => $email->subject,
                'body' => $email->body,
                'is_html' => (bool)$email->is_html,
                'scheduled_for_utc' => $email->scheduled_for->toIso8601String(),
                'scheduled_for_local' => $scheduledTimeInUserTz->toIso8601String(),
                'scheduled_for_display' => $scheduledTimeInUserTz->format('Y-m-d H:i:s') . ' (' . $userTimezone . ')',
                'status' => $email->status,
                'created_at' => $email->created_at->toIso8601String(),
                'updated_at' => $email->updated_at->toIso8601String(),
                'time_remaining' => $nowInUserTz->diffForHumans($scheduledTimeInUserTz, true) . ' from now',
            ],
        ];
    }
    
    /**
     * Delete a scheduled email
     */
    private function deleteScheduledEmail(User $user, int $scheduledId)
    {
        $email = ScheduledEmail::where('user_id', $user->id)
            ->where('id', $scheduledId)
            ->first();
        
        if (!$email) {
            return [
                'success' => false,
                'error' => 'Scheduled email not found',
            ];
        }
        
        // Delete the email
        $email->delete();
        
        return [
            'success' => true,
            'action' => 'delete',
            'message' => 'Scheduled email deleted successfully',
            'scheduled_id' => $scheduledId,
        ];
    }
    
    /**
     * Validate email address format
     */
    private function validateEmailAddresses($emails)
    {
        $emailList = explode(',', $emails);
        
        foreach ($emailList as $email) {
            $email = trim($email);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return false;
            }
        }
        
        return true;
    }
}