<?php

namespace App\Services\Tools;

use App\Models\User;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;

class LanguagePreferenceTools implements ToolInterface
{
    // Redis constants
    const METADATA_TTL = 3600; // 1 hour
    
    public function getName()
    {
        return 'set_language_preference';
    }
    
    public function getDescription()
    {
        return 'Set or update the user\'s preferred language for responses';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'language_code' => [
                    'type' => 'string',
                    'description' => 'ISO language code (e.g., "en" for English, "es" for Spanish, "fr" for French)',
                ],
                'auto_detect' => [
                    'type' => 'boolean',
                    'description' => 'Whether to auto-detect language from user messages',
                ]
            ],
            'required' => ['language_code'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            Log::info('Setting language preference', [
                'user_id' => $user->id, 
                'language_code' => $arguments['language_code'],
                'auto_detect' => $arguments['auto_detect'] ?? false
            ]);
            
            $languageCode = $arguments['language_code'];
            $autoDetect = $arguments['auto_detect'] ?? false;
            
            // Standard language codes
            $validLanguages = [
                'en' => 'English',
                // 'es' => 'Spanish',
                // 'fr' => 'French',
                // 'de' => 'German',
                // 'it' => 'Italian',
                // 'pt' => 'Portuguese',
                // 'ru' => 'Russian',
                // 'ja' => 'Japanese',
                // 'zh' => 'Chinese',
                // 'ko' => 'Korean',
                // 'ar' => 'Arabic',
                // 'hi' => 'Hindi',
                'ur' => 'Urdu',
                'he' => 'Hebrew'
            ];
            
            // Validate language code
            if (!isset($validLanguages[$languageCode])) {
                return [
                    'success' => false,
                    'error' => 'Invalid language code',
                    'message' => 'The specified language code is not supported.',
                    'supported_languages' => array_keys($validLanguages)
                ];
            }
            
            // Update metadata in Redis
            $this->updateMetadataField($user->id, 'preferred_language', $languageCode);
            $this->updateMetadataField($user->id, 'language_auto_detect', $autoDetect);
            
            // Always update or create user preferences in database to trigger the observer
            if ($user->preferences) {
                $user->preferences->language = $languageCode;
                $user->preferences->language_auto_detect = $autoDetect;
                $user->preferences->save();
            } else {
                // Create preferences if they don't exist
                $preferences = new \App\Models\UserPreferences([
                    'user_id' => $user->id,
                    'language' => $languageCode,
                    'language_auto_detect' => $autoDetect
                ]);
                $preferences->save();
                
                // Associate with user
                $user->preferences()->save($preferences);
            }
            
            return [
                'success' => true,
                'language' => [
                    'code' => $languageCode,
                    'name' => $validLanguages[$languageCode],
                    'auto_detect' => $autoDetect
                ],
                'message' => "Language preference updated to {$validLanguages[$languageCode]}."
            ];
        } catch (\Exception $e) {
            Log::error('Error setting language preference', [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'System error',
                'message' => 'An unexpected error occurred: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Update a field in the user's conversation metadata in Redis
     */
    private function updateMetadataField(int $userId, string $field, $value): void
    {
        try {
            $redisKey = "conversation:{$userId}:meta";
            
            // Update the specific field
            Redis::hset($redisKey, $field, $value);
            
            // Set expiration if new key
            if (Redis::ttl($redisKey) < 0) {
                Redis::expire($redisKey, self::METADATA_TTL);
            }
            
            Log::info("Updated metadata for user", [
                'user_id' => $userId,
                'field' => $field,
                'value' => $value
            ]);
        } catch (\Exception $e) {
            Log::error("Failed to update metadata: " . $e->getMessage());
        }
    }
}