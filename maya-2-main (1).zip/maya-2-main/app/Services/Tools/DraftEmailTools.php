<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Services\Gmail\GmailService;
use Illuminate\Support\Facades\Log;
use Google_Service_Gmail_Draft;
use Google_Service_Gmail_Message;

class DraftEmailTools implements ToolInterface
{
    protected $gmailService;
    
    public function __construct(GmailService $gmailService)
    {
        $this->gmailService = $gmailService;
    }
    
    public function getName()
    {
        return 'gmail_draft_email';
    }
    
    public function getDescription()
    {
        return 'Create, update, or get email drafts in Gmail';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'action' => [
                    'type' => 'string',
                    'description' => 'Action to perform on drafts',
                    'enum' => ['create', 'update', 'list', 'get', 'delete'],
                ],
                'draft_id' => [
                    'type' => 'string',
                    'description' => 'ID of the draft for update, get, or delete actions',
                ],
                'to' => [
                    'type' => 'string',
                    'description' => 'Recipient email address(es) for new draft',
                ],
                'cc' => [
                    'type' => 'string',
                    'description' => 'CC recipient email address(es) for new draft',
                ],
                'bcc' => [
                    'type' => 'string',
                    'description' => 'BCC recipient email address(es) for new draft',
                ],
                'subject' => [
                    'type' => 'string',
                    'description' => 'Email subject line for new draft',
                ],
                'body' => [
                    'type' => 'string',
                    'description' => 'Email body content for new draft',
                ],
                'html_body' => [
                    'type' => 'boolean',
                    'description' => 'Whether the body content is HTML formatted',
                    'default' => false,
                ],
                'attachments' => [
                    'type' => 'array',
                    'description' => 'List of attachment IDs to include in draft',
                    'items' => [
                        'type' => 'string',
                    ],
                ],
                'max_drafts' => [
                    'type' => 'integer',
                    'description' => 'Maximum number of drafts to return when listing',
                    'default' => 10,
                ],
            ],
            'required' => ['action'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            // Check if the user has an active Gmail account
            if (!$user->gmailAccount || !$user->gmailAccount->is_active) {
                return [
                    'success' => false,
                    'error' => 'No active Gmail account found for this user',
                ];
            }
            
            $action = $arguments['action'];
            
            // Validate the required parameters based on action
            if (in_array($action, ['update', 'get', 'delete']) && !isset($arguments['draft_id'])) {
                return [
                    'success' => false,
                    'error' => "The 'draft_id' parameter is required for $action action",
                ];
            }
            
            if ($action === 'create' && (!isset($arguments['subject']) || !isset($arguments['body']))) {
                return [
                    'success' => false,
                    'error' => "The 'subject' and 'body' parameters are required for create action",
                ];
            }
            
            // Get Gmail service
            $service = $this->gmailService->getGmailService($user);
            
            switch ($action) {
                case 'create':
                    return $this->createDraft($service, $user, $arguments);
                
                case 'update':
                    return $this->updateDraft($service, $user, $arguments);
                
                case 'list':
                    return $this->listDrafts($service, $user, $arguments);
                
                case 'get':
                    return $this->getDraft($service, $user, $arguments);
                
                case 'delete':
                    return $this->deleteDraft($service, $user, $arguments);
                
                default:
                    return [
                        'success' => false,
                        'error' => 'Invalid action specified',
                    ];
            }
        } catch (\Exception $e) {
            Log::error('Error managing email drafts: ' . $e->getMessage(), [
                'user_id' => $user->id,
                'action' => $arguments['action'] ?? 'unknown',
            ]);
            
            return [
                'success' => false,
                'error' => 'Failed to manage email drafts: ' . $e->getMessage(),
            ];
        }
    }
    
    /**
     * Create a new draft email
     */
    private function createDraft($service, User $user, array $arguments)
    {
        try {
            // Build email headers
            $headers = [
                'From' => $user->gmailAccount->email,
                'Subject' => $arguments['subject'],
            ];
            
            if (isset($arguments['to']) && !empty($arguments['to'])) {
                $headers['To'] = $arguments['to'];
            }
            
            if (isset($arguments['cc']) && !empty($arguments['cc'])) {
                $headers['Cc'] = $arguments['cc'];
            }
            
            if (isset($arguments['bcc']) && !empty($arguments['bcc'])) {
                $headers['Bcc'] = $arguments['bcc'];
            }
            
            // Create email
            $isHtml = $arguments['html_body'] ?? false;
            $encodedEmail = $this->gmailService->createEmailRaw($headers, $arguments['body'], $isHtml);
            
            // Create message object
            $message = new Google_Service_Gmail_Message();
            $message->setRaw($encodedEmail);
            
            // Create draft object
            $draft = new Google_Service_Gmail_Draft();
            $draft->setMessage($message);
            
            // Save draft
            $result = $service->users_drafts->create('me', $draft);
            
            return [
                'success' => true,
                'action' => 'create',
                'draft_id' => $result->getId(),
                'to' => $arguments['to'] ?? '',
                'subject' => $arguments['subject'],
                'created_at' => date('c'),
            ];
        } catch (\Exception $e) {
            Log::error('Error creating draft: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to create draft: ' . $e->getMessage(),
            ];
        }
    }
    
    /**
     * Update an existing draft email
     */
    private function updateDraft($service, User $user, array $arguments)
    {
        try {
            // First get the existing draft
            $draftId = $arguments['draft_id'];
            
            try {
                $existingDraft = $service->users_drafts->get('me', $draftId);
            } catch (\Exception $e) {
                return [
                    'success' => false,
                    'error' => 'Draft not found: ' . $e->getMessage(),
                ];
            }
            
            // Build email headers
            $headers = [
                'From' => $user->gmailAccount->email,
                'Subject' => $arguments['subject'] ?? '(No Subject)',
            ];
            
            if (isset($arguments['to']) && !empty($arguments['to'])) {
                $headers['To'] = $arguments['to'];
            }
            
            if (isset($arguments['cc']) && !empty($arguments['cc'])) {
                $headers['Cc'] = $arguments['cc'];
            }
            
            if (isset($arguments['bcc']) && !empty($arguments['bcc'])) {
                $headers['Bcc'] = $arguments['bcc'];
            }
            
            // Create updated email
            $isHtml = $arguments['html_body'] ?? false;
            $body = $arguments['body'] ?? '';
            $encodedEmail = $this->gmailService->createEmailRaw($headers, $body, $isHtml);
            
            // Create message object
            $message = new Google_Service_Gmail_Message();
            $message->setRaw($encodedEmail);
            
            // Create draft object
            $draft = new Google_Service_Gmail_Draft();
            $draft->setMessage($message);
            
            // Update draft (delete + create in Gmail API)
            $service->users_drafts->delete('me', $draftId);
            $result = $service->users_drafts->create('me', $draft);
            
            return [
                'success' => true,
                'action' => 'update',
                'draft_id' => $result->getId(),
                'message' => 'Draft updated successfully',
                'updated_at' => date('c'),
            ];
        } catch (\Exception $e) {
            Log::error('Error updating draft: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to update draft: ' . $e->getMessage(),
            ];
        }
    }
    
    /**
     * List draft emails
     */
    private function listDrafts($service, User $user, array $arguments)
    {
        try {
            $maxResults = min($arguments['max_drafts'] ?? 10, 50); // Limit to max 50
            
            // Get total count of drafts first
            $optParamsCount = [
                'maxResults' => 1000 // Set a high number to get full count
            ];
            
            $countResponse = $service->users_drafts->listUsersDrafts('me', $optParamsCount);
            $totalDrafts = count($countResponse->getDrafts() ?: []);
            
            // Now get the requested number of drafts
            $optParams = [
                'maxResults' => $maxResults,
            ];
            
            $response = $service->users_drafts->listUsersDrafts('me', $optParams);
            $drafts = $response->getDrafts() ?: [];
            
            $result = [];
            
            if (!empty($drafts)) {
                foreach ($drafts as $draft) {
                    $draftId = $draft->getId();
                    $fullDraft = $service->users_drafts->get('me', $draftId, ['format' => 'metadata']);
                    
                    $message = $fullDraft->getMessage();
                    $headers = $message->getPayload()->getHeaders();
                    
                    // Extract headers
                    $to = '';
                    $subject = '(No Subject)';
                    $date = '';
                    
                    foreach ($headers as $header) {
                        if ($header->getName() === 'To') {
                            $to = $header->getValue();
                        } elseif ($header->getName() === 'Subject') {
                            $subject = $header->getValue();
                        } elseif ($header->getName() === 'Date') {
                            $date = $header->getValue();
                        }
                    }
                    
                    $result[] = [
                        'id' => $draftId,
                        'to' => $to,
                        'subject' => $subject,
                        'created_at' => $date ?: date('c'),
                        'updated_at' => $date ?: date('c'),
                        'snippet' => $message->getSnippet(),
                    ];
                }
            }
            
            return [
                'success' => true,
                'action' => 'list',
                'total_drafts' => $totalDrafts,
                'showing' => count($result),
                'has_more' => ($totalDrafts > count($result)),
                'drafts' => $result,
            ];
        } catch (\Exception $e) {
            Log::error('Error listing drafts: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to list drafts: ' . $e->getMessage(),
            ];
        }
    }
    
    /**
     * Get a specific draft email
     */
    private function getDraft($service, User $user, array $arguments)
    {
        try {
            $draftId = $arguments['draft_id'];
            
            try {
                $draft = $service->users_drafts->get('me', $draftId, ['format' => 'full']);
            } catch (\Exception $e) {
                return [
                    'success' => false,
                    'error' => 'Draft not found: ' . $e->getMessage(),
                ];
            }
            
            $message = $draft->getMessage();
            $payload = $message->getPayload();
            $headers = $payload->getHeaders();
            
            // Extract headers
            $to = '';
            $cc = '';
            $bcc = '';
            $subject = '(No Subject)';
            $date = '';
            
            foreach ($headers as $header) {
                if ($header->getName() === 'To') {
                    $to = $header->getValue();
                } elseif ($header->getName() === 'Cc') {
                    $cc = $header->getValue();
                } elseif ($header->getName() === 'Bcc') {
                    $bcc = $header->getValue();
                } elseif ($header->getName() === 'Subject') {
                    $subject = $header->getValue();
                } elseif ($header->getName() === 'Date') {
                    $date = $header->getValue();
                }
            }
            
            // Get body content
            $body = $this->gmailService->getMessageBody($payload);
            
            // Check for attachments
            $hasAttachments = false;
            $attachments = [];
            
            if ($payload->getParts()) {
                foreach ($payload->getParts() as $part) {
                    if ($part->getFilename() && $part->getBody()->getAttachmentId()) {
                        $hasAttachments = true;
                        $attachments[] = [
                            'id' => $part->getBody()->getAttachmentId(),
                            'filename' => $part->getFilename(),
                            'mimeType' => $part->getMimeType(),
                        ];
                    }
                }
            }
            
            $result = [
                'id' => $draftId,
                'to' => $to,
                'cc' => $cc,
                'bcc' => $bcc,
                'subject' => $subject,
                'body' => $body['content'],
                'body_type' => $body['type'],
                'created_at' => $date ?: date('c'),
                'updated_at' => $date ?: date('c'),
                'has_attachments' => $hasAttachments,
            ];
            
            if ($hasAttachments) {
                $result['attachments'] = $attachments;
            }
            
            return [
                'success' => true,
                'action' => 'get',
                'draft' => $result,
            ];
        } catch (\Exception $e) {
            Log::error('Error getting draft: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to get draft: ' . $e->getMessage(),
            ];
        }
    }
    
    /**
     * Delete a draft email
     */
    private function deleteDraft($service, User $user, array $arguments)
    {
        try {
            $draftId = $arguments['draft_id'];
            
            try {
                $service->users_drafts->delete('me', $draftId);
            } catch (\Exception $e) {
                return [
                    'success' => false,
                    'error' => 'Draft not found or already deleted: ' . $e->getMessage(),
                ];
            }
            
            return [
                'success' => true,
                'action' => 'delete',
                'draft_id' => $draftId,
                'message' => 'Draft deleted successfully',
            ];
        } catch (\Exception $e) {
            Log::error('Error deleting draft: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to delete draft: ' . $e->getMessage(),
            ];
        }
    }
}