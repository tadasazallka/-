<?php
// app/Services/Tools/GetCurrentWeatherTools.php

namespace App\Services\Tools;

use App\Models\User;
use App\Services\WeatherService;
use Illuminate\Support\Facades\Log;

class GetCurrentWeatherTools implements ToolInterface
{
    protected $weatherService;
    
    public function __construct(WeatherService $weatherService)
    {
        $this->weatherService = $weatherService;
    }
    
    public function getName()
    {
        return 'get_current_weather';
    }
    
    public function getDescription()
    {
        return 'Get current weather information for a specific location';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'location' => [
                    'type' => 'string',
                    'description' => 'City name or location (e.g. "New York", "London, UK")',
                ],
                'units' => [
                    'type' => 'string',
                    'description' => 'Temperature units: metric (Celsius) or imperial (Fahrenheit)',
                    'enum' => ['metric', 'imperial'],
                    'default' => 'metric',
                ],
            ],
            'required' => ['location'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            $location = $arguments['location'];
            $units = $arguments['units'] ?? 'metric';
            
            Log::info('Getting current weather', [
                'user_id' => $user->id,
                'location' => $location,
                'units' => $units
            ]);
            
            return $this->weatherService->getCurrentWeather($location, $units);
            
        } catch (\Exception $e) {
            Log::error('Error getting current weather', [
                'error' => $e->getMessage(),
                'location' => $arguments['location'] ?? null
            ]);
            
            return [
                'success' => false,
                'error' => 'Failed to get weather data: ' . $e->getMessage()
            ];
        }
    }
}