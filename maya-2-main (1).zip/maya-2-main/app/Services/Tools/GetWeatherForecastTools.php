<?php
// app/Services/Tools/GetWeatherForecastTools.php

namespace App\Services\Tools;

use App\Models\User;
use App\Services\WeatherService;
use Illuminate\Support\Facades\Log;

class GetWeatherForecastTools implements ToolInterface
{
    protected $weatherService;
    
    public function __construct(WeatherService $weatherService)
    {
        $this->weatherService = $weatherService;
    }
    
    public function getName()
    {
        return 'get_weather_forecast';
    }
    
    public function getDescription()
    {
        return 'Get weather forecast for a specific location';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'location' => [
                    'type' => 'string',
                    'description' => 'City name or location (e.g. "New York", "London, UK")',
                ],
                'units' => [
                    'type' => 'string',
                    'description' => 'Temperature units: metric (Celsius) or imperial (Fahrenheit)',
                    'enum' => ['metric', 'imperial'],
                    'default' => 'metric',
                ],
                'days' => [
                    'type' => 'integer',
                    'description' => 'Number of days to forecast (1-5)',
                    'minimum' => 1,
                    'maximum' => 5,
                    'default' => 5,
                ],
            ],
            'required' => ['location'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            $location = $arguments['location'];
            $units = $arguments['units'] ?? 'metric';
            $days = $arguments['days'] ?? 5;
            
            Log::info('Getting weather forecast', [
                'user_id' => $user->id,
                'location' => $location,
                'units' => $units,
                'days' => $days
            ]);
            
            return $this->weatherService->getWeatherForecast($location, $units, $days);
            
        } catch (\Exception $e) {
            Log::error('Error getting weather forecast', [
                'error' => $e->getMessage(),
                'location' => $arguments['location'] ?? null
            ]);
            
            return [
                'success' => false,
                'error' => 'Failed to get weather forecast: ' . $e->getMessage()
            ];
        }
    }
}