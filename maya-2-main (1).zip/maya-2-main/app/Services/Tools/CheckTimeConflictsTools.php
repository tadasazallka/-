<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Services\PlanLimitService;
use App\Services\TimeConflictService;
use App\Services\TimezoneService;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class CheckTimeConflictsTools implements ToolInterface
{
    protected $planLimitService;
    protected $timeConflictService;
    protected $timezoneService;
    
    public function __construct(
        PlanLimitService $planLimitService,
        TimeConflictService $timeConflictService,
        TimezoneService $timezoneService
    ) {
        $this->planLimitService = $planLimitService;
        $this->timeConflictService = $timeConflictService;
        $this->timezoneService = $timezoneService;
    }

    public function getName()
    {
        return 'check_time_conflicts';
    }
    
    public function getDescription()
    {
        return 'Check for time conflicts before creating or updating calendar events without modifying anything';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'start_time' => [
                    'type' => 'string',
                    'description' => 'Start time in ISO 8601 UTC format (e.g. "2025-05-15T10:00:00Z")',
                    'format' => 'date-time',
                ],
                'end_time' => [
                    'type' => 'string',
                    'description' => 'End time in ISO 8601 UTC format (e.g. "2025-05-15T11:00:00Z")',
                    'format' => 'date-time',
                ],
                'event_id' => [
                    'type' => 'string',
                    'description' => 'Optional: ID of an existing event to exclude from conflict detection (for updates)',
                ],
                'is_all_day' => [
                    'type' => 'boolean',
                    'description' => 'Whether this is an all-day event',
                ],
            ],
            'required' => ['start_time', 'end_time'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            Log::info('Executing check_time_conflicts', ['user_id' => $user->id, 'arguments' => $arguments]);
            
            // First check if user's plan allows time conflict detection
            $canUseTimeConflictDetection = $this->planLimitService->canUseTimeConflictDetection($user);
            
            if (!$canUseTimeConflictDetection) {
                return [
                    'success' => true,
                    'has_permission' => false,
                    'message' => 'Time conflict detection is a premium feature. Upgrade your plan to enable this functionality.',
                    'plan_info' => [
                        'current_plan' => $user->currentPlan()->slug,
                        'upgrade_url' => 'https://maya-landing-hebrew.vercel.app/pricing'
                    ]
                ];
            }
            
            // Get user timezone (only for display and all-day event handling)
            $userTz = $user->timezone ?? 'UTC';
            
            // Parse start and end times directly in UTC
            $startDateTime = null;
            $endDateTime = null;
            
            if (isset($arguments['start_time'])) {
                // Parse ISO 8601 UTC input
                $startDateTime = Carbon::parse($arguments['start_time'], 'UTC');
                Log::info('Parsed start time', [
                    'input' => $arguments['start_time'],
                    'parsed_utc' => $startDateTime->toIso8601String()
                ]);
            }
            
            if (isset($arguments['end_time'])) {
                // Parse ISO 8601 UTC input
                $endDateTime = Carbon::parse($arguments['end_time'], 'UTC');
                Log::info('Parsed end time', [
                    'input' => $arguments['end_time'],
                    'parsed_utc' => $endDateTime->toIso8601String()
                ]);
            }
            
            // Validate that both times are provided
            if (!$startDateTime || !$endDateTime) {
                return [
                    'success' => false,
                    'error' => 'Missing time parameters',
                    'message' => 'Both start_time and end_time are required in ISO 8601 UTC format'
                ];
            }
            
            // Check if the event is in the past directly in UTC
            $nowUTC = Carbon::now('UTC');
            if ($startDateTime->lt($nowUTC)) {
                return [
                    'success' => false,
                    'error' => 'Past date not allowed',
                    'message' => 'Cannot check conflicts for past dates. Please choose a future date and time.',
                    'current_time' => $nowUTC->toIso8601String(),
                    'requested_time' => $startDateTime->toIso8601String()
                ];
            }
            
            // Validate that end time is after start time
            if ($endDateTime->lte($startDateTime)) {
                return [
                    'success' => false,
                    'error' => 'Invalid time range',
                    'message' => 'End time must be after start time.'
                ];
            }
            
            // Special handling for all-day events
            $isAllDay = $arguments['is_all_day'] ?? false;
            if ($isAllDay) {
                // For all-day events, adjust times to full day boundaries in user's timezone
                $userStartDate = $startDateTime->copy()->setTimezone($userTz)->startOfDay();
                $userEndDate = $endDateTime->copy()->setTimezone($userTz)->endOfDay();
                
                // Convert back to UTC for storage and operations
                $startDateTime = $userStartDate->copy()->setTimezone('UTC');
                $endDateTime = $userEndDate->copy()->setTimezone('UTC');
                
                Log::info('Adjusted all-day event times', [
                    'user_timezone' => $userTz,
                    'start_utc' => $startDateTime->toIso8601String(),
                    'end_utc' => $endDateTime->toIso8601String()
                ]);
            }
            
            // Check for time conflicts
            $excludeEventId = $arguments['event_id'] ?? null;
            $conflicts = $this->timeConflictService->checkTimeConflicts(
                $user,
                $startDateTime,
                $endDateTime,
                $excludeEventId
            );
            
            // Format conflicts for display - converting back to user timezone
            $formattedConflicts = $this->timeConflictService->formatConflictInfo($conflicts, $userTz);
            
            // Prepare response
            $response = [
                'success' => true,
                'has_conflicts' => count($conflicts) > 0,
                'conflict_count' => count($conflicts),
                'time_conflicts' => $formattedConflicts
            ];
            
            // Add human-readable warning if conflicts exist
            if (count($conflicts) > 0) {
                $response['conflict_warning'] = "This event would overlap with {$formattedConflicts['count']} existing " . 
                    ($formattedConflicts['count'] == 1 ? "event" : "events") . " in your calendar.";
                
                // Include both UTC and user-local time information for clarity
                $startDateTimeUser = $startDateTime->copy()->setTimezone($userTz);
                $endDateTimeUser = $endDateTime->copy()->setTimezone($userTz);
                
                $response['requested_time_range'] = [
                    'start_utc' => $startDateTime->toIso8601String(),
                    'end_utc' => $endDateTime->toIso8601String(),
                    'start_local' => $startDateTimeUser->format('Y-m-d H:i:s T'),
                    'end_local' => $endDateTimeUser->format('Y-m-d H:i:s T'),
                    'timezone' => $userTz,
                    'is_all_day' => $isAllDay
                ];
            }
            
            return $response;
            
        } catch (\Exception $e) {
            Log::error('Error in check_time_conflicts', [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'System error',
                'message' => 'An unexpected error occurred: ' . $e->getMessage()
            ];
        }
    }
}