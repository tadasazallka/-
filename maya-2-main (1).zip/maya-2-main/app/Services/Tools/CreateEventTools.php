<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Services\CalendarCreateService;
use App\Services\PlanLimitService;
use App\Services\TimeConflictService;
use App\Services\TimezoneService;
use App\Services\Tools\ToolInterface;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class CreateEventTools implements ToolInterface
{
    protected $calendarCreateService;
    protected $planLimitService;
    protected $timeConflictService;
    protected $timezoneService;
    
    // Maximum file size constants (in bytes) - should match controller
    const DEFAULT_REMINDER_MINUTES = 10; // Default reminder time
    
    public function __construct(
        CalendarCreateService $calendarCreateService,
        PlanLimitService $planLimitService,
        TimeConflictService $timeConflictService,
        TimezoneService $timezoneService
    ) {
        $this->calendarCreateService = $calendarCreateService;
        $this->planLimitService = $planLimitService;
        $this->timeConflictService = $timeConflictService;
        $this->timezoneService = $timezoneService;
    }

    public function getName()
    {
        return 'calendar_create_event';
    }
    
    public function getDescription()
    {
        return 'Create a new event in the user\'s calendar';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'title' => [
                    'type' => 'string',
                    'description' => 'Title of the event',
                ],
                'start_time' => [
                    'type' => 'string',
                    'description' => 'Start time in ISO 8601 UTC format (e.g. "2025-05-15T10:00:00Z")',
                    'format' => 'date-time',
                ],
                'end_time' => [
                    'type' => 'string',
                    'description' => 'End time in ISO 8601 UTC format (e.g. "2025-05-15T11:00:00Z")',
                    'format' => 'date-time',
                ],
                'description' => [
                    'type' => 'string',
                    'description' => 'Description or notes for the event',
                ],
                'location' => [
                    'type' => 'string',
                    'description' => 'Location of the event',
                ],
                'attendees' => [
                    'type' => 'array',
                    'description' => 'List of email addresses for attendees',
                    'items' => [
                        'type' => 'string',
                    ],
                ],
                'recurrence' => [
                    'type' => 'object',
                    'description' => 'Recurrence rules for repeating events',
                    'properties' => [
                        'frequency' => [
                            'type' => 'string',
                            'enum' => ['daily', 'weekly', 'monthly', 'yearly'],
                        ],
                        'interval' => [
                            'type' => 'integer',
                            'description' => 'Interval between recurrences',
                        ],
                        'count' => [
                            'type' => 'integer',
                            'description' => 'Number of occurrences',
                        ],
                        'until' => [
                            'type' => 'string',
                            'description' => 'End date for recurrence in YYYY-MM-DD format',
                            'format' => 'date',
                        ],
                    ],
                ],
                'reminders' => [
                    'type' => 'array',
                    'description' => 'Reminder notifications for the event (empty array to disable reminders, omit for default 10-minute reminder)',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                            'method' => [
                                'type' => 'string',
                                'enum' => ['email', 'popup'],
                            ],
                            'minutes' => [
                                'type' => 'integer',
                                'description' => 'Minutes before the event to send reminder',
                            ],
                        ],
                    ],
                ],
                'is_all_day' => [
                    'type' => 'boolean',
                    'description' => 'Whether this is an all-day event',
                ],
                'add_google_meet' => [
                    'type' => 'boolean',
                    'description' => 'Whether to add Google Meet conferencing to the event (only works with Google Calendar)',
                ],
                'confirm_conflicts' => [
                    'type' => 'boolean',
                    'description' => 'Whether to proceed with event creation even if time conflicts are detected',
                ],
                'skip_conflict_check' => [
                    'type' => 'boolean',
                    'description' => 'Whether to skip time conflict detection entirely (useful for performance with free plans)',
                ],
            ],
            'required' => ['title', 'start_time', 'end_time'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            Log::info('Executing calendar_create_event', ['user_id' => $user->id, 'arguments' => $arguments]);
            
            // Get user timezone (for formatting responses and all-day event handling)
            $userTz = $user->timezone ?? 'UTC';
            
            // Parse start and end times directly in UTC
            $startDateTime = null;
            $endDateTime = null;
            
            if (isset($arguments['start_time'])) {
                // Parse ISO 8601 UTC input
                $startDateTime = Carbon::parse($arguments['start_time'], 'UTC');
                Log::info('Parsed start time', [
                    'input' => $arguments['start_time'],
                    'parsed_utc' => $startDateTime->toIso8601String()
                ]);
            }
            
            if (isset($arguments['end_time'])) {
                // Parse ISO 8601 UTC input
                $endDateTime = Carbon::parse($arguments['end_time'], 'UTC');
                Log::info('Parsed end time', [
                    'input' => $arguments['end_time'],
                    'parsed_utc' => $endDateTime->toIso8601String()
                ]);
            }
            
            // Validate that both start and end times are provided
            if (!$startDateTime || !$endDateTime) {
                return [
                    'success' => false,
                    'error' => 'Missing time parameters',
                    'message' => 'Both start_time and end_time are required in ISO 8601 UTC format'
                ];
            }
            
            // Check if the event is in the past directly in UTC
            $nowUTC = Carbon::now('UTC');
            if ($startDateTime->lt($nowUTC)) {
                return [
                    'success' => false,
                    'error' => 'Past date not allowed',
                    'message' => 'Cannot create events in the past. Please choose a future date and time.',
                    'current_time' => $nowUTC->toIso8601String(),
                    'requested_time' => $startDateTime->toIso8601String()
                ];
            }
            
            // Validate that the end time is after the start time
            if ($endDateTime->lte($startDateTime)) {
                return [
                    'success' => false,
                    'error' => 'Invalid time range',
                    'message' => 'End time must be after start time.'
                ];
            }
            
            // Special handling for all-day events
            $isAllDay = $arguments['is_all_day'] ?? false;
            if ($isAllDay) {
                // For all-day events, adjust times to full day boundaries in user's timezone
                $userStartDate = $startDateTime->copy()->setTimezone($userTz)->startOfDay();
                $userEndDate = $endDateTime->copy()->setTimezone($userTz)->endOfDay();
                
                // Convert back to UTC for storage and operations
                $startDateTime = $userStartDate->copy()->setTimezone('UTC');
                $endDateTime = $userEndDate->copy()->setTimezone('UTC');
                
                Log::info('Adjusted all-day event times', [
                    'user_timezone' => $userTz,
                    'start_utc' => $startDateTime->toIso8601String(),
                    'end_utc' => $endDateTime->toIso8601String()
                ]);
            }
            
            // Check for time conflicts if the feature is enabled and not explicitly skipped
            $conflicts = [];
            $skipConflictCheck = $arguments['skip_conflict_check'] ?? false;
            $confirmConflicts = $arguments['confirm_conflicts'] ?? false;
            
            $canUseTimeConflictDetection = $this->planLimitService->canUseTimeConflictDetection($user);
            
            if ($canUseTimeConflictDetection && !$skipConflictCheck) {
                $conflicts = $this->timeConflictService->checkTimeConflicts(
                    $user,
                    $startDateTime,
                    $endDateTime
                );
                
                Log::info('Time conflict check', [
                    'user_id' => $user->id,
                    'conflicts_found' => count($conflicts),
                    'confirm_conflicts' => $confirmConflicts
                ]);
                
                // If conflicts are found and not confirmed, return without creating the event
                if (!empty($conflicts) && !$confirmConflicts) {
                    $formattedConflicts = $this->timeConflictService->formatConflictInfo($conflicts, $userTz);
                    
                    return [
                        'success' => false,
                        'requires_confirmation' => true,
                        'error' => 'Time conflicts detected',
                        'message' => "This event would overlap with {$formattedConflicts['count']} existing " . 
                            ($formattedConflicts['count'] == 1 ? "event" : "events") . " in your calendar. Please confirm if you want to proceed.",
                        'time_conflicts' => $formattedConflicts,
                        'requested_time_range' => [
                            'start' => $startDateTime->toIso8601String(),
                            'end' => $endDateTime->toIso8601String(),
                            'timezone' => 'UTC'
                        ]
                    ];
                }
            }
            
            // Automatically enable Google Meet if user's plan allows it
            $canUseGoogleMeetLinks = $this->planLimitService->canUseGoogleMeetLinks($user);
            $addGoogleMeet = false;
            
            // Only add Google Meet if explicitly requested OR if user's plan allows it (and it's not explicitly disabled)
            if ((isset($arguments['add_google_meet']) && $arguments['add_google_meet'] === true) || 
                ($canUseGoogleMeetLinks && (!isset($arguments['add_google_meet']) || $arguments['add_google_meet'] !== false))) {
                
                if ($canUseGoogleMeetLinks) {
                    Log::info('Automatically adding Google Meet (user has access to feature)', ['user_id' => $user->id]);
                    $addGoogleMeet = true;
                } else {
                    Log::info('User requested Google Meet but does not have feature access', ['user_id' => $user->id]);
                }
            }
            
            // Process reminders - determine if user explicitly disabled reminders
            $userDisabledReminders = false;
            
            // Check if reminders array is empty but was explicitly set (meaning user doesn't want reminders)
            if (array_key_exists('reminders', $arguments) && empty($arguments['reminders'])) {
                $userDisabledReminders = true;
                Log::info('User explicitly disabled reminders', ['user_id' => $user->id]);
            }
            
            // Prepare parameters for the calendar service
            $eventParams = [
                'title' => $arguments['title'],
                'description' => $arguments['description'] ?? null,
                'location' => $arguments['location'] ?? null,
                'calendar_id' => $arguments['calendar_id'] ?? null,
                'is_all_day' => $isAllDay,
                'recurrence' => $arguments['recurrence'] ?? null,
                'attendees' => $arguments['attendees'] ?? [],
                'reminders' => $arguments['reminders'] ?? [],
                'user_disabled_reminders' => $userDisabledReminders,
                'created_via' => 'openai_assistant',
                'add_google_meet' => $addGoogleMeet,
                'start_datetime' => $startDateTime,
                'end_datetime' => $endDateTime,
                'metadata' => [
                    'source' => 'openai_function_call',
                    'user_timezone' => $userTz,
                    'confirmed_conflicts' => $confirmConflicts && !empty($conflicts)
                ]
            ];
            
            // Create the event using the service
            $result = $this->calendarCreateService->createEvent($user, $eventParams);
            $event = $result['event'] ?? null;
            
            if ($event) {
                // Format the response for OpenAI - display in user's timezone
                $startTimeLocal = $this->timezoneService->utcToUser($event->start_time, $userTz);
                $endTimeLocal = $this->timezoneService->utcToUser($event->end_time, $userTz);
                
                $response = [
                    'success' => true,
                    'event' => [
                        'id' => $event->id,
                        'title' => $event->title,
                        'start_utc' => Carbon::parse($event->start_time)->toIso8601String(),
                        'end_utc' => Carbon::parse($event->end_time)->toIso8601String(),
                        'start_local' => $startTimeLocal->format('c'),
                        'end_local' => $endTimeLocal->format('c'),
                        'location' => $event->location,
                        'is_all_day' => $event->is_all_day,
                        'calendar' => $event->calendar->name ?? 'Primary',
                        'created_at' => Carbon::parse($event->created_at)->toIso8601String(),
                        'user_timezone' => $userTz
                    ]
                ];
                
                // Add reminder info if available
                if ($event->reminder !== null) {
                    $response['event']['reminder_minutes'] = $event->reminder;
                    $response['event']['has_reminder'] = true;
                } else {
                    $response['event']['has_reminder'] = false;
                }
                
                // Add Google Meet link if available
                if ($event->metadata['has_google_meet'] ?? false) {
                    $response['event']['google_meet_link'] = $event->metadata['google_meet_link'] ?? null;
                    $response['google_meet_added'] = true;
                } else if ($addGoogleMeet) {
                    $response['google_meet_added'] = false;
                    $response['google_meet_error'] = 'Failed to add Google Meet link';
                }
                
                // Add recurrence info if available
                if ($event->recurrence) {
                    $response['event']['recurrence'] = $event->recurrence;
                }
                
                // Add attendees if available
                if (!empty($event->attendees)) {
                    $response['event']['attendees'] = $event->attendees;
                }
                
                // Add time conflicts if any were detected
                if (!empty($conflicts)) {
                    $formattedConflicts = $this->timeConflictService->formatConflictInfo($conflicts, $userTz);
                    $response['time_conflicts'] = $formattedConflicts;
                    $response['conflicts_confirmed'] = $confirmConflicts;
                    
                    // Create a human-readable message about the conflicts
                    if ($formattedConflicts['count'] > 0) {
                        $response['conflict_warning'] = "This event overlaps with {$formattedConflicts['count']} existing " . 
                            ($formattedConflicts['count'] == 1 ? "event" : "events") . " in your calendar.";
                    }
                }
                
                return $response;
            } else {
                $response = [
                    'success' => false,
                    'error' => 'Failed to create event',
                    'message' => isset($result['message']) ? $result['message'] : 'The event could not be created. Please check the parameters and try again.'
                ];
                
                // Add time conflicts if any were detected
                if (!empty($conflicts)) {
                    $formattedConflicts = $this->timeConflictService->formatConflictInfo($conflicts, $userTz);
                    $response['time_conflicts'] = $formattedConflicts;
                    
                    // Create a human-readable message about the conflicts
                    if ($formattedConflicts['count'] > 0) {
                        $response['conflict_warning'] = "This event would overlap with {$formattedConflicts['count']} existing " . 
                            ($formattedConflicts['count'] == 1 ? "event" : "events") . " in your calendar.";
                    }
                }
                
                if (isset($result['error'])) {
                    $response['error_details'] = $result['error'];
                }
                
                return $response;
            }
        } catch (\Exception $e) {
            Log::error('Error in calendar_create_event', [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'System error',
                'message' => 'An unexpected error occurred: ' . $e->getMessage()
            ];
        }
    }
}