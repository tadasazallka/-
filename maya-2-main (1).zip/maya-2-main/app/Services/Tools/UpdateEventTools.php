<?php

namespace App\Services\Tools;

use App\Models\Event;
use App\Models\User;
use App\Services\CalendarUpdateService;
use App\Services\PlanLimitService;
use App\Services\TimeConflictService;
use App\Services\TimezoneService;
use App\Services\Tools\ToolInterface;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class UpdateEventTools implements ToolInterface
{
    protected $calendarUpdateService;
    protected $planLimitService;
    protected $timeConflictService;
    protected $timezoneService;

    public function __construct(
        CalendarUpdateService $calendarUpdateService,
        PlanLimitService $planLimitService,
        TimeConflictService $timeConflictService,
        TimezoneService $timezoneService
    ) {
        $this->calendarUpdateService = $calendarUpdateService;
        $this->planLimitService = $planLimitService;
        $this->timeConflictService = $timeConflictService;
        $this->timezoneService = $timezoneService;
    }

    public function getName()
    {
        return 'calendar_update_event';
    }
    
    public function getDescription()
    {
        return 'Update an existing event in the user\'s calendar';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'event_id' => [
                    'type' => 'string',
                    'description' => 'ID of the event to update',
                ],
                'title' => [
                    'type' => 'string',
                    'description' => 'New title for the event',
                ],
                'start_time' => [
                    'type' => 'string',
                    'description' => 'Start time in ISO 8601 UTC format (e.g. "2025-05-15T10:00:00Z")',
                    'format' => 'date-time',
                ],
                'end_time' => [
                    'type' => 'string',
                    'description' => 'End time in ISO 8601 UTC format (e.g. "2025-05-15T11:00:00Z")',
                    'format' => 'date-time',
                ],
                'description' => [
                    'type' => 'string',
                    'description' => 'New description or notes for the event',
                ],
                'location' => [
                    'type' => 'string',
                    'description' => 'New location of the event',
                ],
                'attendees' => [
                    'type' => 'array',
                    'description' => 'New list of email addresses for attendees',
                    'items' => [
                        'type' => 'string',
                    ],
                ],
                'is_all_day' => [
                    'type' => 'boolean',
                    'description' => 'Whether this is an all-day event',
                ],
                'update_all_instances' => [
                    'type' => 'boolean',
                    'description' => 'For recurring events, whether to update all instances or just this one',
                ],
                'add_google_meet' => [
                    'type' => 'boolean',
                    'description' => 'Whether to add Google Meet conferencing to the event (only works with Google Calendar)',
                ],
                'confirm_conflicts' => [
                    'type' => 'boolean',
                    'description' => 'Whether to proceed with event update even if time conflicts are detected',
                ],
                'skip_conflict_check' => [
                    'type' => 'boolean',
                    'description' => 'Whether to skip time conflict detection entirely (useful for performance with free plans)',
                ],
            ],
            'required' => ['event_id'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            Log::info('Executing calendar_update_event', ['user_id' => $user->id, 'arguments' => $arguments]);
            
            // Get user timezone
            $userTz = $user->timezone ?? 'UTC';
            
            // Get the event
            $eventId = $arguments['event_id'];
            $event = Event::where('id', $eventId)
                ->where('user_id', $user->id)
                ->first();
            
            if (!$event) {
                return [
                    'success' => false,
                    'error' => 'Event not found',
                    'message' => 'The specified event could not be found'
                ];
            }
            
            // Parse start and end times directly in UTC
            $startDateTime = null;
            $endDateTime = null;
            $isAllDay = $arguments['is_all_day'] ?? $event->is_all_day;
            
            if (isset($arguments['start_time'])) {
                try {
                    // Parse ISO 8601 UTC input
                    $startDateTime = Carbon::parse($arguments['start_time'], 'UTC');
                    
                    Log::info('Parsed start time for update', [
                        'input' => $arguments['start_time'],
                        'parsed_utc' => $startDateTime->toIso8601String()
                    ]);
                    
                    // Check if the updated event time is in the past
                    $nowUtc = Carbon::now('UTC');
                    if ($startDateTime->lt($nowUtc)) {
                        Log::warning('Attempted to update event to a time in the past', [
                            'user_id' => $user->id,
                            'event_id' => $eventId,
                            'start_time' => $startDateTime->toIso8601String(),
                            'current_time' => $nowUtc->toIso8601String()
                        ]);
                        
                        return [
                            'success' => false,
                            'error' => 'Past date not allowed',
                            'message' => 'Cannot update events to times in the past. Please choose a future date and time.',
                            'current_time' => $nowUtc->toIso8601String(),
                            'requested_time' => $startDateTime->toIso8601String()
                        ];
                    }
                } catch (\Exception $e) {
                    Log::error('Failed to parse start time', [
                        'start_time' => $arguments['start_time'],
                        'error' => $e->getMessage()
                    ]);
                    
                    return [
                        'success' => false,
                        'error' => 'Invalid start time format',
                        'message' => 'Could not parse the start time. Please use ISO 8601 UTC format (e.g. "2025-05-15T10:00:00Z").'
                    ];
                }
            }
            
            if (isset($arguments['end_time'])) {
                try {
                    // Parse ISO 8601 UTC input
                    $endDateTime = Carbon::parse($arguments['end_time'], 'UTC');
                    
                    Log::info('Parsed end time for update', [
                        'input' => $arguments['end_time'],
                        'parsed_utc' => $endDateTime->toIso8601String()
                    ]);
                    
                    // Validate that the end time is after the start time
                    if ($startDateTime && $endDateTime->lte($startDateTime)) {
                        return [
                            'success' => false,
                            'error' => 'Invalid time range',
                            'message' => 'End time must be after start time.'
                        ];
                    }
                } catch (\Exception $e) {
                    Log::error('Failed to parse end time', [
                        'end_time' => $arguments['end_time'],
                        'error' => $e->getMessage()
                    ]);
                    
                    return [
                        'success' => false,
                        'error' => 'Invalid end time format',
                        'message' => 'Could not parse the end time. Please use ISO 8601 UTC format (e.g. "2025-05-15T11:00:00Z").'
                    ];
                }
            }
            
            // Special handling for all-day events
            if ($isAllDay && ($startDateTime || $endDateTime)) {
                // For all-day events, adjust times to full day boundaries in user's timezone
                if ($startDateTime) {
                    $userStartDate = $startDateTime->copy()->setTimezone($userTz)->startOfDay();
                    $startDateTime = $userStartDate->copy()->setTimezone('UTC');
                    
                    Log::info('Adjusted all-day event start time', [
                        'user_timezone' => $userTz,
                        'start_utc' => $startDateTime->toIso8601String()
                    ]);
                }
                
                if ($endDateTime) {
                    $userEndDate = $endDateTime->copy()->setTimezone($userTz)->endOfDay();
                    $endDateTime = $userEndDate->copy()->setTimezone('UTC');
                    
                    Log::info('Adjusted all-day event end time', [
                        'user_timezone' => $userTz,
                        'end_utc' => $endDateTime->toIso8601String()
                    ]);
                }
            }
            
            // Check for time conflicts if changing times and feature is enabled
            $conflicts = [];
            $skipConflictCheck = $arguments['skip_conflict_check'] ?? false;
            $confirmConflicts = $arguments['confirm_conflicts'] ?? false;
            $canUseTimeConflictDetection = $this->planLimitService->canUseTimeConflictDetection($user);
            
            if ($canUseTimeConflictDetection && !$skipConflictCheck && ($startDateTime || $endDateTime)) {
                $checkStartTime = $startDateTime ?: $event->start_time;
                $checkEndTime = $endDateTime ?: $event->end_time;
                
                $conflicts = $this->timeConflictService->checkTimeConflicts(
                    $user,
                    $checkStartTime,
                    $checkEndTime,
                    $event->id // Exclude the current event ID
                );
                
                Log::info('Time conflict check on update', [
                    'user_id' => $user->id,
                    'event_id' => $event->id,
                    'conflicts_found' => count($conflicts),
                    'confirm_conflicts' => $confirmConflicts
                ]);
                
                // If conflicts are found and not confirmed, return without updating the event
                if (!empty($conflicts) && !$confirmConflicts) {
                    $formattedConflicts = $this->timeConflictService->formatConflictInfo($conflicts, $userTz);
                    
                    // Return information about conflicts without updating the event
                    return [
                        'success' => false,
                        'requires_confirmation' => true,
                        'error' => 'Time conflicts detected',
                        'message' => "This update would create overlaps with {$formattedConflicts['count']} existing " . 
                            ($formattedConflicts['count'] == 1 ? "event" : "events") . " in your calendar. Please confirm if you want to proceed.",
                        'time_conflicts' => $formattedConflicts,
                        'requested_time_range' => [
                            'start' => $checkStartTime->toIso8601String(),
                            'end' => $checkEndTime->toIso8601String(),
                            'timezone' => 'UTC'
                        ],
                        'event_id' => $event->id,
                        'event_title' => $event->title
                    ];
                }
            }
            
            // Automatically enable Google Meet if user's plan allows it
            $canUseGoogleMeetLinks = $this->planLimitService->canUseGoogleMeetLinks($user);
            $isGoogleCalendar = $event->calendar && $event->calendar->provider === 'google';
            $addGoogleMeet = false;
            
            // Only add Google Meet if explicitly requested OR if user's plan allows it (and it's not explicitly disabled)
            // Also check if the calendar is Google Calendar as Meet only works with Google
            if ((isset($arguments['add_google_meet']) && $arguments['add_google_meet'] === true) || 
                ($canUseGoogleMeetLinks && $isGoogleCalendar && (!isset($arguments['add_google_meet']) || $arguments['add_google_meet'] !== false))) {
                
                if ($canUseGoogleMeetLinks && $isGoogleCalendar) {
                    Log::info('Automatically adding Google Meet for event update (user has access to feature)', ['user_id' => $user->id]);
                    $addGoogleMeet = true;
                } else {
                    Log::info('Cannot add Google Meet for this update', [
                        'user_id' => $user->id,
                        'has_feature' => $canUseGoogleMeetLinks,
                        'is_google_calendar' => $isGoogleCalendar
                    ]);
                }
            }
            
            // Prepare parameters for the calendar service
            $updateParams = [
                'event_id' => $eventId,
                'update_all_instances' => $arguments['update_all_instances'] ?? false,
                'add_google_meet' => $addGoogleMeet,
                'is_all_day' => $isAllDay
            ];
            
            // Only add fields that are being updated
            if (isset($arguments['title'])) {
                $updateParams['title'] = $arguments['title'];
            }
            
            if (isset($arguments['description'])) {
                $updateParams['description'] = $arguments['description'];
            }
            
            if (isset($arguments['location'])) {
                $updateParams['location'] = $arguments['location'];
            }
            
            if (isset($arguments['attendees'])) {
                $updateParams['attendees'] = $arguments['attendees'];
            }
            
            // Add the datetime objects if available
            if ($startDateTime) {
                $updateParams['start_datetime'] = $startDateTime;
            }
            
            if ($endDateTime) {
                $updateParams['end_datetime'] = $endDateTime;
            }
            
            // Update user timezone in event metadata
            if (!isset($updateParams['metadata'])) {
                $updateParams['metadata'] = [];
            }
            
            $updateParams['metadata']['user_timezone'] = $userTz;
            $updateParams['metadata']['confirmed_conflicts'] = $confirmConflicts && !empty($conflicts);
            
            // If we have new start/end times, store the user's local time in metadata
            if ($startDateTime) {
                $updateParams['metadata']['user_local_start_time'] = $startDateTime->copy()->setTimezone($userTz)->toIso8601String();
            }
            
            if ($endDateTime) {
                $updateParams['metadata']['user_local_end_time'] = $endDateTime->copy()->setTimezone($userTz)->toIso8601String();
            }
            
            // Use a calendar update service to update the event
            $updatedEvent = $this->calendarUpdateService->updateEvent($user, $updateParams);
            
            if ($updatedEvent) {
                // Format the response for OpenAI - convert times to user's timezone
                $startTimeLocal = $updatedEvent->start_time->copy()->setTimezone($userTz);
                $endTimeLocal = $updatedEvent->end_time->copy()->setTimezone($userTz);
                $updatedAtLocal = $updatedEvent->updated_at->copy()->setTimezone($userTz);
                
                $response = [
                    'success' => true,
                    'event' => [
                        'id' => $updatedEvent->id,
                        'title' => $updatedEvent->title,
                        'start_utc' => $updatedEvent->start_time->toIso8601String(),
                        'end_utc' => $updatedEvent->end_time->toIso8601String(),
                        'start_local' => $startTimeLocal->toIso8601String(),
                        'end_local' => $endTimeLocal->toIso8601String(),
                        'location' => $updatedEvent->location,
                        'is_all_day' => $updatedEvent->is_all_day,
                        'updated_at' => $updatedAtLocal->toIso8601String(),
                        'user_timezone' => $userTz
                    ]
                ];
                
                // Add Google Meet link if available
                if ($updatedEvent->metadata['has_google_meet'] ?? false) {
                    $response['event']['google_meet_link'] = $updatedEvent->metadata['google_meet_link'] ?? null;
                    $response['google_meet_added'] = true;
                } else if ($addGoogleMeet) {
                    $response['google_meet_added'] = false;
                    $response['google_meet_error'] = 'Failed to add Google Meet link';
                }
                
                // Add attendees if available
                if (!empty($updatedEvent->attendees)) {
                    $response['event']['attendees'] = $updatedEvent->attendees;
                }
                
                // Add time conflicts if any were detected and were confirmed
                if (!empty($conflicts)) {
                    $formattedConflicts = $this->timeConflictService->formatConflictInfo($conflicts, $userTz);
                    $response['time_conflicts'] = $formattedConflicts;
                    $response['conflicts_confirmed'] = $confirmConflicts;
                    
                    // Create a human-readable message about the conflicts
                    if ($formattedConflicts['count'] > 0) {
                        $response['conflict_warning'] = "This event now overlaps with {$formattedConflicts['count']} existing " . 
                            ($formattedConflicts['count'] == 1 ? "event" : "events") . " in your calendar.";
                    }
                }
                
                return $response;
            } else {
                $response = [
                    'success' => false,
                    'error' => 'Failed to update event',
                    'message' => 'The event could not be updated. Please check the parameters and try again.'
                ];
                
                // Add time conflicts if any were detected
                if (!empty($conflicts)) {
                    $formattedConflicts = $this->timeConflictService->formatConflictInfo($conflicts, $userTz);
                    $response['time_conflicts'] = $formattedConflicts;
                    
                    // Create a human-readable message about the conflicts
                    if ($formattedConflicts['count'] > 0) {
                        $response['conflict_warning'] = "This event would overlap with {$formattedConflicts['count']} existing " . 
                            ($formattedConflicts['count'] == 1 ? "event" : "events") . " in your calendar.";
                    }
                }
                
                return $response;
            }
        } catch (\Exception $e) {
            Log::error('Error in calendar_update_event', [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'System error',
                'message' => 'An unexpected error occurred: ' . $e->getMessage()
            ];
        }
    }
}