<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Services\Tools\ToolInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

/**
 * Web Search Tool - Searches the web for information using Serper API
 */
class WebSearchTools implements ToolInterface
{
    protected $apiKey;
    protected $baseUrl = 'https://google.serper.dev';
    
    public function __construct()
    {
        $this->apiKey = config('services.serper.api_key');
    }
    
    public function getName()
    {
        return 'web_search';
    }
    
    public function getDescription()
    {
        return 'Search the web for information on any topic';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'query' => [
                    'type' => 'string',
                    'description' => 'The search query',
                ],
                'num_results' => [
                    'type' => 'integer',
                    'description' => 'Number of search results to return',
                    'default' => 5,
                ],
                'search_type' => [
                    'type' => 'string',
                    'description' => 'Type of search to perform',
                    'enum' => ['web', 'news', 'image'],
                    'default' => 'web',
                ],
                'time_range' => [
                    'type' => 'string',
                    'description' => 'Time range for search results',
                    'enum' => ['all', 'day', 'week', 'month', 'year'],
                    'default' => 'all',
                ],
                'region' => [
                    'type' => 'string',
                    'description' => 'Geographic region for search results',
                    'default' => 'us',
                ],
                'safe_search' => [
                    'type' => 'boolean',
                    'description' => 'Whether to enable safe search filtering',
                    'default' => true,
                ],
                'include_snippets' => [
                    'type' => 'boolean',
                    'description' => 'Whether to include content snippets with search results',
                    'default' => true,
                ],
            ],
            'required' => ['query'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            // Extract search parameters
            $query = $arguments['query'];
            $numResults = $arguments['num_results'] ?? 5;
            $searchType = $arguments['search_type'] ?? 'web';
            $timeRange = $arguments['time_range'] ?? 'all';
            $region = $arguments['region'] ?? 'us';
            $safeSearch = $arguments['safe_search'] ?? true;
            
            // Create cache key
            $cacheKey = "search:{$searchType}:{$query}:{$numResults}:{$timeRange}:{$region}:" . ($safeSearch ? 'safe' : 'unsafe');
            
            // Check if we have cached results
            if (Cache::has($cacheKey)) {
                Log::info('Returning cached search results', ['query' => $query]);
                return Cache::get($cacheKey);
            }
            
            // Log the search request
            Log::info('Performing web search', [
                'user_id' => $user->id,
                'query' => $query,
                'search_type' => $searchType
            ]);
            
            $endpoint = "/search";
            
            if ($searchType === 'news') {
                $endpoint = "/news";
            } elseif ($searchType === 'image') {
                $endpoint = "/images";
            }
            
            // Set up request payload
            $payload = [
                'q' => $query,
                'gl' => $region,
                'num' => $numResults
            ];
            
            // Add time range if not 'all'
            if ($timeRange !== 'all') {
                $payload['tbs'] = $this->mapTimeRange($timeRange);
            }
            
            // Add safe search if required
            if ($safeSearch) {
                $payload['safe'] = 'active';
            }
            
            // Make the API request
            $response = Http::withHeaders([
                'X-API-KEY' => $this->apiKey,
                'Content-Type' => 'application/json'
            ])->post("{$this->baseUrl}{$endpoint}", $payload);
            
            if ($response->failed()) {
                Log::error('Search API error', [
                    'status' => $response->status(),
                    'response' => $response->body()
                ]);
                
                return [
                    'success' => false,
                    'error' => 'Failed to perform search. Please try again later.',
                    'status' => $response->status()
                ];
            }
            
            $data = $response->json();
            $processedResults = $this->processSearchResults($data, $searchType, $arguments['include_snippets'] ?? true);
            
            // Cache the results for 1 hour
            Cache::put($cacheKey, $processedResults, 3600);
            
            return $processedResults;
            
        } catch (\Exception $e) {
            Log::error('Error in web search', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'An error occurred while performing the search: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Process and normalize search results based on search type
     */
    protected function processSearchResults(array $data, string $searchType, bool $includeSnippets)
    {
        $result = [
            'success' => true,
            'total_results' => $data['searchInformation']['totalResults'] ?? 'Unknown'
        ];
        
        $processed = [];
        
        if ($searchType === 'web') {
            $items = $data['organic'] ?? [];
            foreach ($items as $item) {
                $entry = [
                    'title' => $item['title'] ?? 'Untitled',
                    'url' => $item['link'] ?? '',
                ];
                
                if ($includeSnippets) {
                    $entry['snippet'] = $item['snippet'] ?? '';
                }
                
                if (isset($item['date'])) {
                    $entry['date_published'] = $item['date'];
                }
                
                $processed[] = $entry;
            }
        } elseif ($searchType === 'news') {
            $items = $data['news'] ?? [];
            foreach ($items as $item) {
                $entry = [
                    'title' => $item['title'] ?? 'Untitled',
                    'url' => $item['link'] ?? '',
                    'source' => $item['source'] ?? 'Unknown',
                ];
                
                if ($includeSnippets) {
                    $entry['snippet'] = $item['snippet'] ?? '';
                }
                
                if (isset($item['date'])) {
                    $entry['date_published'] = $item['date'];
                }
                
                $processed[] = $entry;
            }
        } else { // image search
            $items = $data['images'] ?? [];
            foreach ($items as $item) {
                $entry = [
                    'title' => $item['title'] ?? 'Untitled',
                    'url' => $item['imageUrl'] ?? '',
                    'thumbnail_url' => $item['thumbnailUrl'] ?? '',
                    'source_website' => $item['source'] ?? 'Unknown',
                ];
                
                if (isset($item['imageWidth']) && isset($item['imageHeight'])) {
                    $entry['image_size'] = "{$item['imageWidth']}x{$item['imageHeight']}";
                }
                
                $processed[] = $entry;
            }
        }
        
        $result['results'] = $processed;
        return $result;
    }
    
    /**
     * Map time range values to Google search parameters
     */
    protected function mapTimeRange(string $timeRange)
    {
        switch ($timeRange) {
            case 'day':
                return 'qdr:d';
            case 'week':
                return 'qdr:w';
            case 'month':
                return 'qdr:m';
            case 'year':
                return 'qdr:y';
            default:
                return '';
        }
    }
}