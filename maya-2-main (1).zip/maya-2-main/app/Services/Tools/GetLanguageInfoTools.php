<?php

namespace App\Services\Tools;

use App\Models\User;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;

class GetLanguageInfoTools implements ToolInterface
{
    // Redis constants
    const METADATA_TTL = 3600; // 1 hour
    
    public function getName()
    {
        return 'get_language_info';
    }
    
    public function getDescription()
    {
        return 'Get the user\'s current language preferences and settings';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => (object)[], // Cast to object to ensure it's {} and not []
            'required' => []
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            Log::info('Getting language information', ['user_id' => $user->id]);
            
            // Standard language codes to names mapping
            $languageNames = [
                'en' => 'English',
                // 'es' => 'Spanish',
                // 'fr' => 'French',
                // 'de' => 'German',
                // 'it' => 'Italian',
                // 'pt' => 'Portuguese',
                // 'ru' => 'Russian',
                // 'ja' => 'Japanese',
                // 'zh' => 'Chinese',
                // 'ko' => 'Korean',
                // 'ar' => 'Arabic',
                // 'hi' => 'Hindi',
                'ur' => 'Urdu',
                'he' => 'Hebrew'
            ];
            
            // Get metadata from Redis
            $metadata = $this->getConversationMetadata($user->id);
            
            // Get preferred language from metadata or user preferences
            $preferredLanguage = $metadata['preferred_language'] ?? null;
            
            if (!$preferredLanguage && isset($user->preferences->language)) {
                $preferredLanguage = $user->preferences->language;
                $this->updateMetadataField($user->id, 'preferred_language', $preferredLanguage);
            }
            
            // Get auto-detect setting
            $autoDetect = $metadata['language_auto_detect'] ?? null;
            
            if ($autoDetect === null && isset($user->preferences->language_auto_detect)) {
                $autoDetect = $user->preferences->language_auto_detect ? 'true' : 'false';
                $this->updateMetadataField($user->id, 'language_auto_detect', $autoDetect);
            } else if ($autoDetect === null) {
                // Default to true if not set
                $autoDetect = 'true';
                $this->updateMetadataField($user->id, 'language_auto_detect', $autoDetect);
            }
            
            // Get detected language if available
            $detectedLanguage = $metadata['detected_language'] ?? null;
            
            return [
                'success' => true,
                'language_settings' => [
                    'preferred_language' => [
                        'code' => $preferredLanguage,
                        'name' => $preferredLanguage ? ($languageNames[$preferredLanguage] ?? 'Unknown') : null
                    ],
                    'auto_detect' => $autoDetect === 'true',
                    'detected_language' => [
                        'code' => $detectedLanguage,
                        'name' => $detectedLanguage ? ($languageNames[$detectedLanguage] ?? 'Unknown') : null
                    ],
                    'supported_languages' => array_map(function($code, $name) {
                        return ['code' => $code, 'name' => $name];
                    }, array_keys($languageNames), $languageNames)
                ]
            ];
        } catch (\Exception $e) {
            Log::error('Error getting language information', [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'System error',
                'message' => 'An unexpected error occurred: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Get all conversation metadata from Redis
     */
    private function getConversationMetadata(int $userId): array
    {
        try {
            $redisKey = "conversation:{$userId}:meta";
            $metadata = Redis::hgetall($redisKey) ?: [];
            
            Log::debug('Retrieved conversation metadata', [
                'user_id' => $userId,
                'metadata' => $metadata
            ]);
            
            return $metadata;
        } catch (\Exception $e) {
            Log::error("Failed to get metadata: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Update a field in the user's conversation metadata in Redis
     */
    private function updateMetadataField(int $userId, string $field, $value): void
    {
        try {
            $redisKey = "conversation:{$userId}:meta";
            
            // Update the specific field
            Redis::hset($redisKey, $field, $value);
            
            // Set expiration if new key
            if (Redis::ttl($redisKey) < 0) {
                Redis::expire($redisKey, self::METADATA_TTL);
            }
            
            Log::info("Updated metadata for user", [
                'user_id' => $userId,
                'field' => $field,
                'value' => $value
            ]);
        } catch (\Exception $e) {
            Log::error("Failed to update metadata: " . $e->getMessage());
        }
    }
}