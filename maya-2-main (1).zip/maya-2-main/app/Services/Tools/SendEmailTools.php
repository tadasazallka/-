<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Models\ScheduledEmail;
use App\Services\Gmail\GmailService;
use App\Services\TimezoneService;
use Google_Service_Gmail_Message;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class SendEmailTools implements ToolInterface
{
    protected $gmailService;
    protected $timezoneService;
    
    public function __construct(GmailService $gmailService, TimezoneService $timezoneService)
    {
        $this->gmailService = $gmailService;
        $this->timezoneService = $timezoneService;
    }
    
    public function getName()
    {
        return 'gmail_send_email';
    }
    
    public function getDescription()
    {
        return 'Compose and send an email from the user\'s Gmail account, or create a new scheduled email. For managing existing scheduled emails, use scheduled_email_tools instead.';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'to' => [
                    'type' => 'string',
                    'description' => 'Recipient email address(es), comma-separated for multiple',
                ],
                'cc' => [
                    'type' => 'string',
                    'description' => 'CC recipient email address(es), comma-separated for multiple',
                ],
                'bcc' => [
                    'type' => 'string',
                    'description' => 'BCC recipient email address(es), comma-separated for multiple',
                ],
                'subject' => [
                    'type' => 'string',
                    'description' => 'Email subject line',
                ],
                'body' => [
                    'type' => 'string',
                    'description' => 'Email body content',
                ],
                'html_body' => [
                    'type' => 'boolean',
                    'description' => 'Whether the body content is HTML formatted',
                    'default' => false,
                ],
                'attachments' => [
                    'type' => 'array',
                    'description' => 'List of attachment IDs to include',
                    'items' => [
                        'type' => 'string',
                    ],
                ],
                'schedule_send' => [
                    'type' => 'string',
                    'description' => 'Schedule the email to be sent at a specified time in ISO 8601 UTC format (e.g. "2025-05-15T10:00:00Z"). This only creates a new scheduled email. To update an existing scheduled email, use the scheduled_email_tools.',
                    'format' => 'date-time',
                ],
                'importance' => [
                    'type' => 'string',
                    'description' => 'Set importance level of the email',
                    'enum' => ['low', 'normal', 'high'],
                    'default' => 'normal',
                ],
            ],
            'required' => ['to', 'subject', 'body'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        Log::info('sendemailtools received arguments', [
            'user_id' => $user->id,
            'all_arguments' => $arguments,
            'has_schedule_send' => isset($arguments['schedule_send']),
            'schedule_send_value' => $arguments['schedule_send'] ?? 'not set'
        ]);
        
        try {
            // Check if the user has an active Gmail account
            if (!$user->gmailAccount || !$user->gmailAccount->is_active) {
                return [
                    'success' => false,
                    'error' => 'No active Gmail account found for this user',
                    'call_to_action' => 'User can connect the Gmail account from Maya dashboard'
                ];
            }
            
            // Check if recipient email address is provided
            if (!isset($arguments['to']) || empty(trim($arguments['to']))) {
                return [
                    'success' => false,
                    'error' => 'Missing recipient email address',
                    'message' => 'Please provide a recipient email address to send the email',
                    'requires_email_address' => true
                ];
            }
            
            // Validate email addresses
            if (!$this->validateEmailAddresses($arguments['to'])) {
                return [
                    'success' => false,
                    'error' => 'Invalid recipient email address format',
                    'message' => 'The recipient email address format is invalid. Please check and try again.',
                    'requires_valid_email' => true
                ];
            }
            
            if (isset($arguments['cc']) && !empty($arguments['cc']) && !$this->validateEmailAddresses($arguments['cc'])) {
                return [
                    'success' => false,
                    'error' => 'Invalid CC email address format',
                    'message' => 'One or more CC email addresses are invalid. Please check and try again.',
                    'requires_valid_email' => true
                ];
            }
            
            if (isset($arguments['bcc']) && !empty($arguments['bcc']) && !$this->validateEmailAddresses($arguments['bcc'])) {
                return [
                    'success' => false,
                    'error' => 'Invalid BCC email address format',
                    'message' => 'One or more BCC email addresses are invalid. Please check and try again.',
                    'requires_valid_email' => true
                ];
            }
            
            // Get Gmail service
            $service = $this->gmailService->getGmailService($user);
            
            // Create email message
            $to = $arguments['to'];
            $subject = $arguments['subject'];
            $body = $arguments['body'];
            $isHtml = $arguments['html_body'] ?? false;
            
            // Build email headers as an array
            $headers = [
                'From' => $user->gmailAccount->email,
                'To' => $to,
                'Subject' => $subject,
            ];
            
            if (isset($arguments['cc']) && !empty($arguments['cc'])) {
                $headers['Cc'] = $arguments['cc'];
            }
            
            if (isset($arguments['bcc']) && !empty($arguments['bcc'])) {
                $headers['Bcc'] = $arguments['bcc'];
            }
            
            // Set importance if specified
            if (isset($arguments['importance']) && $arguments['importance'] !== 'normal') {
                if ($arguments['importance'] === 'high') {
                    $headers['Importance'] = 'High';
                    $headers['X-Priority'] = '1';
                } else {
                    $headers['Importance'] = 'Low';
                    $headers['X-Priority'] = '5';
                }
            }
            
            // Check if scheduled send
            if (isset($arguments['schedule_send']) && !empty($arguments['schedule_send'])) {
                try {
                    // Parse ISO 8601 UTC input directly
                    $scheduledTimeInUTC = Carbon::parse($arguments['schedule_send'], 'UTC');
                    
                    // Get current time in UTC
                    $nowUTC = Carbon::now('UTC');
                    
                    // Check if scheduled time is in the future
                    if ($scheduledTimeInUTC->lte($nowUTC)) {
                        return [
                            'success' => false,
                            'error' => 'Scheduled time must be in the future',
                            'message' => 'You cannot schedule an email to be sent in the past. The scheduled time must be in the future.',
                            'current_time' => $nowUTC->toIso8601String(),
                            'requested_time' => $scheduledTimeInUTC->toIso8601String()
                        ];
                    }
                    
                    // For display purposes, convert to user's timezone
                    $userTimezone = $user->timezone ?? 'UTC';
                    $scheduledTimeInUserTz = $scheduledTimeInUTC->copy()->setTimezone($userTimezone);
                    
                    Log::info('Scheduling email', [
                        'user_timezone' => $userTimezone,
                        'scheduled_time_utc' => $scheduledTimeInUTC->toIso8601String(),
                        'scheduled_time_user_tz' => $scheduledTimeInUserTz->toIso8601String(),
                        'headers_type' => gettype($headers)
                    ]);
                    
                    // Create scheduled email record with UTC time for database and headers as array
                    $scheduledEmail = ScheduledEmail::create([
                        'user_id' => $user->id,
                        'to' => $arguments['to'],
                        'cc' => $arguments['cc'] ?? null,
                        'bcc' => $arguments['bcc'] ?? null,
                        'subject' => $arguments['subject'],
                        'body' => $arguments['body'],
                        'is_html' => $isHtml,
                        'headers' => $headers, // Store headers as array - model will handle casting
                        'scheduled_for' => $scheduledTimeInUTC, // Store in UTC
                        'status' => 'pending'
                    ]);
                    
                    return [
                        'success' => true,
                        'message' => 'Email scheduled for sending',
                        'scheduled_for_utc' => $scheduledTimeInUTC->toIso8601String(),
                        'scheduled_for_local' => $scheduledTimeInUserTz->toIso8601String(),
                        'scheduled_for_display' => $scheduledTimeInUserTz->format('Y-m-d H:i:s') . ' (' . $userTimezone . ')',
                        'scheduled_id' => $scheduledEmail->id,
                        'subject' => $arguments['subject'],
                        'to' => $arguments['to'],
                        'note' => 'To update this scheduled email, use the scheduled_email_tools with the provided scheduled_id.'
                    ];
                } catch (\Exception $e) {
                    Log::error('Error scheduling email: ' . $e->getMessage(), [
                        'exception' => $e->getMessage(),
                        'trace' => $e->getTraceAsString()
                    ]);
                    return [
                        'success' => false,
                        'error' => 'Invalid schedule_send date format. Please use ISO 8601 UTC format (e.g. "2025-05-15T10:00:00Z")',
                        'details' => $e->getMessage()
                    ];
                }
            }
            
            // Create email for immediate sending
            $encodedEmail = $this->gmailService->createEmailRaw($headers, $body, $isHtml);
            
            // Create a message object
            $message = new Google_Service_Gmail_Message();
            $message->setRaw($encodedEmail);
            
            // Send email
            $sent = $service->users_messages->send('me', $message);
            
            return [
                'success' => true,
                'message_id' => $sent->getId(),
                'sent_to' => $arguments['to'],
                'subject' => $arguments['subject'],
                'timestamp' => Carbon::now()->toIso8601String(),
                'scheduled' => false,
            ];
        } catch (\Exception $e) {
            Log::error('Error sending email: ' . $e->getMessage(), [
                'user_id' => $user->id,
                'arguments' => $arguments,
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'Failed to send email: ' . $e->getMessage(),
            ];
        }
    }
    
    /**
     * Validate email address format
     * 
     * @param string $emails Comma-separated list of email addresses
     * @return bool True if all email addresses are valid
     */
    private function validateEmailAddresses($emails)
    {
        $emailList = explode(',', $emails);
        
        foreach ($emailList as $email) {
            $email = trim($email);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return false;
            }
        }
        
        return true;
    }
}