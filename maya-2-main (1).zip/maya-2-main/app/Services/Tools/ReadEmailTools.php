<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Services\Gmail\GmailService;
use Illuminate\Support\Facades\Log;

class ReadEmailTools implements ToolInterface
{
    protected $gmailService;
    
    public function __construct(GmailService $gmailService)
    {
        $this->gmailService = $gmailService;
    }
    
    public function getName()
    {
        return 'gmail_read_emails';
    }
    
    public function getDescription()
    {
        return 'Retrieve and read emails from the user\'s Gmail account';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'label' => [
                    'type' => 'string',
                    'description' => 'Gmail label to read emails from (e.g., "INBOX", "SENT", "TRASH")',
                    'default' => 'INBOX',
                ],
                'max_results' => [
                    'type' => 'integer',
                    'description' => 'Maximum number of emails to retrieve',
                    'default' => 5, // Changed from 10 to 5
                ],
                'read_status' => [
                    'type' => 'string',
                    'description' => 'Filter by read status: "read", "unread", or "all"',
                    'enum' => ['read', 'unread', 'all'],
                    'default' => 'all',
                ],
                // 'include_attachments' => [
                //     'type' => 'boolean',
                //     'description' => 'Whether to include attachment information',
                //     'default' => false,
                // ],
                'order_by' => [
                    'type' => 'string',
                    'description' => 'How to order the emails: "date", "from", "subject"',
                    'enum' => ['date', 'from', 'subject'],
                    'default' => 'date',
                ],
                'sort_direction' => [
                    'type' => 'string',
                    'description' => 'Sort direction: "asc" or "desc"',
                    'enum' => ['asc', 'desc'],
                    'default' => 'desc',
                ],
                'email_id' => [
                    'type' => 'string',
                    'description' => 'Specific email ID to read (if you want just one email)',
                ],
            ],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            // Check if the user has an active Gmail account
            if (!$user->gmailAccount || !$user->gmailAccount->is_active) {
                return [
                    'success' => false,
                    'error' => 'No active Gmail account found for this user',
                    'call to action' => 'User can connect the gmail account from maya dashboard'
                ];
            }
            
            $service = $this->gmailService->getGmailService($user);
            
            // If email_id is provided, get a single email
            if (isset($arguments['email_id'])) {
                try {
                    $message = $service->users_messages->get('me', $arguments['email_id'], ['format' => 'full']);
                    
                    // Check if we need to mark as read
                    $includeBody = true;
                    
                    return [
                        'success' => true,
                        'email' => $this->gmailService->parseMessage($message, $includeBody),
                    ];
                } catch (\Exception $e) {
                    return [
                        'success' => false,
                        'error' => 'Email not found or cannot be accessed: ' . $e->getMessage(),
                    ];
                }
            }
            
            // Build query for listing emails
            $query = [];
            $label = $arguments['label'] ?? 'INBOX';
            $maxResults = min($arguments['max_results'] ?? 5, 15); // Changed from 50 to 15 maximum
            
            // Add read status to query if specified
            if (isset($arguments['read_status']) && $arguments['read_status'] !== 'all') {
                if ($arguments['read_status'] === 'read') {
                    $query[] = 'is:read';
                } else {
                    $query[] = 'is:unread';
                }
            }
            
            // Handle ordering
            $orderBy = $arguments['order_by'] ?? 'date';
            if ($orderBy === 'date') {
                // For date, we use Gmail's built-in sorting
                $orderBy = null;
            }
            
            $options = [
                'q' => implode(' ', $query),
                'maxResults' => $maxResults,
                'labelIds' => [$label],
            ];
            
            // List messages
            $messageList = $service->users_messages->listUsersMessages('me', $options);
            $messages = $messageList->getMessages();
            
            $emails = [];
            $totalCount = 0;
            
            if ($messageList->getResultSizeEstimate() > 0) {
                $totalCount = $messageList->getResultSizeEstimate();
                
                foreach ($messages as $message) {
                    $includeAttachments = $arguments['include_attachments'] ?? false;
                    $format = $includeAttachments ? 'full' : 'metadata';
                    
                    $fullMessage = $service->users_messages->get('me', $message->getId(), ['format' => $format]);
                    $emails[] = $this->gmailService->parseMessage($fullMessage, false);
                }
                
                // Custom sorting if needed
                if ($orderBy && $orderBy !== 'date') {
                    if ($orderBy === 'from') {
                        usort($emails, function($a, $b) {
                            return strcmp($a['from'], $b['from']);
                        });
                    } elseif ($orderBy === 'subject') {
                        usort($emails, function($a, $b) {
                            return strcmp($a['subject'], $b['subject']);
                        });
                    }
                    
                    // Apply sort direction
                    if (($arguments['sort_direction'] ?? 'desc') === 'desc') {
                        $emails = array_reverse($emails);
                    }
                }
            }
            
            return [
                'success' => true,
                'label' => $label,
                'total_emails' => $totalCount,
                'emails' => $emails,
                'showing' => count($emails),
                'has_more' => ($totalCount > count($emails)),
            ];
        } catch (\Exception $e) {
            Log::error('Error reading emails: ' . $e->getMessage(), [
                'user_id' => $user->id,
                'arguments' => $arguments,
            ]);
            
            return [
                'success' => false,
                'error' => 'Failed to read emails: ' . $e->getMessage(),
            ];
        }
    }
}