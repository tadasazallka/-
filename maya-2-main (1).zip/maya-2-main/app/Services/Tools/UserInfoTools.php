<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Models\FeatureUsage;
use Illuminate\Support\Facades\Log;

class UserInfoTools implements ToolInterface
{
    public function getName()
    {
        return 'get_user_info';
    }
    
    public function getDescription()
    {
        return 'Get comprehensive information about the user including their plan, connected services, and preferences';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'info_type' => [
                    'type' => 'string',
                    'description' => 'Type of user information to retrieve',
                    'enum' => ['all', 'plan', 'connections', 'preferences', 'usage'],
                    'default' => 'all',
                ],
            ],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            $infoType = $arguments['info_type'] ?? 'all';
            $result = [
                'success' => true,
                'user_id' => $user->id,
                'name' => $user->name,
                'timezone' => $user->timezone,
                'is_signed_up' => (bool) $user->is_signed_up,
                'whatsapp_id' => $user->whatsapp_id
            ];
            
            // Get plan information
            if ($infoType === 'all' || $infoType === 'plan') {
                $this->addPlanInformation($result, $user);
            }
            
            // Get connected services information
            if ($infoType === 'all' || $infoType === 'connections') {
                $this->addConnectionsInformation($result, $user);
            }
            
            // Get user preferences
            if ($infoType === 'all' || $infoType === 'preferences') {
                $this->addPreferencesInformation($result, $user);
            }
            
            // Get usage statistics
            if ($infoType === 'all' || $infoType === 'usage') {
                $this->addUsageInformation($result, $user);
            }
            
            return $result;
        } catch (\Exception $e) {
            Log::error('Error getting user info: ' . $e->getMessage(), [
                'user_id' => $user->id,
                'arguments' => $arguments,
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'Failed to get user information: ' . $e->getMessage(),
            ];
        }
    }
    
    /**
     * Add plan information to result
     */
    private function addPlanInformation(&$result, User $user)
    {
        // Get current plan
        $currentPlan = $user->currentPlan();
        $activeSubscription = $user->activeSubscription();
        
        $result['plan'] = [
            'type' => $currentPlan->slug,
            'name' => $currentPlan ? $currentPlan->name : 'Free',
            'slug' => $currentPlan ? $currentPlan->slug : 'free',
            'is_premium' => $user->isPremium(),
            'has_active_subscription' => $user->hasActiveSubscription(),
            'on_trial' => $activeSubscription ? $activeSubscription->onTrial() : false,
            'expires_at' => $activeSubscription && $activeSubscription->ends_at ? $activeSubscription->ends_at->format('Y-m-d H:i:s') : null,
        ];
        
        // Add feature permissions based on plan
        $result['plan']['features'] = $currentPlan ? $currentPlan->features : [
            'create_events' => true,
            'view_events' => true,
            'update_events' => true,
            'delete_events' => true,
            'create_events_via_text_voice_image' => true,
            'web_search' => true,
            'gmail_integration' => false,
            'schedule_emails' => false,
            'events_per_day' => 5,
            'emails_per_day' => 0,
            'searches_per_day' => 10,
        ];
        
        // Add permissions based on feature availability
        $result['plan']['permissions'] = [
            'can_create_events' => $user->canUseFeature('events_per_week'),
            'can_use_gmail' => $user->canUseFeature('gmail_integration') && $user->gmailAccount && $user->gmailAccount->is_active,
            'can_use_web_search' => $user->canUseFeature('web_search'),
            'max_events_per_week' => $currentPlan ? $currentPlan->getFeatureLimit('events_per_week') : 5,
            'max_whatsapp_reminders' => $currentPlan ? $currentPlan->getFeatureLimit('whatsapp_reminders') : 3,
        ];
    }
    
    /**
     * Add connections information to result
     */
    private function addConnectionsInformation(&$result, User $user)
    {
        // Gmail account information
        $gmailAccount = $user->gmailAccount;
        $result['connections']['gmail'] = [
            'connected' => $gmailAccount ? true : false,
            'email' => $gmailAccount ? $gmailAccount->email : null,
            'is_active' => $gmailAccount ? (bool) $gmailAccount->is_active : false,
            'token_expired' => $gmailAccount ? $gmailAccount->isTokenExpired() : null,
        ];
        
        // Calendar accounts and connections
        $calendarAccounts = $user->calendarAccounts()->with('calendars')->get();
        $result['connections']['calendar_accounts'] = [];
        
        foreach ($calendarAccounts as $account) {
            $accountInfo = [
                'id' => $account->id,
                'provider' => $account->provider,
                'is_active' => (bool) $account->is_active,
                'calendars' => []
            ];
            
            // Add connected calendars for this account
            foreach ($account->calendars as $calendar) {
                $accountInfo['calendars'][] = [
                    'id' => $calendar->id,
                    'name' => $calendar->name,
                    'is_primary' => (bool) $calendar->is_primary,
                    'is_active' => (bool) $calendar->is_active,
                    'color' => $calendar->color,
                ];
            }
            
            $result['connections']['calendar_accounts'][] = $accountInfo;
        }
        
        // Get default calendar
        $defaultCalendar = $user->getOrCreateDefaultCalendar();
        $result['connections']['default_calendar'] = [
            'id' => $defaultCalendar->id,
            'name' => $defaultCalendar->name,
            'is_primary' => (bool) $defaultCalendar->is_primary,
            'is_active' => (bool) $defaultCalendar->is_active,
        ];
        
        // Get primary calendar
        $primaryCalendar = $user->primaryCalendar;
        $result['connections']['primary_calendar'] = $primaryCalendar ? [
            'id' => $primaryCalendar->id,
            'name' => $primaryCalendar->name,
            'provider' => $primaryCalendar->provider,
            'is_active' => (bool) $primaryCalendar->is_active,
        ] : null;
    }
    
    /**
     * Add preferences information to result
     */
    private function addPreferencesInformation(&$result, User $user)
    {
        $preferences = $user->preferences;
        
        $result['preferences'] = $preferences ? [
            'measurement_system' => $preferences->measurement_system,
            'event_notifications' => (bool) $preferences->event_notifications,
            'other_notifications' => (bool) $preferences->other_notifications,
            'daily_agenda_overview' => (bool) $preferences->daily_agenda_overview,
            'smart_timing' => (bool) $preferences->smart_timing,
            'event_duration' => $preferences->event_duration,
            'event_alert' => $preferences->event_alert,
            'all_day_event_alert' => $preferences->all_day_event_alert,
            'time_conflict_detection' => (bool) $preferences->time_conflict_detection,
            'google_meet_links' => (bool) $preferences->google_meet_links,
        ] : [
            'measurement_system' => 'metric',
            'event_notifications' => true,
            'other_notifications' => true,
            'daily_agenda_overview' => false,
            'smart_timing' => true,
            'event_duration' => 60,
            'event_alert' => 30,
            'all_day_event_alert' => 540, // 9 hours before noon (3 AM)
            'time_conflict_detection' => true,
            'google_meet_links' => false,
        ];
        
        // Get language preference from Redis metadata
        $redisKey = "conversation:{$user->id}:meta";
        $metadata = \Illuminate\Support\Facades\Redis::hgetall($redisKey) ?: [];
        $result['preferences']['language'] = $metadata['language'] ?? 'en';
    }
    
    /**
     * Add usage information to result
     */
    private function addUsageInformation(&$result, User $user)
    {
        // Get events created this week
        $eventsThisWeek = $user->events()
            ->where('created_at', '>=', now()->subDays(7))
            ->count();
            
        // Get events created today
        $eventsToday = $user->events()
            ->whereDate('created_at', today())
            ->count();
            
        // Use existing user method to check recent feature usage
        $webSearchesToday = $this->countFeatureUsageToday($user->id, 'web_searches');
        
        $result['usage'] = [
            'events_today' => $eventsToday,
            'events_this_week' => $eventsThisWeek,
            'total_events' => $user->events()->count(),
            'web_searches_today' => $webSearchesToday,
        ];
        
        // Add plan limits for comparison
        $currentPlan = $user->currentPlan();
        if ($currentPlan) {
            $result['usage']['limits'] = [
                'events_per_week' => $currentPlan->getFeatureLimit('events_per_week') ?: -1,
                'voice_messages_per_day' => $currentPlan->getFeatureLimit('voice_messages_per_day') ?: -1,
                'image_processing_per_day' => $currentPlan->getFeatureLimit('image_processing_per_day') ?: -1,
                'web_searches_per_day' => $currentPlan->getFeatureLimit('searches_per_day') ?: -1,
            ];
        }
    }
    
    /**
     * Count feature usage for today
     */
    private function countFeatureUsageToday($userId, $feature)
    {
        try {
            if (class_exists('App\\Models\\FeatureUsage')) {
                $count = \App\Models\FeatureUsage::where('user_id', $userId)
                    ->where('feature', $feature)
                    ->whereDate('created_at', today())
                    ->sum('count');
                    
                return $count;
            }
            return 0;
        } catch (\Exception $e) {
            Log::warning('Error counting feature usage: ' . $e->getMessage());
            return 0;
        }
    }
}