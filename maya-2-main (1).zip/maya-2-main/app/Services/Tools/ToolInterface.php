<?php

namespace App\Services\Tools;

use App\Models\User;

/**
 * Interface for all AI assistant tools
 */
interface ToolInterface
{
    /**
     * Get the name of the tool (used for function naming in OpenAI API)
     * 
     * @return string
     */
    public function getName();
    
    /**
     * Get the description of what the tool does
     * 
     * @return string
     */
    public function getDescription();
    
    /**
     * Get the parameters schema for the tool in JSON Schema format
     * 
     * @return array
     */
    public function getParameters();
    
    /**
     * Execute the tool with the given arguments
     * 
     * @param array $arguments Tool arguments passed from OpenAI
     * @param User $user The authenticated user
     * @return array Response data
     */
    public function execute(array $arguments, User $user);
}