<?php

namespace App\Services\Tools;

use App\Models\User;
use App\Models\Event;
use App\Models\CalendarConnection;
use App\Services\TimezoneService;
use App\Services\Tools\ToolInterface;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Carbon;

class FindEventsTools implements ToolInterface
{
    protected $timezoneService;
    
    public function __construct(TimezoneService $timezoneService)
    {
        $this->timezoneService = $timezoneService;
    }
    
    public function getName()
    {
        return 'calendar_find_events';
    }
    
    public function getDescription()
    {
        return 'Search for calendar events based on date range, query, creation date, and other filters';
    }
    
    public function getParameters()
    {
        return [
            'type' => 'object',
            'properties' => [
                'start_date' => [
                    'type' => 'string',
                    'description' => 'Start date in ISO 8601 UTC format (e.g., "2025-05-15T00:00:00Z")',
                    'format' => 'date-time',
                ],
                'end_date' => [
                    'type' => 'string',
                    'description' => 'End date in ISO 8601 UTC format (e.g., "2025-05-16T23:59:59Z")',
                    'format' => 'date-time',
                ],
                'query' => [
                    'type' => 'string',
                    'description' => 'Search query to match against event title, description, or attendees',
                ],
                'max_results' => [
                    'type' => 'integer',
                    'description' => 'Maximum number of results to return',
                ],
                'include_recurring' => [
                    'type' => 'boolean',
                    'description' => 'Whether to include recurring event instances',
                ],
                'filter_type' => [
                    'type' => 'string',
                    'description' => 'Filter for specific types of events: "all", "upcoming", "past", "today"',
                    'enum' => ['all', 'upcoming', 'past', 'today'],
                ],
                'search_type' => [
                    'type' => 'string',
                    'description' => 'Type of search: "event_time" (when events occur) or "created_time" (when events were created)',
                    'enum' => ['event_time', 'created_time'],
                ],
                'created_start_date' => [
                    'type' => 'string',
                    'description' => 'Filter events created on or after this date in ISO 8601 UTC format',
                    'format' => 'date-time',
                ],
                'created_end_date' => [
                    'type' => 'string',
                    'description' => 'Filter events created on or before this date in ISO 8601 UTC format',
                    'format' => 'date-time',
                ],
                'created_filter_type' => [
                    'type' => 'string',
                    'description' => 'Filter for when events were created: "all", "today", "yesterday", "this_week", "last_week", "this_month"',
                    'enum' => ['all', 'today', 'yesterday', 'this_week', 'last_week', 'this_month'],
                ],
            ],
            'required' => ['filter_type'],
        ];
    }
    
    public function execute(array $arguments, User $user)
    {
        try {
            Log::info('Executing calendar_find_events', ['user_id' => $user->id, 'arguments' => $arguments]);
            
            // Get user timezone (only for display purposes)
            $userTz = $user->timezone ?? 'UTC';
            
            // Set defaults and parse inputs
            $maxResults = $arguments['max_results'] ?? 10;
            $includeRecurring = $arguments['include_recurring'] ?? true;
            $filterType = $arguments['filter_type'] ?? 'upcoming';
            $query = $arguments['query'] ?? null;
            $searchType = $arguments['search_type'] ?? 'event_time';
            $createdFilterType = $arguments['created_filter_type'] ?? null;
            
            // Initialize the query builder
            $eventsQuery = $user->events();
            
            // Determine if we're searching by event time or creation time
            if ($searchType === 'created_time') {
                // Handle searching by when events were CREATED
                $this->applyCreationTimeFilters($eventsQuery, $arguments, $userTz, $createdFilterType);
            } else {
                // Handle searching by when events OCCUR
                $this->applyEventTimeFilters($eventsQuery, $filterType, $arguments, $userTz);
            }
            
            // Apply text search if query is provided
            if ($query) {
                if(env('DB_CONNECTION') == 'mysql'){
                    $eventsQuery->where(function($q) use ($query) {
                        $q->where('title', 'LIKE', '%' . $query . '%')
                        ->orWhere('description', 'LIKE', '%' . $query . '%')
                        ->orWhere('location', 'LIKE', '%' . $query . '%');
                    });
                }
                else{
                    $eventsQuery->where(function($q) use ($query) {
                        $q->where('title', 'ilike', '%' . $query . '%')
                        ->orWhere('description', 'ilike', '%' . $query . '%')
                        ->orWhere('location', 'ilike', '%' . $query . '%');
                    });
                }
            }
            
            // Apply limit
            $events = $eventsQuery->limit($maxResults)->get();
            
            // Transform events to a more useful format and convert times to user's timezone
            $formattedEvents = [];
            foreach ($events as $event) {
                // Convert UTC times to user's timezone for display
                $startTimeLocal = $this->timezoneService->utcToUser($event->start_time, $userTz);
                $endTimeLocal = $this->timezoneService->utcToUser($event->end_time, $userTz);
                $createdAtLocal = $this->timezoneService->utcToUser($event->created_at, $userTz);
                $updatedAtLocal = $event->updated_at ? $this->timezoneService->utcToUser($event->updated_at, $userTz) : null;
                
                $formattedEvent = [
                    'id' => $event->id,
                    'title' => $event->title,
                    'description' => $event->description,
                    'start_utc' => Carbon::parse($event->start_time)->toIso8601String(),
                    'end_utc' => Carbon::parse($event->end_time)->toIso8601String(),
                    'start_local' => $startTimeLocal->format('c'),
                    'end_local' => $endTimeLocal->format('c'),
                    'created_at_utc' => Carbon::parse($event->created_at)->toIso8601String(),
                    'created_at_local' => $createdAtLocal->format('c'),
                    'updated_at_utc' => $event->updated_at ? Carbon::parse($event->updated_at)->toIso8601String() : null,
                    'updated_at_local' => $updatedAtLocal ? $updatedAtLocal->format('c') : null,
                    'is_all_day' => $event->is_all_day,
                    'location' => $event->location,
                    'status' => $event->status,
                    'calendar_id' => $event->calendar_connection_id,
                    'calendar_name' => $event->calendar->name ?? 'Primary',
                    'user_timezone' => $userTz
                ];
                
                // Add human-readable created time
                $formattedEvent['created_human'] = $this->getHumanTimeAgo($createdAtLocal);
                
                // Add attendees if available
                if (!empty($event->attendees)) {
                    $formattedEvent['attendees'] = $event->attendees;
                }
                
                // Add recurrence info if available
                if (!empty($event->recurrence)) {
                    $formattedEvent['recurrence'] = $event->recurrence;
                }
                
                $formattedEvents[] = $formattedEvent;
            }
            
            // Get total count for pagination purposes
            $totalCount = $eventsQuery->count();
            
            // Prepare response
            $response = [
                'success' => true,
                'events' => $formattedEvents,
                'total_count' => $totalCount,
                'has_more' => $totalCount > count($formattedEvents),
                'user_timezone' => $userTz,
                'search_type' => $searchType
            ];
            
            // Add filter information based on search type
            if ($searchType === 'created_time') {
                $response['created_filter_applied'] = $createdFilterType;
                
                if (isset($arguments['created_start_date']) || isset($arguments['created_end_date'])) {
                    $response['creation_date_range'] = [
                        'start_utc' => isset($arguments['created_start_date']) ? $arguments['created_start_date'] : null,
                        'end_utc' => isset($arguments['created_end_date']) ? $arguments['created_end_date'] : null,
                    ];
                }
            } else {
                $response['filter_applied'] = $filterType;
                
                if (isset($arguments['start_date']) || isset($arguments['end_date'])) {
                    $response['date_range'] = [
                        'start_utc' => isset($arguments['start_date']) ? $arguments['start_date'] : null,
                        'end_utc' => isset($arguments['end_date']) ? $arguments['end_date'] : null,
                    ];
                }
            }
            
            return $response;
            
        } catch (\Exception $e) {
            Log::error('Error in calendar_find_events', [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'success' => false,
                'error' => 'System error',
                'message' => 'An unexpected error occurred: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Generate a human-readable time ago string
     */
    private function getHumanTimeAgo($dateTime)
    {
        $now = Carbon::now($dateTime->timezone);
        $diff = $dateTime->diffInSeconds($now);
        
        if ($diff < 60) {
            return $diff . ' seconds ago';
        } elseif ($diff < 3600) {
            $minutes = floor($diff / 60);
            return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
        } elseif ($diff < 86400) {
            $hours = floor($diff / 3600);
            return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
        } elseif ($diff < 604800) {
            $days = floor($diff / 86400);
            return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
        } else {
            return $dateTime->format('M j, Y g:i A');
        }
    }
    
    /**
     * Apply filters based on when events occur
     * All date comparisons are in UTC
     */
    private function applyEventTimeFilters($eventsQuery, $filterType, $arguments, $userTz)
    {
        // Get current time in UTC for database comparisons
        $nowUtc = Carbon::now('UTC');
        
        switch ($filterType) {
            case 'upcoming':
                $eventsQuery->where('start_time', '>=', $nowUtc)
                        ->orderBy('start_time', 'asc');
                
                Log::info('Applied upcoming filter', [
                    'now_utc' => $nowUtc->toIso8601String(),
                    'filter_type' => 'upcoming'
                ]);
                break;
                
            case 'past':
                $eventsQuery->where('start_time', '<', $nowUtc)
                        ->orderBy('start_time', 'desc');
                
                Log::info('Applied past filter', [
                    'now_utc' => $nowUtc->toIso8601String(),
                    'filter_type' => 'past'
                ]);
                break;
                
            case 'today':
                // Create today range in user's timezone
                $todayStart = Carbon::now($userTz)->startOfDay();
                $todayEnd = Carbon::now($userTz)->endOfDay();
                
                // Convert to UTC for database comparison
                $todayStartUtc = $todayStart->copy()->setTimezone('UTC');
                $todayEndUtc = $todayEnd->copy()->setTimezone('UTC');
                
                $eventsQuery->where('start_time', '>=', $todayStartUtc)
                        ->where('start_time', '<=', $todayEndUtc)
                        ->orderBy('start_time', 'asc');
                
                Log::info('Applied today filter', [
                    'user_timezone' => $userTz,
                    'today_start_user' => $todayStart->toIso8601String(),
                    'today_end_user' => $todayEnd->toIso8601String(),
                    'today_start_utc' => $todayStartUtc->toIso8601String(),
                    'today_end_utc' => $todayEndUtc->toIso8601String(),
                    'filter_type' => 'today'
                ]);
                break;
                
            case 'all':
            default:
                $eventsQuery->orderBy('start_time', 'asc');
                
                Log::info('Applied all filter', [
                    'filter_type' => 'all'
                ]);
                break;
        }
        
        // Apply date range if specified - dates should already be in ISO 8601 UTC format
        if (isset($arguments['start_date'])) {
            try {
                // Parse the ISO 8601 date directly in UTC
                $startDateUtc = Carbon::parse($arguments['start_date'], 'UTC');
                
                $eventsQuery->where('start_time', '>=', $startDateUtc);
                
                Log::info('Applied start date filter', [
                    'start_date_input' => $arguments['start_date'],
                    'parsed_utc' => $startDateUtc->toIso8601String()
                ]);
            } catch (\Exception $e) {
                Log::warning('Invalid start_date format', [
                    'start_date' => $arguments['start_date'],
                    'error' => $e->getMessage()
                ]);
                throw new \Exception('Could not parse start_date. Please use ISO 8601 UTC format.');
            }
        }
        
        if (isset($arguments['end_date'])) {
            try {
                // Parse the ISO 8601 date directly in UTC
                $endDateUtc = Carbon::parse($arguments['end_date'], 'UTC');
                
                $eventsQuery->where('start_time', '<=', $endDateUtc);
                
                Log::info('Applied end date filter', [
                    'end_date_input' => $arguments['end_date'],
                    'parsed_utc' => $endDateUtc->toIso8601String()
                ]);
            } catch (\Exception $e) {
                Log::warning('Invalid end_date format', [
                    'end_date' => $arguments['end_date'],
                    'error' => $e->getMessage()
                ]);
                throw new \Exception('Could not parse end_date. Please use ISO 8601 UTC format.');
            }
        }
    }
    
    /**
     * Apply filters based on when events were created
     * All date comparisons are in UTC
     */
    private function applyCreationTimeFilters($eventsQuery, $arguments, $userTz, $createdFilterType)
    {
        // Apply explicit timestamp filters if provided - should be in ISO 8601 UTC format
        if (isset($arguments['created_start_date'])) {
            try {
                // Parse the ISO 8601 date directly in UTC
                $createdStartDateUtc = Carbon::parse($arguments['created_start_date'], 'UTC');
                
                $eventsQuery->where('created_at', '>=', $createdStartDateUtc);
                
                Log::info("Filtering events created after", [
                    'input' => $arguments['created_start_date'],
                    'parsed_utc' => $createdStartDateUtc->toIso8601String()
                ]);
            } catch (\Exception $e) {
                Log::warning('Invalid created_start_date format', [
                    'created_start_date' => $arguments['created_start_date'],
                    'error' => $e->getMessage()
                ]);
                throw new \Exception('Could not parse created_start_date. Please use ISO 8601 UTC format.');
            }
        }
        
        if (isset($arguments['created_end_date'])) {
            try {
                // Parse the ISO 8601 date directly in UTC
                $createdEndDateUtc = Carbon::parse($arguments['created_end_date'], 'UTC');
                
                $eventsQuery->where('created_at', '<=', $createdEndDateUtc);
                
                Log::info("Filtering events created before", [
                    'input' => $arguments['created_end_date'],
                    'parsed_utc' => $createdEndDateUtc->toIso8601String()
                ]);
            } catch (\Exception $e) {
                Log::warning('Invalid created_end_date format', [
                    'created_end_date' => $arguments['created_end_date'],
                    'error' => $e->getMessage()
                ]);
                throw new \Exception('Could not parse created_end_date. Please use ISO 8601 UTC format.');
            }
        }
        
        // Apply pre-defined time period filters if no explicit timestamps were provided
        if ($createdFilterType && !isset($arguments['created_start_date']) && !isset($arguments['created_end_date'])) {
            // Create date ranges in user's timezone, then convert to UTC for comparison
            $now = Carbon::now($userTz);
            
            switch ($createdFilterType) {
                case 'today':
                    $todayStart = $now->copy()->startOfDay();
                    $todayEnd = $now->copy()->endOfDay();
                    
                    // Convert to UTC for database comparison
                    $todayStartUtc = $todayStart->copy()->setTimezone('UTC');
                    $todayEndUtc = $todayEnd->copy()->setTimezone('UTC');
                    
                    $eventsQuery->where('created_at', '>=', $todayStartUtc)
                                ->where('created_at', '<=', $todayEndUtc);
                    
                    Log::info('Applied today creation filter', [
                        'user_timezone' => $userTz,
                        'today_start_user' => $todayStart->toIso8601String(),
                        'today_end_user' => $todayEnd->toIso8601String(),
                        'today_start_utc' => $todayStartUtc->toIso8601String(),
                        'today_end_utc' => $todayEndUtc->toIso8601String()
                    ]);
                    break;
                    
                case 'yesterday':
                    $yesterdayStart = $now->copy()->subDay()->startOfDay();
                    $yesterdayEnd = $now->copy()->subDay()->endOfDay();
                    
                    // Convert to UTC for database comparison
                    $yesterdayStartUtc = $yesterdayStart->copy()->setTimezone('UTC');
                    $yesterdayEndUtc = $yesterdayEnd->copy()->setTimezone('UTC');
                    
                    $eventsQuery->where('created_at', '>=', $yesterdayStartUtc)
                                ->where('created_at', '<=', $yesterdayEndUtc);
                    
                    Log::info('Applied yesterday creation filter', [
                        'user_timezone' => $userTz,
                        'yesterday_start_user' => $yesterdayStart->toIso8601String(),
                        'yesterday_end_user' => $yesterdayEnd->toIso8601String(),
                        'yesterday_start_utc' => $yesterdayStartUtc->toIso8601String(),
                        'yesterday_end_utc' => $yesterdayEndUtc->toIso8601String()
                    ]);
                    break;
                    
                case 'this_week':
                    $weekStart = $now->copy()->startOfWeek();
                    $weekEnd = $now->copy()->endOfWeek();
                    
                    // Convert to UTC for database comparison
                    $weekStartUtc = $weekStart->copy()->setTimezone('UTC');
                    $weekEndUtc = $weekEnd->copy()->setTimezone('UTC');
                    
                    $eventsQuery->where('created_at', '>=', $weekStartUtc)
                                ->where('created_at', '<=', $weekEndUtc);
                    
                    Log::info('Applied this week creation filter', [
                        'user_timezone' => $userTz,
                        'week_start_user' => $weekStart->toIso8601String(),
                        'week_end_user' => $weekEnd->toIso8601String(),
                        'week_start_utc' => $weekStartUtc->toIso8601String(),
                        'week_end_utc' => $weekEndUtc->toIso8601String()
                    ]);
                    break;
                    
                case 'last_week':
                    $lastWeekStart = $now->copy()->subWeek()->startOfWeek();
                    $lastWeekEnd = $now->copy()->subWeek()->endOfWeek();
                    
                    // Convert to UTC for database comparison
                    $lastWeekStartUtc = $lastWeekStart->copy()->setTimezone('UTC');
                    $lastWeekEndUtc = $lastWeekEnd->copy()->setTimezone('UTC');
                    
                    $eventsQuery->where('created_at', '>=', $lastWeekStartUtc)
                                ->where('created_at', '<=', $lastWeekEndUtc);
                    
                    Log::info('Applied last week creation filter', [
                        'user_timezone' => $userTz,
                        'last_week_start_user' => $lastWeekStart->toIso8601String(),
                        'last_week_end_user' => $lastWeekEnd->toIso8601String(),
                        'last_week_start_utc' => $lastWeekStartUtc->toIso8601String(),
                        'last_week_end_utc' => $lastWeekEndUtc->toIso8601String()
                    ]);
                    break;
                    
                case 'this_month':
                    $monthStart = $now->copy()->startOfMonth();
                    $monthEnd = $now->copy()->endOfMonth();
                    
                    // Convert to UTC for database comparison
                    $monthStartUtc = $monthStart->copy()->setTimezone('UTC');
                    $monthEndUtc = $monthEnd->copy()->setTimezone('UTC');
                    
                    $eventsQuery->where('created_at', '>=', $monthStartUtc)
                                ->where('created_at', '<=', $monthEndUtc);
                    
                    Log::info('Applied this month creation filter', [
                        'user_timezone' => $userTz,
                        'month_start_user' => $monthStart->toIso8601String(),
                        'month_end_user' => $monthEnd->toIso8601String(),
                        'month_start_utc' => $monthStartUtc->toIso8601String(),
                        'month_end_utc' => $monthEndUtc->toIso8601String()
                    ]);
                    break;
            }
        }
        
        // Default to order by creation date (most recent first)
        $eventsQuery->orderBy('created_at', 'desc');
    }
}