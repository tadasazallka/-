<?php

namespace App\Services;

use App\Models\User;
use App\Models\Event;
use App\Services\Calendars\CalendarProviderFactory;
use App\Services\PlanLimitService;
use App\Services\TimeConflictService;
use App\Services\TimezoneService;
use App\Traits\DateTimeProcessingTrait;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Carbon;

class CalendarCreateService
{
    use DateTimeProcessingTrait;
    
    protected $calendarProviderFactory;
    protected $planLimitService;
    protected $timeConflictService;
    protected $timezoneService;
    
    // Confidence threshold
    const CONFIDENCE_THRESHOLD = 0.7;
    const DEFAULT_REMINDER_MINUTES = 10;
    
    public function __construct(
        CalendarProviderFactory $calendarProviderFactory,
        PlanLimitService $planLimitService,
        TimeConflictService $timeConflictService,
        TimezoneService $timezoneService
    ) {
        $this->calendarProviderFactory = $calendarProviderFactory;
        $this->planLimitService = $planLimitService;
        $this->timeConflictService = $timeConflictService;
        $this->timezoneService = $timezoneService;
    }
    
    /**
     * Create a calendar event for a user
     * 
     * @param User $user The user creating the event
     * @param array $eventParams Parameters for the event
     * @return array [Event|null, array] The created event or null on failure and additional info
     */
    public function createEvent(User $user, array $eventParams): array
    {
        try {
            Log::info('Creating calendar event', ['user_id' => $user->id]);
            
            // Check if user can create events based on plan
            $canCreate = $this->planLimitService->canCreateEvent($user);
            if (!$canCreate) {
                return [
                    'event' => null,
                    'message' => 'Your event creation limit is reached. You need to subscribe to a premium plan',
                ];
            }
            
            // Get user's calendar based on the request or use the primary/default
            $calendar = null;
            
            // If no calendar specified or not found, use primary or create default
            if (!$calendar) {
                $calendar = $user->primaryCalendar ?? $user->getOrCreateDefaultCalendar();
            }
            
            // Get user's timezone (for all-day events and metadata)
            $userTz = $user->timezone ?? 'UTC';
            
            // Check if this is an all-day event
            $isAllDay = $eventParams['is_all_day'] ?? false;
            
            // Get start and end times - expecting UTC Carbon instances from the tool
            $startDateTime = $eventParams['start_datetime'] ?? null;
            $endDateTime = $eventParams['end_datetime'] ?? null;
            
            // Validate that datetimes are provided and in UTC
            if (!$startDateTime || !$endDateTime) {
                return [
                    'event' => null,
                    'error' => 'missing_datetime',
                    'message' => 'Start and end datetime must be provided in UTC'
                ];
            }
            
            // Ensure both times are in UTC
            if ($startDateTime->timezone->getName() !== 'UTC') {
                $startDateTime = $startDateTime->setTimezone('UTC');
            }
            
            if ($endDateTime->timezone->getName() !== 'UTC') {
                $endDateTime = $endDateTime->setTimezone('UTC');
            }
            
            // Current time in UTC for validation
            $now = Carbon::now('UTC');
            
            // Log the datetime values for debugging
            Log::info('Event datetime values', [
                'now_utc' => $now->toIso8601String(),
                'start_utc' => $startDateTime->toIso8601String(),
                'end_utc' => $endDateTime->toIso8601String(),
                'is_all_day' => $isAllDay ? 'Yes' : 'No'
            ]);
            
            // Validate: Event can't be in the past
            if ($startDateTime->lt($now)) {
                return [
                    'event' => null,
                    'error' => 'past_event_date',
                    'message' => 'Cannot create events in the past. Please choose a future date and time.',
                    'current_time' => $now->toIso8601String(),
                    'requested_time' => $startDateTime->toIso8601String()
                ];
            }

            // Validate: End time must be after start time
            if ($endDateTime->lte($startDateTime)) {
                return [
                    'event' => null,
                    'error' => 'invalid_time_range',
                    'message' => 'End time must be after start time.',
                    'start_time' => $startDateTime->toIso8601String(),
                    'end_time' => $endDateTime->toIso8601String()
                ];
            }
            
            // Check for time conflicts if the feature is enabled for the user
            $conflicts = [];
            $canUseTimeConflictDetection = $this->planLimitService->canUseTimeConflictDetection($user);
            
            if ($canUseTimeConflictDetection) {
                $conflicts = $this->timeConflictService->checkTimeConflicts(
                    $user,
                    $startDateTime,
                    $endDateTime
                );
                
                Log::info('Time conflict check', [
                    'user_id' => $user->id,
                    'conflicts_found' => count($conflicts)
                ]);
            }
            
            // Process recurrence, reminders, and attendees
            $recurrence = $eventParams['recurrence'] ?? null;
            
            // Process reminders
            $reminderMinutes = null;
            $userDisabledReminders = $eventParams['user_disabled_reminders'] ?? false;
            
            if (!empty($eventParams['reminders']) && is_array($eventParams['reminders'])) {
                // If multiple reminders, take the first one's minutes value
                $reminderMinutes = $eventParams['reminders'][0]['minutes'] ?? null;
            } elseif (!$userDisabledReminders) {
                // Set default reminder time if user didn't explicitly disable reminders
                $reminderMinutes = self::DEFAULT_REMINDER_MINUTES; // Default to 10 minutes
            }
            
            $attendees = $eventParams['attendees'] ?? [];
            
            // Get the appropriate calendar provider
            $calendarProvider = $this->calendarProviderFactory->getProvider($calendar);
            
            // Check if user can use Google Meet and wants to add it
            $addGoogleMeet = false;
            if ($calendar->provider === 'google' && 
                isset($eventParams['add_google_meet']) && 
                $eventParams['add_google_meet'] === true) {
                
                $canUseGoogleMeetLinks = $this->planLimitService->canUseGoogleMeetLinks($user);
                
                if ($canUseGoogleMeetLinks) {
                    $addGoogleMeet = true;
                    Log::info('Adding Google Meet link to event', ['user_id' => $user->id]);
                } else {
                    Log::info('User requested Google Meet but does not have access to this feature', ['user_id' => $user->id]);
                }
            }
            
            // Prepare data for provider - all in UTC
            $providerEventData = [
                'title' => $eventParams['title'],
                'description' => $eventParams['description'] ?? null,
                'start_time' => $startDateTime,
                'end_time' => $endDateTime,
                'location' => $eventParams['location'] ?? null,
                'is_all_day' => $isAllDay,
                'recurrence' => $recurrence,
                'attendees' => $attendees,
                'reminders' => $eventParams['reminders'] ?? [],
                'add_google_meet' => $addGoogleMeet
            ];
            
            // Create the event in the provider's calendar system
            $providerResult = $calendarProvider->createEvent($calendar, $providerEventData);
            
            if ($providerResult) {
                // Create the event in our database
                $event = new Event([
                    'user_id' => $user->id,
                    'calendar_connection_id' => $calendar->id,
                    'title' => $eventParams['title'],
                    'description' => $eventParams['description'] ?? null,
                    'start_time' => $startDateTime,
                    'end_time' => $endDateTime,
                    'location' => $eventParams['location'] ?? null,
                    'is_all_day' => $isAllDay,
                    'recurrence' => $recurrence,
                    'attendees' => $attendees,
                    'status' => 'scheduled',
                    'reminder' => $reminderMinutes,
                    'reminder_sent' => false,
                    'created_via' => $eventParams['created_via'] ?? 'maya',
                    'provider_event_id' => $providerResult['provider_event_id'] ?? null,
                    'metadata' => [
                        'creation_timestamp' => now()->timestamp,
                        'source' => $eventParams['metadata']['source'] ?? 'maya',
                        'reminders' => $eventParams['reminders'] ?? [],
                        'has_google_meet' => $addGoogleMeet,
                        'google_meet_link' => $providerResult['google_meet_link'] ?? null,
                        'user_timezone' => $userTz,
                        // Store both UTC and user local times in metadata for reference
                        'start_time_utc' => $startDateTime->toIso8601String(),
                        'end_time_utc' => $endDateTime->toIso8601String(),
                        'start_time_local' => $startDateTime->copy()->setTimezone($userTz)->toIso8601String(),
                        'end_time_local' => $endDateTime->copy()->setTimezone($userTz)->toIso8601String(),
                        'user_disabled_reminders' => $userDisabledReminders
                    ] + ($eventParams['metadata'] ?? []) + ($providerResult['provider_metadata'] ?? [])
                ]);
                
                $event->save();
                
                // Return the event along with any conflicts found
                return [
                    'event' => $event,
                    'conflicts' => $conflicts,
                    'google_meet_added' => $addGoogleMeet
                ];
            }
            
            return [
                'event' => null,
                'conflicts' => $conflicts,
                'error' => 'Failed to create event in provider system'
            ];
            
        } catch (\Exception $e) {
            Log::error('Failed to create calendar event: ' . $e->getMessage(), [
                'exception' => $e,
                'trace' => $e->getTraceAsString()
            ]);
            
            return [
                'event' => null,
                'conflicts' => [],
                'error' => $e->getMessage()
            ];
        }
    }
}