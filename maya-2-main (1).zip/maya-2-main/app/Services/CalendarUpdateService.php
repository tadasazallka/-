<?php

namespace App\Services;

use App\Models\User;
use App\Models\Event;
use App\Services\Calendars\CalendarProviderFactory;
use App\Services\TimeConflictService;
use App\Services\TimezoneService;
use App\Traits\DateTimeProcessingTrait;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class CalendarUpdateService
{
    use DateTimeProcessingTrait;
    
    protected $calendarProviderFactory;
    protected $timeConflictService;
    protected $timezoneService;
    
    public function __construct(
        CalendarProviderFactory $calendarProviderFactory,
        TimeConflictService $timeConflictService,
        TimezoneService $timezoneService
    ) {
        $this->calendarProviderFactory = $calendarProviderFactory;
        $this->timeConflictService = $timeConflictService;
        $this->timezoneService = $timezoneService;
    }
    
    /**
     * Update an existing calendar event
     * 
     * @param User $user The user updating the event
     * @param array $updateParams Parameters for the event update
     * @return Event|null The updated event or null on failure
     */
    public function updateEvent(User $user, array $updateParams)
    {
        try {
            Log::info('Updating calendar event', ['user_id' => $user->id, 'params' => $updateParams]);
            
            // Get the event to update
            $eventId = $updateParams['event_id'];
            $event = Event::where('id', $eventId)
                ->where('user_id', $user->id)
                ->first();
            
            if (!$event) {
                Log::warning('Event not found for update', ['event_id' => $eventId, 'user_id' => $user->id]);
                return null;
            }
            
            // Get the calendar connection
            $calendar = $event->calendar;
            if (!$calendar) {
                Log::error('Calendar not found for event', ['event_id' => $event->id]);
                return null;
            }
            
            // Get user's timezone
            $userTz = $user->timezone ?? 'UTC';
            
            // Determine if we're updating date/time
            $updatingDateTime = isset($updateParams['start_datetime']) || isset($updateParams['end_datetime']);
            
            // Update event properties
            if (isset($updateParams['title'])) {
                $event->title = $updateParams['title'];
            }
            
            if (isset($updateParams['description'])) {
                $event->description = $updateParams['description'];
            }
            
            if (isset($updateParams['location'])) {
                $event->location = $updateParams['location'];
            }
            
            if (isset($updateParams['attendees'])) {
                $event->attendees = $updateParams['attendees'];
            }
            
            if (isset($updateParams['is_all_day'])) {
                $event->is_all_day = $updateParams['is_all_day'];
            }
            
            // Process date/time updates
            if ($updatingDateTime) {
                // Get existing start/end times
                $startDateTime = clone $event->start_time;
                $endDateTime = clone $event->end_time;
                
                // Log current times for debugging
                Log::info('Current event times before update', [
                    'event_id' => $event->id,
                    'start_time_utc' => $startDateTime->toIso8601String(),
                    'end_time_utc' => $endDateTime->toIso8601String()
                ]);
                
                // Update with new datetime values if provided
                if (isset($updateParams['start_datetime'])) {
                    $startDateTime = $updateParams['start_datetime'];
                    
                    // Ensure it's in UTC
                    if ($startDateTime->timezone->getName() !== 'UTC') {
                        $startDateTime = $startDateTime->setTimezone('UTC');
                    }
                    
                    Log::info('Using start_datetime for update', [
                        'start_datetime_utc' => $startDateTime->toIso8601String()
                    ]);
                }
                
                if (isset($updateParams['end_datetime'])) {
                    $endDateTime = $updateParams['end_datetime'];
                    
                    // Ensure it's in UTC
                    if ($endDateTime->timezone->getName() !== 'UTC') {
                        $endDateTime = $endDateTime->setTimezone('UTC');
                    }
                    
                    Log::info('Using end_datetime for update', [
                        'end_datetime_utc' => $endDateTime->toIso8601String()
                    ]);
                }
                
                // Check if the updated start time is in the past
                $nowUtc = Carbon::now('UTC');
                
                // Debug log to verify what we're comparing
                Log::info('Time comparison values for update', [
                    'now_utc' => $nowUtc->toIso8601String(),
                    'start_time_utc' => $startDateTime->toIso8601String(),
                    'now_timestamp' => $nowUtc->timestamp,
                    'start_timestamp' => $startDateTime->timestamp,
                    'comparison_result' => ($startDateTime->timestamp < $nowUtc->timestamp) ? 'In past' : 'In future'
                ]);
                
                // Check if the updated start time is in the past
                if ($startDateTime->timestamp < $nowUtc->timestamp) {
                    Log::warning('Attempted to update event to a time in the past', [
                        'user_id' => $user->id,
                        'event_id' => $event->id,
                        'start_time_utc' => $startDateTime->toIso8601String(),
                        'current_time_utc' => $nowUtc->toIso8601String()
                    ]);
                    
                    return null;
                }
                
                // Ensure end time is after start time
                if ($endDateTime->timestamp <= $startDateTime->timestamp) {
                    Log::warning('Invalid event time range in update', [
                        'user_id' => $user->id,
                        'event_id' => $event->id,
                        'start_time' => $startDateTime->toIso8601String(),
                        'end_time' => $endDateTime->toIso8601String()
                    ]);
                    
                    return null;
                }
                
                // Update the event times
                $event->start_time = $startDateTime;
                $event->end_time = $endDateTime;
                
                // Log the updated times for debugging
                Log::info('Updated event times', [
                    'event_id' => $event->id,
                    'start_time_utc' => $startDateTime->toIso8601String(),
                    'end_time_utc' => $endDateTime->toIso8601String()
                ]);
            }
            
            // Get metadata
            $metadata = $event->metadata ?? [];
            
            // Add timezone information to metadata
            $metadata['user_timezone'] = $userTz;
            
            // If start or end times were updated, add the user's local time to metadata
            if (isset($updateParams['start_datetime'])) {
                $metadata['user_local_start_time'] = $event->start_time->copy()->setTimezone($userTz)->toIso8601String();
            }
            
            if (isset($updateParams['end_datetime'])) {
                $metadata['user_local_end_time'] = $event->end_time->copy()->setTimezone($userTz)->toIso8601String();
            }
            
            // Add metadata updates if provided
            if (isset($updateParams['metadata']) && is_array($updateParams['metadata'])) {
                $metadata = array_merge($metadata, $updateParams['metadata']);
            }
            
            // Update the metadata
            $event->metadata = $metadata;
            
            // Prepare data for calendar provider
            $providerEventData = [
                'title' => $event->title,
                'description' => $event->description,
                'start_time' => $event->start_time,
                'end_time' => $event->end_time,
                'location' => $event->location,
                'is_all_day' => $event->is_all_day,
                'attendees' => $event->attendees,
                'add_google_meet' => $updateParams['add_google_meet'] ?? false
            ];
            
            // Get the calendar provider
            $calendarProvider = $this->calendarProviderFactory->getProvider($calendar);
            
            // Update the event in the provider's calendar system
            $providerResult = $calendarProvider->updateEventById($calendar, $event, $providerEventData);
            
            if ($providerResult) {
                // Update provider-specific fields
                if (isset($providerResult['provider_event_id'])) {
                    $event->provider_event_id = $providerResult['provider_event_id'];
                }
                
                // Update metadata with provider result
                if (isset($providerResult['provider_metadata'])) {
                    $metadata = array_merge($metadata, [
                        'provider_metadata' => $providerResult['provider_metadata']
                    ]);
                }
                
                // Update Google Meet information
                if (isset($providerResult['google_meet_link'])) {
                    $metadata['has_google_meet'] = true;
                    $metadata['google_meet_link'] = $providerResult['google_meet_link'];
                }
                
                // Save metadata back to event
                $event->metadata = $metadata;
                
                // Save the updated event
                $event->save();
                
                Log::info('Successfully updated event', [
                    'event_id' => $event->id,
                    'start_time_utc' => $event->start_time->toIso8601String(),
                    'end_time_utc' => $event->end_time->toIso8601String(),
                    'user_timezone' => $userTz
                ]);
                
                return $event;
            } else {
                Log::error('Failed to update event in provider system', ['event_id' => $event->id]);
                return null;
            }
            
        } catch (\Exception $e) {
            Log::error('Failed to update calendar event: ' . $e->getMessage(), [
                'exception' => $e,
                'trace' => $e->getTraceAsString()
            ]);
            return null;
        }
    }
}