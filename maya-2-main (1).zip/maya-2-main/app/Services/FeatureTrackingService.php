<?php

namespace App\Services;

use App\Models\User;
use App\Models\FeatureUsage;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class FeatureTrackingService
{
    protected $timezoneService;
    
    public function __construct(TimezoneService $timezoneService)
    {
        $this->timezoneService = $timezoneService;
    }

    /**
     * Record usage of a feature for a user
     */
    public function recordUsage(User $user, string $feature, int $usage = 1)
    {
        // Check if we need to track this feature
        if (!in_array($feature, $this->trackableFeatures())) {
            return;
        }
        
        // Get period start based on user's timezone
        $periodStart = $this->getPeriodStart($feature, $user->timezone ?? 'UTC');
        
        // Check if record exists
        $record = FeatureUsage::where('user_id', $user->id)
            ->where('feature', $feature)
            ->where('period_start', $periodStart)
            ->first();
        
        if ($record) {
            // Update existing record
            $record->increment('usage', $usage);
        } else {
            // Create new record
            FeatureUsage::create([
                'user_id' => $user->id,
                'feature' => $feature,
                'period_start' => $periodStart,
                'usage' => $usage
            ]);
        }
    }
    
    /**
     * Get current usage for a feature
     */
    public function getUsage(User $user, string $feature)
    {
        return FeatureUsage::where('user_id', $user->id)
            ->where('feature', $feature)
            ->where('period_start', $this->getPeriodStart($feature, $user->timezone ?? 'UTC'))
            ->value('usage') ?? 0;
    }
    
    /**
     * Check if a user can use a feature
     */
    public function canUseFeature(User $user, string $feature, int $usage = 1)
    {
        $plan = $user->currentPlan();
        
        if (!$plan) {
            return false;
        }
        
        $limit = $plan->getFeatureLimit($feature);
        
        // No limit (unlimited)
        if ($limit === null || $limit === -1) {
            return true;
        }
        
        // Check against current usage
        $currentUsage = $this->getUsage($user, $feature);
        
        return ($currentUsage + $usage) <= $limit;
    }
    
    /**
     * Get period start date based on feature period and user timezone
     */
    protected function getPeriodStart(string $feature, string $userTimezone = 'UTC')
    {
        $periodMap = [
            'events_per_week' => 'week',
            'whatsapp_reminders' => 'week',
        ];
        
        $period = $periodMap[$feature] ?? 'week';
        
        // Use the user's timezone to determine the start of the period
        $userNow = $this->timezoneService->nowUserTime($userTimezone);
        $periodStartInUserTz = $userNow->copy()->startOf($period);
        
        // Convert back to UTC for storage
        return $this->timezoneService->userToUTC($periodStartInUserTz, $userTimezone);
    }
    
    /**
     * List of features we track usage for
     */
    public function trackableFeatures()
    {
        return [
            'events_per_week',
            'whatsapp_reminders',
        ];
    }
    
    /**
     * Reset usage tracking for expired periods
     * This could be called via a scheduled command
     */
    public function resetExpiredPeriods()
    {
        // For each user, check and reset their expired periods
        
        $users = User::all();
        
        foreach ($users as $user) {
            $userTimezone = $user->timezone ?? 'UTC';
            
            foreach ($this->trackableFeatures() as $feature) {
                $currentPeriodStart = $this->getPeriodStart($feature, $userTimezone);
                
                // Delete records for older periods for this user
                FeatureUsage::where('user_id', $user->id)
                    ->where('feature', $feature)
                    ->where('period_start', '<', $currentPeriodStart)
                    ->delete();
            }
        }
    }
}