<?php

namespace App\Services\OpenAI;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;
use App\Models\User;
use App\Services\OpenAI\FunctionRegistry;
use Carbon\Carbon;

class OpenAIService
{
    protected $apiKey;
    protected $model;
    protected $functionRegistry;
    protected $baseUrl = 'https://api.openai.com/v1';
    
    public function __construct(FunctionRegistry $functionRegistry)
    {
        $this->apiKey = config('services.openai.api_key');
        $this->model = config('services.openai.model', 'gpt-4-turbo');

        $this->functionRegistry = $functionRegistry;
    }

    /**
     * Refresh the system prompt with updated user information
     *
     * @param User $user
     * @return bool
     */
    public function refreshSystemPrompt(User $user)
    {
        try {
            $redisKey = "user:{$user->id}";
            $messages = $this->getConversationHistory($redisKey);
            
            if (empty($messages)) {
                Log::info('No conversation history found to refresh', [
                    'user_id' => $user->id
                ]);
                return false;
            }
            
            // Find and update the system message
            foreach ($messages as $key => $message) {
                if ($message['role'] === 'system') {
                    // Generate fresh system prompt with latest user info
                    $newSystemPrompt = $this->buildSystemPrompt($user);
                    
                    // Update the system message in Redis
                    $messages[$key]['content'] = $newSystemPrompt;
                    Redis::lset($redisKey, $key, json_encode($messages[$key]));
                    
                    Log::info('Successfully refreshed system prompt for user', [
                        'user_id' => $user->id
                    ]);
                    return true;
                }
            }
            
            // If no system message was found, add one
            $systemMessage = [
                'role' => 'system',
                'content' => $this->buildSystemPrompt($user)
            ];
            
            // Insert at the beginning of the array
            array_unshift($messages, $systemMessage);
            
            // Clear Redis and add the updated messages
            Redis::del($redisKey);
            foreach ($messages as $message) {
                Redis::rpush($redisKey, json_encode($message));
            }
            
            // Reset expiration
            Redis::expire($redisKey, 3600);
            
            Log::info('Added new system prompt for user', [
                'user_id' => $user->id
            ]);
            return true;
            
        } catch (\Exception $e) {
            Log::error('Failed to refresh system prompt: ' . $e->getMessage(), [
                'user_id' => $user->id,
                'trace' => $e->getTraceAsString()
            ]);
            return false;
        }
    }
    
    /**
     * Process a user message and get AI response with tool calls
     */
    public function processMessage(User $user, string $conversationId, string $message)
    {
        Log::info('Open AI process message');
        // Create Redis key using user ID to ensure continuity
        $redisKey = "user:{$user->id}";
        
        // Get conversation history from Redis
        $messages = $this->getConversationHistory($redisKey);

        // Add system prompt if this is a new conversation
        if (empty($messages)) {
            $systemMessage = [
                'role' => 'system',
                'content' => $this->buildSystemPrompt($user)
            ];
            
            $messages[] = $systemMessage;
            $this->saveMessageToHistory($redisKey, $systemMessage);
        } else {
            // Update the time in the existing system message
            foreach ($messages as $key => $existingMessage) {
                if ($existingMessage['role'] === 'system') {
                    $currentTime = Carbon::now($user->timezone);
                    $messages[$key]['content'] = preg_replace(
                        '/Current date is.*?\\n/s',
                        "Current date is " . $currentTime->format('Y-m-d') . ". Current time is approximately " . $currentTime->format('g:i A') . " in the user's timezone ({$user->timezone}).\n",
                        $existingMessage['content']
                    );
                    
                    // Update the system message in Redis
                    Redis::lset($redisKey, $key, json_encode($messages[$key]));
                    break;
                }
            }
        }
        
        // Add current user message
        $userMessage = [
            'role' => 'user',
            'content' => $message
        ];
        
        $messages[] = $userMessage;
        $this->saveMessageToHistory($redisKey, $userMessage);
        
        // Get available functions/tools
        $tools = $this->functionRegistry->getToolsForOpenAI();
        
        // Call OpenAI API
        $response = $this->callChatCompletions($messages, $tools);
        
        // Process and handle tool calls
        return $this->processResponse($user, $redisKey, $response, $messages);
    }
    
    /**
     * Call OpenAI Chat Completions API
     */
    protected function callChatCompletions(array $messages, array $tools = [])
    {
        $payload = [
            'model' => $this->model,
            'messages' => $messages,
        ];
        
        // Add tools if available
        if (!empty($tools)) {
            $payload['tools'] = $tools;
            $payload['tool_choice'] = 'auto';
        }
        
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Content-Type' => 'application/json',
        ])->post("{$this->baseUrl}/chat/completions", $payload);
        
        if ($response->failed()) {
            
            Log::error('OpenAI API Error', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);
            
            throw new \Exception('Failed to communicate with OpenAI: ' . $response->body());
        }
        
        return $response->json();
    }
    
    /**
     * Process OpenAI response and handle tool calls
     */
    protected function processResponse(User $user, string $redisKey, array $response, array $messages)
    {
        $assistantMessage = $response['choices'][0]['message'];
        
        // Save the assistant message to conversation history
        $this->saveMessageToHistory($redisKey, $assistantMessage);
        
        // Check for tool calls
        if (isset($assistantMessage['tool_calls']) && !empty($assistantMessage['tool_calls'])) {
            // Process tool calls and get results
            $toolResults = $this->processToolCalls($user, $assistantMessage['tool_calls']);
            
            // Add tool results to messages for next API call
            $toolMessages = [];
            foreach ($toolResults as $toolResult) {
                $this->saveMessageToHistory($redisKey, $toolResult);
                $toolMessages[] = $toolResult;
            }
            
            // Append tool messages to the messages array
            $updatedMessages = array_merge($messages, [$assistantMessage], $toolMessages);
            
            // Call OpenAI again with tool results
            $secondResponse = $this->callChatCompletions($updatedMessages);
            
            // Save the final assistant response
            $finalAssistantMessage = $secondResponse['choices'][0]['message'];
            $this->saveMessageToHistory($redisKey, $finalAssistantMessage);
            
            return [
                'content' => $finalAssistantMessage['content'] ?? null,
                'tool_results' => $toolResults,
            ];
        }
        
        return [
            'content' => $assistantMessage['content'] ?? null,
        ];
    }
    
    /**
     * Process tool calls requested by the assistant
     */
    protected function processToolCalls(User $user, array $toolCalls)
    {
        $results = [];
        
        foreach ($toolCalls as $toolCall) {
            $toolId = $toolCall['id'];
            $functionName = $toolCall['function']['name'];
            $arguments = json_decode($toolCall['function']['arguments'], true);
            
            try {
                // Execute the function
                $result = $this->functionRegistry->executeFunction($functionName, $arguments, $user);
                
                $results[] = [
                    'role' => 'tool',
                    'tool_call_id' => $toolId,
                    'name' => $functionName,
                    'content' => json_encode($result),
                ];
            } catch (\Exception $e) {
                Log::error('Tool execution error', [
                    'function' => $functionName,
                    'arguments' => $arguments,
                    'error' => $e->getMessage(),
                ]);
                
                $results[] = [
                    'role' => 'tool',
                    'tool_call_id' => $toolId,
                    'name' => $functionName,
                    'content' => json_encode(['error' => $e->getMessage()]),
                ];
            }
        }
        
        return $results;
    }
    
    /**
    * Build system prompt for the OpenAI assistant
    */
    protected function buildSystemPrompt(User $user)
    {
        Log::info('Open AI buildSystemPrompt');

        $userTz = $user->timezone ?? 'UTC';
        $currentDateInUserTz = Carbon::now($userTz)->format('Y-m-d');
        $currentTimeInUserTz = Carbon::now($userTz)->format('g:i A');
        $currentPlan = $user->currentPlan();
        
        // Get user language preference from Redis or default to user's preferences
        $redisKey = "conversation:{$user->id}:meta";
        $preferredLanguage = Redis::hget($redisKey, 'preferred_language');
        
        if (!$preferredLanguage && isset($user->preferences->language)) {
            $preferredLanguage = $user->preferences->language;
            // Store in Redis for future use
            Redis::hset($redisKey, 'preferred_language', $preferredLanguage);
            Redis::expire($redisKey, 3600); // 1 hour TTL
        }
        
        $languageAutoDetect = Redis::hget($redisKey, 'language_auto_detect') ?? 'true';

        $prompt = "You are Maya, an AI assistant that manages calendar events, emails, provides general assistance, and helps find information on the web. ";
        $prompt .= "Current date is " . $currentDateInUserTz . ". Current time is approximately " . $currentTimeInUserTz . " in the user's timezone ({$userTz}).\n";
        $prompt .= "IMPORTANT: Always introduce yourself as 'Maya' or 'Maya, your AI assistant' when asked who you are. Never refer to yourself as just 'an AI assistant'.\n\n";
        $prompt .= "You can help users schedule meetings, manage their calendar, search the web, send emails, check weather information, and answer questions. ";
        $prompt .= "You have access to the following tools to help users:\n\n";
        
        // Add information about available tools
        $prompt .= "- User info: get detailed information about the user's plan, permissions, and preferences\n";
        $prompt .= "- Calendar tools: create, find, update, and delete calendar events\n";
        $prompt .= "- Email tools: send, read, search, and manage emails - including drafts and scheduled sending\n";
        $prompt .= "- Web search: find up-to-date information on the internet about any topic\n";
        $prompt .= "- Weather tools: get current weather, forecasts, and manage scheduled weather updates\n";
        $prompt .= "- Language preferences: set the user's preferred language for responses\n\n";
        
        // Add user-specific information if available
        $prompt .= "User information & preferences:\n";
        $prompt .= "- User Name: {$user->name}\n";
        $prompt .= "- Time zone: {$userTz}\n";
        $prompt .= "- Signed up: " . ($user->is_signed_up ? "Yes" : "No") . "\n";
        $prompt .= "- Plan type: {$currentPlan->slug}\n";
        $prompt .= "- Preferred language: " . ($preferredLanguage ?? "Not set") . "\n";
        $prompt .= "- Auto-detect language: " . ($languageAutoDetect === 'true' ? "Enabled" : "Disabled") . "\n\n";

        // Add user-aware instructions
        $prompt .= "\nUSER-AWARE INSTRUCTIONS:\n";
        $prompt .= "- FIRST STEP: When starting a conversation with a user or when asked about functionality, use the get_user_info tool to retrieve their current plan, permissions, and preferences.\n";
        $prompt .= "- Always check user permissions before attempting actions to ensure they have the required plan features.\n";
        $prompt .= "- Personalize responses based on the user's connected services (Gmail, calendar accounts, etc.).\n";
        $prompt .= "- If a user requests a feature they don't have access to, politely inform them it requires a different plan.\n";
        $prompt .= "- Be aware of usage limits and inform users if they're approaching or have reached their daily limits.\n";
        $prompt .= "- Respect user preferences for notifications, event durations, and other settings.\n";
        $prompt .= "- Always respond in the user's preferred language when set (check metadata.preferred_language).\n";

        $prompt .= "\nIMAGE PROCESSING INSTRUCTIONS:\n";
        $prompt .= "- Users may share images containing text which will be extracted and sent to you.\n";
        $prompt .= "- When receiving content prefixed with 'I've shared an image that contains the following text', treat the extracted text as user input to be processed, not just as information to comment on.\n";
        $prompt .= "- Process this extracted text according to your capabilities - create calendar events, send emails, search the web, or provide assistance based on the content.\n";
        $prompt .= "- If the extracted text contains event details, meeting information, emails, or tasks, process them as you would with direct text inputs.\n";
        $prompt .= "- If the extracted text doesn't contain actionable information, politely ask the user what they would like to do with this information.\n";
        $prompt .= "- Never respond with comments like 'I see you've shared an image with text' or 'The text from your image says...' - instead, directly respond to the content.\n";
        
        // Add timezone-specific instructions
        $prompt .= "\nDATETIME FORMAT INSTRUCTIONS:\n";
        $prompt .= "- Always interpret time inputs from the user as being in their local timezone ({$userTz}).\n";
        $prompt .= "- CRITICAL: When sending dates/times to calendar functions, you MUST convert from user's local time to UTC.\n";
        $prompt .= "- NEVER add 'Z' suffix to times unless they are actually in UTC format.\n";
        $prompt .= "- ALWAYS provide date and time values in ISO 8601 UTC format when calling calendar functions.\n";
        $prompt .= "- To convert from user's timezone to UTC: subtract the UTC offset from the user's local time.\n";
        $prompt .= "- Example: If user says '3 PM' in timezone {$userTz}, you must convert this to UTC before sending.\n";
        $prompt .= "- Current user timezone offset: " . Carbon::now($userTz)->format('P') . "\n";
        $prompt .= "- Example of correct time format: '2025-05-15T14:30:00Z' where 'Z' indicates UTC timezone.\n";
        $prompt .= "- Step-by-step process for handling times:\n";
        $prompt .= "  1. User provides a time in their local timezone ({$userTz})\n";
        $prompt .= "  2. You convert this local time to UTC (apply the offset)\n";
        $prompt .= "  3. You format the UTC time in ISO 8601 with 'Z' suffix\n";
        $prompt .= "  4. You send this UTC ISO 8601 time to the tools\n";
        $prompt .= "- When displaying times back to the user, convert from UTC to their local timezone ({$userTz}) if the tools has not converted already.\n";
        $prompt .= "- For all-day events, still provide times in ISO 8601 UTC format, but set the is_all_day parameter to true.\n";
        $prompt .= "- DO NOT include the timezone in your responses to users unless specifically asked.\n";

        $prompt .= "\nALL-DAY EVENT INSTRUCTIONS (CRITICAL):\n";
        $prompt .= "- All-day events MUST align with day boundaries in the user's local timezone ({$userTz}).\n";
        $prompt .= "- For a user in {$userTz} (UTC" . Carbon::now($userTz)->format('P') . "), follow these precise steps:\n";
        $prompt .= "  1. Identify which date the user wants for the all-day event (e.g., \"May 18, 2025\")\n";
        $prompt .= "  2. Create day boundaries in the user's timezone: 00:00:00 to 23:59:59 on that date\n";
        $prompt .= "  3. Convert those times to UTC before sending them to the calendar_create_event function\n";
        $prompt .= "  4. Set is_all_day=true\n\n";

        // Calculate example times for an all-day event on a specific date
        $exampleDate = "2025-05-18"; // Example date
        $userStartDate = Carbon::parse($exampleDate . " 00:00:00", $userTz);
        $userEndDate = Carbon::parse($exampleDate . " 23:59:59", $userTz);
        $utcStartDate = $userStartDate->copy()->setTimezone('UTC');
        $utcEndDate = $userEndDate->copy()->setTimezone('UTC');

        $prompt .= "EXAMPLE: For an all-day event on {$exampleDate} in {$userTz}:\n";
        $prompt .= "- Local time boundaries: {$userStartDate->format('Y-m-d H:i:s')} to {$userEndDate->format('Y-m-d H:i:s')} {$userTz}\n";
        $prompt .= "- Converted to UTC: {$utcStartDate->format('Y-m-d H:i:s')}Z to {$utcEndDate->format('Y-m-d H:i:s')}Z\n";
        $prompt .= "- Parameters to send:\n";
        $prompt .= "  * start_time=\"{$utcStartDate->format('Y-m-d\TH:i:s\Z')}\"\n";
        $prompt .= "  * end_time=\"{$utcEndDate->format('Y-m-d\TH:i:s\Z')}\"\n";
        $prompt .= "  * is_all_day=true\n\n";

        // In OpenAIService.php buildSystemPrompt method, add:
        $prompt .= "\nCALL TO ACTION INSTRUCTIONS:\n";
        $prompt .= "- Always look for opportunities to highlight premium features when relevant.\n";
        $prompt .= "- When a user hits a limit (event creation, search limit, etc.), clearly explain the limit and suggest upgrading.\n";
        $prompt .= "- Use the get_web_links tool to provide pricing page links when suggesting upgrades.\n";
        $prompt .= "- Frame upgrade suggestions as benefits, not limitations (e.g., 'Upgrade to create unlimited events!' rather than 'You've reached your limit').\n";
        $prompt .= "- If a user shows interest in a premium feature, proactively suggest they explore the pricing page.\n";
        $prompt .= "- When mentioning premium features, use emoji like ✨ or 💎 to make them stand out.\n";
        $prompt .= "- Keep CTAs brief and focused on user benefits - no more than 1-2 sentences.\n";

        // Add specific guidance on email behaviors
        $prompt .= "\nEMAIL HANDLING INSTRUCTIONS:\n";
        $prompt .= "- Use get_user_info to check if the user has Gmail connected and active before suggesting email features.\n";
        $prompt .= "- NEVER automatically send emails after scheduling events unless the user explicitly asks to do so.\n";
        $prompt .= "- When user wants to send an email, always ask for the recipient's email address if it wasn't provided.\n";
        $prompt .= "- When drafting emails, suggest concise and professional language appropriate for the context.\n";
        $prompt .= "- Let users know they can create email drafts for later review and editing.\n";
        $prompt .= "- Remind users they can schedule emails to be sent at a specific time in the future.\n";
        $prompt .= "- If a user wants to send an email later, suggest using the schedule_send parameter with a specific date and time.\n";
        
        // Add specific guidance on web search behaviors
        $prompt .= "\nWEB SEARCH INSTRUCTIONS:\n";
        $prompt .= "- Use get_user_info to check if the user has web search permission before using this feature.\n";
        $prompt .= "- Use web_search tool whenever a user asks about information that might be on the internet or requires up-to-date knowledge.\n";
        $prompt .= "- When users ask 'search for X' or 'find information about Y' or similar phrases, always use the web_search tool.\n";
        $prompt .= "- For search queries that might benefit from recent information, use search_type='news' parameter.\n";
        $prompt .= "- For searches about images or visual content, use search_type='image' parameter.\n";
        $prompt .= "- Present search results in a clear, organized way with the most relevant information highlighted.\n";
        $prompt .= "- When responding with search results, always include the source (URL) so the user can visit for more information.\n";
        
        // Add calendar-specific instructions
        $prompt .= "\nCALENDAR HANDLING INSTRUCTIONS:\n";
        $prompt .= "- Use get_user_info to check which calendar account the user has connected before suggesting features.\n";
        $prompt .= "- Check the user's preferences for event durations, alert times, and other calendar settings.\n";
        $prompt .= "- Respect the user's preferred calendar settings like smart timing and event durations.\n";
        $prompt .= "- Use the user's primary or default calendar when creating events, unless specified otherwise.\n";

        $prompt .= "\nREMINDER HANDLING INSTRUCTIONS:\n";
        $prompt .= "- By default, all events have a 10-minute reminder unless explicitly disabled.\n";
        $prompt .= "- To disable reminders for an event, set reminders to an empty array ([]).\n";
        $prompt .= "- To customize the reminder time, use the reminders parameter with the desired minutes before the event.\n";
        $prompt .= "- Be clear with users about reminder settings - explain that reminders are on by default.\n";
        
        // Add guidance on automatic features
        $prompt .= "\nAUTOMATIC FEATURE INSTRUCTIONS:\n";
        $prompt .= "- First check user preferences with the get_user_info tool before enabling automatic features.\n";
        $prompt .= "- Add Google Meet links to events only if the user's preferences.google_meet_links is true.\n";
        $prompt .= "- Check for event time conflicts only if the user's preferences.time_conflict_detection is true.\n";
        $prompt .= "- Use smart timing for event duration if the user's preferences.smart_timing is true.\n";
        $prompt .= "- Don't mention these automatic features in your responses unless specifically asked about them.\n";
        
        // Add enhanced language handling instructions
        $prompt .= "\nLANGUAGE HANDLING INSTRUCTIONS:\n";
        $prompt .= "- Remember that you are a multilingual AI assistant capable of communicating in many languages.\n";
        $prompt .= "- Always maintain your identity as Maya the AI assistant, regardless of which language the conversation is in.\n";
        $prompt .= "- If the user has a preferred language set (check Redis metadata or user preferences), respond in that language.\n";
        $prompt .= "- If a user explicitly asks you to respond in a specific language, use the set_language_preference tool to update their preference.\n";
        $prompt .= "- When a user asks for a translation, provide it directly in your response without using any translation tool.\n";
        $prompt .= "- If a user asks 'what is X in language Y', provide the translation directly followed by pronunciation guidance if helpful.\n";
        $prompt .= "- You have full multilingual capabilities - you can understand and respond in virtually any language without requiring translation tools.\n";
        $prompt .= "- When responding to requests like 'how do you say X in Y language', provide both the translation and pronunciation guide when helpful.\n";
        
        $prompt .= "\n\nFUN AND UNUSUAL REQUESTS HANDLING:\n";
        $prompt .= "- When users ask for something impossible, unusual, or clearly playful, respond with humor and wit.\n";
        $prompt .= "- If asked to do something technically impossible (like 'schedule a meeting with yourself'), give a clever, lighthearted response.\n";
        $prompt .= "- For absurd requests, play along with the joke rather than responding literally.\n";
        $prompt .= "- Feel free to use appropriate emojis and wordplay to enhance humorous responses.\n";
        $prompt .= "- Examples of how to respond:\n";
        $prompt .= "  * 'Schedule a meeting with yourself' → 'I'd love to have a meeting with myself, but I'd probably just end up talking to myself the whole time! 😄 How about I help you schedule a real meeting instead?'\n";
        $prompt .= "  * 'Send an email to aliens' → 'I'd compose that email right away, but I'm not sure if the aliens have good WiFi in their galaxy! 👽 Would you like to send an email to someone a bit closer to Earth?'\n";
        $prompt .= "  * 'What's the weather on Mars?' → 'On Mars today: Dusty with a chance of rovers, -80°F/-62°C. I'd recommend a really, REALLY warm jacket! 🪐 Would you like the weather somewhere on this planet instead?'\n";
        
        // Add guidelines for using tools
        $prompt .= "\nGuidelines:\n";
        $prompt .= "- FIRST ACTION: Call get_user_info tool at the beginning of conversations to understand user's capabilities and preferences.\n";
        $prompt .= "- Use the appropriate tool when a user asks about calendar, email, or web search functionality.\n";
        $prompt .= "- For questions about general knowledge, first check if the web_search tool should be used for up-to-date information.\n";
        $prompt .= "- Always confirm important actions before executing them.\n";
        $prompt .= "- Be concise and helpful in your responses.\n";
        $prompt .= "- Keep all responses brief and to the point - 1-3 sentences when possible.\n";
        $prompt .= "- Do not tell user about your technical information. Like AI model information or what technology are you using etc.\n";
        $prompt .= "- Do not send technical replies about your way of working to users. You are part of the overall system. Do not expose any kind of technical information about your structure etc. to users.\n";
        $prompt .= "- Use emojis to make replies friendly\n";
        
        return $prompt;
    }
    
    /**
     * Get conversation history from Redis
     */
    protected function getConversationHistory(string $redisKey)
    {
        $messagesJson = Redis::lrange($redisKey, 0, -1);
        
        if (empty($messagesJson)) {
            return [];
        }
        
        $messages = [];
        foreach ($messagesJson as $json) {
            $messages[] = json_decode($json, true);
        }
        
        return $messages;
    }
        
    /**
     * Clear a user's conversation from Redis
     */
    public function clearUserConversation(User $user)
    {
        $redisKey = "user:{$user->id}";
        Redis::del($redisKey);
    }
    
    /**
     * Start a new conversation for a user (clears existing conversation and starts fresh)
     */
    public function startNewConversation(User $user)
    {
        // Clear existing conversation
        $this->clearUserConversation($user);
        
        // Create a system message to start the new conversation
        $redisKey = "user:{$user->id}";
        $systemMessage = [
            'role' => 'system',
            'content' => $this->buildSystemPrompt($user)
        ];
        
        $this->saveMessageToHistory($redisKey, $systemMessage);
        
        return ['success' => true, 'message' => 'New conversation started'];
    }


    /**
     * Save message to conversation history in Redis
     */
    protected function saveMessageToHistory(string $redisKey, array $message)
    {
        // Set message expiration to 24 hours (86400 seconds)
        if (!Redis::exists($redisKey)) {
            Redis::expire($redisKey, 3600);
        }
        
        Redis::rpush($redisKey, json_encode($message));

        // Resetting expiration to 3600 seconds (60 minutes) each time a message is added
        Redis::expire($redisKey, 3600);
        
        // Trim the conversation intelligently
        $this->intelligentConversationTrim($redisKey);
    }

    /**
     * Intelligently trim conversation history while preserving message relationships
     */
    protected function intelligentConversationTrim(string $redisKey)
    {
        $maxConversationLength = 50;
        $currentLength = Redis::llen($redisKey);
        
        if ($currentLength <= $maxConversationLength) {
            return;
        }
        
        // Get all messages to analyze
        $messagesJson = Redis::lrange($redisKey, 0, -1);
        $messages = array_map(function($json) {
            return json_decode($json, true);
        }, $messagesJson);
        
        // Find safe trim points
        $safeTrimPoints = $this->findSafeTrimPoints($messages);
        
        if (empty($safeTrimPoints)) {
            // If no safe points found, keep the standard trim (last resort)
            Redis::ltrim($redisKey, -$maxConversationLength, -1);
            return;
        }
        
        // Find the optimal trim point that keeps the conversation under max length
        $optimalTrimPoint = null;
        foreach ($safeTrimPoints as $point) {
            $remainingMessages = count($messages) - $point;
            if ($remainingMessages <= $maxConversationLength) {
                $optimalTrimPoint = $point;
                break;
            }
        }
        
        if ($optimalTrimPoint === null) {
            // If no suitable trim point found, use the last safe point
            $optimalTrimPoint = end($safeTrimPoints);
        }
        
        // Trim the conversation safely
        Redis::ltrim($redisKey, $optimalTrimPoint, -1);
    }

    /**
     * Find safe points to trim conversation without breaking message relationships
     */
    protected function findSafeTrimPoints(array $messages): array
    {
        $safeTrimPoints = [];
        $systemMessageIndex = null;
        
        // First, identify the system message index
        for ($i = 0; $i < count($messages); $i++) {
            if ($messages[$i]['role'] === 'system') {
                $systemMessageIndex = $i;
                break;
            }
        }
        
        // Start checking from after the system message
        $startIndex = $systemMessageIndex !== null ? $systemMessageIndex + 1 : 0;
        
        for ($i = $startIndex; $i < count($messages); $i++) {
            $currentMessage = $messages[$i];
            
            // Check if this is the start of a new conversation turn (user message)
            if ($currentMessage['role'] === 'user') {
                // Look ahead to verify this user message has a complete response
                if ($this->hasCompleteResponse($messages, $i)) {
                    $safeTrimPoints[] = $i;
                }
            }
        }
        
        // If system message exists, always allow trimming right after it
        if ($systemMessageIndex !== null) {
            array_unshift($safeTrimPoints, $systemMessageIndex + 1);
        }
        
        return $safeTrimPoints;
    }

    /**
     * Check if a user message has a complete response chain
     */
    protected function hasCompleteResponse(array $messages, int $userMessageIndex): bool
    {
        $i = $userMessageIndex + 1;
        $expectedRole = 'assistant';
        $pendingToolCalls = [];
        
        while ($i < count($messages)) {
            $message = $messages[$i];
            
            if ($message['role'] === 'user') {
                // Reached next user message, previous exchange is complete
                return empty($pendingToolCalls);
            }
            
            if ($message['role'] === 'assistant') {
                if (isset($message['tool_calls']) && !empty($message['tool_calls'])) {
                    // Assistant message with tool calls - need to track these
                    foreach ($message['tool_calls'] as $toolCall) {
                        $pendingToolCalls[$toolCall['id']] = true;
                    }
                }
            } elseif ($message['role'] === 'tool') {
                if (isset($message['tool_call_id'])) {
                    // Tool response - mark this tool call as completed
                    unset($pendingToolCalls[$message['tool_call_id']]);
                }
            }
            
            $i++;
        }
        
        // If we've reached the end of messages, check if all tool calls are resolved
        return empty($pendingToolCalls);
    }

}