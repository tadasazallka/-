<?php

namespace App\Services\OpenAI;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\User;

/**
 * Extension to OpenAIService with additional methods for multi-agent architecture
 */
class OpenAIServiceExtension
{
    protected $apiKey;
    protected $model;
    protected $baseUrl = 'https://api.openai.com/v1';
    
    public function __construct()
    {
        $this->apiKey = config('services.openai.api_key');
        $this->model = config('services.openai.model', 'gpt-4-turbo');
    }
    
    /**
     * Send a basic completion request to OpenAI (for intent detection, etc.)
     * 
     * @param array $messages The messages to send
     * @param array $options Additional options for the API request
     * @return array The API response
     */
    public function sendBasicCompletion(array $messages, array $options = []): array
    {
        // Default options
        $defaultOptions = [
            'model' => $this->model,
            'temperature' => 0.7,
            'max_tokens' => 300,
        ];
        
        // Merge with provided options
        $options = array_merge($defaultOptions, $options);
        $options['messages'] = $messages;
        
        // Make the API request
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Content-Type' => 'application/json',
        ])->post("{$this->baseUrl}/chat/completions", $options);
        
        if ($response->failed()) {
            Log::error('OpenAI API Error', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);
            
            throw new \Exception('Failed to communicate with OpenAI: ' . $response->body());
        }
        
        return $response->json();
    }
    
    /**
     * Detect language of a text
     * 
     * @param string $text The text to detect language for
     * @return string The detected language code
     */
    public function detectLanguage(string $text): string
    {
        try {
            $prompt = "Identify the language of the following text and respond with only the ISO 639-1 language code (e.g., 'en' for English, 'es' for Spanish, 'fr' for French, etc.):";
            
            $response = $this->sendBasicCompletion([
                [
                    'role' => 'system',
                    'content' => $prompt
                ],
                [
                    'role' => 'user',
                    'content' => $text
                ]
            ], [
                'max_tokens' => 10,
                'temperature' => 0.3
            ]);
            
            $languageCode = trim(strtolower($response['choices'][0]['message']['content'] ?? 'en'));
            return strlen($languageCode) <= 5 ? $languageCode : 'en';
        } catch (\Exception $e) {
            Log::error('Failed to detect language: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return 'en'; // Default to English on error
        }
    }
    
    /**
     * Translate text to English
     * 
     * @param string $text The text to translate
     * @param string $sourceLanguage The source language code
     * @return string The translated text
     */
    public function translateToEnglish(string $text, string $sourceLanguage): string
    {
        try {
            $response = $this->sendBasicCompletion([
                [
                    'role' => 'system',
                    'content' => "Translate the following text from {$sourceLanguage} to English. Preserve the meaning, intent, and tone. Return only the translated text without any additional comments."
                ],
                [
                    'role' => 'user',
                    'content' => $text
                ]
            ], [
                'temperature' => 0.3
            ]);
            
            return $response['choices'][0]['message']['content'] ?? $text;
        } catch (\Exception $e) {
            Log::error('Failed to translate text to English: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return $text; // Return original text on error
        }
    }
    
    /**
     * Translate text from English to another language
     * 
     * @param string $text The text to translate
     * @param string $targetLanguage The target language code
     * @return string The translated text
     */
    public function translateFromEnglish(string $text, string $targetLanguage): string
    {
        try {
            $response = $this->sendBasicCompletion([
                [
                    'role' => 'system',
                    'content' => "Translate the following text from English to {$targetLanguage}. Preserve the meaning, intent, and tone. Return only the translated text without any additional comments."
                ],
                [
                    'role' => 'user',
                    'content' => $text
                ]
            ], [
                'temperature' => 0.3
            ]);
            
            return $response['choices'][0]['message']['content'] ?? $text;
        } catch (\Exception $e) {
            Log::error('Failed to translate text from English: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return $text; // Return original text on error
        }
    }
    
    /**
     * Transcribe audio to text using OpenAI's Whisper API
     * 
     * @param string $audioFilePath Path to the audio file
     * @return string|null The transcribed text or null on failure
     */
    public function transcribeAudio(string $audioFilePath): ?string
    {
        try {
            if (!file_exists($audioFilePath)) {
                Log::error('Audio file not found', ['path' => $audioFilePath]);
                return null;
            }
            
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
            ])->attach(
                'file', file_get_contents($audioFilePath), basename($audioFilePath)
            )->post($this->baseUrl . '/audio/transcriptions', [
                'model' => 'whisper-1',
            ]);
            
            if ($response->successful()) {
                $responseData = $response->json();
                return $responseData['text'] ?? null;
            } else {
                Log::error('OpenAI Whisper API error', [
                    'status' => $response->status(),
                    'body' => $response->body(),
                ]);
                return null;
            }
        } catch (\Exception $e) {
            Log::error('Failed to transcribe audio: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return null;
        }
    }
    
    /**
     * Extract text from an image using OpenAI's Vision API
     * 
     * @param string $imageUrl URL to the image
     * @return string|null The extracted text or null on failure
     */
    public function extractTextFromImage(string $imageUrl): ?string
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
            ])->post($this->baseUrl . '/chat/completions', [
                'model' => 'gpt-4-vision-preview',
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => [
                            [
                                'type' => 'text',
                                'text' => 'Extract all the text content from this image. If there are details about an event (dates, times, location, title), please format them clearly. Return only the extracted text without any commentary.'
                            ],
                            [
                                'type' => 'image_url',
                                'image_url' => [
                                    'url' => $imageUrl,
                                ],
                            ],
                        ],
                    ],
                ],
                'max_tokens' => 500,
                'temperature' => 0.3,
            ]);
            
            if ($response->successful()) {
                $responseData = $response->json();
                return $responseData['choices'][0]['message']['content'] ?? null;
            } else {
                Log::error('OpenAI Vision API error', [
                    'status' => $response->status(),
                    'body' => $response->body(),
                ]);
                return null;
            }
        } catch (\Exception $e) {
            Log::error('Failed to extract text from image: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return null;
        }
    }
}