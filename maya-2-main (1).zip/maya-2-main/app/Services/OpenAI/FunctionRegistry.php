<?php

namespace App\Services\OpenAI;

use App\Services\Tools\FindEventsTools;
use App\Services\Tools\CreateEventTools;
use App\Services\Tools\UpdateEventTools;
use App\Services\Tools\DeleteEventTools;
use App\Services\Tools\CheckTimeConflictsTools;
use App\Services\Tools\ReadEmailTools;
use App\Services\Tools\SendEmailTools;
use App\Services\Tools\SearchEmailTools;
use App\Services\Tools\DraftEmailTools;
use App\Services\Tools\GetCurrentWeatherTools;
use App\Services\Tools\WebLinksTools;
use App\Services\Tools\WebSearchTools;
use App\Services\Tools\GetUserPlanTools;
use App\Services\Tools\UserInfoTools;
use App\Services\Tools\LanguagePreferenceTools;
use App\Services\Tools\GetLanguageInfoTools;
use App\Services\Tools\GetWeatherForecastTools;
use App\Services\Tools\ManageWeatherScheduleTools;
use App\Services\Tools\ScheduledEmailTools;
use Illuminate\Support\Facades\App;

class FunctionRegistry
{
    protected $tools = [];
    
    /**
     * Register all available tools
     */
    public function __construct()
    {
        // Register calendar tools
        $this->registerTool(FindEventsTools::class);
        $this->registerTool(CreateEventTools::class);
        $this->registerTool(UpdateEventTools::class);
        $this->registerTool(DeleteEventTools::class);
        $this->registerTool(CheckTimeConflictsTools::class); // Add the new time conflict checker tool
        
        // Helper Tools
        $this->registerTool(WebLinksTools::class);
        $this->registerTool(UserInfoTools::class);
        $this->registerTool(LanguagePreferenceTools::class);
        $this->registerTool(GetLanguageInfoTools::class);
        
        // Register Gmail tools
        $this->registerTool(ReadEmailTools::class);
        $this->registerTool(SendEmailTools::class);
        $this->registerTool(SearchEmailTools::class);
        $this->registerTool(DraftEmailTools::class);
        $this->registerTool(ScheduledEmailTools::class);
        
        // Register search tools
        $this->registerTool(WebSearchTools::class);

        // Register weather tools
        $this->registerTool(GetCurrentWeatherTools::class);
        $this->registerTool(GetWeatherForecastTools::class);
        $this->registerTool(ManageWeatherScheduleTools::class);
    }
    
    /**
     * Register a tool
     */
    public function registerTool(string $toolClass)
    {
        $instance = App::make($toolClass);
        $this->tools[$instance->getName()] = $instance;
    }
    
    /**
     * Get all tools formatted for OpenAI API
     */
    public function getToolsForOpenAI()
    {
        $tools = [];
        
        foreach ($this->tools as $name => $instance) {
            $tools[] = [
                'type' => 'function',
                'function' => [
                    'name' => $name,
                    'description' => $instance->getDescription(),
                    'parameters' => $instance->getParameters(),
                ]
            ];
        }
        
        return $tools;
    }
    
    /**
     * Execute a function by name
     */
    public function executeFunction(string $name, array $arguments, $user)
    {
        if (!isset($this->tools[$name])) {
            throw new \Exception("Function not found: {$name}");
        }
        
        return $this->tools[$name]->execute($arguments, $user);
    }
    
    /**
     * Get a list of all registered tool names
     */
    public function getToolNames()
    {
        return array_keys($this->tools);
    }
}