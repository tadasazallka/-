<?php

namespace App\Services;

use App\Models\User;
use App\Services\TimezoneService;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Carbon;

class CalendarInfoService
{
    protected $timezoneService;
    
    // Confirmation threshold
    const CONFIDENCE_THRESHOLD = 0.7;
    
    public function __construct(TimezoneService $timezoneService)
    {
        $this->timezoneService = $timezoneService;
    }
    
    /**
     * Handle calendar info intent (general upcoming events)
     */
    public function handleCalendarInfo(User $user, string $message, array $parameters, float $confidence): string
    {
        Log::info('Handling calendar info intent', ['user_id' => $user->id, 'parameters' => $parameters]);
        
        // Get user timezone (for display only)
        $userTz = $user->timezone ?? 'UTC';
        
        // Use current time in UTC for database query
        $nowUtc = Carbon::now('UTC');
        
        Log::info('Time context for calendar info', [
            'now_utc' => $nowUtc->toIso8601String(),
            'user_timezone' => $userTz
        ]);
        
        // Get upcoming events directly using UTC comparison
        $upcomingEvents = $user->events()
            ->where('start_time', '>=', $nowUtc)
            ->orderBy('start_time')
            ->limit(5) // Limit to next 5 events
            ->get();
        
        if ($upcomingEvents->isEmpty()) {
            return "You don't have any upcoming events scheduled. Your calendar is clear!";
        }
        
        // Format the response
        $response = "Here are your upcoming events:\n\n";
        
        foreach ($upcomingEvents as $event) {
            // Convert UTC times to user's timezone for display
            $startDateTime = $this->timezoneService->utcToUser($event->start_time, $userTz);
            $endDateTime = $this->timezoneService->utcToUser($event->end_time, $userTz);
            
            Log::info('Event time conversion for display', [
                'event_id' => $event->id,
                'start_time_utc' => Carbon::parse($event->start_time)->toIso8601String(),
                'end_time_utc' => Carbon::parse($event->end_time)->toIso8601String(),
                'start_time_user' => $startDateTime->toIso8601String(),
                'end_time_user' => $endDateTime->toIso8601String(),
                'user_timezone' => $userTz
            ]);
            
            $response .= "📌 " . $event->title . "\n";
            $response .= "📆 " . $startDateTime->format('l, F j') . "\n";
            $response .= "🕒 " . $startDateTime->format('g:i A') . " - " . $endDateTime->format('g:i A') . "\n";
            
            if (!empty($event->location)) {
                $response .= "📍 " . $event->location . "\n";
            }
            
            $response .= "\n";
        }
        
        $totalEvents = $user->events()
            ->where('start_time', '>=', $nowUtc)
            ->count();
        
        if ($totalEvents > 5) {
            $response .= "You have " . ($totalEvents - 5) . " more upcoming event" . ($totalEvents - 5 > 1 ? "s" : "") . ".";
        }
        
        return $response;
    }
    
    /**
     * Handle calendar info range intent (events in a specific date range)
     */
    public function handleCalendarInfoRange(User $user, string $message, array $parameters, float $confidence): string
    {
        Log::info('Handling calendar info range intent', ['user_id' => $user->id, 'parameters' => $parameters]);
        
        // Get user timezone (for display only)
        $userTz = $user->timezone ?? 'UTC';
        
        $fromDate = $parameters['from_date'] ?? null;
        $toDate = $parameters['to_date'] ?? $fromDate;
        
        if (!$fromDate) {
            return "For which date range would you like to see your events? Please specify a start and end date.";
        }
        
        // Parse dates in user's timezone then convert to UTC for database operations
        try {
            // Create Carbon objects in user's timezone for boundary calculations
            $fromDateTime = Carbon::parse($fromDate, $userTz)->startOfDay();
            $toDateTime = Carbon::parse($toDate, $userTz)->endOfDay();
            
            // Convert to UTC for database query
            $fromDateTimeUtc = $fromDateTime->copy()->setTimezone('UTC');
            $toDateTimeUtc = $toDateTime->copy()->setTimezone('UTC');
            
            // Log the query parameters
            Log::info('Date range query parameters', [
                'user_timezone' => $userTz,
                'from_date_user' => $fromDateTime->toIso8601String(),
                'to_date_user' => $toDateTime->toIso8601String(),
                'from_date_utc' => $fromDateTimeUtc->toIso8601String(),
                'to_date_utc' => $toDateTimeUtc->toIso8601String()
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to parse date range', [
                'from_date' => $fromDate,
                'to_date' => $toDate,
                'error' => $e->getMessage()
            ]);
            
            return "I couldn't understand the date range. Please use a format like 'January 1, 2025' or 'next Monday'.";
        }
        
        // Get events in the date range directly using UTC values
        $events = $user->events()
            ->whereBetween('start_time', [$fromDateTimeUtc, $toDateTimeUtc])
            ->orderBy('start_time')
            ->get();
        
        if ($events->isEmpty()) {
            return "You don't have any events scheduled between " . $fromDateTime->format('M j, Y') . " and " . $toDateTime->format('M j, Y') . ".";
        }
        
        // Format the response
        $response = "Here are your events between " . $fromDateTime->format('M j, Y') . " and " . $toDateTime->format('M j, Y') . ":\n\n";
        
        foreach ($events as $event) {
            // Convert UTC times to user's timezone for display
            $startDateTime = $this->timezoneService->utcToUser($event->start_time, $userTz);
            $endDateTime = $this->timezoneService->utcToUser($event->end_time, $userTz);
            
            Log::info('Event time conversion for display in range query', [
                'event_id' => $event->id,
                'start_time_utc' => Carbon::parse($event->start_time)->toIso8601String(),
                'end_time_utc' => Carbon::parse($event->end_time)->toIso8601String(),
                'start_time_user' => $startDateTime->toIso8601String(),
                'end_time_user' => $endDateTime->toIso8601String(),
                'user_timezone' => $userTz
            ]);
            
            $response .= "📌 " . $event->title . "\n";
            $response .= "📆 " . $startDateTime->format('l, F j') . "\n";
            $response .= "🕒 " . $startDateTime->format('g:i A') . " - " . $endDateTime->format('g:i A') . "\n";
            
            if (!empty($event->location)) {
                $response .= "📍 " . $event->location . "\n";
            }
            
            $response .= "\n";
        }
        
        return $response;
    }
    
    /**
     * Handle calendar info by title intent (find events by title)
     */
    public function handleCalendarInfoByTitle(User $user, string $message, array $parameters, float $confidence): string
    {
        Log::info('Handling calendar info by title intent', ['user_id' => $user->id, 'parameters' => $parameters]);
        
        // Get user timezone (for display only)
        $userTz = $user->timezone ?? 'UTC';
        
        // Create now() in UTC for database query
        $nowUtc = Carbon::now('UTC');
        
        $title = $parameters['title'] ?? null;
        
        if (empty($title)) {
            return "Which event would you like information about? Please provide the title.";
        }
        
        // Search for events with similar titles - all comparisons in UTC
        $events = $user->events()
            ->where('title', 'like', '%' . $title . '%')
            ->where('start_time', '>=', $nowUtc)
            ->orderBy('start_time')
            ->get();
        
        if ($events->isEmpty()) {
            return "I couldn't find any upcoming events with a title similar to \"" . $title . "\".";
        }
        
        if ($events->count() === 1) {
            // Only one event found, show details
            $event = $events->first();
            
            // Convert UTC times to user's timezone for display
            $startDateTime = $this->timezoneService->utcToUser($event->start_time, $userTz);
            $endDateTime = $this->timezoneService->utcToUser($event->end_time, $userTz);
            
            Log::info('Event time conversion for single event by title', [
                'event_id' => $event->id,
                'start_time_utc' => Carbon::parse($event->start_time)->toIso8601String(),
                'end_time_utc' => Carbon::parse($event->end_time)->toIso8601String(),
                'start_time_user' => $startDateTime->toIso8601String(),
                'end_time_user' => $endDateTime->toIso8601String(),
                'user_timezone' => $userTz
            ]);
            
            $response = "Here are the details for \"" . $event->title . "\":\n\n";
            $response .= "📆 " . $startDateTime->format('l, F j, Y') . "\n";
            $response .= "🕒 " . $startDateTime->format('g:i A') . " - " . $endDateTime->format('g:i A') . "\n";
            
            if (!empty($event->location)) {
                $response .= "📍 " . $event->location . "\n";
            }
            
            if (!empty($event->description)) {
                $response .= "📝 " . $event->description . "\n";
            }
            
            return $response;
        } else {
            // Multiple events found, list them
            $response = "I found multiple events with titles similar to \"" . $title . "\":\n\n";
            
            foreach ($events as $event) {
                // Convert UTC times to user's timezone for display
                $startDateTime = $this->timezoneService->utcToUser($event->start_time, $userTz);
                $endDateTime = $this->timezoneService->utcToUser($event->end_time, $userTz);
                
                $response .= "📌 " . $event->title . "\n";
                $response .= "📆 " . $startDateTime->format('l, F j') . "\n";
                $response .= "🕒 " . $startDateTime->format('g:i A') . " - " . $endDateTime->format('g:i A') . "\n\n";
            }
            
            return $response;
        }
    }
    
    /**
     * Get today's events
     */
    public function handleTodaysEvents(User $user, string $message, array $parameters, float $confidence): string
    {
        Log::info('Handling today\'s events request', ['user_id' => $user->id]);
        
        // Get user timezone (for display and date boundary calculation)
        $userTz = $user->timezone ?? 'UTC';
        
        // Calculate today's date range in user's timezone
        $todayStart = Carbon::now($userTz)->startOfDay();
        $todayEnd = Carbon::now($userTz)->endOfDay();
        
        // Convert to UTC for database query
        $todayStartUtc = $todayStart->copy()->setTimezone('UTC');
        $todayEndUtc = $todayEnd->copy()->setTimezone('UTC');
        
        // Log the date ranges for debugging
        Log::info('Today date ranges', [
            'user_timezone' => $userTz,
            'today_date' => $todayStart->toDateString(),
            'today_start_user' => $todayStart->toIso8601String(),
            'today_end_user' => $todayEnd->toIso8601String(),
            'today_start_utc' => $todayStartUtc->toIso8601String(),
            'today_end_utc' => $todayEndUtc->toIso8601String()
        ]);
        
        // Get events for today using UTC values
        $events = $user->events()
            ->where('start_time', '>=', $todayStartUtc)
            ->where('start_time', '<=', $todayEndUtc)
            ->orderBy('start_time')
            ->get();
        
        // Log the found events for debugging
        if ($events->isNotEmpty()) {
            foreach ($events as $event) {
                Log::info('Found event for today', [
                    'id' => $event->id,
                    'title' => $event->title,
                    'start_time_utc' => Carbon::parse($event->start_time)->toIso8601String(),
                    'start_time_user' => $this->timezoneService->utcToUser($event->start_time, $userTz)->toIso8601String()
                ]);
            }
        } else {
            Log::info('No events found for today');
        }
        
        if ($events->isEmpty()) {
            return "You don't have any events scheduled for today.";
        }
        
        // Format the response
        $response = "Here are your events for today:\n\n";
        
        foreach ($events as $event) {
            // Convert UTC times to user's timezone for display
            $startDateTime = $this->timezoneService->utcToUser($event->start_time, $userTz);
            $endDateTime = $this->timezoneService->utcToUser($event->end_time, $userTz);
            
            $response .= "📌 " . $event->title . "\n";
            $response .= "🕒 " . $startDateTime->format('g:i A') . " - " . $endDateTime->format('g:i A') . "\n";
            
            if (!empty($event->location)) {
                $response .= "📍 " . $event->location . "\n";
            }
            
            $response .= "\n";
        }
        
        return $response;
    }
    
    /**
     * Get tomorrow's events
     */
    public function handleTomorrowsEvents(User $user, string $message, array $parameters, float $confidence): string
    {
        Log::info('Handling tomorrow\'s events request', ['user_id' => $user->id]);
        
        // Get user timezone (for display and date boundary calculation)
        $userTz = $user->timezone ?? 'UTC';
        
        // Calculate tomorrow's date range in user's timezone
        $tomorrowStart = Carbon::now($userTz)->addDay()->startOfDay();
        $tomorrowEnd = Carbon::now($userTz)->addDay()->endOfDay();
        
        // Convert to UTC for database query
        $tomorrowStartUtc = $tomorrowStart->copy()->setTimezone('UTC');
        $tomorrowEndUtc = $tomorrowEnd->copy()->setTimezone('UTC');
        
        // Log the date ranges for debugging
        Log::info('Tomorrow date ranges', [
            'user_timezone' => $userTz,
            'tomorrow_date' => $tomorrowStart->toDateString(),
            'tomorrow_start_user' => $tomorrowStart->toIso8601String(),
            'tomorrow_end_user' => $tomorrowEnd->toIso8601String(),
            'tomorrow_start_utc' => $tomorrowStartUtc->toIso8601String(),
            'tomorrow_end_utc' => $tomorrowEndUtc->toIso8601String()
        ]);
        
        // Get events for tomorrow using UTC values
        $events = $user->events()
            ->where('start_time', '>=', $tomorrowStartUtc)
            ->where('start_time', '<=', $tomorrowEndUtc)
            ->orderBy('start_time')
            ->get();
        
        if ($events->isEmpty()) {
            return "You don't have any events scheduled for tomorrow.";
        }
        
        // Format the response
        $response = "Here are your events for tomorrow:\n\n";
        
        foreach ($events as $event) {
            // Convert UTC times to user's timezone for display
            $startDateTime = $this->timezoneService->utcToUser($event->start_time, $userTz);
            $endDateTime = $this->timezoneService->utcToUser($event->end_time, $userTz);
            
            $response .= "📌 " . $event->title . "\n";
            $response .= "🕒 " . $startDateTime->format('g:i A') . " - " . $endDateTime->format('g:i A') . "\n";
            
            if (!empty($event->location)) {
                $response .= "📍 " . $event->location . "\n";
            }
            
            $response .= "\n";
        }
        
        return $response;
    }
    
    /**
     * Get this week's events
     */
    public function handleThisWeeksEvents(User $user, string $message, array $parameters, float $confidence): string
    {
        Log::info('Handling this week\'s events request', ['user_id' => $user->id]);
        
        // Get user timezone (for display and date boundary calculation)
        $userTz = $user->timezone ?? 'UTC';
        
        // Calculate this week's date range in user's timezone
        $weekStart = Carbon::now($userTz)->startOfWeek();
        $weekEnd = Carbon::now($userTz)->endOfWeek();
        
        // Convert to UTC for database query
        $weekStartUtc = $weekStart->copy()->setTimezone('UTC');
        $weekEndUtc = $weekEnd->copy()->setTimezone('UTC');
        
        // Log the date ranges for debugging
        Log::info('Week date ranges', [
            'user_timezone' => $userTz,
            'week_start_date' => $weekStart->toDateString(),
            'week_end_date' => $weekEnd->toDateString(),
            'week_start_user' => $weekStart->toIso8601String(),
            'week_end_user' => $weekEnd->toIso8601String(),
            'week_start_utc' => $weekStartUtc->toIso8601String(),
            'week_end_utc' => $weekEndUtc->toIso8601String()
        ]);
        
        // Get events for this week using UTC values
        $events = $user->events()
            ->where('start_time', '>=', $weekStartUtc)
            ->where('start_time', '<=', $weekEndUtc)
            ->orderBy('start_time')
            ->get();
        
        if ($events->isEmpty()) {
            return "You don't have any events scheduled for this week.";
        }
        
        // Format the response
        $response = "Here are your events for this week:\n\n";
        
        // Group events by day
        $eventsByDay = [];
        foreach ($events as $event) {
            // Convert UTC times to user's timezone for grouping and display
            $startDateTime = $this->timezoneService->utcToUser($event->start_time, $userTz);
            $day = $startDateTime->format('Y-m-d');
            
            if (!isset($eventsByDay[$day])) {
                $eventsByDay[$day] = [];
            }
            
            $eventsByDay[$day][] = [
                'event' => $event,
                'start_datetime' => $startDateTime,
                'end_datetime' => $this->timezoneService->utcToUser($event->end_time, $userTz)
            ];
        }
        
        // Format each day's events
        foreach ($eventsByDay as $day => $dayEvents) {
            $dayDate = Carbon::parse($day, $userTz);
            $response .= "📅 " . $dayDate->format('l, F j') . "\n";
            
            foreach ($dayEvents as $eventData) {
                $event = $eventData['event'];
                $startDateTime = $eventData['start_datetime'];
                $endDateTime = $eventData['end_datetime'];
                
                $response .= "- " . $event->title . " (" . $startDateTime->format('g:i A') . " - " . $endDateTime->format('g:i A') . ")\n";
            }
            
            $response .= "\n";
        }
        
        return $response;
    }
    
    /**
     * Get next event
     */
    public function handleNextEvent(User $user, string $message, array $parameters, float $confidence): string
    {
        Log::info('Handling next event request', ['user_id' => $user->id]);
        
        // Get user timezone (for display only)
        $userTz = $user->timezone ?? 'UTC';
        
        // Use current time in UTC for database query
        $nowUtc = Carbon::now('UTC');
        
        // Get the next upcoming event using UTC comparison
        $nextEvent = $user->events()
            ->where('start_time', '>=', $nowUtc)
            ->orderBy('start_time')
            ->first();
        
        if (!$nextEvent) {
            return "You don't have any upcoming events scheduled.";
        }
        
        // Convert UTC times to user's timezone for display
        $startDateTime = $this->timezoneService->utcToUser($nextEvent->start_time, $userTz);
        $endDateTime = $this->timezoneService->utcToUser($nextEvent->end_time, $userTz);
        
        Log::info('Next event time details', [
            'event_id' => $nextEvent->id,
            'start_time_utc' => Carbon::parse($nextEvent->start_time)->toIso8601String(),
            'end_time_utc' => Carbon::parse($nextEvent->end_time)->toIso8601String(),
            'start_time_user' => $startDateTime->toIso8601String(),
            'end_time_user' => $endDateTime->toIso8601String(),
            'user_timezone' => $userTz
        ]);
        
        // Format the response
        $response = "Your next event is:\n\n";
        $response .= "📌 " . $nextEvent->title . "\n";
        $response .= "📆 " . $startDateTime->format('l, F j, Y') . "\n";
        $response .= "🕒 " . $startDateTime->format('g:i A') . " - " . $endDateTime->format('g:i A') . "\n";
        
        if (!empty($nextEvent->location)) {
            $response .= "📍 " . $nextEvent->location . "\n";
        }
        
        if (!empty($nextEvent->description)) {
            $response .= "📝 " . $nextEvent->description . "\n";
        }
        
        // Calculate time until the event - in user's timezone for natural description
        $now = Carbon::now($userTz);
        $timeUntil = $now->diffForHumans($startDateTime, ['parts' => 2]);
        
        $response .= "\nThis event starts " . $timeUntil . ".";
        
        return $response;
    }
}