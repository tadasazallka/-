<?php

namespace App\Services\Gmail;

use App\Models\GmailAccount;
use App\Models\User;
use Google_Client;
use Google_Service_Gmail;
use Google_Service_Gmail_Message;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class GmailService
{
    /**
     * Get Gmail service for a user
     */
    public function getGmailService(User $user)
    {
        $gmailAccount = $user->gmailAccount;
        
        if (!$gmailAccount) {
            throw new \Exception('User does not have a Gmail account connected');
        }
        
        // Check if token is expired
        if ($gmailAccount->isTokenExpired()) {
            Log::info('Refreshing expired Gmail token', [
                'user_id' => $user->id,
                'account_id' => $gmailAccount->id,
                'remaining_time' => $gmailAccount->token_expires_at ? now()->diffInMinutes($gmailAccount->token_expires_at, false) : 'unknown'
            ]);
            $gmailAccount = $this->refreshToken($gmailAccount);
        }
        
        $client = $this->createGoogleClient($gmailAccount);
        return new Google_Service_Gmail($client);
    }
    
    /**
     * Create Google client with authentication
     */
    private function createGoogleClient(GmailAccount $gmailAccount)
    {
        $client = new Google_Client();
        $client->setApplicationName(config('services.google.app_name'));
        $client->setClientId(config('services.google.client_id'));
        $client->setClientSecret(config('services.google.client_secret'));
        $client->setAccessToken([
            'access_token' => $gmailAccount->access_token,
            'refresh_token' => $gmailAccount->refresh_token,
            'expires_in' => $gmailAccount->token_expires_at?->diffInSeconds(now()),
        ]);
        
        return $client;
    }
    
    /**
     * Refresh the Gmail access token
     */
    public function refreshToken(GmailAccount $gmailAccount)
    {
        try {
            $client = new Google_Client();
            $client->setClientId(config('services.google.client_id'));
            $client->setClientSecret(config('services.google.client_secret'));
            
            $newToken = $client->fetchAccessTokenWithRefreshToken($gmailAccount->refresh_token);
            
            if (isset($newToken['access_token'])) {
                $gmailAccount->access_token = $newToken['access_token'];
                $expiresIn = $newToken['expires_in'] ?? 3600;
                $gmailAccount->token_expires_at = now()->addSeconds($expiresIn);
                $gmailAccount->save();
            }
            
            return $gmailAccount;
        } catch (\Exception $e) {
            Log::error('Failed to refresh Gmail token: ' . $e->getMessage());
            throw new \Exception('Failed to refresh Gmail access token');
        }
    }
    
    /**
     * Parse a Gmail message to a structured format
     */
    public function parseMessage($message, $includeBody = false)
    {
        $messageId = $message->getId();
        $headers = $message->getPayload()->getHeaders();
        
        // Parse headers
        $parsedHeaders = [];
        foreach ($headers as $header) {
            $parsedHeaders[$header->getName()] = $header->getValue();
        }
        
        // Extract important headers
        $from = $parsedHeaders['From'] ?? '';
        $to = $parsedHeaders['To'] ?? '';
        $subject = $parsedHeaders['Subject'] ?? '(No Subject)';
        $date = $parsedHeaders['Date'] ?? '';
        
        // Determine if read/unread
        $isUnread = false;
        $labelIds = $message->getLabelIds() ?: [];
        if (in_array('UNREAD', $labelIds)) {
            $isUnread = true;
        }
        
        // Check for attachments
        $hasAttachments = false;
        $attachments = [];
        
        $payload = $message->getPayload();
        if ($payload->getParts()) {
            foreach ($payload->getParts() as $part) {
                if ($part->getFilename() && $part->getBody()->getAttachmentId()) {
                    $hasAttachments = true;
                    $attachments[] = [
                        'id' => $part->getBody()->getAttachmentId(),
                        'filename' => $part->getFilename(),
                        'mimeType' => $part->getMimeType(),
                    ];
                }
            }
        }
        
        $result = [
            'id' => $messageId,
            'from' => $from,
            'to' => $to,
            'subject' => $subject,
            'date' => $date,
            'has_attachments' => $hasAttachments,
            'unread' => $isUnread,
            'snippet' => $message->getSnippet(),
            'labels' => $labelIds,
        ];
        
        // Include attachments if present
        if ($hasAttachments) {
            $result['attachments'] = $attachments;
        }
        
        // Include body if requested
        if ($includeBody) {
            $body = $this->getMessageBody($message->getPayload());
            $result['body'] = $body['content'];
            $result['body_type'] = $body['type'];
        }
        
        return $result;
    }
    
    /**
     * Get message body content
     */
    public function getMessageBody($payload)
    {
        // Check if the payload body has data
        if ($payload->getBody()->getData()) {
            return [
                'content' => $this->decodeBody($payload->getBody()->getData()),
                'type' => $payload->getMimeType(),
            ];
        }
        
        // If no data directly in body, check parts
        if ($payload->getParts()) {
            foreach ($payload->getParts() as $part) {
                // Look for text/plain or text/html parts
                if ($part->getMimeType() === 'text/plain' || $part->getMimeType() === 'text/html') {
                    if ($part->getBody()->getData()) {
                        return [
                            'content' => $this->decodeBody($part->getBody()->getData()),
                            'type' => $part->getMimeType(),
                        ];
                    }
                }
                
                // Recursively check any nested parts (for multipart emails)
                if ($part->getParts()) {
                    $nestedBody = $this->getMessageBody($part);
                    if ($nestedBody['content']) {
                        return $nestedBody;
                    }
                }
            }
        }
        
        return [
            'content' => '',
            'type' => 'text/plain',
        ];
    }
    
    /**
     * Decode base64 body content
     */
    private function decodeBody($data)
    {
        $sanitized = str_replace(['-', '_'], ['+', '/'], $data);
        return base64_decode($sanitized);
    }
    
    /**
     * Create a raw email message for sending with proper UTF-8 encoding
     */
    public function createEmailRaw(array $headers, string $body, bool $isHtml = false)
    {
        $message = '';
        
        // Add headers with proper encoding for non-ASCII characters
        foreach ($headers as $name => $value) {
            // Check if the header value contains non-ASCII characters
            if (preg_match('/[^\x20-\x7E]/', $value)) {
                // Encode the header value according to RFC 2047
                $encoded = mb_encode_mimeheader($value, 'UTF-8', 'B', "\r\n");
                $message .= "$name: $encoded\r\n";
            } else {
                $message .= "$name: $value\r\n";
            }
        }
        
        // Set content type with proper charset
        $contentType = $isHtml ? 'text/html' : 'text/plain';
        $message .= "Content-Type: $contentType; charset=UTF-8\r\n";
        $message .= "MIME-Version: 1.0\r\n";
        
        // Add boundary between headers and body
        $message .= "\r\n";
        
        // Add body with proper encoding
        // For non-ASCII body, make sure it's properly encoded as UTF-8
        $message .= $body;
        
        // Base64 encode the entire message
        return base64_encode($message);
    }
    
    /**
     * Get attachment content by ID
     */
    public function getAttachment(User $user, string $messageId, string $attachmentId)
    {
        try {
            $service = $this->getGmailService($user);
            $attachment = $service->users_messages_attachments->get('me', $messageId, $attachmentId);
            
            if ($attachment) {
                $data = $this->decodeBody($attachment->getData());
                return [
                    'success' => true,
                    'data' => $data,
                    'size' => $attachment->getSize(),
                ];
            }
            
            return [
                'success' => false,
                'error' => 'Attachment not found',
            ];
        } catch (\Exception $e) {
            Log::error('Error retrieving attachment: ' . $e->getMessage());
            
            return [
                'success' => false,
                'error' => 'Failed to retrieve attachment: ' . $e->getMessage(),
            ];
        }
    }
    
    /**
     * Send an email with the draft API - allows for later sending
     */
    public function createDraft(User $user, array $emailData)
    {
        try {
            $service = $this->getGmailService($user);
            
            // Create email headers
            $headers = [
                'From' => $user->gmailAccount->email,
                'To' => $emailData['to'],
                'Subject' => $emailData['subject'],
            ];
            
            if (isset($emailData['cc']) && !empty($emailData['cc'])) {
                $headers['Cc'] = $emailData['cc'];
            }
            
            if (isset($emailData['bcc']) && !empty($emailData['bcc'])) {
                $headers['Bcc'] = $emailData['bcc'];
            }
            
            // Create raw email
            $isHtml = $emailData['html_body'] ?? false;
            $encodedEmail = $this->createEmailRaw($headers, $emailData['body'], $isHtml);
            
            // Create message
            $message = new Google_Service_Gmail_Message();
            $message->setRaw($encodedEmail);
            
            // Create draft object
            $draft = new Google_Service_Gmail_Draft();
            $draft->setMessage($message);
            
            // Create draft
            $result = $service->users_drafts->create('me', $draft);
            
            return [
                'success' => true,
                'draft_id' => $result->getId(),
                'message' => 'Draft created successfully',
            ];
        } catch (\Exception $e) {
            Log::error('Error creating draft: ' . $e->getMessage());
            
            return [
                'success' => false,
                'error' => 'Failed to create draft: ' . $e->getMessage(),
            ];
        }
    }
    
    /**
     * List Gmail labels
     */
    public function getLabels(User $user)
    {
        try {
            $service = $this->getGmailService($user);
            $labels = $service->users_labels->listUsersLabels('me');
            
            $result = [];
            foreach ($labels->getLabels() as $label) {
                $result[] = [
                    'id' => $label->getId(),
                    'name' => $label->getName(),
                    'type' => $label->getType(),
                ];
            }
            
            return [
                'success' => true,
                'labels' => $result,
            ];
        } catch (\Exception $e) {
            Log::error('Error retrieving Gmail labels: ' . $e->getMessage());
            
            return [
                'success' => false,
                'error' => 'Failed to retrieve labels: ' . $e->getMessage(),
            ];
        }
    }
}