<?php

namespace App\Services\Agents;

use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Log;

class AgentRegistry
{
    /**
     * The registered agents
     * 
     * @var array
     */
    protected $agents = [];
    
    /**
     * The intent to agent mappings
     * 
     * @var array
     */
    protected $intentMappings = [];
    
    /**
     * Create a new agent registry instance and register all agents
     */
    public function __construct()
    {
        $this->registerAgent(CalendarAgent::class);
        $this->registerAgent(EmailAgent::class);
        $this->registerAgent(WebSearchAgent::class);
        $this->registerAgent(GeneralAgent::class);
        $this->registerAgent(WeatherAgent::class); 
    }
    
    /**
     * Register an agent with the registry
     * 
     * @param string $agentClass The agent class name
     * @return void
     */
    public function registerAgent(string $agentClass): void
    {
        try {
            $agent = App::make($agentClass);
            
            if (!($agent instanceof AgentInterface)) {
                Log::error("Agent class does not implement AgentInterface", ['class' => $agentClass]);
                return;
            }
            
            $name = $agent->getName();
            $this->agents[$name] = $agent;
            
            // Register intents supported by this agent
            foreach ($agent->getSupportedIntents() as $intent) {
                $this->intentMappings[$intent] = $name;
            }
            
            Log::info("Registered agent", ['name' => $name, 'intents' => $agent->getSupportedIntents()]);
        } catch (\Exception $e) {
            Log::error("Failed to register agent", [
                'class' => $agentClass,
                'error' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Get an agent by name
     * 
     * @param string $name The agent name
     * @return AgentInterface|null
     */
    public function getAgent(string $name): ?AgentInterface
    {
        return $this->agents[$name] ?? null;
    }
    
    /**
     * Get the agent for a specific intent
     * 
     * @param string $intent The intent
     * @return AgentInterface|null
     */
    public function getAgentForIntent(string $intent): ?AgentInterface
    {
        $agentName = $this->intentMappings[$intent] ?? null;
        
        if (!$agentName) {
            return null;
        }
        
        return $this->getAgent($agentName);
    }
    
    /**
     * Get all registered agents
     * 
     * @return array
     */
    public function getAllAgents(): array
    {
        return $this->agents;
    }
}