<?php

namespace App\Services\Agents;

use App\Models\User;
use App\Services\OpenAI\OpenAIService;
use App\Services\OpenAI\OpenAIServiceExtension;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;

class AgentOrchestratorService
{
    protected $openAIService;
    protected $openAIServiceExt;
    protected $agentRegistry;
    
    /**
     * Create a new agent orchestrator service instance.
     */
    public function __construct(
        OpenAIService $openAIService,
        OpenAIServiceExtension $openAIServiceExt,
        AgentRegistry $agentRegistry
    ) {
        $this->openAIService = $openAIService;
        $this->openAIServiceExt = $openAIServiceExt;
        $this->agentRegistry = $agentRegistry;
    }
    
    /**
     * Process an incoming message and route to appropriate agent
     */
    public function processMessage(User $user, string $conversationId, string $message)
    {
        Log::info('Agent Orchestrator processing message', [
            'user_id' => $user->id,
            'message' => $message
        ]);
        
        // Get conversation context
        $context = $this->getConversationContext($user->id, $conversationId);
        
        // If we're in the middle of a conversation with a specific agent, continue with that agent
        if (!empty($context['current_agent'])) {
            $agentName = $context['current_agent'];
            Log::info("Continuing conversation with agent: {$agentName}");
            
            $agent = $this->agentRegistry->getAgent($agentName);
            if (!$agent) {
                Log::error("Agent {$agentName} not found in registry");
                // Fall back to intent detection
            } else {
                // Check if we should continue with this agent or switch
                if ($this->shouldContinueWithAgent($message, $agentName)) {
                    return $this->executeAgentRequest($user, $conversationId, $agent, $message, $context);
                }
                // If we shouldn't continue, fall through to intent detection
            }
        }
        
        // Detect intent and route to appropriate agent
        $intent = $this->detectIntent($message);
        Log::info("Detected intent: {$intent}");
        
        $agent = $this->agentRegistry->getAgentForIntent($intent);
        if (!$agent) {
            Log::warning("No agent found for intent: {$intent}");
            // Fall back to general agent
            $agent = $this->agentRegistry->getAgent('general');
        }
        
        // Update context with new agent
        $context['current_agent'] = $agent->getName();
        $this->saveConversationContext($user->id, $conversationId, $context);
        
        // Execute the request with the selected agent
        return $this->executeAgentRequest($user, $conversationId, $agent, $message, $context);
    }
    
    /**
     * Execute a request with a specific agent
     */
    protected function executeAgentRequest(User $user, string $conversationId, AgentInterface $agent, string $message, array $context = [])
    {
        $agentName = $agent->getName();
        $agentConversationId = "{$conversationId}:{$agentName}";
        
        Log::info("Executing request with agent", [
            'agent' => $agentName,
            'user_id' => $user->id
        ]);
        
        // Get agent's response
        $response = $agent->processMessage($user, $agentConversationId, $message);
        
        // Update context with any new information
        $context['last_interaction'] = time();
        $this->saveConversationContext($user->id, $conversationId, $context);
        
        return $response;
    }
    
    /**
     * Detect the intent of a message to route to the appropriate agent
     */
    protected function detectIntent(string $message): string
    {
        // Create a system prompt for intent classification
        $systemPrompt = "You are an intent classifier. Your job is to categorize user messages into one of the following categories:
            - calendar: Messages about creating, updating, viewing, or deleting calendar events, OR any questions about the user's schedule, agenda, plans, or what they're doing today/tomorrow/this week, etc.
            - email: Messages about sending, reading, or searching emails
            - web_search: Messages asking for information that would require searching the web
            - weather: Messages about weather conditions, forecasts, or setting up weather notifications/schedules
            - general: Any other general queries or requests
            
            Time-related questions like 'what am I doing today?', 'show my schedule', 'what's on my agenda?' all indicate calendar intent.
            
            Weather-related queries include:
            - Current weather conditions (e.g., 'What's the weather in New York?')
            - Weather forecasts (e.g., 'Will it rain tomorrow in London?')
            - Setting up weather updates (e.g., 'Update me about weather daily at 9 AM')
            - Managing weather schedules (e.g., 'Stop my weather updates')

            Respond with ONLY the category name and nothing else.";
        
        // Use OpenAI Extension to detect intent
        $messages = [
            [
                'role' => 'system',
                'content' => $systemPrompt
            ],
            [
                'role' => 'user',
                'content' => $message
            ]
        ];
        
        try {
            $intentResponse = $this->openAIServiceExt->sendBasicCompletion($messages, [
                'max_tokens' => 10,
                'temperature' => 0.3
            ]);
            
            // Parse the response to extract the intent category
            $intent = trim(strtolower($intentResponse['choices'][0]['message']['content'] ?? ''));
            
            // Ensure we get a valid intent, default to general
            $validIntents = ['calendar', 'email', 'web_search', 'general'];
            return in_array($intent, $validIntents) ? $intent : 'general';
        } catch (\Exception $e) {
            Log::error('Error detecting intent: ' . $e->getMessage());
            return 'general'; // Default to general on error
        }
    }
    
    /**
     * Determine if we should continue with the current agent or switch
     */
    protected function shouldContinueWithAgent(string $message, string $currentAgent): bool
    {
        // Create a system prompt for context switching detection
        $systemPrompt = "You are a context switching detector. Determine if the user's message represents:
            1. A continuation of the current conversation about {$currentAgent}
            2. A change in topic requiring a different assistant
            
            Respond with ONLY 'continue' or 'switch' and nothing else.";
        
        // Use OpenAI Extension to detect if we should switch
        $messages = [
            [
                'role' => 'system',
                'content' => $systemPrompt
            ],
            [
                'role' => 'user',
                'content' => $message
            ]
        ];
        
        try {
            $switchResponse = $this->openAIServiceExt->sendBasicCompletion($messages, [
                'max_tokens' => 10,
                'temperature' => 0.3
            ]);
            
            // Parse the response
            $decision = trim(strtolower($switchResponse['choices'][0]['message']['content'] ?? ''));
            
            return $decision === 'continue';
        } catch (\Exception $e) {
            Log::error('Error detecting context switch: ' . $e->getMessage());
            return true; // Default to continuing on error
        }
    }
    
    /**
     * Get the conversation context from Redis
     */
    protected function getConversationContext(int $userId, string $conversationId): array
    {
        $contextKey = "context:{$userId}:{$conversationId}";
        $contextJson = Redis::get($contextKey);
        
        if (!$contextJson) {
            return [];
        }
        
        return json_decode($contextJson, true) ?: [];
    }
    
    /**
     * Save the conversation context to Redis
     */
    protected function saveConversationContext(int $userId, string $conversationId, array $context): void
    {
        $contextKey = "context:{$userId}:{$conversationId}";
        Redis::set($contextKey, json_encode($context));
        Redis::expire($contextKey, 3600); // 1 hour TTL
    }
}