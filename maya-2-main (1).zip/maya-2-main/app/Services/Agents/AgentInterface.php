<?php

namespace App\Services\Agents;

use App\Models\User;

interface AgentInterface
{
    /**
     * Get the name of the agent
     * 
     * @return string
     */
    public function getName(): string;
    
    /**
     * Get the description of the agent
     * 
     * @return string
     */
    public function getDescription(): string;
    
    /**
     * Get the agent's system prompt
     * 
     * @return string
     */
    public function getSystemPrompt(): string;
    
    /**
     * Get supported intent types for this agent
     * 
     * @return array
     */
    public function getSupportedIntents(): array;
    
    /**
     * Get the tool names this agent can use
     * 
     * @return array
     */
    public function getToolNames(): array;
    
    /**
     * Process a message with this agent
     * 
     * @param User $user The user
     * @param string $conversationId The conversation ID
     * @param string $message The message to process
     * @return array The response
     */
    public function processMessage(User $user, string $conversationId, string $message): array;
}