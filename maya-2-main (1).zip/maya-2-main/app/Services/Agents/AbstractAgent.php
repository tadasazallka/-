<?php

namespace App\Services\Agents;

use App\Models\User;
use App\Services\OpenAI\OpenAIService;
use App\Services\OpenAI\FunctionRegistry;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;
use Carbon\Carbon;

abstract class AbstractAgent implements AgentInterface
{
    /**
     * The OpenAI service instance
     * 
     * @var OpenAIService
     */
    protected $openAIService;
    
    /**
     * The function registry for tool registration
     * 
     * @var FunctionRegistry
     */
    protected $functionRegistry;
    
    /**
     * Create a new agent instance
     * 
     * @param OpenAIService $openAIService
     * @param FunctionRegistry $functionRegistry
     */
    public function __construct(
        OpenAIService $openAIService,
        FunctionRegistry $functionRegistry
    ) {
        $this->openAIService = $openAIService;
        $this->functionRegistry = $functionRegistry;
    }
    
    /**
     * Process a message with this agent
     * 
     * @param User $user The user
     * @param string $conversationId The conversation ID
     * @param string $message The message to process
     * @return array The response
     */
    public function processMessage(User $user, string $conversationId, string $message): array
    {
        Log::info('Agent processing message', [
            'agent' => $this->getName(),
            'user_id' => $user->id,
            'message' => $message
        ]);
        
        // Create Redis key for this specific agent's conversation
        $redisKey = "user:{$user->id}:agent:{$this->getName()}";
        
        // Get conversation history
        $messages = $this->getConversationHistory($redisKey);
        
        // Add system prompt if this is a new conversation
        if (empty($messages)) {
            $systemMessage = [
                'role' => 'system',
                'content' => $this->buildSystemPrompt($user)
            ];
            
            $messages[] = $systemMessage;
            $this->saveMessageToHistory($redisKey, $systemMessage);
        } else {
            // Update the time in the existing system message
            foreach ($messages as $key => $existingMessage) {
                if ($existingMessage['role'] === 'system') {
                    $currentTime = Carbon::now($user->timezone);
                    $messages[$key]['content'] = preg_replace(
                        '/Current date is.*?\\n/s',
                        "Current date is " . $currentTime->format('Y-m-d') . ". Current time is approximately " . $currentTime->format('g:i A') . " in the user's timezone ({$user->timezone}).\n",
                        $existingMessage['content']
                    );
                    
                    // Update the system message in Redis
                    Redis::lset($redisKey, $key, json_encode($messages[$key]));
                    break;
                }
            }
        }
        
        // Add current user message
        $userMessage = [
            'role' => 'user',
            'content' => $message
        ];
        
        $messages[] = $userMessage;
        $this->saveMessageToHistory($redisKey, $userMessage);
        
        // Get agent-specific tools
        $toolNames = $this->getToolNames();
        
        // Filter function registry to only include tools this agent can use
        $tools = $this->filterToolsByNames($toolNames);
        
        // Call OpenAI with agent-specific tools
        $response = $this->openAIService->processMessage($user, $conversationId, $message, $tools);
        
        // Save assistant response to conversation history
        if (isset($response['content']) && $response['content']) {
            $assistantMessage = [
                'role' => 'assistant',
                'content' => $response['content']
            ];
            $this->saveMessageToHistory($redisKey, $assistantMessage);
        }
        
        return $response;
    }
    
    /**
     * Build the system prompt for this agent
     * 
     * @param User $user The user
     * @return string
     */
    protected function buildSystemPrompt(User $user): string
    {
        $userTz = $user->timezone ?? 'UTC';
        $currentDateInUserTz = Carbon::now($userTz)->format('Y-m-d');
        $currentTimeInUserTz = Carbon::now($userTz)->format('g:i A');
        
        // Get user language preference from Redis or default to user's preferences
        $redisKey = "conversation:{$user->id}:meta";
        $preferredLanguage = Redis::hget($redisKey, 'preferred_language');
        
        if (!$preferredLanguage && isset($user->preferences->language)) {
            $preferredLanguage = $user->preferences->language;
        }
        
        $languageAutoDetect = Redis::hget($redisKey, 'language_auto_detect') ?? 'true';
        
        $prompt = "You are Maya, an AI assistant specialized in " . $this->getDescription() . ".\n";
        $prompt .= "Current date is " . $currentDateInUserTz . ". Current time is approximately " . $currentTimeInUserTz . " in the user's timezone ({$userTz}).\n";
        $prompt .= "IMPORTANT: Always introduce yourself as 'Maya' or 'Maya, your AI assistant' when asked who you are. Never refer to yourself as just 'an AI assistant'.\n\n";
        
        // Add user information
        $prompt .= "User information:\n";
        $prompt .= "- User Name: {$user->name}\n";
        $prompt .= "- Time zone: {$userTz}\n";
        $prompt .= "- Is signed up: " . ($user->is_signed_up ? "Yes" : "No") . "\n";
        $prompt .= "- Preferred language: " . ($preferredLanguage ?? "Not set") . "\n";
        $prompt .= "- Auto-detect language: " . ($languageAutoDetect === 'true' ? "Enabled" : "Disabled") . "\n\n";
        
        // Add the agent-specific system prompt
        $prompt .= $this->getSystemPrompt();
        
        // Add language handling instructions
        $prompt .= "\n\nLANGUAGE HANDLING INSTRUCTIONS:\n";
        $prompt .= "- Remember that you are a multilingual AI assistant capable of communicating in many languages.\n";
        $prompt .= "- Always maintain your identity as Maya the AI assistant, regardless of which language the conversation is in.\n";
        $prompt .= "- If the user has a preferred language set, respond in that language.\n";
        $prompt .= "- If a user explicitly asks you to respond in a specific language, use the set_language_preference tool to update their preference.\n";
        $prompt .= "- When a user asks for a translation, provide it directly in your response.\n";
        $prompt .= "- If a user asks 'what is X in language Y', provide the translation directly followed by pronunciation guidance if helpful.\n";
        $prompt .= "- You have full multilingual capabilities - you can understand and respond in virtually any language without requiring translation tools.\n";
        
        // Add general guidance
        $prompt .= "\n\nGeneral guidelines:\n";
        $prompt .= "- FIRST ACTION: Call get_user_info tool at the beginning of conversations to understand user's capabilities and preferences.\n";
        $prompt .= "- Always confirm important actions before executing them.\n";
        $prompt .= "- Be concise and helpful in your responses.\n";
        $prompt .= "- Keep all responses brief and to the point - 1-3 sentences when possible.\n";
        $prompt .= "- Do not tell user about your technical information. Like AI model information or what technology you are using etc.\n";
        $prompt .= "- Use emojis to make replies friendly\n";

        return $prompt;
    }
    
    /**
     * Filter the function registry to only include tools this agent can use
     * 
     * @param array $toolNames The tool names this agent can use
     * @return array The filtered tools
     */
    protected function filterToolsByNames(array $toolNames): array
    {
        // Make sure essential tools are always available
        $essentialTools = [
            'get_user_info',
            'set_language_preference',
            'get_language_info'
        ];
        
        $toolNames = array_merge($toolNames, $essentialTools);
        $toolNames = array_unique($toolNames);
        
        // Get all tools from the registry
        $allTools = $this->functionRegistry->getToolsForOpenAI();
        
        // Filter to only include tools this agent can use
        $filteredTools = array_filter($allTools, function($tool) use ($toolNames) {
            return in_array($tool['function']['name'], $toolNames);
        });
        
        return array_values($filteredTools); // Re-index array
    }
    
    /**
     * Get conversation history from Redis
     */
    protected function getConversationHistory(string $redisKey)
    {
        $messagesJson = Redis::lrange($redisKey, 0, -1);
        
        if (empty($messagesJson)) {
            return [];
        }
        
        $messages = [];
        foreach ($messagesJson as $json) {
            $messages[] = json_decode($json, true);
        }
        
        return $messages;
    }
    
    /**
     * Save message to conversation history in Redis
     */
    protected function saveMessageToHistory(string $redisKey, array $message)
    {
        // Set message expiration to 1 hour (3600 seconds)
        if (!Redis::exists($redisKey)) {
            Redis::expire($redisKey, 3600);
        }
        
        Redis::rpush($redisKey, json_encode($message));
        
        // Resetting expiration to 3600 seconds (1 hour) each time a message is added
        Redis::expire($redisKey, 3600);
        
        // Trim the conversation to the last 50 messages to prevent it from growing too large
        $maxConversationLength = 50;
        $currentLength = Redis::llen($redisKey);
        
        if ($currentLength > $maxConversationLength) {
            Redis::ltrim($redisKey, $currentLength - $maxConversationLength, -1);
        }
    }
    
    /**
     * Clear a user's conversation from Redis
     */
    public function clearUserConversation(User $user)
    {
        $redisKey = "user:{$user->id}:agent:{$this->getName()}";
        Redis::del($redisKey);
    }
}