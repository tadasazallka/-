<?php

namespace App\Services;

use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class PlanLimitService
{
    /**
     * Check if user can create a new event
     * 
     * @param User $user
     * @return bool
     */
    public function canCreateEvent(User $user)
    {
        Log::info('working on canCreateEvent');
        // Check events per week limit
        $plan = $user->currentPlan();
        
        if (!$plan) {
            Log::info('plan not found when working on canCreateEvent');
            return false;
        }
        
        $eventsLimit = $plan->getFeatureLimit('events_per_week');
        
        // If unlimited (-1)
        if ($eventsLimit === -1) {
            Log::info('unlimittd event limit when working on canCreateEvent');
            return true;
        }
        
        // Count events created in the past week
        $eventsThisWeek = $user->events()
            ->where('created_at', '>=', Carbon::now()->subDays(7))
            ->count();

        if ($eventsThisWeek >= $eventsLimit) {
            Log::info('this week events are already used when working on canCreateEvent');
            return false;
        }
        
        return true;
    }

    /**
     * Check if user can activate a calendar connection
     * 
     * @param User $user
     * @return bool
     */
    public function canActivateCalendarConnection(User $user)
    {
        $plan = $user->currentPlan();
        
        if (!$plan) {
            return false;
        }
        
        $calendarLimit = $plan->getFeatureLimit('calendar_sync_limit');
        
        // If unlimited (-1)
        if ($calendarLimit === -1) {
            return true;
        }
        
        // Count active calendar connections, excluding the default calendar
        $activeCalendars = $user->calendars()
            ->where('is_active', true)
            ->where('provider', '!=', 'default')
            ->count();
        
        if ($activeCalendars >= $calendarLimit) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Check if user can send a WhatsApp reminder
     * 
     * @param User $user
     * @return bool
     */
    public function canSendWhatsAppReminder(User $user)
    {
        $plan = $user->currentPlan();
        
        if (!$plan) {
            return false;
        }
        
        $reminderLimit = $plan->getFeatureLimit('whatsapp_reminders');
        
        // If unlimited (-1)
        if ($reminderLimit === -1) {
            return true;
        }
        
        // Count reminders sent in the past month
        $remindersThisMonth = $this->countRemindersThisMonth($user);
        
        if ($remindersThisMonth >= $reminderLimit) {
            return false;
        }
        
        return true;
    }
    
   /**
     * Check if user can connect a new calendar account
     * 
     * @param User $user
     * @return bool
     */
    public function canConnectCalendarAccount(User $user)
    {
        $plan = $user->currentPlan();
        
        if (!$plan) {
            return false;
        }
        
        // Use calendar_sync_limit for the number of calendar accounts
        $accountsLimit = $plan->getFeatureLimit('calendar_sync_limit');
        
        // If unlimited (-1)
        if ($accountsLimit === -1) {
            return true;
        }
        
        // Count calendar accounts, excluding default calendar
        $accountsCount = $user->calendarAccounts()
            ->where('is_active', true)
            ->where('provider', '!=', 'default')
            ->count();
        
        // Check if the user has reached their account limit
        if ($accountsCount >= $accountsLimit) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Check if user can use time conflict detection
     * 
     * @param User $user
     * @return bool
     */
    public function canUseTimeConflictDetection(User $user)
    {
        return $this->canUseFeature($user, 'time_conflict_detection');
    }
    
    /**
     * Check if user can use daily agenda overview
     * 
     * @param User $user
     * @return bool
     */
    public function canUseDailyAgendaOverview(User $user)
    {
        return $this->canUseFeature($user, 'daily_agenda_overview');
    }
    
    /**
     * Check if user can use Google Meet links
     * 
     * @param User $user
     * @return bool
     */
    public function canUseGoogleMeetLinks(User $user)
    {
        return $this->canUseFeature($user, 'google_meet_links');
    }
    
    /**
     * Check if user can access early access features
     * 
     * @param User $user
     * @return bool
     */
    public function canAccessEarlyFeatures(User $user)
    {
        return $this->canUseFeature($user, 'early_access_features');
    }
    
    /**
     * Generic method to check if user can use a boolean feature
     * 
     * @param User $user
     * @param string $featureKey
     * @return bool
     */
    public function canUseFeature(User $user, string $featureKey)
    {
        $plan = $user->currentPlan();
        
        if (!$plan) {
            return false;
        }
        
        return isset($plan->features[$featureKey]) && $plan->features[$featureKey] === true;
    }
    
    /**
     * Count reminders sent this month
     * 
     * @param User $user
     * @return int
     */
    protected function countRemindersThisMonth(User $user)
    {
        return \App\Models\FeatureUsage::where('user_id', $user->id)
            ->where('feature', 'whatsapp_reminders')
            ->where('period_start', '>=', Carbon::now()->startOfMonth())
            ->sum('usage');
    }
    
    /**
     * Record usage of a feature
     * 
     * @param User $user
     * @param string $feature
     * @param int $usageCount
     * @return void
     */
    public function recordUsage(User $user, string $feature, int $usageCount = 1)
    {
        $startOfPeriod = Carbon::now()->startOfMonth();
        
        $usage = \App\Models\FeatureUsage::firstOrNew([
            'user_id' => $user->id,
            'feature' => $feature,
            'period_start' => $startOfPeriod,
        ]);
        
        $usage->usage = ($usage->usage ?? 0) + $usageCount;
        $usage->save();
    }
    
    /**
     * Get remaining events a user can create this week
     * 
     * @param User $user
     * @return int|null (null if unlimited)
     */
    public function getRemainingEvents(User $user)
    {
        $plan = $user->currentPlan();
        
        if (!$plan) {
            return 0;
        }
        
        $eventsLimit = $plan->getFeatureLimit('events_per_week');
        
        // If unlimited (-1)
        if ($eventsLimit === -1) {
            return null;
        }
        
        // Count events created in the past week
        $eventsThisWeek = $user->events()
            ->where('created_at', '>=', Carbon::now()->subDays(7))
            ->count();
        
        return max(0, $eventsLimit - $eventsThisWeek);
    }
    
    /**
     * Get remaining WhatsApp reminders a user can send this month
     * 
     * @param User $user
     * @return int|null (null if unlimited)
     */
    public function getRemainingReminders(User $user)
    {
        $plan = $user->currentPlan();
        
        if (!$plan) {
            return 0;
        }
        
        $reminderLimit = $plan->getFeatureLimit('whatsapp_reminders');
        
        // If unlimited (-1)
        if ($reminderLimit === -1) {
            return null;
        }
        
        // Count reminders sent in the past month
        $remindersThisMonth = $this->countRemindersThisMonth($user);
        
        return max(0, $reminderLimit - $remindersThisMonth);
    }
    
    /**
     * Get remaining calendars a user can connect
     * 
     * @param User $user
     * @return int|null (null if unlimited)
     */
    public function getRemainingCalendars(User $user)
    {
        $plan = $user->currentPlan();
        
        if (!$plan) {
            return 0;
        }
        
        $calendarLimit = $plan->getFeatureLimit('calendar_sync_limit');
        
        // If unlimited (-1)
        if ($calendarLimit === -1) {
            return null;
        }
        
        // Count connected calendars
        $connectedCalendars = $user->calendars()->where('provider', '!=', 'default')->count();
        
        return max(0, $calendarLimit - $connectedCalendars);
    }
    
    /**
     * Get the upgrade plan needed for a feature
     * 
     * @param string $featureKey
     * @return string|null
     */
    public function getUpgradePlanForFeature(string $featureKey)
    {
        $plans = \App\Models\Plan::where('is_active', true)
            ->orderBy('sort_order')
            ->get();
        
        foreach ($plans as $plan) {
            if (isset($plan->features[$featureKey]) && $plan->features[$featureKey] === true) {
                return $plan->slug;
            }
        }
        
        return null;
    }
    
    /**
     * Get the upgrade plan needed for a numeric limit
     * 
     * @param string $featureKey
     * @param int $currentLimit
     * @return string|null
     */
    public function getUpgradePlanForLimit(string $featureKey, int $currentLimit)
    {
        $plans = \App\Models\Plan::where('is_active', true)
            ->orderBy('sort_order')
            ->get();
        
        foreach ($plans as $plan) {
            if (isset($plan->features[$featureKey])) {
                $limit = $plan->features[$featureKey];
                
                // Check if this plan has a higher limit or unlimited (-1)
                if ($limit === -1 || (is_numeric($limit) && $limit > $currentLimit)) {
                    return $plan->slug;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Check if a user has reached their event limit
     * 
     * @param User $user
     * @return bool
     */
    public function hasReachedEventLimit(User $user)
    {
        return !$this->canCreateEvent($user);
    }
    
    /**
     * Check if a user has reached their reminder limit
     * 
     * @param User $user
     * @return bool
     */
    public function hasReachedReminderLimit(User $user)
    {
        return !$this->canSendWhatsAppReminder($user);
    }
    
    /**
     * Check if a user has reached their calendar limit
     * 
     * @param User $user
     * @return bool
     */
    public function hasReachedCalendarLimit(User $user)
    {
        return !$this->canConnectCalendarAccount($user);
    }
}