<?php
// app/Services/WeatherScheduleService.php

namespace App\Services;

use App\Models\WeatherSchedule;
use App\Models\WeatherScheduleLog;
use App\Models\User;
use App\Services\WeatherService;
use App\Services\WhatsappAPIService;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class WeatherScheduleService
{
    protected $weatherService;
    protected $whatsappService;
    
    public function __construct(
        WeatherService $weatherService,
        WhatsappAPIService $whatsappService
    ) {
        $this->weatherService = $weatherService;
        $this->whatsappService = $whatsappService;
    }
    
    /**
     * Create a new weather schedule
     */
    public function createSchedule(User $user, string $location, string $scheduleTime, string $frequency = 'daily'): WeatherSchedule
    {
        return WeatherSchedule::create([
            'user_id' => $user->id,
            'location' => $location,
            'schedule_time' => $scheduleTime,
            'frequency' => $frequency,
        ]);
    }
    
    /**
     * Update an existing weather schedule
     */
    public function updateSchedule(WeatherSchedule $schedule, array $data): WeatherSchedule
    {
        $schedule->update($data);
        return $schedule->fresh();
    }
    
    /**
     * Process due weather schedules
     */
    public function processDueSchedules(): void
    {
        $schedules = WeatherSchedule::with('user')->get();
        
        foreach ($schedules as $schedule) {
            try {
                if ($this->isDue($schedule)) {
                    $this->sendWeatherUpdate($schedule);
                }
            } catch (\Exception $e) {
                Log::error('Failed to process weather schedule', [
                    'schedule_id' => $schedule->id,
                    'error' => $e->getMessage()
                ]);
            }
        }
    }
    
    /**
     * Check if a schedule is due
     */
    protected function isDue(WeatherSchedule $schedule): bool
    {
        $userTimezone = $schedule->user->timezone ?? 'UTC';
        $now = Carbon::now($userTimezone);
        
        // Handle both HH:MM and full datetime formats
        $scheduleTimeStr = $schedule->schedule_time;
        
        // If it's a full datetime, extract just the time
        if (strlen($scheduleTimeStr) > 5) {
            $scheduleTimeStr = Carbon::parse($scheduleTimeStr)->format('H:i');
        }
        
        // Parse the schedule time in the user's timezone
        list($hours, $minutes) = explode(':', $scheduleTimeStr);
        $hours = (int) $hours;
        $minutes = (int) $minutes;
        
        // Create today's schedule time
        $scheduleTime = $now->copy()->setTime($hours, $minutes, 0);
        
        // Log the check
        Log::debug('Checking if schedule is due', [
            'schedule_id' => $schedule->id,
            'user_timezone' => $userTimezone,
            'now' => $now->format('Y-m-d H:i:s'),
            'schedule_time' => $scheduleTime->format('Y-m-d H:i:s'),
            'schedule_time_stored' => $schedule->schedule_time,
            'schedule_time_extracted' => $scheduleTimeStr,
            'last_sent_at' => $schedule->last_sent_at
        ]);
        
        // Check if we're within 5 minutes after the schedule time
        $minutesPassed = $now->diffInMinutes($scheduleTime, false);
        
        // If schedule time has not passed yet or it's more than 5 minutes past
        if ($minutesPassed > 0 || $minutesPassed < -5) {
            Log::debug('Schedule time not within window', [
                'minutes_difference' => $minutesPassed
            ]);
            return false;
        }
        
        // Check if it was already sent for this period
        if ($schedule->last_sent_at) {
            $lastSent = Carbon::parse($schedule->last_sent_at)->setTimezone($userTimezone);
            
            Log::debug('Checking last sent', [
                'last_sent_at' => $lastSent->format('Y-m-d H:i:s'),
                'frequency' => $schedule->frequency
            ]);
            
            switch ($schedule->frequency) {
                case 'daily':
                    // Check if it was sent today
                    if ($lastSent->isToday()) {
                        Log::debug('Already sent today');
                        return false;
                    }
                    break;
                    
                case 'weekly':
                    // Check if it was sent in the last 7 days
                    if ($lastSent->diffInDays($now) < 7) {
                        Log::debug('Already sent this week');
                        return false;
                    }
                    break;
                    
                case 'monthly':
                    // Check if it was sent this month
                    if ($lastSent->isSameMonth($now)) {
                        Log::debug('Already sent this month');
                        return false;
                    }
                    break;
            }
        }
        
        Log::debug('Schedule is due');
        return true;
    }
    
    /**
     * Send weather update for a schedule
     */
    protected function sendWeatherUpdate(WeatherSchedule $schedule): void
    {
        $weatherData = $this->weatherService->getCurrentWeather($schedule->location);
        $message = $this->weatherService->formatWeatherMessage($weatherData);
        
        // Add forecast if it's the morning schedule (before 10 AM)
        $scheduleHour = Carbon::parse($schedule->schedule_time)->hour;
        if ($scheduleHour < 10) {
            $forecastData = $this->weatherService->getWeatherForecast($schedule->location);
            $message .= "\n\n" . $this->weatherService->formatForecastMessage($forecastData);
        }
        
        try {
            $this->whatsappService->sendWhatsAppMessage($schedule->user->whatsapp_id, $message);
            
            $schedule->update(['last_sent_at' => now()]);
            
            WeatherScheduleLog::create([
                'weather_schedule_id' => $schedule->id,
                'sent_at' => now(),
                'weather_data' => $weatherData,
                'status' => 'success',
            ]);
            
            Log::info('Weather update sent successfully', [
                'schedule_id' => $schedule->id,
                'user_id' => $schedule->user_id,
                'location' => $schedule->location
            ]);
        } catch (\Exception $e) {
            WeatherScheduleLog::create([
                'weather_schedule_id' => $schedule->id,
                'sent_at' => now(),
                'weather_data' => $weatherData,
                'status' => 'failed',
                'error_message' => $e->getMessage(),
            ]);
            
            Log::error('Failed to send weather update', [
                'schedule_id' => $schedule->id,
                'error' => $e->getMessage()
            ]);
        }
    }
}