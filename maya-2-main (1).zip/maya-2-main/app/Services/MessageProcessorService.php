<?php

namespace App\Services;

use App\Models\User;
use App\Services\OpenAI\OpenAIService as MainOpenAIService;
use Illuminate\Support\Facades\Log;
use App\Services\OpenAIService;
use App\Services\CloudinaryService;
use App\Resources\WhatsappMessages;
use Exception;
use Illuminate\Support\Facades\Redis;

class MessageProcessorService
{
    protected $openAIService;
    protected $mainOpenAIService;
    protected $cloudinaryService;
    
    // Maximum file size constants (in bytes) - should match controller
    const MAX_IMAGE_SIZE_BYTES = 5 * 1024 * 1024; // 5MB
    const MAX_AUDIO_SIZE_BYTES = 2 * 1024 * 1024; // 2MB
    
    // Redis constants
    const METADATA_TTL = 3600; // 1 hour
    
    public function __construct(
        OpenAIService $openAIService,
        MainOpenAIService $mainOpenAIService,
        CloudinaryService $cloudinaryService
    ) {
        $this->openAIService = $openAIService;
        $this->mainOpenAIService = $mainOpenAIService;
        $this->cloudinaryService = $cloudinaryService;
    }
    
    /**
     * Process text message from WhatsApp
     */
    public function processTextMessage(User $user, string $text): string
    {
        Log::info('Processing text message from user: ' . $user->id, ['message' => $text]);
        
        try {
            $userInfoRefreshService = app(UserInfoRefreshService::class);
            $needsRefresh = $userInfoRefreshService->needsInfoRefresh($user->id);
            
            if ($needsRefresh) {
                Log::info('User info needs refresh, updating OpenAI conversation', [
                    'user_id' => $user->id
                ]);
                
                // Refresh the OpenAI conversation with updated user info
                $this->mainOpenAIService->refreshSystemPrompt($user);
                
                // Clear the refresh flag
                $userInfoRefreshService->clearInfoRefreshFlag($user->id);
            }
            
            // Directly process with OpenAI without translation
            $response = $this->mainOpenAIService->processMessage(
                $user,
                'conversation:'.$user->id,
                $text
            );
            
            return $response['content'];
        } catch (\Exception $e) {
            Log::error('Error processing text message: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);

            $redisKey = "user:{$user->id}";
            Redis::del($redisKey);
            Log::info('Cleared user chat cache due to API error', [
                'user_id' => $user->id
            ]);
            
            // Get user's language preference
            $language = $user->preferences->language ?? 'en';
            
            return WhatsappMessages::getErrorResponse($language);
        }
    }
    
    /**
     * Transcribe audio file using OpenAI
     * 
     * @param string $cloudinaryUrl URL of the audio file on Cloudinary
     * @return string|null Transcribed text or null on failure
     */
    public function transcribeAudio(string $cloudinaryUrl): ?string
    {
        try {
            return $this->openAIService->transcribeAudio($cloudinaryUrl);
        } catch (Exception $e) {
            Log::error('Error transcribing audio: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Extract text from an image using OpenAI
     * 
     * @param string $cloudinaryUrl URL of the image file on Cloudinary
     * @return string|null Extracted text or null on failure
     */
    public function extractTextFromImage(string $cloudinaryUrl): ?string
    {
        try {
            return $this->openAIService->extractTextFromImage($cloudinaryUrl);
        } catch (Exception $e) {
            Log::error('Error extracting text from image: ' . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Process voice message from WhatsApp using Cloudinary
     */
    public function processVoiceMessage(User $user, string $cloudinaryUrl, string $publicId): string
    {
        try {
            // Get user's language preference
            $language = $user->preferences->language ?? 'en';
            
            // Get file size from Cloudinary if possible
            try {
                $fileInfo = $this->cloudinaryService->getResourceInfo($publicId, 'video');
                $fileSize = $fileInfo['bytes'] ?? 0;
                
                if ($fileSize > self::MAX_AUDIO_SIZE_BYTES) {
                    // Clean up the Cloudinary resource
                    $this->cloudinaryService->deleteFile($publicId, 'video');
                    return WhatsappMessages::getMediaSizeExceededMessage($language, 'audio');
                }
            } catch (\Exception $e) {
                Log::warning('Failed to get audio file size from Cloudinary: ' . $e->getMessage());
                // Continue with processing as the size check might have been done in the controller
            }
            
            // Transcribe the audio file using the Cloudinary URL
            $transcription = $this->openAIService->transcribeAudio($cloudinaryUrl);
            
            // Clean up the Cloudinary resource after processing
            $this->cloudinaryService->deleteFile($publicId, 'video');
            
            if (!$transcription) {
                return WhatsappMessages::getAudioTranscriptionErrorMessage($language);
            }
            
            Log::info('Voice message transcription', ['user_id' => $user->id, 'transcription' => $transcription]);
            
            // Use the transcribed text as input for a regular text message
            return $this->processTextMessage($user, "User has shared a voice note that contains the following text. Treat this as you are directly treating a voice note from the user." . $transcription);
        } catch (\Exception $e) {
            Log::error('Error processing voice message: ' . $e->getMessage());
            
            // Get user's language preference
            $language = $user->preferences->language ?? 'en';
            
            return WhatsappMessages::getAudioProcessingErrorMessage($language);
        }
    }
    
    /**
     * Process image message from WhatsApp using Cloudinary
     */
    public function processImageMessage(User $user, string $cloudinaryUrl, string $publicId): string
    {
        try {
            // Get user's language preference
            $language = $user->preferences->language ?? 'en';
            
            // Get file size from Cloudinary if possible
            try {
                $fileInfo = $this->cloudinaryService->getResourceInfo($publicId, 'image');
                $fileSize = $fileInfo['bytes'] ?? 0;
                
                if ($fileSize > self::MAX_IMAGE_SIZE_BYTES) {
                    // Clean up the Cloudinary resource
                    $this->cloudinaryService->deleteFile($publicId, 'image');
                    return WhatsappMessages::getMediaSizeExceededMessage($language, 'image');
                }
            } catch (\Exception $e) {
                Log::warning('Failed to get image file size from Cloudinary: ' . $e->getMessage());
                // Continue with processing as the size check might have been done in the controller
            }
            
            // Extract text from the image using the Cloudinary URL
            $extractedText = $this->openAIService->extractTextFromImage($cloudinaryUrl);
            
            // Clean up the Cloudinary resource after processing
            $this->cloudinaryService->deleteFile($publicId, 'image');
            
            if (!$extractedText) {
                return WhatsappMessages::getImageExtractionErrorMessage($language);
            }
            
            Log::info('Image text extraction', ['user_id' => $user->id, 'extracted_text' => $extractedText]);
            
            // Process the extracted text with context that it came from an image
            return $this->processTextMessage(
                $user, 
                "User has shared an image that contains the following text. Treat this as you are directly treating an image from the user." . $extractedText
            );
        } catch (\Exception $e) {
            Log::error('Error processing image message: ' . $e->getMessage());
            
            // Get user's language preference
            $language = $user->preferences->language ?? 'en';
            
            return WhatsappMessages::getImageProcessingErrorMessage($language);
        }
    }

}