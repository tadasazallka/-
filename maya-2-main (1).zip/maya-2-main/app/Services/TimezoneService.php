<?php

namespace App\Services;

use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class TimezoneService
{
    /**
     * Convert a time to UTC
     * Accepts string, Carbon, or DateTime
     * 
     * @param mixed $dateTime The datetime to convert
     * @param string $sourceTimezone Source timezone if input is a string without timezone info
     * @return Carbon Carbon instance in UTC
     */
    public function toUTC($dateTime, $sourceTimezone = 'UTC') 
    {
        if (is_string($dateTime)) {
            return Carbon::parse($dateTime, $sourceTimezone)->setTimezone('UTC');
        }
        
        if ($dateTime instanceof Carbon) {
            return $dateTime->copy()->setTimezone('UTC');
        }
        
        if ($dateTime instanceof \DateTime) {
            return Carbon::instance($dateTime)->setTimezone('UTC');
        }
        
        throw new \Exception("Unsupported datetime format");
    }
    
    /**
     * Convert a UTC time to user's timezone
     * Accepts string, Carbon, or DateTime
     * 
     * @param mixed $dateTime The datetime in UTC to convert
     * @param string $targetTimezone Target timezone
     * @return Carbon Carbon instance in target timezone
     */
    public function utcToUser($dateTime, $targetTimezone) 
    {
        if (is_string($dateTime)) {
            return Carbon::parse($dateTime, 'UTC')->setTimezone($targetTimezone);
        }
        
        if ($dateTime instanceof Carbon) {
            return $dateTime->copy()->setTimezone($targetTimezone);
        }
        
        if ($dateTime instanceof \DateTime) {
            return Carbon::instance($dateTime)->setTimezone($targetTimezone);
        }
        
        throw new \Exception("Unsupported datetime format");
    }
    
    /**
     * Get current time in UTC
     * 
     * @return Carbon Current time in UTC
     */
    public function nowUTC() 
    {
        return Carbon::now('UTC');
    }
    
    /**
     * Get current time in user's timezone
     * 
     * @param string $userTimezone User's timezone
     * @return Carbon Current time in user's timezone
     */
    public function nowUserTime($userTimezone) 
    {
        return Carbon::now($userTimezone);
    }
    
    /**
     * Check if a time is in the past
     * All comparisons are done in UTC
     * 
     * @param mixed $dateTime The datetime to check
     * @param string $timezone Timezone if input is a string without timezone info
     * @return bool True if the time is in the past
     */
    public function isInPast($dateTime, $timezone = 'UTC') 
    {
        $dateTimeUTC = $this->toUTC($dateTime, $timezone);
        $nowUTC = $this->nowUTC();
        
        Log::info('Time comparison for past check', [
            'now_utc' => $nowUTC->toIso8601String(),
            'datetime_utc' => $dateTimeUTC->toIso8601String(),
            'result' => $dateTimeUTC->lt($nowUTC) ? 'In past' : 'Not in past'
        ]);
        
        return $dateTimeUTC->lt($nowUTC);
    }
    
    /**
     * Parse a date and time in a specified timezone
     * 
     * @param string $date Date in YYYY-MM-DD format
     * @param string|null $time Optional time in HH:MM[:SS] format
     * @param string $timezone Timezone for the parsed datetime
     * @return Carbon Carbon instance in the specified timezone
     */
    public function parseDateTime($date, $time = null, $timezone = 'UTC') 
    {
        try {
            // Try to parse as combined date and time
            if ($time) {
                $dateTime = Carbon::parse("$date $time", $timezone);
            } else {
                // Try to parse as just date
                $dateTime = Carbon::parse($date, $timezone);
            }
            
            Log::info('Parsed datetime', [
                'input_date' => $date,
                'input_time' => $time,
                'timezone' => $timezone,
                'parsed' => $dateTime->toIso8601String()
            ]);
            
            return $dateTime;
        } catch (\Exception $e) {
            Log::error('Failed to parse datetime', [
                'date' => $date,
                'time' => $time,
                'timezone' => $timezone,
                'error' => $e->getMessage()
            ]);
            throw new \Exception("Could not parse the date/time input. Please use a format like 'YYYY-MM-DD' for date and 'HH:MM' for time.");
        }
    }
    
    /**
     * Convert an ISO 8601 string to a Carbon instance
     * 
     * @param string $isoString ISO 8601 datetime string
     * @param string $targetTimezone Optional target timezone (defaults to UTC)
     * @return Carbon Carbon instance
     */
    public function fromISO8601($isoString, $targetTimezone = 'UTC')
    {
        try {
            $carbon = Carbon::parse($isoString);
            
            if ($targetTimezone !== 'UTC') {
                $carbon = $carbon->setTimezone($targetTimezone);
            }
            
            return $carbon;
        } catch (\Exception $e) {
            Log::error('Failed to parse ISO 8601 string', [
                'iso_string' => $isoString,
                'error' => $e->getMessage()
            ]);
            throw new \Exception("Invalid ISO 8601 datetime format: {$isoString}");
        }
    }

    /**
     * Convert a time from user's timezone to UTC
     * Accepts string, Carbon, or DateTime
     * 
     * @param mixed $dateTime The datetime in user's timezone to convert
     * @param string $userTimezone The user's timezone
     * @return Carbon Carbon instance in UTC
     */
    public function userToUTC($dateTime, $userTimezone) 
    {
        if (is_string($dateTime)) {
            return Carbon::parse($dateTime, $userTimezone)->setTimezone('UTC');
        }
        
        if ($dateTime instanceof Carbon) {
            return $dateTime->copy()->setTimezone('UTC');
        }
        
        if ($dateTime instanceof \DateTime) {
            return Carbon::instance($dateTime)->setTimezone('UTC');
        }
        
        throw new \Exception("Unsupported datetime format");
    }
}