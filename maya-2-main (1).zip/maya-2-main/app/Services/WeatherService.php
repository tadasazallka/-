<?php
// app/Services/WeatherService.php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class WeatherService
{
    protected $apiKey;
    protected $baseUrl = 'http://api.weatherapi.com/v1';
    
    public function __construct()
    {
        $this->apiKey = config('services.weatherapi.api_key');
    }
    
    /**
     * Get current weather for a location
     */
    public function getCurrentWeather(string $location, string $units = 'metric'): array
    {
        try {
            $cacheKey = "weather:current:{$location}:{$units}";
            
            // Cache for 30 minutes
            return Cache::remember($cacheKey, 1800, function () use ($location) {
                $response = Http::get("{$this->baseUrl}/current.json", [
                    'key' => $this->apiKey,
                    'q' => $location,
                    'aqi' => 'no'
                ]);
                
                if ($response->failed()) {
                    $error = $response->json()['error']['message'] ?? 'Failed to fetch weather data';
                    Log::error('Weather API error', [
                        'status' => $response->status(),
                        'error' => $error,
                        'location' => $location
                    ]);
                    
                    return [
                        'success' => false,
                        'error' => $error,
                    ];
                }
                
                $data = $response->json();
                
                return [
                    'success' => true,
                    'location' => $data['location']['name'] . ', ' . $data['location']['country'],
                    'temperature' => round($data['current']['temp_c']),
                    'feels_like' => round($data['current']['feelslike_c']),
                    'conditions' => $data['current']['condition']['text'],
                    'humidity' => $data['current']['humidity'],
                    'wind_speed' => round($data['current']['wind_kph'] / 3.6, 1), // Convert to m/s
                    'icon' => $data['current']['condition']['icon'],
                    'raw_data' => $data,
                ];
            });
        } catch (\Exception $e) {
            Log::error('Weather service error', [
                'error' => $e->getMessage(),
                'location' => $location
            ]);
            
            return [
                'success' => false,
                'error' => 'An error occurred while fetching weather data',
            ];
        }
    }
    
    /**
     * Get weather forecast for a location
     */
    public function getWeatherForecast(string $location, string $units = 'metric', int $days = 5): array
    {
        try {
            // WeatherAPI.com free tier allows up to 3 days of forecast
            $days = min($days, 3);
            $cacheKey = "weather:forecast:{$location}:{$units}:{$days}";
            
            // Cache for 1 hour
            return Cache::remember($cacheKey, 3600, function () use ($location, $days) {
                $response = Http::get("{$this->baseUrl}/forecast.json", [
                    'key' => $this->apiKey,
                    'q' => $location,
                    'days' => $days,
                    'aqi' => 'no',
                    'alerts' => 'no'
                ]);
                
                if ($response->failed()) {
                    $error = $response->json()['error']['message'] ?? 'Failed to fetch weather forecast';
                    Log::error('Weather API forecast error', [
                        'status' => $response->status(),
                        'error' => $error,
                        'location' => $location
                    ]);
                    
                    return [
                        'success' => false,
                        'error' => $error,
                    ];
                }
                
                $data = $response->json();
                $forecast = [];
                
                foreach ($data['forecast']['forecastday'] as $day) {
                    $forecast[] = [
                        'date' => $day['date'],
                        'min_temp' => round($day['day']['mintemp_c']),
                        'max_temp' => round($day['day']['maxtemp_c']),
                        'condition' => $day['day']['condition']['text'],
                        'description' => $day['day']['condition']['text'],
                    ];
                }
                
                return [
                    'success' => true,
                    'location' => $data['location']['name'] . ', ' . $data['location']['country'],
                    'forecast' => $forecast,
                ];
            });
        } catch (\Exception $e) {
            Log::error('Weather forecast service error', [
                'error' => $e->getMessage(),
                'location' => $location
            ]);
            
            return [
                'success' => false,
                'error' => 'An error occurred while fetching weather forecast',
            ];
        }
    }
    
    /**
     * Format weather data for WhatsApp message
     */
    public function formatWeatherMessage(array $weatherData): string
    {
        if (!$weatherData['success']) {
            return "⚠️ Unable to fetch weather data. Please try again later.";
        }
        
        $emoji = $this->getWeatherEmoji($weatherData['conditions']);
        
        $message = "🌤️ *Weather Update for {$weatherData['location']}*\n\n";
        $message .= "{$emoji} *Conditions:* {$weatherData['conditions']}\n";
        $message .= "🌡️ *Temperature:* {$weatherData['temperature']}°C\n";
        $message .= "🤔 *Feels like:* {$weatherData['feels_like']}°C\n";
        $message .= "💧 *Humidity:* {$weatherData['humidity']}%\n";
        $message .= "💨 *Wind:* {$weatherData['wind_speed']} m/s\n";
        
        return $message;
    }
    
    /**
     * Format forecast data for WhatsApp message
     */
    public function formatForecastMessage(array $forecastData): string
    {
        if (!$forecastData['success']) {
            return "⚠️ Unable to fetch weather forecast. Please try again later.";
        }
        
        $message = "📅 *Weather Forecast for {$forecastData['location']}*\n\n";
        
        foreach ($forecastData['forecast'] as $day) {
            $date = date('l, M j', strtotime($day['date']));
            $emoji = $this->getWeatherEmoji($day['description']);
            
            $message .= "*{$date}*\n";
            $message .= "{$emoji} {$day['description']}\n";
            $message .= "↑ {$day['max_temp']}°C / ↓ {$day['min_temp']}°C\n\n";
        }
        
        return trim($message);
    }
    
    /**
     * Get emoji for weather condition
     */
    private function getWeatherEmoji(string $condition): string
    {
        $condition = strtolower($condition);
        
        if (strpos($condition, 'clear') !== false || strpos($condition, 'sunny') !== false) return '☀️';
        if (strpos($condition, 'partly cloudy') !== false) return '⛅';
        if (strpos($condition, 'cloudy') !== false || strpos($condition, 'overcast') !== false) return '☁️';
        if (strpos($condition, 'rain') !== false || strpos($condition, 'drizzle') !== false) return '🌧️';
        if (strpos($condition, 'thunder') !== false || strpos($condition, 'storm') !== false) return '⛈️';
        if (strpos($condition, 'snow') !== false || strpos($condition, 'sleet') !== false) return '❄️';
        if (strpos($condition, 'mist') !== false || strpos($condition, 'fog') !== false) return '🌫️';
        
        return '🌤️';
    }
}