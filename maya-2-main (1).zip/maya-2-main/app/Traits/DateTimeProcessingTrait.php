<?php

namespace App\Traits;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;

trait DateTimeProcessingTrait
{
    // Time definitions for natural language processing
    protected const TIME_DEFINITIONS = [
        'morning' => ['start' => '08:00', 'end' => '12:00'],
        'noon' => ['start' => '12:00', 'end' => '13:00'],
        'afternoon' => ['start' => '13:00', 'end' => '17:00'],
        'evening' => ['start' => '17:00', 'end' => '21:00'],
        'night' => ['start' => '21:00', 'end' => '23:59'],
        'midnight' => ['start' => '00:00', 'end' => '01:00'],
    ];

    /**
     * Process natural language date and time references
     */
    protected function processNaturalLanguageDates(array $eventParams, string $timezone): array
    {
        // Handle relative date expressions
        if (isset($eventParams['start_date'])) {
            $dateString = strtolower($eventParams['start_date']);
            
            // Handle relative dates
            switch ($dateString) {
                case 'today':
                    $eventParams['start_date'] = Carbon::now($timezone)->format('Y-m-d');
                    break;
                case 'tomorrow':
                    $eventParams['start_date'] = Carbon::now($timezone)->addDay()->format('Y-m-d');
                    break;
                case 'day after tomorrow':
                    $eventParams['start_date'] = Carbon::now($timezone)->addDays(2)->format('Y-m-d');
                    break;
                case 'yesterday':
                    $eventParams['start_date'] = Carbon::now($timezone)->subDay()->format('Y-m-d');
                    break;
            }
            
            // Handle "this week", "next week", "this month", etc.
            if (strpos($dateString, 'this week') !== false) {
                $currentDayOfWeek = Carbon::now($timezone)->dayOfWeek;
                $daysToAdd = 0;
                
                // Set to middle of the week if no specific day mentioned
                if ($dateString === 'this week') {
                    // If it's already Friday or weekend, move to next week
                    if ($currentDayOfWeek >= 5) { // Friday, Saturday or Sunday
                        $eventParams['start_date'] = Carbon::now($timezone)->addDays(8 - $currentDayOfWeek)->format('Y-m-d');
                        $eventParams['natural_time_description'] = 'this week (next Monday)';
                    } else {
                        $daysToAdd = 3 - $currentDayOfWeek; // Target Wednesday
                        if ($daysToAdd < 0) $daysToAdd = 0;
                        $eventParams['start_date'] = Carbon::now($timezone)->addDays($daysToAdd)->format('Y-m-d');
                        $eventParams['natural_time_description'] = 'this week';
                    }
                }
            }
            
            if (strpos($dateString, 'next week') !== false) {
                $eventParams['start_date'] = Carbon::now($timezone)->addWeek()->startOfWeek()->addDays(2)->format('Y-m-d');
                $eventParams['natural_time_description'] = 'next week (Wednesday)';
            }
            
            if (strpos($dateString, 'this month') !== false) {
                $now = Carbon::now($timezone);
                $daysInMonth = $now->daysInMonth;
                $currentDay = $now->day;
                
                // If we're in the last week of the month, schedule for the first week of next month
                if ($currentDay > $daysInMonth - 7) {
                    $eventParams['start_date'] = $now->addMonth()->startOfMonth()->addDays(5)->format('Y-m-d');
                    $eventParams['natural_time_description'] = 'early next month';
                } else {
                    // Otherwise schedule for the middle of the current month
                    $targetDay = intval($daysInMonth / 2);
                    if ($currentDay >= $targetDay) {
                        $targetDay = $currentDay + 2; // Just a couple days ahead if we're already past midpoint
                        if ($targetDay > $daysInMonth) $targetDay = $daysInMonth;
                    }
                    $eventParams['start_date'] = $now->setDay($targetDay)->format('Y-m-d');
                    $eventParams['natural_time_description'] = 'this month';
                }
            }
            
            if (strpos($dateString, 'next month') !== false) {
                $nextMonth = Carbon::now($timezone)->addMonth();
                $eventParams['start_date'] = $nextMonth->setDay(min(15, $nextMonth->daysInMonth))->format('Y-m-d');
                $eventParams['natural_time_description'] = 'middle of next month';
            }
            
            // Handle specific days of the week
            $daysOfWeek = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
            foreach ($daysOfWeek as $index => $day) {
                if (strpos($dateString, $day) !== false) {
                    $currentDayOfWeek = Carbon::now($timezone)->dayOfWeek;
                    // In Carbon, dayOfWeek is 0 (Sunday) through 6 (Saturday)
                    // Convert to 1 (Monday) through 7 (Sunday) for easier calculation
                    $targetDayOfWeek = $index + 1;
                    if ($targetDayOfWeek == 7) $targetDayOfWeek = 0; // Adjust for Sunday
                    
                    // Calculate days to add
                    $daysToAdd = ($targetDayOfWeek - $currentDayOfWeek) % 7;
                    // If the day is today and it's past noon, or the calculated day is in the past, add a week
                    if (($daysToAdd == 0 && Carbon::now($timezone)->hour >= 12) || $daysToAdd < 0) {
                        $daysToAdd += 7;
                    }
                    
                    $eventParams['start_date'] = Carbon::now($timezone)->addDays($daysToAdd)->format('Y-m-d');
                    $eventParams['natural_time_description'] = 'on ' . ucfirst($day);
                    break;
                }
            }
        }
        
        // Handle time expressions
        if (isset($eventParams['start_time'])) {
            $timeString = strtolower($eventParams['start_time']);
            
            foreach (self::TIME_DEFINITIONS as $timeName => $timeRange) {
                if ($timeString === $timeName) {
                    $eventParams['start_time'] = $timeRange['start'];
                    $eventParams['end_time'] = $timeRange['end'];
                    $eventParams['natural_time_description'] = 'in the ' . $timeName;
                    break;
                }
            }
        }
        
        // If end date is not specified but start date is, use start date as end date
        if (!isset($eventParams['end_date']) && isset($eventParams['start_date'])) {
            $eventParams['end_date'] = $eventParams['start_date'];
        }
        
        return $eventParams;
    }

    /**
     * Parse date and time strings into a Carbon datetime
     */
    protected function parseDateTime(?string $date, ?string $time, string $timezone): \Carbon\Carbon
    {
        $dateString = $date ?? date('Y-m-d');
        $timeString = $time ?? '09:00';
        
        // Check if time is a natural language expression
        $timeString = $this->convertNaturalTimeToFormat($timeString);
        
        // Combine date and time
        $dateTimeString = $dateString . ' ' . $timeString;
        
        try {
            // Parse with user's timezone
            return Carbon::parse($dateTimeString, $timezone);
        } catch (\Exception $e) {
            // Fallback to current date and time
            Log::warning('Failed to parse date time: ' . $dateTimeString . ', falling back to current', [
                'exception' => $e->getMessage()
            ]);
            return Carbon::now($timezone);
        }
    }
    
    /**
     * Convert natural language time expressions to formatted time
     */
    protected function convertNaturalTimeToFormat(string $timeExpression): string
    {
        $timeExpression = strtolower(trim($timeExpression));
        
        // Check if it matches any of our predefined time periods
        if (isset(self::TIME_DEFINITIONS[$timeExpression])) {
            return self::TIME_DEFINITIONS[$timeExpression]['start'];
        }
        
        // Process more complex time expressions
        if (preg_match('/^(\d{1,2})(?:\s*)(am|pm)$/', $timeExpression, $matches)) {
            $hour = (int)$matches[1];
            $meridiem = $matches[2];
            
            if ($meridiem === 'pm' && $hour < 12) {
                $hour += 12;
            } elseif ($meridiem === 'am' && $hour === 12) {
                $hour = 0;
            }
            
            return sprintf('%02d:00', $hour);
        }
        
        // Handle "noon" and specific cases
        switch ($timeExpression) {
            case 'noon':
            case 'midday':
                return '12:00';
            case 'midnight':
                return '00:00';
            case 'end of day':
            case 'end of the day':
            case 'eod':
                return '17:00';
            case 'dawn':
            case 'sunrise':
                return '06:30';
            case 'dusk':
            case 'sunset':
                return '18:30';
        }
        
        // If all else fails, return the original time expression
        // Carbon might be able to parse it directly
        return $timeExpression;
    }
}