<?php

namespace App\Jobs;

use App\Models\CalendarAccount;
use App\Models\CalendarConnection;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SyncAllCalendarsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $userId;

    /**
     * Create a new job instance.
     */
    public function __construct(int $userId)
    {
        $this->userId = $userId;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        // Get all active calendar accounts for this user
        $accounts = CalendarAccount::where('user_id', $this->userId)
            ->where('is_active', true)
            ->get();

        foreach ($accounts as $account) {
            // Get active calendars for this account
            $calendars = CalendarConnection::where('calendar_account_id', $account->id)
                ->where('is_active', true)
                ->get();
                
            foreach ($calendars as $calendar) {
                // Dispatch individual sync jobs for each calendar
                SyncCalendarJob::dispatch($calendar)
                    ->onQueue('calendarsync');
                    
                Log::info('Dispatched sync job for calendar', [
                    'user_id' => $this->userId,
                    'calendar_id' => $calendar->id,
                    'provider' => $calendar->provider
                ]);
            }
        }
    }
}