<?php

namespace App\Jobs;

use App\Models\CalendarConnection;
use App\Services\Calendars\Sync\GoogleCalendarSyncService;
use App\Services\Calendars\Sync\AppleCalendarSyncService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SyncCalendarJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * The calendar connection instance.
     *
     * @var CalendarConnection
     */
    protected $calendarConnection;

    /**
     * The number of times the job may be attempted.
     *
     * @var int
     */
    public $tries = 1;

    /**
     * Create a new job instance.
     *
     * @param CalendarConnection $calendarConnection
     * @return void
     */
    public function __construct(CalendarConnection $calendarConnection)
    {
        $this->calendarConnection = $calendarConnection;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        Log::info('Starting background sync for calendar', [
            'calendar_id' => $this->calendarConnection->id,
            'provider' => $this->calendarConnection->provider
        ]);

        if(!$this->calendarConnection->is_active){
            return;
        }

        try {
            if ($this->calendarConnection->provider === 'google') {
                // First register push notifications for Google calendars
                $googleSyncService = app(GoogleCalendarSyncService::class);
                // $googleSyncService->registerPushNotifications($this->calendarConnection);
                
                // Then sync events
                $googleSyncService->syncCalendarEvents($this->calendarConnection);
            } 
            elseif ($this->calendarConnection->provider === 'apple') {
                $appleSyncService = app(AppleCalendarSyncService::class);
                $appleSyncService->syncCalendarEvents($this->calendarConnection);
            }

            Log::info('Background sync completed successfully for calendar', [
                'calendar_id' => $this->calendarConnection->id
            ]);
        } catch (\Exception $e) {
            Log::error('Error in background calendar sync', [
                'calendar_id' => $this->calendarConnection->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            throw $e; // Rethrow to trigger retry mechanism
        }
    }
}