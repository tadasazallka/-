<?php

namespace App\Jobs;

use App\Http\Controllers\WhatsappHookController;
use App\Models\User;
use App\Resources\WhatsappMessages;
use App\Services\CloudinaryService;
use App\Services\MessageProcessorService;
use App\Services\MessageQueueService;
use App\Services\ManyChatAPIService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ProcessUserMessagesJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * User whose messages will be processed
     */
    protected $user;
    
    /**
     * The maximum number of tries
     */
    public $tries = 3;
    
    /**
     * Timeout in seconds
     */
    public $timeout = 180;
    
    /**
     * Create a new job instance.
     */
    public function __construct(User $user)
    {
        $this->user = $user;
        $this->onQueue('whatsapp-messages');
    }

    /**
     * Execute the job.
     */
    public function handle(
        MessageQueueService $queueService,
        MessageProcessorService $messageProcessor,
        ManyChatAPIService $manyChatAPIService,
        CloudinaryService $cloudinaryService
    ) {
        // Try to acquire the user lock - if we can't, exit gracefully
        if (!$queueService->acquireUserLock($this->user)) {
            Log::info('Another job is already processing messages for this user', [
                'user_id' => $this->user->id
            ]);
            return;
        }
        
        try {
            // Process messages as long as there are any in the queue
            while ($queueService->hasQueuedMessages($this->user)) {
                // Get the next message for processing
                $message = $queueService->getNextMessageForProcessing($this->user);
                
                // If no message was returned (it might be locked), break the loop
                if (!$message) {
                    Log::info('No messages available for processing', [
                        'user_id' => $this->user->id
                    ]);
                    break;
                }
                
                Log::info('Processing message via ManyChat', [
                    'user_id' => $this->user->id,
                    'message_id' => $message['id'],
                    'message_type' => $message['type'] ?? 'unknown',
                    'subscriber_id' => $message['subscriber_id'] ?? null
                ]);
                
                try {
                    // Process message based on its type
                    $response = $this->processMessageByType(
                        $message, 
                        $messageProcessor, 
                        $manyChatAPIService, 
                        $cloudinaryService
                    );
                    
                    if ($response) {
                        // Send response back to the user via ManyChat
                        $subscriberId = $this->user->manychat_subscriber_id;
                        if ($subscriberId) {
                            $sent = $manyChatAPIService->sendWhatsAppMessage($subscriberId, $response);
                            
                            if ($sent) {
                                Log::info('Response sent via ManyChat', [
                                    'user_id' => $this->user->id,
                                    'subscriber_id' => $subscriberId,
                                    'message_id' => $message['id'],
                                    'response_length' => strlen($response)
                                ]);
                            } else {
                                Log::warning('Failed to send response via ManyChat', [
                                    'user_id' => $this->user->id,
                                    'subscriber_id' => $subscriberId,
                                    'message_id' => $message['id']
                                ]);
                            }
                        } else {
                            Log::warning('No ManyChat subscriber ID found for user', [
                                'user_id' => $this->user->id,
                                'message_id' => $message['id']
                            ]);
                        }
                    } else {
                        Log::warning('No response generated for message', [
                            'user_id' => $this->user->id,
                            'message_id' => $message['id'],
                            'message_type' => $message['type']
                        ]);
                    }
                    
                    // Mark message as processed
                    $queueService->markMessageAsProcessed($this->user, $message['id']);
                    
                } catch (\Exception $e) {
                    // Log the error
                    Log::error('Error processing message via ManyChat: ' . $e->getMessage(), [
                        'user_id' => $this->user->id,
                        'message_id' => $message['id'],
                        'message_type' => $message['type'] ?? 'unknown',
                        'trace' => $e->getTraceAsString()
                    ]);
                    
                    // Release the lock for this message
                    $queueService->releaseMessageLock($this->user, $message['id']);
                    
                    // Send error response via ManyChat
                    $language = $this->user->preferences->language ?? 'en';
                    $errorResponse = WhatsappMessages::getErrorResponse($language);
                    
                    $subscriberId = $this->user->manychat_subscriber_id;
                    if ($subscriberId) {
                        $manyChatAPIService->sendWhatsAppMessage($subscriberId, $errorResponse);
                    }
                    
                    // Mark it as processed to prevent endless retries
                    $queueService->markMessageAsProcessed($this->user, $message['id']);
                }
            }
        } catch (\Exception $e) {
            Log::error('Fatal error in ManyChat message processing job: ' . $e->getMessage(), [
                'user_id' => $this->user->id,
                'trace' => $e->getTraceAsString()
            ]);
        } finally {
            // Always release the user lock when done
            $queueService->releaseUserLock($this->user);
        }
        
        Log::info('ManyChat message processing job completed', [
            'user_id' => $this->user->id
        ]);
        
        // If there are still messages in the queue, dispatch a new job
        if ($queueService->hasQueuedMessages($this->user)) {
            Log::info('New messages added during processing, dispatching follow-up job', [
                'user_id' => $this->user->id,
                'queue_count' => $queueService->countQueuedMessages($this->user)
            ]);
            
            self::dispatch($this->user)->delay(now()->addSeconds(2));
        }
    }
    
    /**
     * Process a message based on its type for ManyChat
     */
    protected function processMessageByType(
        array $message, 
        MessageProcessorService $messageProcessor,
        ManyChatAPIService $manyChatAPIService,
        CloudinaryService $cloudinaryService
    ): ?string {
        $language = $this->user->preferences->language ?? 'en';
        
        switch ($message['type']) {
            case 'text':
                return $messageProcessor->processTextMessage($this->user, $message['content']);
                
            case 'image':
                return $this->processImageMessage($message, $messageProcessor, $cloudinaryService, $language);
                
            case 'audio':
                return $this->processAudioMessage($message, $messageProcessor, $cloudinaryService, $language);
                
            case 'document':
                return WhatsappMessages::getDocumentResponse($language);
                
            case 'sticker':
                return WhatsappMessages::getStickerResponse($language);
                
            case 'location':
                $locationData = $message['location'] ?? [];
                $name = $locationData['name'] ?? 'this location';
                return WhatsappMessages::getLocationResponse($language, $name);
                
            case 'unknown':
            default:
                return WhatsappMessages::getUnknownTypeResponse($language);
        }
    }
    
    /**
     * Process image message from ManyChat URL
     */
    protected function processImageMessage(
        array $message, 
        MessageProcessorService $messageProcessor,
        CloudinaryService $cloudinaryService,
        string $language
    ): string {
        $imageData = $message['image'] ?? [];
        $imageUrl = $imageData['url'] ?? null;
        
        if (!$imageUrl) {
            Log::warning('No image URL provided in message', [
                'user_id' => $this->user->id,
                'message_id' => $message['id']
            ]);
            return WhatsappMessages::getMediaProcessingErrorMessage($language, 'image');
        }
        
        try {
            // Send processing acknowledgment first
            $this->sendProcessingAcknowledgment('image', $language);
            
            // Download image from ManyChat URL
            $context = stream_context_create([
                'http' => [
                    'timeout' => 30,
                    'user_agent' => 'Mozilla/5.0 (compatible; MayaBot/1.0)'
                ]
            ]);
            
            $mediaContent = file_get_contents($imageUrl, false, $context);
            
            if (!$mediaContent) {
                Log::error('Failed to download image from ManyChat URL', [
                    'user_id' => $this->user->id,
                    'image_url' => $imageUrl
                ]);
                return WhatsappMessages::getMediaProcessingErrorMessage($language, 'image');
            }
            
            // Check file size
            $fileSize = strlen($mediaContent);
            if ($fileSize > WhatsappHookController::MAX_IMAGE_SIZE_BYTES) {
                Log::warning('Image file too large', [
                    'user_id' => $this->user->id,
                    'file_size' => $fileSize,
                    'max_size' => WhatsappHookController::MAX_IMAGE_SIZE_BYTES
                ]);
                return WhatsappMessages::getMediaSizeExceededMessage($language, 'image');
            }
            
            // Upload to Cloudinary
            $cloudinaryData = $cloudinaryService->uploadFromBinary(
                $mediaContent, 
                "manychat/images", 
                "image", 
                "manychat_image_" . uniqid() . ".jpg"
            );
            
            if (!$cloudinaryData || isset($cloudinaryData['error'])) {
                Log::error('Failed to upload image to Cloudinary', [
                    'user_id' => $this->user->id,
                    'cloudinary_error' => $cloudinaryData['error'] ?? 'unknown'
                ]);
                return WhatsappMessages::getMediaProcessingErrorMessage($language, 'image');
            }
            
            // Process the image with message processor
            return $messageProcessor->processImageMessage(
                $this->user,
                $cloudinaryData['secure_url'],
                $cloudinaryData['public_id']
            );
            
        } catch (\Exception $e) {
            Log::error('Exception processing image from ManyChat: ' . $e->getMessage(), [
                'user_id' => $this->user->id,
                'image_url' => $imageUrl,
                'trace' => $e->getTraceAsString()
            ]);
            return WhatsappMessages::getImageProcessingErrorMessage($language);
        }
    }
    
    /**
     * Process audio message from ManyChat URL
     */
    protected function processAudioMessage(
        array $message, 
        MessageProcessorService $messageProcessor,
        CloudinaryService $cloudinaryService,
        string $language
    ): string {
        $audioData = $message['audio'] ?? [];
        $audioUrl = $audioData['url'] ?? null;
        
        if (!$audioUrl) {
            Log::warning('No audio URL provided in message', [
                'user_id' => $this->user->id,
                'message_id' => $message['id']
            ]);
            return WhatsappMessages::getMediaProcessingErrorMessage($language, 'audio');
        }
        
        try {
            // Send processing acknowledgment first
            $this->sendProcessingAcknowledgment('audio', $language);
            
            // Download audio from ManyChat URL
            $context = stream_context_create([
                'http' => [
                    'timeout' => 30,
                    'user_agent' => 'Mozilla/5.0 (compatible; MayaBot/1.0)'
                ]
            ]);
            
            $mediaContent = file_get_contents($audioUrl, false, $context);
            
            if (!$mediaContent) {
                Log::error('Failed to download audio from ManyChat URL', [
                    'user_id' => $this->user->id,
                    'audio_url' => $audioUrl
                ]);
                return WhatsappMessages::getMediaProcessingErrorMessage($language, 'audio');
            }
            
            // Check file size
            $fileSize = strlen($mediaContent);
            if ($fileSize > WhatsappHookController::MAX_AUDIO_SIZE_BYTES) {
                Log::warning('Audio file too large', [
                    'user_id' => $this->user->id,
                    'file_size' => $fileSize,
                    'max_size' => WhatsappHookController::MAX_AUDIO_SIZE_BYTES
                ]);
                return WhatsappMessages::getMediaSizeExceededMessage($language, 'audio');
            }
            
            // Upload to Cloudinary (use 'video' resource type for audio)
            $cloudinaryData = $cloudinaryService->uploadFromBinary(
                $mediaContent, 
                "manychat/audios", 
                "video", 
                "manychat_audio_" . uniqid() . ".mp3"
            );
            
            if (!$cloudinaryData || isset($cloudinaryData['error'])) {
                Log::error('Failed to upload audio to Cloudinary', [
                    'user_id' => $this->user->id,
                    'cloudinary_error' => $cloudinaryData['error'] ?? 'unknown'
                ]);
                return WhatsappMessages::getMediaProcessingErrorMessage($language, 'audio');
            }
            
            // Process the audio with message processor
            return $messageProcessor->processVoiceMessage(
                $this->user,
                $cloudinaryData['secure_url'],
                $cloudinaryData['public_id']
            );
            
        } catch (\Exception $e) {
            Log::error('Exception processing audio from ManyChat: ' . $e->getMessage(), [
                'user_id' => $this->user->id,
                'audio_url' => $audioUrl,
                'trace' => $e->getTraceAsString()
            ]);
            return WhatsappMessages::getAudioProcessingErrorMessage($language);
        }
    }
    
    /**
     * Send a processing acknowledgment message
     */
    protected function sendProcessingAcknowledgment(string $messageType, string $language): void
    {
        try {
            $subscriberId = $this->user->manychat_subscriber_id;
            if (!$subscriberId) {
                return;
            }
            
            $message = '';
            switch ($messageType) {
                case 'image':
                    $messages = WhatsappMessages::getImageAcknowledgmentMessages($language);
                    $message = $messages[array_rand($messages)];
                    break;
                case 'audio':
                    $messages = WhatsappMessages::getAudioAcknowledgmentMessages($language);
                    $message = $messages[array_rand($messages)];
                    break;
                default:
                    return;
            }
            
            if (!empty($message)) {
                app(ManyChatAPIService::class)->sendWhatsAppMessage($subscriberId, $message);
                Log::info("Sent processing acknowledgment via ManyChat for {$messageType}", [
                    'user_id' => $this->user->id,
                    'subscriber_id' => $subscriberId,
                    'language' => $language
                ]);
            }
        } catch (\Exception $e) {
            Log::warning("Failed to send processing acknowledgment via ManyChat: {$e->getMessage()}");
        }
    }
    
    /**
     * The job failed to process.
     */
    public function failed(\Throwable $exception)
    {
        Log::error('ManyChat message processing job failed', [
            'user_id' => $this->user->id,
            'exception' => $exception->getMessage(),
            'trace' => $exception->getTraceAsString()
        ]);
        
        // Release the user lock to prevent deadlock
        app(MessageQueueService::class)->releaseUserLock($this->user);
    }
}