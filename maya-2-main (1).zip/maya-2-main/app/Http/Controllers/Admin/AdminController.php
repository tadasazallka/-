<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Event;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\CalendarAccount;
use App\Models\CalendarConnection;
use App\Models\ScheduledEmail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    /**
     * Get overview statistics for the admin dashboard
     */
    public function overview()
    {
        $data = [
            'users' => $this->getUserStats(),
            'events' => $this->getEventStats(),
            'subscriptions' => $this->getSubscriptionStats(),
            'calendar_integrations' => $this->getCalendarIntegrationStats(),
            'scheduled_emails' => $this->getScheduledEmailStats(),
            'growth' => $this->getGrowthStats(),
        ];

        return response()->json($data);
    }

    /**
     * Get detailed user statistics
     */
    public function users(Request $request)
    {
        $perPage = $request->get('per_page', 15);
        $search = $request->get('search');
        
        $query = User::with(['preferences', 'activeSubscription.plan'])
            ->withCount(['events', 'calendars', 'subscriptions']);

        if ($search) {
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('whatsapp_id', 'like', "%{$search}%");
            });
        }

        $users = $query->latest()->paginate($perPage);

        return response()->json($users);
    }

    /**
     * Get detailed event statistics
     */
    public function events(Request $request)
    {
        $perPage = $request->get('per_page', 15);
        $status = $request->get('status');
        $dateFrom = $request->get('date_from');
        $dateTo = $request->get('date_to');

        $query = Event::with(['user:id,name,email', 'calendar:id,name,provider'])
            ->select('*');

        if ($status) {
            $query->where('status', $status);
        }

        if ($dateFrom) {
            $query->where('start_time', '>=', Carbon::parse($dateFrom));
        }

        if ($dateTo) {
            $query->where('start_time', '<=', Carbon::parse($dateTo));
        }

        $events = $query->latest('start_time')->paginate($perPage);

        return response()->json($events);
    }

    /**
     * Get subscription analytics
     */
    public function subscriptions(Request $request)
    {
        $perPage = $request->get('per_page', 15);
        $status = $request->get('status');
        $planId = $request->get('plan_id');

        $query = Subscription::with(['user:id,name,email', 'plan:id,name,slug,price'])
            ->select('*');

        if ($status) {
            $query->where('status', $status);
        }

        if ($planId) {
            $query->where('plan_id', $planId);
        }

        $subscriptions = $query->latest()->paginate($perPage);

        return response()->json($subscriptions);
    }

    /**
     * Get revenue analytics
     */
    public function revenue(Request $request)
    {
        $period = $request->get('period', 'month'); // month, year, week
        $limit = $request->get('limit', 12);

        $data = [];

        switch ($period) {
            case 'week':
                $data = $this->getRevenueByPeriod('week', $limit);
                break;
            case 'year':
                $data = $this->getRevenueByPeriod('year', $limit);
                break;
            default:
                $data = $this->getRevenueByPeriod('month', $limit);
        }

        return response()->json([
            'period' => $period,
            'data' => $data,
            'total_revenue' => collect($data)->sum('revenue'),
            'total_subscriptions' => collect($data)->sum('subscriptions')
        ]);
    }

    /**
     * Get system health metrics
     */
    public function systemHealth()
    {
        $data = [
            'active_users_today' => User::whereDate('updated_at', today())->count(),
            'events_created_today' => Event::whereDate('created_at', today())->count(),
            'pending_scheduled_emails' => ScheduledEmail::where('status', 'pending')->count(),
            'failed_scheduled_emails' => ScheduledEmail::where('status', 'failed')->count(),
            'calendar_sync_errors' => CalendarAccount::where('is_active', false)->count(),
            'users_without_preferences' => User::doesntHave('preferences')->count(),
            'events_needing_reminders' => Event::needingReminders()->count(),
            'recurring_events_count' => Event::whereNotNull('recurrence')->count(),
        ];

        return response()->json($data);
    }

    /**
     * Get user activity data
     */
    public function userActivity(Request $request)
    {
        $days = $request->get('days', 30);
        
        $activity = DB::table('users')
            ->select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as registrations')
            )
            ->where('created_at', '>=', now()->subDays($days))
            ->groupBy(DB::raw('DATE(created_at)'))
            ->orderBy('date')
            ->get();

        $eventActivity = DB::table('events')
            ->select(
                DB::raw('DATE(created_at) as date'),
                DB::raw('COUNT(*) as events_created')
            )
            ->where('created_at', '>=', now()->subDays($days))
            ->groupBy(DB::raw('DATE(created_at)'))
            ->orderBy('date')
            ->get();

        return response()->json([
            'registrations' => $activity,
            'events_created' => $eventActivity
        ]);
    }

    /**
     * Get user engagement metrics
     */
    public function engagement()
    {
        $data = [
            'total_users' => User::count(),
            'signed_up_users' => User::where('is_signed_up', true)->count(),
            'users_with_events' => User::has('events')->count(),
            'users_with_calendar_connections' => User::has('calendars')->count(),
            'users_with_preferences' => User::has('preferences')->count(),
            'average_events_per_user' => round(Event::count() / max(User::count(), 1), 2),
            'users_by_timezone' => User::select('timezone', DB::raw('count(*) as count'))
                ->groupBy('timezone')
                ->orderByDesc('count')
                ->get(),
            'preferred_languages' => DB::table('user_preferences')
                ->select('language', DB::raw('count(*) as count'))
                ->whereNotNull('language')
                ->groupBy('language')
                ->orderByDesc('count')
                ->get(),
        ];

        return response()->json($data);
    }

    /**
     * Get plans overview
     */
    public function plans()
    {
        $plans = Plan::withCount('subscriptions')
            ->with(['subscriptions' => function($query) {
                $query->where('status', 'active');
            }])
            ->get()
            ->map(function($plan) {
                return [
                    'id' => $plan->id,
                    'name' => $plan->name,
                    'slug' => $plan->slug,
                    'price' => $plan->price,
                    'is_active' => $plan->is_active,
                    'total_subscriptions' => $plan->subscriptions_count,
                    'active_subscriptions' => $plan->subscriptions->where('status', 'active')->count(),
                    // Remove monthly_revenue as 'amount' column doesn't exist in subscriptions table
                    // 'monthly_revenue' => $plan->subscriptions->where('status', 'active')->sum('amount'),
                ];
            });

        return response()->json($plans);
    }

    // Private helper methods

    private function getUserStats()
    {
        return [
            'total' => User::count(),
            'signed_up' => User::where('is_signed_up', true)->count(),
            'with_subscriptions' => User::has('subscriptions')->count(),
            'premium_users' => Subscription::where('status', 'active')
                ->whereHas('plan', function($q) {
                    $q->where('slug', '!=', 'free');
                })->count(),
            'recent' => User::where('created_at', '>=', now()->subDays(7))->count(),
        ];
    }

    private function getEventStats()
    {
        return [
            'total' => Event::count(),
            'upcoming' => Event::upcoming()->count(),
            'past' => Event::past()->count(),
            'with_reminders' => Event::whereNotNull('reminder')->count(),
            'recurring' => Event::whereNotNull('recurrence')->count(),
            'all_day' => Event::where('is_all_day', true)->count(),
            'by_status' => Event::select('status', DB::raw('count(*) as count'))
                ->groupBy('status')
                ->pluck('count', 'status'),
        ];
    }

    private function getSubscriptionStats()
    {
        return [
            'total' => Subscription::count(),
            'active' => Subscription::where('status', 'active')->count(),
            'cancelled' => Subscription::where('status', 'cancelled')->count(),
            'on_trial' => Subscription::where('trial_ends_at', '>', now())->count(),
            // Removed monthly_revenue calculation as 'amount' column doesn't exist
            // 'monthly_revenue' => Subscription::where('status', 'active')->sum('amount'),
            'by_plan' => Subscription::join('plans', 'subscriptions.plan_id', '=', 'plans.id')
                ->select('plans.name', DB::raw('count(*) as count'))
                ->where('subscriptions.status', 'active')
                ->groupBy('plans.name')
                ->pluck('count', 'name'),
        ];
    }

    private function getCalendarIntegrationStats()
    {
        return [
            'total_accounts' => CalendarAccount::count(),
            'active_accounts' => CalendarAccount::where('is_active', true)->count(),
            'by_provider' => CalendarAccount::select('provider', DB::raw('count(*) as count'))
                ->groupBy('provider')
                ->pluck('count', 'provider'),
            'total_connections' => CalendarConnection::count(),
            'primary_calendars' => CalendarConnection::where('is_primary', true)->count(),
        ];
    }

    private function getScheduledEmailStats()
    {
        return [
            'total' => ScheduledEmail::count(),
            'pending' => ScheduledEmail::where('status', 'pending')->count(),
            'sent' => ScheduledEmail::where('status', 'sent')->count(),
            'failed' => ScheduledEmail::where('status', 'failed')->count(),
            'scheduled_today' => ScheduledEmail::whereDate('scheduled_for', today())->count(),
        ];
    }

    private function getGrowthStats()
    {
        $thirtyDaysAgo = now()->subDays(30);
        $sixtyDaysAgo = now()->subDays(60);

        $currentPeriodUsers = User::where('created_at', '>=', $thirtyDaysAgo)->count();
        $previousPeriodUsers = User::where('created_at', '>=', $sixtyDaysAgo)
            ->where('created_at', '<', $thirtyDaysAgo)->count();

        $currentPeriodEvents = Event::where('created_at', '>=', $thirtyDaysAgo)->count();
        $previousPeriodEvents = Event::where('created_at', '>=', $sixtyDaysAgo)
            ->where('created_at', '<', $thirtyDaysAgo)->count();

        return [
            'user_growth_rate' => $this->calculateGrowthRate($currentPeriodUsers, $previousPeriodUsers),
            'event_growth_rate' => $this->calculateGrowthRate($currentPeriodEvents, $previousPeriodEvents),
            'current_period_users' => $currentPeriodUsers,
            'previous_period_users' => $previousPeriodUsers,
            'current_period_events' => $currentPeriodEvents,
            'previous_period_events' => $previousPeriodEvents,
        ];
    }

    private function getRevenueByPeriod($period, $limit)
    {
        $dateFormat = match($period) {
            'week' => '%Y-%u',
            'year' => '%Y',
            default => '%Y-%m'
        };

        // Calculate revenue based on plan prices for active subscriptions
        return Subscription::join('plans', 'subscriptions.plan_id', '=', 'plans.id')
            ->select(
                DB::raw("DATE_FORMAT(subscriptions.created_at, '{$dateFormat}') as period"),
                DB::raw('SUM(plans.price) as revenue'),
                DB::raw('COUNT(*) as subscriptions')
            )
            ->where('subscriptions.status', 'active')
            ->groupBy('period')
            ->orderByDesc('period')
            ->limit($limit)
            ->get()
            ->reverse()
            ->values();
    }

    private function calculateGrowthRate($current, $previous)
    {
        if ($previous == 0) {
            return $current > 0 ? 100 : 0;
        }
        
        return round((($current - $previous) / $previous) * 100, 2);
    }
}