<?php

namespace App\Http\Controllers\Sync;

use App\Http\Controllers\Controller;
use App\Models\CalendarConnection;
use App\Services\Calendars\Sync\GoogleCalendarSyncService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;

class CalendarSyncController extends Controller
{
    /**
     * Google Calendar Sync Service
     * 
     * @var GoogleCalendarSyncService
     */
    protected $googleSyncService;
    
    /**
     * Constructor
     * 
     * @param GoogleCalendarSyncService $googleSyncService
     */
    public function __construct(GoogleCalendarSyncService $googleSyncService)
    {
        $this->googleSyncService = $googleSyncService;
    }
    
    /**
     * Handle Google Calendar webhook notifications
     * 
     * @param Request $request
     * @return JsonResponse
     */
    public function handleGoogleWebhook(Request $request): JsonResponse
    {
        Log::info('Google Calendar webhook received', [
            'headers' => $request->headers->all(),
            'ip' => $request->ip()
        ]);
        
        try {
            // Process the notification
            $result = $this->googleSyncService->processNotification($request->headers->all());
            
            return response()->json([
                'success' => $result['success'],
                'message' => $result['message']
            ]);
            
        } catch (\Exception $e) {
            Log::error('Error handling Google Calendar webhook', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Error processing webhook notification: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Manually sync a specific calendar
     * 
     * @param Request $request
     * @param int $id Calendar connection ID
     * @return JsonResponse
     */
    public function syncCalendar(Request $request, int $id): JsonResponse
    {
        try {
            $user = $request->user();
            
            // Find the calendar
            $calendar = CalendarConnection::where('id', $id)
                ->where('user_id', $user->id)
                ->first();
                
            if (!$calendar) {
                return response()->json([
                    'success' => false,
                    'message' => 'Calendar not found'
                ], 404);
            }
            
            if ($calendar->provider !== 'google') {
                return response()->json([
                    'success' => false,
                    'message' => 'This endpoint only supports Google Calendar synchronization'
                ], 400);
            }
            
            // Sync the calendar
            $result = $this->googleSyncService->syncCalendarEvents($calendar);
            
            return response()->json([
                'success' => true,
                'message' => 'Calendar synchronized successfully',
                'stats' => $result
            ]);
            
        } catch (\Exception $e) {
            Log::error('Error synchronizing calendar', [
                'calendar_id' => $id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Error synchronizing calendar: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Enable push notifications for a calendar
     * 
     * @param Request $request
     * @param int $id Calendar connection ID
     * @return JsonResponse
     */
    public function enablePushNotifications(Request $request, int $id): JsonResponse
    {
        try {
            $user = $request->user();
            
            // Find the calendar
            $calendar = CalendarConnection::where('id', $id)
                ->where('user_id', $user->id)
                ->first();
                
            if (!$calendar) {
                return response()->json([
                    'success' => false,
                    'message' => 'Calendar not found'
                ], 404);
            }
            
            if ($calendar->provider !== 'google') {
                return response()->json([
                    'success' => false,
                    'message' => 'This endpoint only supports Google Calendar'
                ], 400);
            }
            
            // Register push notifications
            $success = $this->googleSyncService->registerPushNotifications($calendar);
            
            if ($success) {
                return response()->json([
                    'success' => true,
                    'message' => 'Push notifications enabled successfully'
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to enable push notifications'
                ], 500);
            }
            
        } catch (\Exception $e) {
            Log::error('Error enabling push notifications', [
                'calendar_id' => $id,
                'error' => $e->getMessage()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Error enabling push notifications: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Disable push notifications for a calendar
     * 
     * @param Request $request
     * @param int $id Calendar connection ID
     * @return JsonResponse
     */
    public function disablePushNotifications(Request $request, int $id): JsonResponse
    {
        try {
            $user = $request->user();
            
            // Find the calendar
            $calendar = CalendarConnection::where('id', $id)
                ->where('user_id', $user->id)
                ->first();
                
            if (!$calendar) {
                return response()->json([
                    'success' => false,
                    'message' => 'Calendar not found'
                ], 404);
            }
            
            if ($calendar->provider !== 'google') {
                return response()->json([
                    'success' => false,
                    'message' => 'This endpoint only supports Google Calendar'
                ], 400);
            }
            
            // Stop push notifications
            $success = $this->googleSyncService->stopPushNotifications($calendar);
            
            if ($success) {
                return response()->json([
                    'success' => true,
                    'message' => 'Push notifications disabled successfully'
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to disable push notifications'
                ], 500);
            }
            
        } catch (\Exception $e) {
            Log::error('Error disabling push notifications', [
                'calendar_id' => $id,
                'error' => $e->getMessage()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Error disabling push notifications: ' . $e->getMessage()
            ], 500);
        }
    }
}