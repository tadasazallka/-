<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\User;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;
use Throwable;

class AuthController extends Controller
{

    public function register(Request $request)
    {
        try {
            // Check if user with whatsapp_id exists
            $user = User::where('whatsapp_id', $request->whatsapp_id)->first();
            $userId = $user ? $user->id : null;
    
            if ($user && $user->email && $user->password) {
                return response()->json([
                    'message' => 'This WhatsApp number is already registered with another account.',
                    'errors' => [
                        'whatsapp_id' => ['This WhatsApp number is already registered with another account.'],
                    ],
                ], 422); // 422 Unprocessable Entity
            }
            
            // Validation rules
            $validator = Validator::make($request->all(), [
                'whatsapp_id' => [
                    'required', 
                    'string',
                    'min:10', // Minimum length for international numbers
                    'max:15', // Maximum length for international numbers
                    'regex:/^[1-9][0-9]+$/', // Must start with 1-9 and contain only digits
                ],
                'name' => ['required', 'string', 'max:255'],
                'email' => ['nullable', 'string', 'email', 'max:255', Rule::unique(User::class)->ignore($userId)],
                'password' => 'required|string|min:8',
            ], [
                'whatsapp_id.regex' => 'WhatsApp number must be a valid number without any signs and not starting with 0.',
                'whatsapp_id.min' => 'WhatsApp number must be at least 10 digits long.',
                'whatsapp_id.max' => 'WhatsApp number cannot be longer than 15 digits.',
            ]);
        
            // If validation fails
            if ($validator->fails()) {
                return response()->json([
                    'message' => 'The given data was invalid.',
                    'errors' => $validator->errors(),
                ], 422);
            }
    
            DB::beginTransaction();
        
            // Create or update user logic
            if ($user) {
                // Update existing user details
                $user->update([
                    'name' => $request->name,
                    'email' => $request->email ?? $user->email, // Keep existing email if not provided
                    'password' => Hash::make($request->password),
                    'is_signed_up' => true, // Mark user as signed up
                ]);
            } else {
                // Create new user
                $user = User::create([
                    'whatsapp_id' => '+'.$request->whatsapp_id,
                    'name' => $request->name,
                    'email' => $request->email,
                    'password' => Hash::make($request->password),
                    'is_signed_up' => true,
                    'timezone' => 'Asia/Jerusalem', // Default timezone
                ]);
                
                // Create default calendar for new user
                $user->getOrCreateDefaultCalendar();
            }

            if(!$user->preferences){
                $user->preferences()->create();
            }
            
            // Check if user already has a subscription, if not assign free plan
            if (!$user->subscriptions()->exists()) {
                $freePlan = Plan::where('slug', 'free')->first();
                if ($freePlan) {
                    Subscription::create([
                        'user_id' => $user->id,
                        'plan_id' => $freePlan->id,
                        'starts_at' => now(),
                        'ends_at' => null, // Free plan doesn't expire
                        'status' => 'active',
                    ]);
                }
            }
            
            // Generate token based on app type
            $token = $user->createToken($request->header('x-app-type', 'default-app'))->plainTextToken;
        
            DB::commit();
        
            // Return response with token and user details
            return response()->json([
                'token' => $token,
                'user' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                ],
            ], 201);
        
        } catch (Throwable $e) {
            // Rollback in case of error
            DB::rollBack();
            return response()->json([
                'message' => $e->getMessage(),
            ], 500);
        }
    }


    public function login(Request $request)
    {
        // Validate the incoming request data
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'message' => 'Invalid Data',
                'errors' => $validator->errors(),
            ], 422);
        }
    
        try {
            // Extract email and password for authentication
            $credentials = $request->only('email', 'password');
    
            if (!Auth::attempt($credentials)) {
                return response()->json([
                    'message' => 'The given data was invalid.',
                    'errors' => [
                        'email' => ['The provided credentials are incorrect.'],
                    ],
                ], 422);
            }
    
            $user = Auth::user();
        
            // Manage tokens with up to 3 per app type
            $appType = $request->header('x-app-type', 'default-app');
            $user->tokens()->where('name', $appType)->delete();
            $token = $user->createToken($request->header('x-app-type', 'default-app'))->plainTextToken;
    
            // Prepare user data
            $data = $this->prepareUserData($user, $request);
    
            return response()->json([
                'token' => $token,
                'user' => $data,
            ]);
    
        } catch (Throwable $e) {
            return response()->json([
                'message' => 'An error occurred.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function validateToken(Request $request)
    {
        try {
            $user = $request->user();
    
            $data = $this->prepareUserData($user, $request);
    
            return response()->json(['user' => $data]);
        } catch (Throwable $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    
    private function prepareUserData($user, $request)
    {
        $data = [
            'id'    => $user->id,
            'name'  => $user->name,
            'email' => $user->email,
            'connected_gmail' => $user->gmailAccount,
            'plan'  => $user->currentPlan()
        ];
        return $data;
    }
    
    public function updatePassword(Request $request){
         // Manually create the validator using Validator::make()
         $validator = Validator::make($request->all(), [
            'old_password' => 'required',
            'new_password' => 'required|string|min:8',
        ]);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Get the authenticated user via Sanctum
        $user = $request->user();

        // Verify the old password matches the current password
        if (!Hash::check($request->input('old_password'), $user->password)) {
            return response()->json(['message' => 'Old password is incorrect'], 400);
        }

        // Hash and update the new password
        $user->password = Hash::make($request->input('new_password'));
        $user->save();

        // Optionally revoke all tokens to force re-login
        $user->tokens()->delete();

        // Return a success message
        return response()->json(['message' => 'Password updated successfully']);
    }

    public function sendResetLink(Request $request){

        // Validate the request
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Send reset link via email
        $status = Password::sendResetLink($request->only('email'));

        return $status === Password::RESET_LINK_SENT
            ? response()->json(['message' => 'Reset link sent successfully.'], 200)
            : response()->json(['message' => 'Failed to send reset link.'], 400);
    }

    public function resetPassword(Request $request){

        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
            'token' => 'required',
            'password' => 'required|string|min:8',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Attempt to reset the user's password
        $status = Password::reset(
            $request->only('email', 'password', 'password_confirmation', 'token'),
            function ($user, $password) {
                $user->forceFill([
                    'password' => Hash::make($password),
                    'remember_token' => Str::random(60),
                ])->save();

                event(new PasswordReset($user));
            }
        );

        return $status === Password::PASSWORD_RESET
            ? response()->json(['message' => 'Password reset successfully.'], 200)
            : response()->json(['message' => 'Password reset failed.'], 400);
    }

    public function logout(Request $request){
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'success'   =>  true,
            'message'   =>  'Logged out successfully.'
        ]);
    }
}
