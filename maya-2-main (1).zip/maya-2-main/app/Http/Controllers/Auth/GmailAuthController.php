<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\GmailAccount;
use App\Models\User;
use Carbon\Carbon;
use Google_Client;
use Google_Service_Gmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class GmailAuthController extends Controller
{
    protected $client;
    
    // Define required scopes
    protected $requiredScopes = [
        Google_Service_Gmail::GMAIL_READONLY,
        Google_Service_Gmail::GMAIL_SEND,
        Google_Service_Gmail::GMAIL_COMPOSE
    ];

    public function __construct()
    {
        $this->client = new Google_Client();
        $this->client->setClientId(config('services.google.client_id'));
        $this->client->setClientSecret(config('services.google.client_secret'));
        $this->client->setRedirectUri(config('services.google.gmail_redirect'));
        $this->client->setAccessType('offline');
        $this->client->setPrompt('consent');
        $this->client->addScope(Google_Service_Gmail::GMAIL_READONLY);
        $this->client->addScope(Google_Service_Gmail::GMAIL_SEND);
        $this->client->addScope(Google_Service_Gmail::GMAIL_COMPOSE);
    }

    /**
     * Redirect the user to the Gmail OAuth consent screen.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function getAuthUrl()
    {
        $authUrl = $this->client->createAuthUrl();
        
        return response()->json([
            'success' => true,
            'auth_url' => $authUrl
        ]);
    }

    /**
     * Handle the callback from Google OAuth.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function handleCallback(Request $request)
    {

        try {
            if (!$request->has('code')) {
                return response()->json([
                    'success' => false, 
                    'message' => 'Authorization code not found'
                ], 400);
            }

            $token = $this->client->fetchAccessTokenWithAuthCode($request->code);
            
            if (isset($token['error'])) {
                Log::error('Error fetching access token: ' . $token['error']);
                return response()->json([
                    'success' => false, 
                    'message' => 'Failed to get access token'
                ], 400);
            }

            $this->client->setAccessToken($token);
            
            // Check if all required scopes were granted
            $grantedScopes = $this->getGrantedScopes();
            $missingScopesInfo = $this->checkForMissingScopes($grantedScopes);
            
            if (!empty($missingScopesInfo['missing'])) {
                Log::warning('User did not grant all required Gmail permissions', [
                    'user_id' => Auth::id(),
                    'missing_scopes' => $missingScopesInfo['missing']
                ]);
                
                return response()->json([
                    'success' => false,
                    'message' => 'You need to select all permissions',
                    'missing_scopes' => $missingScopesInfo['friendly_names']
                ], 422);
            }
            
            // Get user email
            $service = new Google_Service_Gmail($this->client);
            $userInfo = $service->users->getProfile('me');
            $email = $userInfo->getEmailAddress();

            // Save or update Gmail account
            $user = Auth::user();
            $gmailAccount = GmailAccount::updateOrCreate(
                ['user_id' => $user->id, 'email' => $email],
                [
                    'access_token' => $token['access_token'],
                    'refresh_token' => $token['refresh_token'] ?? null,
                    'token_expires_at' => isset($token['expires_in']) 
                        ? Carbon::now()->addSeconds($token['expires_in']) 
                        : null,
                    'is_active' => true,
                ]
            );

            return response()->json([
                'success' => true,
                'message' => 'Gmail connected successfully',
            ]);
            
        } catch (\Exception $e) {
            Log::error('Error in Gmail connection', [
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Failed to connect Google Calendar: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get the scopes granted by the user
     * 
     * @return array
     */
    protected function getGrantedScopes()
    {
        if (!$this->client->getAccessToken()) {
            return [];
        }
        
        try {
            // Get token info which includes the scopes
            $tokenInfo = $this->client->verifyIdToken();
            
            if ($tokenInfo) {
                return isset($tokenInfo['scope']) ? explode(' ', $tokenInfo['scope']) : [];
            }
            
            // Alternative approach if verifyIdToken doesn't return scope information
            $token = $this->client->getAccessToken();
            return isset($token['scope']) ? explode(' ', $token['scope']) : [];
            
        } catch (\Exception $e) {
            Log::error('Error getting granted scopes: ' . $e->getMessage());
            
            // Try direct token inspection as fallback
            $token = $this->client->getAccessToken();
            return isset($token['scope']) ? explode(' ', $token['scope']) : [];
        }
    }
    
    /**
     * Check which required scopes are missing
     * 
     * @param array $grantedScopes
     * @return array
     */
    protected function checkForMissingScopes(array $grantedScopes)
    {
        $missingScopes = [];
        $friendlyNames = [];
        
        foreach ($this->requiredScopes as $requiredScope) {
            if (!in_array($requiredScope, $grantedScopes)) {
                $missingScopes[] = $requiredScope;
                $friendlyNames[] = $this->getScopeFriendlyName($requiredScope);
            }
        }
        
        return [
            'missing' => $missingScopes,
            'friendly_names' => $friendlyNames
        ];
    }
    
    /**
     * Get a user-friendly name for a scope
     * 
     * @param string $scope
     * @return string
     */
    protected function getScopeFriendlyName($scope)
    {
        $scopeMap = [
            Google_Service_Gmail::GMAIL_READONLY => 'Read emails',
            Google_Service_Gmail::GMAIL_SEND => 'Send emails',
            Google_Service_Gmail::GMAIL_COMPOSE => 'Create and manage drafts'
        ];
        
        return $scopeMap[$scope] ?? $scope;
    }

    /**
     * Refresh the access token if expired.
     *
     * @param  GmailAccount  $gmailAccount
     * @return bool
     */
    public function refreshTokenIfNeeded(GmailAccount $gmailAccount)
    {
        if ($gmailAccount->isTokenExpired() && $gmailAccount->refresh_token) {
            try {
                $this->client->setAccessToken([
                    'access_token' => $gmailAccount->access_token,
                    'refresh_token' => $gmailAccount->refresh_token,
                ]);

                if ($this->client->isAccessTokenExpired()) {
                    $newToken = $this->client->fetchAccessTokenWithRefreshToken();
                    
                    if (isset($newToken['error'])) {
                        Log::error('Token refresh error: ' . $newToken['error_description']);
                        return false;
                    }

                    $gmailAccount->update([
                        'access_token' => $newToken['access_token'],
                        'token_expires_at' => Carbon::now()->addSeconds($newToken['expires_in']),
                    ]);

                    // If a new refresh token was provided, update it
                    if (isset($newToken['refresh_token'])) {
                        $gmailAccount->update(['refresh_token' => $newToken['refresh_token']]);
                    }

                    return true;
                }
            } catch (\Exception $e) {
                Log::error('Token refresh exception: ' . $e->getMessage());
                return false;
            }
        }

        return !$gmailAccount->isTokenExpired();
    }

    /**
     * Get Gmail client for a specific user's account.
     *
     * @param  User  $user
     * @return Google_Client|null
     */
    public function getGmailClient(User $user)
    {
        $gmailAccount = $user->gmailAccounts()->where('is_active', true)->first();
        
        if (!$gmailAccount) {
            return null;
        }

        if (!$this->refreshTokenIfNeeded($gmailAccount)) {
            return null;
        }

        $this->client->setAccessToken([
            'access_token' => $gmailAccount->access_token,
            'refresh_token' => $gmailAccount->refresh_token,
        ]);

        return $this->client;
    }

    public function disconnectGmail(Request $request)
    {
        $user = $request->user();
    
        $account = GmailAccount::where('user_id', $user->id)
            ->first();
    
        if (!$account) {
            return response()->json([
                'success' => false,
                'message' => 'Calendar account not found'
            ], 404);
        }
    
        try {
    
            $account->delete();
    
            return response()->json([
                'success' => true,
                'message' => 'Gmail disconnected successfully'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to disconnect calendar: ' . $e->getMessage()
            ], 500);
        }
    }
}