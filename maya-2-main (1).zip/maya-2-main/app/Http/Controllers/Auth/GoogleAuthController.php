<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\CalendarAccount;
use App\Models\CalendarConnection;
use App\Services\PlanLimitService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\JsonResponse;
use Carbon\Carbon;
use Google_Client;
use Google_Service_Calendar;

class GoogleAuthController extends Controller
{
    /**
     * The Google Client instance
     *
     * @var Google_Client
     */
    protected $client;

    /**
     * Plan Limit Service
     * 
     * @var PlanLimitService
     */
    protected $planLimitService;
    
    /**
     * Required scopes for Google Calendar integration
     *
     * @var array
     */
    protected $requiredScopes = [
        Google_Service_Calendar::CALENDAR,
        'email'
    ];

    /**
     * Constructor
     */
    public function __construct(PlanLimitService $planLimitService)
    {
        $this->planLimitService = $planLimitService;
        $this->client = new Google_Client();
        $this->client->setClientId(config('services.google.client_id'));
        $this->client->setClientSecret(config('services.google.client_secret'));
        $this->client->setRedirectUri(config('services.google.redirect'));
        $this->client->setAccessType('offline');
        $this->client->setPrompt('consent'); // Force to approve the consent screen
        $this->client->setIncludeGrantedScopes(true); // Enable incremental auth
        $this->client->addScope(Google_Service_Calendar::CALENDAR);
        $this->client->addScope('email');
    }

    /**
     * Get Google OAuth URL for calendar connection
     *
     * @return JsonResponse
     */
    public function getGoogleAuthUrl(): JsonResponse
    {
        $user = Auth::user();
        
        // Check if the user can connect another calendar account
        if (!$this->planLimitService->canConnectCalendarAccount($user)) {
            return response()->json([
                'success' => false,
                'message' => 'You have reached your calendar account limit for your current plan.',
                'remaining' => 0
            ], 403);
        }
                
        // Set state parameter to store user ID
        // $this->client->setState(json_encode(['user_id' => Auth::id()]));
        
        // Generate auth URL
        $authUrl = $this->client->createAuthUrl();
        
        return response()->json([
            'success' => true,
            'auth_url' => $authUrl
        ]);
    }
    
    /**
     * Handle Google OAuth callback
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function handleGoogleCallback(Request $request): JsonResponse
    {

        try {
            if ($request->has('error')) {
                Log::error('Google OAuth error: ' . $request->get('error'));
                return response()->json([
                    'success' => false, 
                    'message' => 'Authorization failed'
                ], 400);
            }
            
            $code = $request->get('code');
            
            if (!$code) {
                return response()->json([
                    'success' => false,
                    'message' => 'Authorization code not found'
                ], 400);
            }
            
            $user = Auth::user();
            
            // Check again if the user can connect another calendar account
            if (!$this->planLimitService->canConnectCalendarAccount($user)) {
                return response()->json([
                    'success' => false,
                    'message' => 'You have reached your calendar account limit for your current plan.',
                    'remaining' => 0
                ], 403);
            }
            
            // Exchange code for tokens
            $token = $this->client->fetchAccessTokenWithAuthCode($code);
            
            if (isset($token['error'])) {
                Log::error('Error fetching access token: ' . $token['error']);
                return response()->json([
                    'success' => false, 
                    'message' => 'Failed to get access token'
                ], 400);
            }
            
            $this->client->setAccessToken($token);
            
            // Get user information to use as account_id
            $service = new \Google_Service_Oauth2($this->client);
            $userInfo = $service->userinfo->get();
            $googleEmail = $userInfo->getEmail();
            
            // Get user calendars
            $calendarService = new Google_Service_Calendar($this->client);
            $calendarList = $calendarService->calendarList->listCalendarList();

            if (empty($calendarList->getItems())) {
                return response()->json([
                    'success' => false,
                    'message' => 'No calendars found'
                ], 400);
            }
            
            // Wrap everything in a transaction for consistency
            return DB::transaction(function() use ($user, $googleEmail, $token, $calendarList) {
                // Create calendar account
                $calendarAccount = CalendarAccount::create([
                    'user_id' => $user->id,
                    'provider' => 'google',
                    'account_id' => $googleEmail,
                    'access_token' => $token['access_token'],
                    'refresh_token' => $token['refresh_token'] ?? null,
                    'expires_at' => isset($token['expires_in']) ? Carbon::now()->addSeconds($token['expires_in']) : null,
                    'is_active' => true,
                    'provider_metadata' => [
                        'connected_at' => now()->timestamp
                    ]
                ]);
                
                $createdCalendars = [];
                // Create calendar connections for each discovered calendar
                foreach ($calendarList->getItems() as $calendar) {
                    // Create calendar connection
                    $calendarConnection = CalendarConnection::create([
                        'user_id' => $user->id,
                        'calendar_account_id' => $calendarAccount->id,
                        'provider' => 'google',
                        'provider_calendar_id' => $calendar->getId(),
                        'name' => $calendar->getSummary() ?? 'Google Calendar',
                        'color' => $calendar->getBackgroundColor() ?? '#4285F4',
                        'is_active' => false, // Set all to inactive initially
                        'is_primary' => false, // Set all to non-primary initially
                        'provider_metadata' => [
                            'timezone' => $calendar->getTimeZone() ?? null,
                            'description' => $calendar->getDescription() ?? null,
                            'access_role' => $calendar->getAccessRole() ?? null
                        ]
                    ]);
                    
                    $createdCalendars[] = [
                        'id' => $calendarConnection->id,
                        'name' => $calendarConnection->name,
                        'color' => $calendarConnection->color,
                        'is_primary' => false,
                        'is_active' => false
                    ];
                    
                    // Dispatch background job to handle sync
                    \App\Jobs\SyncCalendarJob::dispatch($calendarConnection)
                        ->onQueue('calendarsync');
                    
                }
                
                if (count($createdCalendars) === 0) {
                    return response()->json([
                        'success' => false,
                        'message' => 'No calendars were found in your Google account.'
                    ], 400);
                }
                
                return response()->json([
                    'success' => true,
                    'message' => 'Google Calendar connected successfully. Calendar sync has been started in the background.',
                    'account_id' => $calendarAccount->id,
                    'calendars' => $createdCalendars
                ]);
            });
            
        } catch (\Exception $e) {
            Log::error('Error in Google calendar connection', [
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Failed to connect Google Calendar: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Get the scopes granted by the user
     * 
     * @return array
     */
    protected function getGrantedScopes()
    {
        if (!$this->client->getAccessToken()) {
            return [];
        }
        
        try {
            // Get token info which includes the scopes
            $tokenInfo = $this->client->verifyIdToken();
            
            if ($tokenInfo) {
                return isset($tokenInfo['scope']) ? explode(' ', $tokenInfo['scope']) : [];
            }
            
            // Alternative approach if verifyIdToken doesn't return scope information
            $token = $this->client->getAccessToken();
            return isset($token['scope']) ? explode(' ', $token['scope']) : [];
            
        } catch (\Exception $e) {
            Log::error('Error getting granted scopes: ' . $e->getMessage());
            
            // Try direct token inspection as fallback
            $token = $this->client->getAccessToken();
            return isset($token['scope']) ? explode(' ', $token['scope']) : [];
        }
    }
    
    /**
     * Check which required scopes are missing
     * 
     * @param array $grantedScopes
     * @return array
     */
    protected function checkForMissingScopes(array $grantedScopes)
    {
        $missingScopes = [];
        $friendlyNames = [];
        
        foreach ($this->requiredScopes as $requiredScope) {
            if (!in_array($requiredScope, $grantedScopes)) {
                $missingScopes[] = $requiredScope;
                $friendlyNames[] = $this->getScopeFriendlyName($requiredScope);
            }
        }
        
        return [
            'missing' => $missingScopes,
            'friendly_names' => $friendlyNames
        ];
    }
    
    /**
     * Get a user-friendly name for a scope
     * 
     * @param string $scope
     * @return string
     */
    protected function getScopeFriendlyName($scope)
    {
        $scopeMap = [
            Google_Service_Calendar::CALENDAR => 'Calendar access',
            'email' => 'Email access for identification'
        ];
        
        return $scopeMap[$scope] ?? $scope;
    }
    
    /**
     * Disconnect a Google Calendar account
     *
     * @param Request $request
     * @param int $id
     * @return JsonResponse
     */
    public function disconnect(Request $request, $id): JsonResponse
    {
        $user = $request->user();
        $account = CalendarAccount::where('id', $id)
            ->where('user_id', $user->id)
            ->where('provider', 'google')
            ->first();
            
        if (!$account) {
            return response()->json([
                'success' => false,
                'message' => 'Calendar account not found'
            ], 404);
        }
        
        // Deactivate the account
        $account->is_active = false;
        $account->save();
        
        // Deactivate all calendars in this account
        CalendarConnection::where('calendar_account_id', $account->id)
            ->update(['is_active' => false]);
        
        return response()->json([
            'success' => true,
            'message' => 'Google Calendar disconnected successfully'
        ]);
    }
    
}