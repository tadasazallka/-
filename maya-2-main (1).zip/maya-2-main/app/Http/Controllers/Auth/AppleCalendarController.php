<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\CalendarAccount;
use App\Models\CalendarConnection;
use App\Services\Calendars\AppleCalendarDiscoverer;
use App\Services\PlanLimitService;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class AppleCalendarController extends Controller
{
    /**
     * Plan Limit Service
     * 
     * @var PlanLimitService
     */
    protected $planLimitService;

    /**
     * Constructor
     */
    public function __construct(PlanLimitService $planLimitService)
    {
        $this->planLimitService = $planLimitService;
    }

    /**
     * Connect to Apple Calendar and create connections for available calendars
     */
    public function connect(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'apple_id' => 'required',
            'app_password' => 'required|string'
        ]);

        if($validator->fails()){
            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ]);
        }

        $user = $request->user();

        // Check if the user can connect another calendar account
        if (!$this->planLimitService->canConnectCalendarAccount($user)) {
            return response()->json([
                'success' => false,
                'message' => 'You have reached your calendar account limit for your current plan.',
                'remaining' => 0
            ], 403);
        }

        $appleId = $request->input('apple_id');
        $appPassword = $request->input('app_password');

        // Check if user already has a connection to Apple calendar
        if ($user->calendarAccounts()->where('provider', 'apple')->where('account_id', $appleId)->exists()) {
            return response()->json([
                'success' => false,
                'message' => 'You already have this Apple Calendar connected.',
            ], 400);
        }

        try {
            // Wrap everything in a transaction for consistency
            return DB::transaction(function() use ($appleId, $appPassword, $user) {
                // Create Apple Calendar provider
                $provider = new AppleCalendarDiscoverer();
                
                // Discover calendars
                $result = $provider->discoverCalendars($appleId, $appPassword);
                
                if (!$result) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Failed to discover calendars. Please check your credentials.'
                    ], 400);
                }
                
                // Create calendar account
                $calendarAccount = CalendarAccount::create([
                    'user_id' => $user->id,
                    'provider' => 'apple',
                    'account_id' => $appleId,
                    'access_token' => $appPassword,
                    'is_active' => true,
                    'provider_metadata' => [
                        'principal_url' => $result['principal_url'] ?? null,
                        'connected_at' => now()->timestamp
                    ]
                ]);

                $createdCalendars = [];
                // Create calendar connections for each discovered calendar
                foreach ($result['calendars'] as $calendar) {
                    // Skip calendars that don't support events
                    if (!($calendar['supports_events'] ?? true)) {
                        continue;
                    }
                    
                    // Create calendar connection
                    $calendarConnection = CalendarConnection::create([
                        'user_id' => $user->id,
                        'calendar_account_id' => $calendarAccount->id,
                        'provider' => 'apple',
                        'provider_calendar_id' => $calendar['url'],
                        'name' => $calendar['name'],
                        'color' => $calendar['color'] ?? '#4a86e8',
                        'is_active' => false, // Set all to inactive initially
                        'is_primary' => false, // Set all to non-primary initially
                        'provider_metadata' => [
                            'calendar_path' => $calendar['url'],
                            'description' => $calendar['description'] ?? null,
                            'timezone' => $calendar['timezone'] ?? null
                        ]
                    ]);
                    
                    $createdCalendars[] = [
                        'id' => $calendarConnection->id,
                        'name' => $calendarConnection->name,
                        'color' => $calendarConnection->color,
                        'is_primary' => false,
                        'is_active' => false
                    ];
                    
                    // Dispatch background job to handle sync
                    \App\Jobs\SyncCalendarJob::dispatch($calendarConnection)
                        ->onQueue('calendarsync');
                }
                
                if (count($createdCalendars) === 0) {
                    return response()->json([
                        'success' => false,
                        'message' => 'No calendars were found in your Apple account.'
                    ], 400);
                }
                
                return response()->json([
                    'success' => true,
                    'message' => 'Apple Calendar connected successfully. Calendar sync has been started in the background.',
                    'account_id' => $calendarAccount->id,
                    'calendars' => $createdCalendars
                ]);
            });
            
        } catch (\Exception $e) {
            Log::error('Apple Calendar Connection Error', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Failed to connect Apple Calendar: ' . $e->getMessage()
            ], 500);
        }
    }
        
    /**
     * Disconnect an Apple Calendar account
     */

    public function disconnect(Request $request, $id)
    {
        $user = $request->user();
    
        $account = CalendarAccount::where('id', $id)
            ->where('user_id', $user->id)
            ->first();
    
        if (!$account) {
            return response()->json([
                'success' => false,
                'message' => 'Calendar account not found'
            ], 404);
        }
    
        DB::beginTransaction();
    
        try {
            // Delete all calendar connections linked to this account and user
            CalendarConnection::where('calendar_account_id', $account->id)
                ->where('user_id', $user->id)
                ->delete();
    
            // Delete the calendar account itself
            $account->delete();
    
            DB::commit();
    
            return response()->json([
                'success' => true,
                'message' => 'Apple Calendar disconnected successfully'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
    
            return response()->json([
                'success' => false,
                'message' => 'Failed to disconnect calendar: ' . $e->getMessage()
            ], 500);
        }
    }
    
}


