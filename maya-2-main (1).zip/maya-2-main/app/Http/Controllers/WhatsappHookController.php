<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Resources\WhatsappMessages;
use App\Services\MessageProcessorService;
use App\Services\ManyChatAPIService;
use App\Services\CloudinaryService;
use App\Services\MessageQueueService;
use App\Jobs\ProcessUserMessagesJob;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;

class WhatsappHookController extends Controller
{
    protected $manyChatAPIService;
    protected $messageProcessor;
    protected $cloudinaryService;
    protected $messageQueueService;
    
    const MAX_IMAGE_SIZE_BYTES = 5 * 1024 * 1024; // 5MB
    const MAX_AUDIO_SIZE_BYTES = 2 * 1024 * 1024; // 2MB
    
    const MESSAGE_COUNT_MIN = 5; // Minimum messages before prompting login
    const MESSAGE_COUNT_MAX = 5; // Maximum messages to show login prompt
    const LOGIN_URL = 'https://maya-landing-hebrew.vercel.app/signup';

    public function __construct(
        ManyChatAPIService $manyChatAPIService,
        MessageProcessorService $messageProcessor,
        CloudinaryService $cloudinaryService,
        MessageQueueService $messageQueueService
    ) {
        $this->manyChatAPIService = $manyChatAPIService;
        $this->messageProcessor = $messageProcessor;
        $this->cloudinaryService = $cloudinaryService;
        $this->messageQueueService = $messageQueueService;
    }
    
    /**
     * Handle webhook verification from ManyChat (if needed)
     */
    public function verify(Request $request)
    {
        // ManyChat typically doesn't require verification like WhatsApp
        // Return success or implement if ManyChat requires specific verification
        return response()->json(['status' => 'verified']);
    }
    
    /**
     * Handle incoming ManyChat webhooks
     */
    public function handle(Request $request)
    {
        Log::info('ManyChat Webhook Received:', $request->all());
        
        try {
            $payload = $request->all();
            
            Log::info('==========================ManyChat webhook received==========================');
            
            // Extract user data from ManyChat payload
            $subscriberId = $payload['id'] ?? null;
            $whatsappPhone = $payload['whatsapp_phone'] ?? null;
            $lastInputText = $payload['last_input_text'] ?? null;
            $firstName = $payload['first_name'] ?? '';
            $lastName = $payload['last_name'] ?? '';
            $name = trim($firstName . ' ' . $lastName) ?: 'Maya User';
            
            if (!$subscriberId || !$whatsappPhone) {
                Log::warning('Missing required fields', [
                    'subscriber_id' => $subscriberId,
                    'whatsapp_phone' => $whatsappPhone
                ]);
                return response()->json(['status' => 'success']);
            }
            
            // Skip if no message content
            if (empty($lastInputText)) {
                Log::info('Empty message content, skipping');
                return response()->json(['status' => 'success']);
            }
            
            // Find or create user based on ManyChat subscriber ID
            $user = $this->findOrCreateUser($subscriberId, $whatsappPhone, $name);
            
            // Increment message count
            $messageCount = $this->incrementMessageCount($user);
            
            // Determine message type and create message data
            $messageData = $this->createMessageData($lastInputText, $payload);
            
            // Add message to queue for processing
            $added = $this->messageQueueService->addMessageToQueue($user, $messageData);
            
            if ($added) {
                // Dispatch job to process the message
                ProcessUserMessagesJob::dispatch($user);
                
                Log::info('Message queued and job dispatched', [
                    'user_id' => $user->id,
                    'subscriber_id' => $subscriberId,
                    'message_type' => $messageData['type']
                ]);
            }
            
            return response()->json(['status' => 'success']);
            
        } catch (\Exception $e) {
            Log::error('Error processing ManyChat webhook: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json(['status' => 'error'], 500);
        }
    }
    
    /**
     * Create message data from ManyChat payload
     */
    protected function createMessageData(string $lastInputText, array $payload): array
    {
        $messageData = [
            'id' => uniqid(),
            'timestamp' => time(),
            'subscriber_id' => $payload['id'] ?? null,
        ];
        
        // Check if it's a media file URL or text
        if ($this->isImageUrl($lastInputText)) {
            $messageData['type'] = 'image';
            $messageData['image'] = [
                'url' => $lastInputText,
                'id' => null,
                'file_size' => null
            ];
        } elseif ($this->isAudioUrl($lastInputText)) {
            $messageData['type'] = 'audio';
            $messageData['audio'] = [
                'url' => $lastInputText,
                'id' => null,
                'file_size' => null
            ];
        } else {
            // Regular text message
            $messageData['type'] = 'text';
            $messageData['content'] = $lastInputText;
        }
        
        return $messageData;
    }
    
    /**
     * Check if the input is an image URL
     */
    protected function isImageUrl(string $text): bool
    {
        // Check if it's a URL and has image extension
        if (!filter_var($text, FILTER_VALIDATE_URL)) {
            return false;
        }
        
        $extension = strtolower(pathinfo(parse_url($text, PHP_URL_PATH), PATHINFO_EXTENSION));
        return in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp']);
    }
    
    /**
     * Check if the input is an audio URL
     */
    protected function isAudioUrl(string $text): bool
    {
        // Check if it's a URL and has audio extension
        if (!filter_var($text, FILTER_VALIDATE_URL)) {
            return false;
        }
        
        $extension = strtolower(pathinfo(parse_url($text, PHP_URL_PATH), PATHINFO_EXTENSION));
        return in_array($extension, ['mp3', 'wav', 'ogg', 'm4a', 'aac']);
    }
    
    /**
     * Increment and return the user's message count
     */
    protected function incrementMessageCount(User $user): int
    {
        $redisKey = "manychat:message_count:{$user->id}";
        $count = Redis::incr($redisKey);
        
        // Set TTL if it's a new key (first message)
        if ($count === 1) {
            // Keep message count for 30 days
            Redis::expire($redisKey, 30 * 24 * 60 * 60);
        }
        
        Log::info("User message count updated", ['user_id' => $user->id, 'count' => $count]);
        return $count;
    }
    
    /**
     * Find a user by ManyChat subscriber ID or create a new one
     */
    protected function findOrCreateUser(string $subscriberId, string $whatsappPhone, string $name, string $timezone = 'Asia/Jerusalem'): User
    {
        Log::info('------------find or create user for ManyChat--------------');

        $user = User::where('manychat_subscriber_id', $subscriberId)->first();
        
        if (!$user) {
            // Also check by WhatsApp phone as backup
            $user = User::where('whatsapp_id', $whatsappPhone)->first();
            
            if ($user) {
                // Update existing user with ManyChat subscriber ID
                $user->update(['manychat_subscriber_id' => $subscriberId]);
            } else {
                // Create a new user
                $user = User::create([
                    'manychat_subscriber_id' => $subscriberId,
                    'whatsapp_id' => $whatsappPhone,
                    'name' => $name,
                    'is_signed_up' => false,
                    'timezone' => $timezone,
                ]);

                $user->preferences()->create();
                
                // Create default calendar for new user
                $user->getOrCreateDefaultCalendar();
                
                // Assign free plan to user
                $freePlan = \App\Models\Plan::where('slug', 'free')->first();
                if ($freePlan) {
                    \App\Models\Subscription::create([
                        'user_id' => $user->id,
                        'plan_id' => $freePlan->id,
                        'starts_at' => now(),
                        'ends_at' => null, // Free plan doesn't expire
                        'status' => 'active',
                    ]);
                }
            }
        }

        if ($user->preferences === null) {
            $user->load('preferences');
        }
        
        return $user;
    }
}