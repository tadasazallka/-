<?php

namespace App\Http\Controllers\Subscription;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Stripe\Exception\ApiErrorException;
use Stripe\StripeClient;

class StripeController extends Controller
{
    protected $stripe;
    
    public function __construct()
    {
        $this->stripe = new StripeClient(config('services.stripe.secret'));
    }
    
    /**
     * Create a checkout session for subscription
     */
    public function createCheckoutSession(Request $request)
    {
        $request->validate([
            'plan_id' => 'required|exists:plans,id',
        ]);
        
        $user = $request->user();
        $plan = Plan::findOrFail($request->plan_id);
        
        // Check if plan is active
        if (!$plan->is_active) {
            return response()->json([
                'message' => 'The selected plan is not available for purchase',
            ], 400);
        }
        
        try {
            // Prepare line items based on plan interval
            $interval = $plan->interval === 'yearly' ? 'year' : 'month';
            $priceInCents = round($plan->price * 100); // Stripe uses cents
            
            // Get or create a Stripe product for this plan
            $productId = $this->getStripeProductId($plan);
            
            // Get or create a Stripe price for this plan
            $priceId = $this->getStripePriceId($plan, $productId, $priceInCents, $interval);
            
            // Create checkout session
            $checkout_session = $this->stripe->checkout->sessions->create([
                'payment_method_types' => ['card'],
                'line_items' => [
                    [
                        'price' => $priceId,
                        'quantity' => 1,
                    ],
                ],
                'mode' => 'subscription',
                'success_url' => config('app.frontend_url') . '/success?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => config('app.frontend_url') . '/cancel',
                'client_reference_id' => $user->id,
                'customer_email' => $user->email,
                'metadata' => [
                    'user_id' => $user->id,
                    'plan_id' => $plan->id,
                ],
                'subscription_data' => [
                    'metadata' => [
                        'user_id' => $user->id,
                        'plan_id' => $plan->id,
                    ],
                ],
            ]);
            
            return response()->json([
                'checkout_url' => $checkout_session->url,
                'session_id' => $checkout_session->id,
            ]);
            
        } catch (ApiErrorException $e) {
            Log::error('Stripe API Error: ' . $e->getMessage());
            
            return response()->json([
                'message' => 'Unable to create checkout session',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    
    /**
     * Get or create a Stripe product ID for a plan
     */
    private function getStripeProductId(Plan $plan)
    {
        // Check if the plan already has a product ID stored
        if ($plan->stripe_product_id) {
            return $plan->stripe_product_id;
        }
        
        // Create a new product in Stripe
        $product = $this->stripe->products->create([
            'name' => $plan->name,
            'description' => $plan->description,
            'metadata' => [
                'plan_id' => $plan->id,
            ],
        ]);
        
        // Save the product ID to the plan
        $plan->stripe_product_id = $product->id;
        $plan->save();
        
        return $product->id;
    }
    
    /**
     * Get or create a Stripe price ID for a plan
     */
    private function getStripePriceId(Plan $plan, string $productId, int $priceInCents, string $interval)
    {
        // Check if the plan already has a price ID stored for this interval
        $priceFieldName = 'stripe_' . $interval . '_price_id';
        
        if ($plan->$priceFieldName) {
            return $plan->$priceFieldName;
        }
        
        // Create a new price in Stripe
        $price = $this->stripe->prices->create([
            'product' => $productId,
            'unit_amount' => $priceInCents,
            'currency' => 'usd', // Change to your currency
            'recurring' => [
                'interval' => $interval === 'year' ? 'year' : 'month',
            ],
            'metadata' => [
                'plan_id' => $plan->id,
            ],
        ]);
        
        // Save the price ID to the plan
        $plan->$priceFieldName = $price->id;
        $plan->save();
        
        return $price->id;
    }
}