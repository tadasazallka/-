<?php

namespace App\Http\Controllers\Subscription;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Stripe\StripeClient;
use Stripe\Webhook;

class StripeWebhookController extends Controller
{
    protected $stripe;
    
    public function __construct()
    {
        $this->stripe = new StripeClient(config('services.stripe.secret'));
    }
    
    public function handleWebhook(Request $request)
    {
        $payload = $request->getContent();
        $sig_header = $request->header('Stripe-Signature');
        $webhook_secret = config('services.stripe.webhook_secret');
        
        try {
            $event = Webhook::constructEvent($payload, $sig_header, $webhook_secret);
            
            // Handle the event
            switch ($event->type) {
                case 'checkout.session.completed':
                    $this->handleCheckoutSessionCompleted($event->data->object);
                    break;
                    
                case 'customer.subscription.created':
                    $this->handleSubscriptionCreated($event->data->object);
                    break;
                    
                case 'customer.subscription.updated':
                    $this->handleSubscriptionUpdated($event->data->object);
                    break;
                    
                case 'customer.subscription.deleted':
                    $this->handleSubscriptionDeleted($event->data->object);
                    break;
                    
                case 'invoice.payment_succeeded':
                    $this->handleInvoicePaymentSucceeded($event->data->object);
                    break;
                    
                case 'invoice.payment_failed':
                    $this->handleInvoicePaymentFailed($event->data->object);
                    break;
                    
                default:
                    // Unexpected event type
                    Log::info('Unhandled Stripe event: ' . $event->type);
            }
            
            return response()->json(['status' => 'success']);
            
        } catch (\Exception $e) {
            Log::error('Stripe Webhook Error: ' . $e->getMessage());
            return response()->json(['status' => 'error', 'message' => $e->getMessage()], 400);
        }
    }
    
    private function handleCheckoutSessionCompleted($session)
    {
        // Get user and plan from metadata
        $userId = $session->metadata->user_id ?? null;
        $planId = $session->metadata->plan_id ?? null;
        
        if (!$userId || !$planId) {
            Log::error('Missing user_id or plan_id in session metadata', [
                'session_id' => $session->id,
                'metadata' => $session->metadata,
            ]);
            return;
        }
        
        $user = User::find($userId);
        $plan = Plan::find($planId);
        
        if (!$user || !$plan) {
            Log::error('User or plan not found', [
                'user_id' => $userId,
                'plan_id' => $planId,
            ]);
            return;
        }
        
        // The subscription is created by Stripe and will be handled in customer.subscription.created
    }
    
    private function handleSubscriptionCreated($stripeSubscription)
    {
        // Extract metadata
        $userId = $stripeSubscription->metadata->user_id ?? null;
        $planId = $stripeSubscription->metadata->plan_id ?? null;
        
        if (!$userId || !$planId) {
            // Try to get from the checkout session that created this subscription
            try {
                $checkoutSessionId = $stripeSubscription->metadata->checkout_session_id ?? null;
                
                if ($checkoutSessionId) {
                    $session = $this->stripe->checkout->sessions->retrieve($checkoutSessionId);
                    $userId = $session->metadata->user_id ?? null;
                    $planId = $session->metadata->plan_id ?? null;
                }
            } catch (\Exception $e) {
                Log::error('Error retrieving checkout session: ' . $e->getMessage());
            }
        }
        
        if (!$userId || !$planId) {
            Log::error('Cannot identify user and plan for subscription', [
                'subscription_id' => $stripeSubscription->id,
            ]);
            return;
        }
        
        $user = User::find($userId);
        $plan = Plan::find($planId);
        
        if (!$user || !$plan) {
            Log::error('User or plan not found', [
                'user_id' => $userId,
                'plan_id' => $planId,
            ]);
            return;
        }
        
        // Calculate dates
        $startsAt = Carbon::createFromTimestamp($stripeSubscription->current_period_start);
        $endsAt = Carbon::createFromTimestamp($stripeSubscription->current_period_end);
        $trialEndsAt = $stripeSubscription->trial_end ? 
            Carbon::createFromTimestamp($stripeSubscription->trial_end) : null;
        
        // Check if we already have a subscription record for this Stripe subscription
        $existingSubscription = Subscription::where('payment_id', $stripeSubscription->id)->first();
        
        if ($existingSubscription) {
            // Update existing subscription
            $existingSubscription->user_id = $user->id;
            $existingSubscription->plan_id = $plan->id;
            $existingSubscription->starts_at = $startsAt;
            $existingSubscription->ends_at = $endsAt;
            $existingSubscription->trial_ends_at = $trialEndsAt;
            $existingSubscription->status = $stripeSubscription->status === 'active' ? 'active' : 'pending';
            $existingSubscription->payment_method = 'stripe';
            $existingSubscription->metadata = [
                'stripe_customer' => $stripeSubscription->customer,
                'stripe_subscription' => $stripeSubscription->id,
            ];
            
            $existingSubscription->save();
            
            $subscription = $existingSubscription;
        } else {
            // Create new subscription record
            $subscription = new Subscription([
                'user_id' => $user->id,
                'plan_id' => $plan->id,
                'starts_at' => $startsAt,
                'ends_at' => $endsAt,
                'trial_ends_at' => $trialEndsAt,
                'status' => $stripeSubscription->status === 'active' ? 'active' : 'pending',
                'payment_method' => 'stripe',
                'payment_id' => $stripeSubscription->id,
                'metadata' => [
                    'stripe_customer' => $stripeSubscription->customer,
                    'stripe_subscription' => $stripeSubscription->id,
                ],
            ]);
            
            $subscription->save();
        }
        
        // Cancel any existing subscriptions for this user (except the current one)
        Subscription::where('user_id', $user->id)
            ->where('id', '!=', $subscription->id)
            ->where('status', 'active')
            ->update(['status' => 'cancelled']);
    }
    
    private function handleSubscriptionUpdated($stripeSubscription)
    {
        // Find subscription by payment_id
        $subscription = Subscription::where('payment_id', $stripeSubscription->id)->first();
        
        if (!$subscription) {
            Log::error('Subscription not found for update', [
                'stripe_subscription_id' => $stripeSubscription->id,
            ]);
            return;
        }
        
        // Update subscription details
        $subscription->starts_at = Carbon::createFromTimestamp($stripeSubscription->current_period_start);
        $subscription->ends_at = Carbon::createFromTimestamp($stripeSubscription->current_period_end);
        
        if ($stripeSubscription->trial_end) {
            $subscription->trial_ends_at = Carbon::createFromTimestamp($stripeSubscription->trial_end);
        }
        
        // Update status
        switch ($stripeSubscription->status) {
            case 'active':
                $subscription->status = 'active';
                break;
            case 'canceled':
                $subscription->status = 'cancelled';
                break;
            case 'unpaid':
            case 'past_due':
                $subscription->status = 'past_due';
                break;
            default:
                $subscription->status = $stripeSubscription->status;
        }
        
        $subscription->save();
    }
    
    private function handleSubscriptionDeleted($stripeSubscription)
    {
        // Find subscription by payment_id
        $subscription = Subscription::where('payment_id', $stripeSubscription->id)->first();
        
        if (!$subscription) {
            Log::error('Subscription not found for deletion', [
                'stripe_subscription_id' => $stripeSubscription->id,
            ]);
            return;
        }
        
        // Mark as cancelled and set end date
        $subscription->status = 'cancelled';
        $subscription->ends_at = Carbon::now();
        $subscription->save();
    }
    
    private function handleInvoicePaymentSucceeded($invoice)
    {
        // If this is a subscription invoice, update the subscription
        if ($invoice->subscription) {
            $subscription = Subscription::where('payment_id', $invoice->subscription)->first();
            
            if ($subscription) {
                // Fetch subscription details from Stripe
                try {
                    $stripeSubscription = $this->stripe->subscriptions->retrieve($invoice->subscription);
                    
                    // Update subscription period only if the values exist
                    if (isset($stripeSubscription->current_period_start)) {
                        $subscription->starts_at = Carbon::createFromTimestamp($stripeSubscription->current_period_start);
                    }
                    
                    if (isset($stripeSubscription->current_period_end)) {
                        $subscription->ends_at = Carbon::createFromTimestamp($stripeSubscription->current_period_end);
                    }
                    
                    $subscription->status = 'active';
                    $subscription->save();
                    
                } catch (\Exception $e) {
                    Log::error('Error retrieving subscription from Stripe: ' . $e->getMessage());
                }
            }
        }
    }
    
    private function handleInvoicePaymentFailed($invoice)
    {
        // If this is a subscription invoice, mark the subscription as past_due
        if ($invoice->subscription) {
            $subscription = Subscription::where('payment_id', $invoice->subscription)->first();
            
            if ($subscription) {
                $subscription->status = 'past_due';
                $subscription->save();
            }
        }
    }
}