<?php

namespace App\Http\Controllers;

use App\Models\CalendarConnection;
use Illuminate\Http\Request;
use Laravel\Socialite\Facades\Socialite;

class CalendarController extends Controller
{
    public function connect($provider)
    {
        return match ($provider) {
            'google' => Socialite::driver('google')
                ->scopes([
                    'https://www.googleapis.com/auth/calendar',
                    'https://www.googleapis.com/auth/calendar.events'
                ])
                ->redirect(),
            'apple' => redirect()->to(/* Apple OAuth URL */),
            default => abort(404)
        };
    }

    public function handleGoogleCallback()
    {
        $user = Socialite::driver('google')->user();
        
        auth()->user()->calendars()->updateOrCreate(
            ['provider_type' => 'google', 'calendar_id' => $user->email],
            [
                'access_token' => encrypt($user->token),
                'refresh_token' => encrypt($user->refreshToken),
                'expires_at' => now()->addSeconds($user->expiresIn),
                'display_name' => $user->name,
                'provider_metadata' => $user->user
            ]
        );

        return redirect()->route('calendars')->with('success', 'Google Calendar connected!');
    }

    public function disconnect(CalendarConnection $calendar)
    {
        // Revoke token via provider API if needed
        $calendar->delete();
        return back()->with('success', 'Calendar disconnected');
    }
}
