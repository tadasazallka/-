<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Jobs\SyncCalendarJob;
use App\Models\CalendarAccount;
use App\Models\CalendarConnection;
use App\Services\PlanLimitService;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CalendarManagementController extends Controller
{
    protected $planLimitService;

    /**
     * Constructor
     */
    public function __construct(PlanLimitService $planLimitService)
    {
        $this->planLimitService = $planLimitService;
    }

    /**
     * List all calendar connections for the authenticated user
     *
     * @return JsonResponse
     */
    public function calendarsInfo(Request $request)
    {
        $user = $request->user();
        
        // Get calendar accounts
        $accounts = $user->calendarAccounts()
            ->with(['calendars' => function($query) {
                $query->select('id', 'calendar_account_id', 'name', 'color', 'provider', 'is_primary', 'is_active');
            }])
            ->where('is_active', true)
            ->get(['id', 'provider', 'account_id']);
        
        // Get default calendar if it exists
        $defaultCalendar = $user->calendars()
            ->where('provider', 'default')
            ->where('is_active', true)
            ->first(['id', 'name', 'color', 'provider', 'is_primary', 'is_active']);
        
        // Get remaining calendar limit
        $remainingCalendars = app(PlanLimitService::class)->getRemainingCalendars($user);
        
        return response()->json([
            'accounts' => $accounts,
            'default_calendar' => $defaultCalendar,
            'remaining_calendars' => $remainingCalendars,
            'has_primary' => $user->calendars()->where('is_primary', true)->exists()
        ]);
    }

    /**
     * Fetch events from all active calendars for the calendar view
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getCalendarEvents(Request $request): JsonResponse
    {
        $user = $request->user();

        // Get month and year from query params
        $month = $request->input('month', now()->month);
        $year = $request->input('year', now()->year);

        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = Carbon::createFromDate($year, $month, 1)->endOfMonth();

        // Get all calendar accounts with their connections and events
        $calendarAccounts = CalendarAccount::where('user_id', $user->id)
            ->where('is_active', true)
            ->with([
                'calendars' => function ($query) use ($startDate, $endDate, $user) {
                    $query->where('is_active', true)
                        ->with(['events' => function ($q) use ($startDate, $endDate, $user) {
                            $q->where('user_id', $user->id)
                                ->where(function($query) use ($startDate, $endDate) {
                                    $query->whereBetween('start_time', [$startDate, $endDate])
                                        ->orWhereBetween('end_time', [$startDate, $endDate])
                                        ->orWhere(function($q) use ($startDate, $endDate) {
                                            $q->where('start_time', '<', $startDate)
                                                ->where('end_time', '>', $endDate);
                                        });
                                })
                                ->select([
                                    'id', 
                                    'calendar_connection_id', 
                                    'title', 
                                    'description', 
                                    'start_time', 
                                    'end_time', 
                                    'location', 
                                    'status'
                                ]);
                        }]);
                }
            ])
            ->get();

        // Format response for accounts
        $formattedAccounts = $calendarAccounts->map(function ($account) {
            return [
                'id' => $account->id,
                'provider' => $account->provider,
                'account_id' => $account->account_id,
                'calendars' => $account->calendars->map(function ($calendar) {
                    return [
                        'id' => $calendar->id,
                        'name' => $calendar->name,
                        'color' => $calendar->color,
                        'provider' => $calendar->provider,
                        'is_primary' => $calendar->is_primary,
                        'events' => $calendar->events->map(function ($event) {
                            return [
                                'id' => $event->id,
                                'title' => $event->title,
                                'start' => $event->start_time->toIso8601String(),
                                'end' => $event->end_time->toIso8601String(),
                                'description' => $event->description,
                                'location' => $event->location,
                                'status' => $event->status,
                            ];
                        })
                    ];
                })
            ];
        });

        // Get default calendar and its events
        $defaultCalendar = $user->calendars()
            ->where('provider', 'default')
            ->where('is_active', true)
            ->with(['events' => function ($query) use ($startDate, $endDate, $user) {
                $query->where('user_id', $user->id)
                    ->where(function($query) use ($startDate, $endDate) {
                        $query->whereBetween('start_time', [$startDate, $endDate])
                            ->orWhereBetween('end_time', [$startDate, $endDate])
                            ->orWhere(function($q) use ($startDate, $endDate) {
                                $q->where('start_time', '<', $startDate)
                                    ->where('end_time', '>', $endDate);
                            });
                    })
                    ->select([
                        'id', 
                        'calendar_connection_id', 
                        'title', 
                        'description', 
                        'start_time', 
                        'end_time', 
                        'location', 
                        'status'
                    ]);
            }])
            ->first();

        // Format default calendar for response
        $formattedDefaultCalendar = null;
        if ($defaultCalendar) {
            $formattedDefaultCalendar = [
                'id' => $defaultCalendar->id,
                'name' => $defaultCalendar->name,
                'color' => $defaultCalendar->color,
                'provider' => $defaultCalendar->provider,
                'is_primary' => $defaultCalendar->is_primary,
                'events' => $defaultCalendar->events->map(function ($event) {
                    return [
                        'id' => $event->id,
                        'title' => $event->title,
                        'start' => $event->start_time->toIso8601String(),
                        'end' => $event->end_time->toIso8601String(),
                        'description' => $event->description,
                        'location' => $event->location,
                        'status' => $event->status,
                    ];
                })
            ];
        }

        return response()->json([
            'calendar_accounts' => $formattedAccounts,
            'default_calendar' => $formattedDefaultCalendar,
            'start_date' => $startDate->toIso8601String(),
            'end_date' => $endDate->toIso8601String()
        ]);
    }



    /**
     * Set a calendar as the primary calendar
     *
     * @param Request $request
     * @param int $id
     * @return JsonResponse
     */
    public function setDefaultCalendar(Request $request, $id): JsonResponse
    {
        $user = $request->user();
        
        // Get the calendar to be set as primary
        $calendar = CalendarConnection::where('id', $id)
            ->where('user_id', $user->id)
            ->where('is_active', true)
            ->first();

        if (!$calendar) {
            return response()->json([
                'success' => false,
                'message' => 'Calendar not found or not active'
            ], 404);
        }
        
        // Begin transaction to ensure data consistency
        DB::beginTransaction();
        
        try {
            // Remove primary status from any existing primary calendar
            CalendarConnection::where('user_id', $user->id)
                ->where('is_primary', true)
                ->update(['is_primary' => false]);
            
            // Set the new calendar as primary
            $calendar->is_primary = true;
            $calendar->save();
            
            DB::commit();
            
            return response()->json([
                'success' => true,
                'message' => 'Primary calendar updated successfully',
                'calendar' => [
                    'id' => $calendar->id,
                    'name' => $calendar->name,
                    'provider' => $calendar->provider,
                    'is_primary' => true
                ]
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'success' => false,
                'message' => 'Failed to update primary calendar'
            ], 500);
        }
    }

    /**
     * Activate a calendar connection
     */
    public function activateCalendar(Request $request, $id)
    {
        $user = $request->user();
        $calendar = CalendarConnection::where('id', $id)
            ->where('user_id', $user->id)
            ->first();
            
        if (!$calendar || $calendar->provider == 'default') {
            return response()->json([
                'success' => false,
                'message' => 'Calendar not found'
            ], 404);
        }
        
        // If calendar is already active, we can just deactivate it
        if ($calendar->is_active) {
            // Check if this is the primary calendar
            $isPrimary = $calendar->is_primary;
            
            // Begin transaction to ensure data consistency
            DB::beginTransaction();
            
            try {
                $calendar->is_active = false;
                
                // If this was the primary calendar, we need to set another one as primary
                if ($isPrimary) {
                    $calendar->is_primary = false;
                    $calendar->save();              // This is because of the unique check in db
                    
                    // Try to find the default calendar
                    $defaultCalendar = $user->calendars()
                        ->where('provider', 'default')
                        ->where('is_active', true)
                        ->first();
                    
                    // If default calendar exists, make it primary
                    if ($defaultCalendar) {
                        $defaultCalendar->is_primary = true;
                        $defaultCalendar->save();
                    } else {
                        // Otherwise, try to find any other active calendar
                        $otherCalendar = $user->calendars()
                            ->where('is_active', true)
                            ->where('id', '!=', $calendar->id)
                            ->first();
                        
                        if ($otherCalendar) {
                            $otherCalendar->is_primary = true;
                            $otherCalendar->save();
                        } else {
                            // Create a default calendar if no active calendars remain
                            $defaultCalendar = $user->getOrCreateDefaultCalendar();
                            $defaultCalendar->is_primary = true;
                            $defaultCalendar->save();
                        }
                    }
                }
                
                $calendar->save();
                
                DB::commit();
                
                return response()->json([
                    'success' => true,
                    'message' => 'Calendar deactivated',
                    'calendar' => [
                        'id' => $calendar->id,
                        'name' => $calendar->name,
                        'is_active' => false,
                        'is_primary' => false
                    ]
                ]);
            } catch (\Exception $e) {
                DB::rollBack();
                
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to deactivate calendar. '.$e->getMessage(),
                ], 500);
            }
        }
        
        // If trying to activate, check if user can activate another calendar
        if (!$this->planLimitService->canActivateCalendarConnection($user)) {
            return response()->json([
                'success' => false,
                'message' => 'You have reached your calendar limit for your current plan.',
                'remaining' => 0
            ], 403);
        }
        
        // Activate the calendar
        $calendar->is_active = true;
        $calendar->save();
        
        // Dispatch the sync job if the calendar provider is not 'default'
        if ($calendar->provider !== 'default') {
            SyncCalendarJob::dispatch($calendar);
        }
        
        return response()->json([
            'success' => true,
            'message' => 'Calendar activated',
            'calendar' => [
                'id' => $calendar->id,
                'name' => $calendar->name,
                'is_active' => true,
                'is_primary' => $calendar->is_primary
            ]
        ]);
    }
}
