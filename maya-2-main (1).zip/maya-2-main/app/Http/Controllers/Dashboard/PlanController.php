<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use Illuminate\Http\Request;

class PlanController extends Controller
{
    
    public function plans(){
        return response()->json([
            'plans' => Plan::all(),
        ]);
    }

    public function getUserPlanUsage(Request $request)
    {
        $user = $request->user();
        $plan = $user->currentPlan();
        
        if (!$plan) {
            return response()->json([
                'message' => 'No active plan found',
            ], 404);
        }
        
        // Get features with limits
        $limitedFeatures = array_filter($plan->features, function($value) {
            return is_numeric($value) && $value > 0;
        });
        
        // Get current usage for each feature
        $usageData = [];
        foreach (array_keys($limitedFeatures) as $feature) {
            $usageData[$feature] = [
                'limit' => $plan->getFeatureLimit($feature),
                'used' => $user->getFeatureUsage($feature),
                'remaining' => $plan->getFeatureLimit($feature) - $user->getFeatureUsage($feature),
            ];
        }
        
        return response()->json([
            'plan' => [
                'name' => $plan->name,
                'slug' => $plan->slug,
            ],
            'usage' => $usageData,
        ]);
    }
}
