<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\UserPreferences;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;

class UserPreferencesController extends Controller
{
    /**
     * Get notification preferences
     */
    public function getNotificationPreferences(Request $request)
    {
        $user = $request->user();
        $preferences = $user->preferences;
        
        if (!$preferences) {
            // Create default preferences if none exist
            $preferences = $user->preferences()->create([
                'event_notifications' => true,
                'other_notifications' => true,
                'daily_agenda_overview' => false,
            ]);
        }
        
        $plan = $user->currentPlan();
        $response = [
            'event_notifications' => (bool) $preferences->event_notifications,
            'other_notifications' => (bool) $preferences->other_notifications,
        ];
        
        // Daily agenda overview is a premium feature
        if ($plan && isset($plan->features['daily_agenda_overview']) && $plan->features['daily_agenda_overview'] === true) {
            $response['daily_agenda_overview'] = (bool) $preferences->daily_agenda_overview;
        } else {
            $response['daily_agenda_overview'] = 'requires_premium';
        }
        
        return response()->json($response);
    }

    public function setNotificationPreferences(Request $request){
        $user = $request->user();

        $validator = Validator::make($request->all(),[
            'type' => 'required|string|in:event,other,dailyAgenda',
            'value' => 'required|boolean',
        ]);

        if($validator->fails()){
            return response()->json([
                'success'   =>  false,
                'errors'    =>  $validator->errors()
            ]);
        }

        $preferences = $user->preferences;

        if (!$preferences) {
            $preferences = $user->preferences()->create([]);
        }

        $type = $request->input('type');
        $value = $request->input('value');

        switch ($type) {
            case 'event':
                $preferences->event_notifications = $value;
                break;

            case 'other':
                $preferences->other_notifications = $value;
                break;

            case 'dailyAgenda':
                $plan = $user->currentPlan();
                if ($plan && isset($plan->features['daily_agenda_overview']) && $plan->features['daily_agenda_overview'] === true) {
                    $preferences->daily_agenda_overview = $value;
                } else {
                    return response()->json([
                        'message' => 'Daily Agenda Overview is a premium feature.'
                    ], 403);
                }
                break;
        }

        $preferences->save();

        return response()->json([
            'message' => 'Preference updated successfully.',
            'updated' => $type,
            'value' => $value
        ]);

    }
    
    /**
     * Update event notifications setting
     */
    public function updateEventNotifications(Request $request)
    {
        return $this->updateSinglePreference($request, 'event_notifications', 'boolean');
    }
    
    /**
     * Update other notifications setting
     */
    public function updateOtherNotifications(Request $request)
    {
        return $this->updateSinglePreference($request, 'other_notifications', 'boolean');
    }
    
    /**
     * Update daily agenda overview setting
     */
    public function updateDailyAgendaOverview(Request $request)
    {
        $user = $request->user();
        $plan = $user->currentPlan();
        
        // Check if feature is available in user's plan
        if (!$plan || !isset($plan->features['daily_agenda_overview']) || !$plan->features['daily_agenda_overview']) {
            return response()->json([
                'message' => 'This feature requires an upgrade',
                'available_in' => $this->getLowestPlanWithFeature('daily_agenda_overview')
            ], 403);
        }
        
        return $this->updateSinglePreference($request, 'daily_agenda_overview', 'boolean');
    }
    
    /**
     * Get advanced preferences
     */
    public function getAdvancedPreferences(Request $request)
    {
        $user = $request->user();
        $preferences = $user->preferences;
        $plan = $user->currentPlan();
        
        if (!$preferences) {
            // Create default preferences if none exist
            $preferences = $user->preferences()->create([
                'smart_timing' => false,
                'event_duration' => 60,
                'event_alert' => 15,
                'all_day_event_alert' => 60,
                'time_conflict_detection' => false,
                'google_meet_links' => false,
            ]);
        }
        
        // Initialize response array with basic preferences
        $response = [
            'smart_timing' => (bool) $preferences->smart_timing,
            'event_duration' => (int) $preferences->event_duration,
            'event_alert' => (int) $preferences->event_alert,
            'all_day_event_alert' => (int) $preferences->all_day_event_alert,
        ];
        
        // Check premium features
        $premiumFeatures = [
            'time_conflict_detection' => 'time_conflict_detection',
            'google_meet_links' => 'google_meet_links',
        ];
        
        foreach ($premiumFeatures as $prefKey => $planKey) {
            if ($plan && isset($plan->features[$planKey]) && $plan->features[$planKey] === true) {
                $response[$prefKey] = (bool) $preferences->$prefKey;
            } else {
                $response[$prefKey] = 'requires_premium';
            }
        }
        
        return response()->json($response);
    }
    
    /**
     * Update smart timing setting
     */
    public function updateSmartTiming(Request $request)
    {
        return $this->updateSinglePreference($request, 'smart_timing', 'boolean');
    }
    
    /**
     * Update event duration setting
     */
    public function updateEventDuration(Request $request)
    {
        return $this->updateSinglePreference($request, 'event_duration', 'integer|min:1');
    }
    
    /**
     * Update event alert setting
     */
    public function updateEventAlert(Request $request)
    {
        return $this->updateSinglePreference($request, 'event_alert', 'integer|min:0');
    }
    
    /**
     * Update all-day event alert setting
     */
    public function updateAllDayEventAlert(Request $request)
    {
        return $this->updateSinglePreference($request, 'all_day_event_alert', 'integer|min:0');
    }
    
    /**
     * Update time conflict detection setting
     */
    public function updateTimeConflictDetection(Request $request)
    {
        $user = $request->user();
        $plan = $user->currentPlan();
        
        // Check if feature is available in user's plan
        if (!$plan || !isset($plan->features['time_conflict_detection']) || !$plan->features['time_conflict_detection']) {
            return response()->json([
                'message' => 'This feature requires an upgrade',
                'available_in' => $this->getLowestPlanWithFeature('time_conflict_detection')
            ], 403);
        }
        
        return $this->updateSinglePreference($request, 'time_conflict_detection', 'boolean');
    }
    
    /**
     * Update Google Meet links setting
     */
    public function updateGoogleMeetLinks(Request $request)
    {
        $user = $request->user();
        $plan = $user->currentPlan();
        
        // Check if feature is available in user's plan
        if (!$plan || !isset($plan->features['google_meet_links']) || !$plan->features['google_meet_links']) {
            return response()->json([
                'message' => 'This feature requires an upgrade',
                'available_in' => $this->getLowestPlanWithFeature('google_meet_links')
            ], 403);
        }
        
        return $this->updateSinglePreference($request, 'google_meet_links', 'boolean');
    }
    
    /**
     * Helper method to update a single preference field
     */
    private function updateSinglePreference(Request $request, $field, $validation)
    {
        $validator = Validator::make($request->all(), [
            'value' => $validation,
        ]);
        
        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors(),
            ], 422);
        }
        
        $user = $request->user();
        $preferences = $user->preferences;
        
        if (!$preferences) {
            $preferences = new UserPreferences();
            $preferences->user_id = $user->id;
        }
        
        $preferences->$field = $request->value;
        $preferences->save();
        
        return response()->json([
            'message' => 'Preference updated successfully',
            $field => $preferences->$field,
        ]);
    }
    
    /**
     * Helper method to find the lowest tier plan that includes a feature
     */
    private function getLowestPlanWithFeature($featureKey)
    {
        $plans = \App\Models\Plan::where('is_active', true)
            ->orderBy('sort_order')
            ->get();
        
        foreach ($plans as $plan) {
            if (isset($plan->features[$featureKey]) && $plan->features[$featureKey] === true) {
                return $plan->slug;
            }
        }
        
        return null;
    }
}