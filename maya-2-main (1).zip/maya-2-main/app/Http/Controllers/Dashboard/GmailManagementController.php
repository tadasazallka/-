<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GmailManagementController extends Controller
{
    public function gmailStatus(Request $request){
        $user = $request->user();
        return response()->json([
            'success' => true,
            'gmails' => $user->gmailAccount,
        ]);
    }
}
