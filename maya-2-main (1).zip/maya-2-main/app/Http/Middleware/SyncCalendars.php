<?php

namespace App\Http\Middleware;

use App\Jobs\SyncAllCalendarsJob;
use App\Models\CalendarAccount;
use App\Services\Calendars\Sync\AppleCalendarSyncService;
use App\Services\Calendars\Sync\GoogleCalendarSyncService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SyncCalendars
{
    protected $appleSyncService;
    protected $googleSyncService;

    public function __construct(AppleCalendarSyncService $appleSyncService, GoogleCalendarSyncService $googleSyncService)
    {
        $this->appleSyncService = $appleSyncService;
        $this->googleSyncService = $googleSyncService;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Only proceed if user is authenticated
        if ($request->user()) {
            // Dispatch job to sync all calendars for this user
            // The job will run in the background and won't delay the request
            dispatch(new SyncAllCalendarsJob($request->user()->id))
                ->onQueue('calendarsync');
        }

        // Continue with the request normally
        return $next($request);
    }
}