<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class CustomResetPasswordNotification extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     */

    public $token;
    public function __construct($token)
    {
        $this->token = $token;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
                ->subject('Reset Your Password')
                ->greeting('Hello!')
                ->line('We have received a request to reset your password. Please use the following OTP/token to reset your password.')
                ->line('Your Reset Token: ' . $this->token)
                ->line('Click the button below to copy the token.')
                ->action('Copy Token', url('/')) // You can replace this with JavaScript copy functionality in the front-end
                ->line('If you did not request a password reset, no further action is required.')
                ->view('emails.resetPassword', ['token' => $this->token]);
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            //
        ];
    }
}
