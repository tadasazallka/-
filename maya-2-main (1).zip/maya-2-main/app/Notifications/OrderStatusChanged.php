<?php

namespace App\Notifications;

use Illuminate\Broadcasting\Channel;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class OrderStatusChanged extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     */
    private $order;

    public function __construct($order)
    {
        $this->order = $order;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['database'];
    }

    /**
     * Get the mail representation of the notification.
     */

    public function toDatabase($notifiable){
        return [
            'order_id' => $this->order->id,
            'new_status' => $this->order->status,
            'message' => 'Your order status has changed to: ' . $this->order->status,
        ];
    }


    public function broadcastOn()
    {
        // Broadcasting on a private channel for a specific user
        return new Channel('testing-soketi');
    }

    public function toBroadcast($notifiable)
    {
        return [
            'data' => [
                'order_id' => $this->order->id,
                'new_status' => $this->order->status,
                'message' => 'Your order status has changed to: ' . $this->order->status,
            ]
        ];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
                    ->line('The introduction to the notification.')
                    ->action('Notification Action', url('/'))
                    ->line('Thank you for using our application!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    // public function toArray(object $notifiable): array
    // {
    //     return [
    //         'order_id' => $this->order->id,
    //         'new_status' => $this->order->status,
    //         'message' => 'Your order status has changed to: ' . $this->order->status,
    //     ];
    // }
}
