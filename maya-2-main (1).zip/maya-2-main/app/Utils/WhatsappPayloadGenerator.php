<?php

namespace App\Utils;

use Illuminate\Support\Str;

class WhatsappPayloadGenerator
{
    /**
     * Generate a WhatsApp webhook payload for a text message
     */
    public static function generateTextMessagePayload(string $whatsappId, string $message): array
    {
        $messageId = 'wamid.' . Str::random(20);
        
        return [
            'entry' => [
                [
                    'id' => Str::random(10),
                    'changes' => [
                        [
                            'value' => [
                                'messaging_product' => 'whatsapp',
                                'metadata' => [
                                    'display_phone_number' => '123456789',
                                    'phone_number_id' => '123456789'
                                ],
                                'contacts' => [
                                    [
                                        'profile' => [
                                            'name' => 'Test User'
                                        ],
                                        'wa_id' => $whatsappId
                                    ]
                                ],
                                'messages' => [
                                    [
                                        'from' => $whatsappId,
                                        'id' => $messageId,
                                        'timestamp' => time(),
                                        'text' => [
                                            'body' => $message
                                        ],
                                        'type' => 'text'
                                    ]
                                ]
                            ],
                            'field' => 'messages'
                        ]
                    ]
                ]
            ]
        ];
    }
    
    /**
     * Generate a WhatsApp webhook payload for a voice message
     */
    public static function generateVoiceMessagePayload(string $whatsappId): array
    {
        $messageId = 'wamid.' . Str::random(20);
        
        return [
            'entry' => [
                [
                    'id' => Str::random(10),
                    'changes' => [
                        [
                            'value' => [
                                'messaging_product' => 'whatsapp',
                                'metadata' => [
                                    'display_phone_number' => '123456789',
                                    'phone_number_id' => '123456789'
                                ],
                                'contacts' => [
                                    [
                                        'profile' => [
                                            'name' => 'Test User'
                                        ],
                                        'wa_id' => $whatsappId
                                    ]
                                ],
                                'messages' => [
                                    [
                                        'from' => $whatsappId,
                                        'id' => $messageId,
                                        'timestamp' => time(),
                                        'audio' => [
                                            'id' => 'audio_id_' . Str::random(10),
                                            'mime_type' => 'audio/ogg; codecs=opus',
                                            'file_size' => 100000 // 100 KB
                                        ],
                                        'type' => 'audio'
                                    ]
                                ]
                            ],
                            'field' => 'messages'
                        ]
                    ]
                ]
            ]
        ];
    }
    
    /**
     * Generate a WhatsApp webhook payload for an image message
     */
    public static function generateImageMessagePayload(string $whatsappId): array
    {
        $messageId = 'wamid.' . Str::random(20);
        
        return [
            'entry' => [
                [
                    'id' => Str::random(10),
                    'changes' => [
                        [
                            'value' => [
                                'messaging_product' => 'whatsapp',
                                'metadata' => [
                                    'display_phone_number' => '123456789',
                                    'phone_number_id' => '123456789'
                                ],
                                'contacts' => [
                                    [
                                        'profile' => [
                                            'name' => 'Test User'
                                        ],
                                        'wa_id' => $whatsappId
                                    ]
                                ],
                                'messages' => [
                                    [
                                        'from' => $whatsappId,
                                        'id' => $messageId,
                                        'timestamp' => time(),
                                        'image' => [
                                            'id' => 'image_id_' . Str::random(10),
                                            'mime_type' => 'image/jpeg',
                                            'file_size' => 200000, // 200 KB
                                            'caption' => 'Test image'
                                        ],
                                        'type' => 'image'
                                    ]
                                ]
                            ],
                            'field' => 'messages'
                        ]
                    ]
                ]
            ]
        ];
    }
    
    /**
     * Generate a WhatsApp webhook payload for a sticker message
     */
    public static function generateStickerMessagePayload(string $whatsappId): array
    {
        $messageId = 'wamid.' . Str::random(20);
        
        return [
            'entry' => [
                [
                    'id' => Str::random(10),
                    'changes' => [
                        [
                            'value' => [
                                'messaging_product' => 'whatsapp',
                                'metadata' => [
                                    'display_phone_number' => '123456789',
                                    'phone_number_id' => '123456789'
                                ],
                                'contacts' => [
                                    [
                                        'profile' => [
                                            'name' => 'Test User'
                                        ],
                                        'wa_id' => $whatsappId
                                    ]
                                ],
                                'messages' => [
                                    [
                                        'from' => $whatsappId,
                                        'id' => $messageId,
                                        'timestamp' => time(),
                                        'sticker' => [
                                            'id' => 'sticker_id_' . Str::random(10),
                                            'mime_type' => 'image/webp',
                                            'file_size' => 50000 // 50 KB
                                        ],
                                        'type' => 'sticker'
                                    ]
                                ]
                            ],
                            'field' => 'messages'
                        ]
                    ]
                ]
            ]
        ];
    }
    
    /**
     * Generate a WhatsApp webhook payload for a location message
     */
    public static function generateLocationMessagePayload(string $whatsappId, string $locationName = 'Test Location'): array
    {
        $messageId = 'wamid.' . Str::random(20);
        
        return [
            'entry' => [
                [
                    'id' => Str::random(10),
                    'changes' => [
                        [
                            'value' => [
                                'messaging_product' => 'whatsapp',
                                'metadata' => [
                                    'display_phone_number' => '123456789',
                                    'phone_number_id' => '123456789'
                                ],
                                'contacts' => [
                                    [
                                        'profile' => [
                                            'name' => 'Test User'
                                        ],
                                        'wa_id' => $whatsappId
                                    ]
                                ],
                                'messages' => [
                                    [
                                        'from' => $whatsappId,
                                        'id' => $messageId,
                                        'timestamp' => time(),
                                        'location' => [
                                            'latitude' => 32.0853,
                                            'longitude' => 34.7818,
                                            'name' => $locationName,
                                            'address' => '123 Test Street, Test City'
                                        ],
                                        'type' => 'location'
                                    ]
                                ]
                            ],
                            'field' => 'messages'
                        ]
                    ]
                ]
            ]
        ];
    }
    
    /**
     * Generate a WhatsApp webhook payload for a document message
     */
    public static function generateDocumentMessagePayload(string $whatsappId, string $filename = 'test_document.pdf'): array
    {
        $messageId = 'wamid.' . Str::random(20);
        
        return [
            'entry' => [
                [
                    'id' => Str::random(10),
                    'changes' => [
                        [
                            'value' => [
                                'messaging_product' => 'whatsapp',
                                'metadata' => [
                                    'display_phone_number' => '123456789',
                                    'phone_number_id' => '123456789'
                                ],
                                'contacts' => [
                                    [
                                        'profile' => [
                                            'name' => 'Test User'
                                        ],
                                        'wa_id' => $whatsappId
                                    ]
                                ],
                                'messages' => [
                                    [
                                        'from' => $whatsappId,
                                        'id' => $messageId,
                                        'timestamp' => time(),
                                        'document' => [
                                            'id' => 'document_id_' . Str::random(10),
                                            'mime_type' => 'application/pdf',
                                            'filename' => $filename,
                                            'file_size' => 300000 // 300 KB
                                        ],
                                        'type' => 'document'
                                    ]
                                ]
                            ],
                            'field' => 'messages'
                        ]
                    ]
                ]
            ]
        ];
    }
    
    /**
     * Generate a WhatsApp webhook payload for multiple messages
     */
    public static function generateMultipleMessagesPayload(string $whatsappId, array $messageTexts): array
    {
        $messages = [];
        
        foreach ($messageTexts as $text) {
            $messages[] = [
                'from' => $whatsappId,
                'id' => 'wamid.' . Str::random(20),
                'timestamp' => time(),
                'text' => [
                    'body' => $text
                ],
                'type' => 'text'
            ];
        }
        
        return [
            'entry' => [
                [
                    'id' => Str::random(10),
                    'changes' => [
                        [
                            'value' => [
                                'messaging_product' => 'whatsapp',
                                'metadata' => [
                                    'display_phone_number' => '123456789',
                                    'phone_number_id' => '123456789'
                                ],
                                'contacts' => [
                                    [
                                        'profile' => [
                                            'name' => 'Test User'
                                        ],
                                        'wa_id' => $whatsappId
                                    ]
                                ],
                                'messages' => $messages
                            ],
                            'field' => 'messages'
                        ]
                    ]
                ]
            ]
        ];
    }
}