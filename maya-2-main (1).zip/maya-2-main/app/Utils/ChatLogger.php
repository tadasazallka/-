<?php

namespace App\Utils;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Carbon\Carbon;

class ChatLogger
{
    protected $logPath;
    protected $logFile;
    
    public function __construct($logPath = 'chat_logs')
    {
        $this->logPath = $logPath;
        
        // Create a new log file with timestamp
        $timestamp = Carbon::now()->format('Y-m-d_His');
        $this->logFile = "chat_log_{$timestamp}.txt";
        
        // Make sure the storage directory exists
        if (!Storage::exists($this->logPath)) {
            Storage::makeDirectory($this->logPath);
        }
        
        // Initialize the log file with a header
        Storage::put("{$this->logPath}/{$this->logFile}", "=== WHATSAPP CHAT LOG - {$timestamp} ===\n\n");
    }
    
    /**
     * Log a user message
     */
    public function logUserMessage($userId, $whatsappId, $message, $messageId = null)
    {
        $this->writeToLog("USER ({$userId}, {$whatsappId}) [" . $this->getCurrentTime() . "]:");
        $this->writeToLog($message);
        $this->writeToLog("---"); // Separator
        
        // Also write to Laravel log for debugging
        Log::info("User message logged", [
            'user_id' => $userId,
            'whatsapp_id' => $whatsappId,
            'message' => $message,
            'message_id' => $messageId
        ]);
    }
    
    /**
     * Log assistant (bot) response
     */
    public function logAssistantResponse($userId, $whatsappId, $response)
    {
        $this->writeToLog("ASSISTANT → USER ({$userId}, {$whatsappId}) [" . $this->getCurrentTime() . "]:");
        $this->writeToLog($response);
        $this->writeToLog("==="); // Stronger separator for end of exchange
        
        Log::info("Assistant response logged", [
            'user_id' => $userId,
            'whatsapp_id' => $whatsappId,
            'response' => $response
        ]);
    }
    
    /**
     * Log what is stored in chat history (Redis)
     */
    public function logChatHistory($userId, $messages)
    {
        $this->writeToLog("\n=== CHAT HISTORY STATE FOR USER {$userId} ===\n");
        
        foreach ($messages as $index => $message) {
            $role = $message['role'] ?? 'unknown';
            $content = $message['content'] ?? 'no content';
            
            // For system messages, truncate if too long
            if ($role === 'system' && strlen($content) > 300) {
                $content = Str::limit($content, 300);
            }
            
            $this->writeToLog("MESSAGE #{$index} - ROLE: {$role}");
            $this->writeToLog("CONTENT: {$content}");
            $this->writeToLog("---");
        }
        
        $this->writeToLog("=== END OF CHAT HISTORY ===\n");
    }
    
    /**
     * Log API request to OpenAI
     */
    public function logApiRequest($payload)
    {
        $this->writeToLog("\n=== API REQUEST TO OPENAI ===\n");
        $this->writeToLog(json_encode($payload, JSON_PRETTY_PRINT));
        $this->writeToLog("=== END OF API REQUEST ===\n");
        
        Log::debug("OpenAI API request", ['payload' => $payload]);
    }
    
    /**
     * Log API response from OpenAI
     */
    public function logApiResponse($response)
    {
        $this->writeToLog("\n=== API RESPONSE FROM OPENAI ===\n");
        $this->writeToLog(json_encode($response, JSON_PRETTY_PRINT));
        $this->writeToLog("=== END OF API RESPONSE ===\n");
        
        Log::debug("OpenAI API response", ['response' => $response]);
    }
    
    /**
     * Get all chat logs
     */
    public function getAllLogs()
    {
        $files = Storage::files($this->logPath);
        $logs = [];
        
        foreach ($files as $file) {
            $logs[$file] = Storage::get($file);
        }
        
        return $logs;
    }
    
    /**
     * Get the current log file content
     */
    public function getCurrentLog()
    {
        return Storage::get("{$this->logPath}/{$this->logFile}");
    }
    
    /**
     * Get current log file path
     */
    public function getCurrentLogPath()
    {
        return "{$this->logPath}/{$this->logFile}";
    }
    
    /**
     * Helper to write to the log file
     */
    public function writeToLog($content)
    {
        Storage::append("{$this->logPath}/{$this->logFile}", $content);
    }
    
    /**
     * Get formatted current time
     */
    protected function getCurrentTime()
    {
        return Carbon::now()->format('H:i:s');
    }
}