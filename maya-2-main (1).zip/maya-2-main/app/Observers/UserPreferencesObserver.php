<?php

namespace App\Observers;

use App\Models\UserPreferences;
use App\Services\UserInfoRefreshService;
use Illuminate\Support\Facades\Log;

class UserPreferencesObserver
{
    protected $userInfoRefreshService;
    
    public function __construct(UserInfoRefreshService $userInfoRefreshService)
    {
        $this->userInfoRefreshService = $userInfoRefreshService;
    }
    
    /**
     * Handle the UserPreferences "updated" event.
     *
     * @param  \App\Models\UserPreferences  $preferences
     * @return void
     */
    public function updated(UserPreferences $preferences)
    {
        // Check if language preference was changed
        if ($preferences->isDirty('language') || $preferences->isDirty('language_auto_detect')) {
            Log::info('User language preferences updated, marking info refresh needed', [
                'user_id' => $preferences->user_id,
                'changed_fields' => $preferences->getDirty()
            ]);
            
            $this->userInfoRefreshService->markUserInfoUpdated($preferences->user_id);
        }
        else {
            Log::info('User preferences updated, marking info refresh needed', [
                'user_id' => $preferences->user_id
            ]);
            
            $this->userInfoRefreshService->markUserInfoUpdated($preferences->user_id);
        }
    }
}