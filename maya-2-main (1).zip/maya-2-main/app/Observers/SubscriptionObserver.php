<?php

namespace App\Observers;

use App\Models\Subscription;
use App\Services\UserInfoRefreshService;
use Illuminate\Support\Facades\Log;

class SubscriptionObserver
{
    protected $userInfoRefreshService;
    
    public function __construct(UserInfoRefreshService $userInfoRefreshService)
    {
        $this->userInfoRefreshService = $userInfoRefreshService;
    }
    
    /**
     * Handle the Subscription "created" event.
     *
     * @param  \App\Models\Subscription  $subscription
     * @return void
     */
    public function created(Subscription $subscription)
    {
        Log::info('New subscription created, marking info refresh needed', [
            'user_id' => $subscription->user_id,
            'plan_id' => $subscription->plan_id
        ]);
        
        $this->userInfoRefreshService->markUserInfoUpdated($subscription->user_id);
    }
    
    /**
     * Handle the Subscription "updated" event.
     *
     * @param  \App\Models\Subscription  $subscription
     * @return void
     */
    public function updated(Subscription $subscription)
    {
        if ($subscription->isDirty(['status', 'plan_id', 'ends_at'])) {
            Log::info('Subscription updated, marking info refresh needed', [
                'user_id' => $subscription->user_id,
                'changed_fields' => $subscription->getDirty()
            ]);
            
            $this->userInfoRefreshService->markUserInfoUpdated($subscription->user_id);
        }
    }
}