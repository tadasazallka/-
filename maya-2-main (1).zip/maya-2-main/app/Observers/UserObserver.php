<?php

namespace App\Observers;

use App\Models\User;
use App\Services\UserInfoRefreshService;
use Illuminate\Support\Facades\Log;

class UserObserver
{
    protected $userInfoRefreshService;
    
    public function __construct(UserInfoRefreshService $userInfoRefreshService)
    {
        $this->userInfoRefreshService = $userInfoRefreshService;
    }
    
    /**
     * Handle the User "updated" event.
     *
     * @param  \App\Models\User  $user
     * @return void
     */
    public function updated(User $user)
    {
        if ($user->isDirty(['is_signed_up', 'timezone'])) {
            Log::info('User data updated, marking info refresh needed', [
                'user_id' => $user->id,
                'changed_fields' => $user->getDirty()
            ]);
            
            $this->userInfoRefreshService->markUserInfoUpdated($user);
        }
    }
}