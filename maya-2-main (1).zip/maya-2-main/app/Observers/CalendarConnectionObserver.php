<?php

namespace App\Observers;

use App\Models\CalendarConnection;
use App\Services\UserInfoRefreshService;
use Illuminate\Support\Facades\Log;

class CalendarConnectionObserver
{
    protected $userInfoRefreshService;
    
    public function __construct(UserInfoRefreshService $userInfoRefreshService)
    {
        $this->userInfoRefreshService = $userInfoRefreshService;
    }
    
    /**
     * Handle the CalendarConnection "created" event.
     *
     * @param  \App\Models\CalendarConnection  $connection
     * @return void
     */
    public function created(CalendarConnection $connection)
    {
        Log::info('New calendar connection created, marking info refresh needed', [
            'user_id' => $connection->user_id,
            'provider' => $connection->provider
        ]);
        
        $this->userInfoRefreshService->markUserInfoUpdated($connection->user_id);
    }
    
    /**
     * Handle the CalendarConnection "updated" event.
     *
     * @param  \App\Models\CalendarConnection  $connection
     * @return void
     */
    public function updated(CalendarConnection $connection)
    {
        if ($connection->isDirty(['is_active', 'is_primary'])) {
            Log::info('Calendar connection updated, marking info refresh needed', [
                'user_id' => $connection->user_id,
                'changed_fields' => $connection->getDirty()
            ]);
            
            $this->userInfoRefreshService->markUserInfoUpdated($connection->user_id);
        }
    }
}