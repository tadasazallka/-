<?php

namespace App\Observers;

use App\Models\GmailAccount;
use App\Services\UserInfoRefreshService;
use Illuminate\Support\Facades\Log;

class GmailAccountObserver
{
    protected $userInfoRefreshService;
    
    public function __construct(UserInfoRefreshService $userInfoRefreshService)
    {
        $this->userInfoRefreshService = $userInfoRefreshService;
    }
    
    /**
     * Handle the GmailAccount "saved" event.
     *
     * @param  \App\Models\GmailAccount  $account
     * @return void
     */
    public function saved(GmailAccount $account)
    {
        Log::info('Gmail account saved, marking info refresh needed', [
            'user_id' => $account->user_id
        ]);
        
        $this->userInfoRefreshService->markUserInfoUpdated($account->user_id);
    }
}