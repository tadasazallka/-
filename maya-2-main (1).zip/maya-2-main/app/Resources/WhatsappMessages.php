<?php

namespace App\Resources;

class WhatsappMessages
{
    /**
     * Image acknowledgment messages in different languages
     */
    public static function getImageAcknowledgmentMessages($language = 'en'): array
    {
        $messages = [
            'en' => [
                "I'm analyzing your image... This will take just a moment. ✨",
                "Processing your photo now. Just a second! 📸",
                "Looking at your image... I'll respond shortly. 👀",
                "Got your picture! Analyzing it now... 🖼️",
                "Thanks for the image! Decoding what I'm seeing... 🔍",
                "Image received! Working my magic on it... ✨",
                "Examining your photo... I'll have insights soon! 📊",
                "Your image is being processed. Just a moment please... ⏳",
                "Analyzing visual content... Almost ready with a response! 🧐",
                "I see your image! Breaking it down now... 🔄"
            ],
            'he' => [
                "אני מנתח את התמונה שלך... זה ייקח רגע. ✨",
                "מעבד את התמונה שלך עכשיו. רק שנייה! 📸",
                "מסתכל על התמונה שלך... אגיב בקרוב. 👀",
                "קיבלתי את התמונה שלך! מנתח אותה עכשיו... 🖼️",
                "תודה על התמונה! מפענח את מה שאני רואה... 🔍",
                "התמונה התקבלה! עובד עליה עכשיו... ✨",
                "בוחן את התמונה שלך... תובנות יגיעו בקרוב! 📊",
                "התמונה שלך מעובדת כרגע. רק רגע בבקשה... ⏳",
                "מנתח תוכן חזותי... כמעט מוכן עם תשובה! 🧐",
                "אני רואה את התמונה שלך! מנתח אותה עכשיו... 🔄"
            ],
            'ur' => [
                "میں آپ کی تصویر کا تجزیہ کر رہا ہوں... یہ صرف ایک لمحہ لے گا۔ ✨",
                "آپ کی تصویر کو اب پروسیس کر رہا ہوں۔ بس ایک سیکنڈ! 📸",
                "آپ کی تصویر دیکھ رہا ہوں... میں جلد ہی جواب دوں گا۔ 👀",
                "آپ کی تصویر مل گئی! اب اس کا تجزیہ کر رہا ہوں... 🖼️",
                "تصویر کے لیے شکریہ! میں جو دیکھ رہا ہوں اسے سمجھ رہا ہوں... 🔍",
                "تصویر موصول ہوئی! اس پر کام کر رہا ہوں... ✨",
                "آپ کی تصویر کا معائنہ کر رہا ہوں... جلد ہی نتائج ملیں گے! 📊",
                "آپ کی تصویر پر کام ہو رہا ہے۔ براہ کرم ایک لمحہ... ⏳",
                "بصری مواد کا تجزیہ کر رہا ہوں... جواب کے لیے تقریباً تیار! 🧐",
                "میں آپ کی تصویر دیکھ رہا ہوں! اب اس کا تجزیہ کر رہا ہوں... 🔄"
            ]
        ];
        
        return $messages[$language] ?? $messages['en'];
    }
    
    /**
     * Audio acknowledgment messages in different languages
     */
    public static function getAudioAcknowledgmentMessages($language = 'en'): array
    {
        $messages = [
            'en' => [
                "I'm listening to your voice message now. I'll respond in just a moment... 🎧",
                "Playing your audio... I'll get back to you shortly! 🔊",
                "Voice message received! Processing what you said... 🎤",
                "Thanks for the audio! Listening carefully... 👂",
                "Decoding your voice message now... 🔍",
                "Got your audio! Just a moment while I process it... ⏳",
                "Listening to what you've shared... Will respond soon! 🎵",
                "Your voice message is being analyzed. Just a moment... 🔄",
                "Processing your audio input... Almost ready! 📊",
                "I'm all ears! Analyzing your voice message now... 🎧"
            ],
            'he' => [
                "אני מאזין להודעה הקולית שלך עכשיו. אגיב עוד רגע... 🎧",
                "מנגן את האודיו שלך... אחזור אליך בקרוב! 🔊",
                "הודעה קולית התקבלה! מעבד את מה שאמרת... 🎤",
                "תודה על האודיו! מקשיב בתשומת לב... 👂",
                "מפענח את הודעת הקול שלך עכשיו... 🔍",
                "קיבלתי את האודיו שלך! רק רגע בזמן שאני מעבד אותו... ⏳",
                "מקשיב למה ששיתפת... אגיב בקרוב! 🎵",
                "הודעת הקול שלך נמצאת בניתוח. רק רגע... 🔄",
                "מעבד את קלט האודיו שלך... כמעט מוכן! 📊",
                "אני כולי אוזניים! מנתח את הודעת הקול שלך עכשיו... 🎧"
            ],
            'ur' => [
                "میں ابھی آپ کا وائس میسیج سن رہا ہوں۔ میں ایک لمحے میں جواب دوں گا... 🎧",
                "آپ کی آڈیو چل رہی ہے... میں جلد ہی آپ سے رابطہ کروں گا! 🔊",
                "وائس میسیج موصول ہوا! آپ کی بات کو سمجھ رہا ہوں... 🎤",
                "آڈیو کے لیے شکریہ! غور سے سن رہا ہوں... 👂",
                "آپ کا وائس میسیج ابھی سمجھ رہا ہوں... 🔍",
                "آپ کی آڈیو مل گئی! جبکہ میں اسے پروسیس کرتا ہوں، ایک لمحہ... ⏳",
                "آپ نے جو شیئر کیا ہے اسے سن رہا ہوں... جلد ہی جواب دوں گا! 🎵",
                "آپ کے وائس میسیج کا تجزیہ کیا جا رہا ہے۔ ایک لمحہ... 🔄",
                "آپ کی آڈیو انپٹ پر کام ہو رہا ہے... تقریباً تیار! 📊",
                "میں پوری توجہ سے سن رہا ہوں! ابھی آپ کے وائس میسیج کا تجزیہ کر رہا ہوں... 🎧"
            ]
        ];
        
        return $messages[$language] ?? $messages['en'];
    }
    
    /**
     * Event reminder messages in different languages
     */
    public static function getEventReminderMessages($language = 'en'): array
    {
        $messages = [
            'en' => [
                'title' => "🔔 Event Reminder",
                'intro' => "Hello! This is a reminder about your upcoming event:",
                'event' => "📅 \"{title}\"",
                'time' => "⏰ {time}",
                'location' => "📍 Location: {location}",
                'description' => "📝 {description}",
                'outro' => "Have a great time!"
            ],
            'he' => [
                'title' => "🔔 תזכורת אירוע",
                'intro' => "שלום! זוהי תזכורת לאירוע הקרוב שלך:",
                'event' => "📅 \"{title}\"",
                'time' => "⏰ {time}",
                'location' => "📍 מיקום: {location}",
                'description' => "📝 {description}",
                'outro' => "שיהיה לך זמן נהדר!"
            ],
            'ur' => [
                'title' => "🔔 ایونٹ کی یاد دہانی",
                'intro' => "ہیلو! یہ آپ کے آنے والے ایونٹ کے بارے میں ایک یاد دہانی ہے:",
                'event' => "📅 \"{title}\"",
                'time' => "⏰ {time}",
                'location' => "📍 مقام: {location}",
                'description' => "📝 {description}",
                'outro' => "آپ کا وقت اچھا گزرے!"
            ]
        ];
        
        return $messages[$language] ?? $messages['en'];
    }
    
    /**
     * Format an event reminder message from templates
     */
    public static function formatEventReminderMessage(array $eventData, string $language = 'en'): string
    {
        $templates = self::getEventReminderMessages($language);
        
        // Start building the message
        $message = $templates['title'] . "\n\n" . $templates['intro'] . "\n\n";
        
        // Add event title
        $message .= str_replace('{title}', $eventData['title'], $templates['event']) . "\n";
        
        // Add event time
        $message .= str_replace('{time}', $eventData['time'], $templates['time']) . "\n";
        
        // Add location if available
        if (!empty($eventData['location'])) {
            $message .= str_replace('{location}', $eventData['location'], $templates['location']) . "\n";
        }
        
        // Add description if available
        if (!empty($eventData['description'])) {
            $message .= str_replace('{description}', $eventData['description'], $templates['description']) . "\n";
        }
        
        // Add outro
        $message .= "\n" . $templates['outro'];
        
        return $message;
    }
    
    /**
     * Document processing messages in different languages
     */
    public static function getDocumentResponse($language = 'en'): string
    {
        $messages = [
            'en' => "I received your document, but I can't process documents at this time. Could you please send the information in a text message?",
            'he' => "קיבלתי את המסמך שלך, אבל אני לא יכול לעבד מסמכים כרגע. האם תוכל לשלוח את המידע בהודעת טקסט?",
            'ur' => "مجھے آپ کا دستاویز موصول ہوا، لیکن میں ابھی دستاویزات پر کام نہیں کر سکتا۔ کیا آپ براہ کرم معلومات کو ٹیکسٹ میسیج میں بھیج سکتے ہیں؟"
        ];
        
        return $messages[$language] ?? $messages['en'];
    }
    
    /**
     * Sticker response messages in different languages
     */
    public static function getStickerResponse($language = 'en'): string
    {
        $messages = [
            'en' => "Thanks for the sticker! How can I help you today?",
            'he' => "תודה על המדבקה! איך אני יכול לעזור לך היום?",
            'ur' => "اسٹیکر کے لیے شکریہ! میں آج آپ کی کیسے مدد کر سکتا ہوں؟"
        ];
        
        return $messages[$language] ?? $messages['en'];
    }
    
    /**
     * Location response messages in different languages
     */
    public static function getLocationResponse($language = 'en', string $name = 'this location'): string
    {
        $messages = [
            'en' => "Thanks for sharing the location: {$name}. Would you like to schedule an event at this location?",
            'he' => "תודה ששיתפת את המיקום: {$name}. האם תרצה לקבוע אירוע במיקום זה?",
            'ur' => "مقام شیئر کرنے کے لیے شکریہ: {$name}۔ کیا آپ اس جگہ پر کوئی ایونٹ شیڈول کرنا چاہیں گے؟"
        ];
        
        return $messages[$language] ?? $messages['en'];
    }
    
    /**
     * Unknown message type response in different languages
     */
    public static function getUnknownTypeResponse($language = 'en'): string
    {
        $messages = [
            'en' => "I received your message, but I can't process this type of content. Please send a text message, voice note, or image.",
            'he' => "קיבלתי את ההודעה שלך, אבל אני לא יכול לעבד את סוג התוכן הזה. אנא שלח הודעת טקסט, הערה קולית או תמונה.",
            'ur' => "مجھے آپ کا پیغام موصول ہوا، لیکن میں اس قسم کے مواد پر کام نہیں کر سکتا۔ براہ کرم ٹیکسٹ میسیج، وائس نوٹ، یا تصویر بھیجیں۔"
        ];
        
        return $messages[$language] ?? $messages['en'];
    }
    
    /**
     * Error processing message in different languages
     */
    public static function getErrorResponse($language = 'en'): string
    {
        $messages = [
            'en' => "Sorry, I could not proceed with your request. Please try again or contact Support 📞",
            'he' => "מצטער, לא הצלחתי לטפל בבקשתך. אנא נסה שוב או צור קשר עם התמיכה 📞",
            'ur' => "معذرت، میں آپ کی درخواست پر کام نہیں کر سکا۔ براہ کرم دوبارہ کوشش کریں یا سپورٹ سے رابطہ کریں 📞"
        ];

        return $messages[$language] ?? $messages['en'];
    }
    
    /**
     * Signup prompt message in different languages
     */
    public static function getSignupPrompt($language = 'en', string $url): string
    {
        $messages = [
            'en' => "✨ Enjoying talking to me? Sign up to unlock more features! {$url}",
            'he' => "✨ נהנה לדבר איתי? הירשם כדי לפתוח יותר תכונות! {$url}",
            'ur' => "✨ مجھ سے بات کرنے سے لطف اندوز ہو رہے ہیں؟ مزید فیچرز کو انلاک کرنے کے لیے سائن اپ کریں! {$url}"
        ];
        
        return $messages[$language] ?? $messages['en'];
    }
    
    /**
     * Multiple messages note in different languages
     */
    public static function getMultipleMessagesNote($language = 'en'): string
    {
        $messages = [
            'en' => "📝 Note: I've processed your first message. For best results, please send your complete request in a single message.",
            'he' => "📝 הערה: עיבדתי את ההודעה הראשונה שלך. לתוצאות מיטביות, אנא שלח את הבקשה המלאה שלך בהודעה אחת.",
            'ur' => "📝 نوٹ: میں نے آپ کا پہلا پیغام پروسیس کیا ہے۔ بہترین نتائج کے لیے، براہ کرم اپنی مکمل درخواست ایک ہی پیغام میں بھیجیں۔"
        ];
        
        return $messages[$language] ?? $messages['en'];
    }
    
    /**
     * Media size exceeded message in different languages
     */
    public static function getMediaSizeExceededMessage($language = 'en', string $type): string
    {
        $messages = [
            'en' => [
                'image' => "I received your image, but it's too large for me to process. Please send a smaller image (under 5MB) or type your request as text.",
                'audio' => "I received your voice message, but it's too large for me to process. Please send a shorter voice message (under 2MB or about 2 minutes) or type your request as text."
            ],
            'he' => [
                'image' => "קיבלתי את התמונה שלך, אבל היא גדולה מדי לעיבוד. אנא שלח תמונה קטנה יותר (פחות מ-5MB) או הקלד את בקשתך כטקסט.",
                'audio' => "קיבלתי את הודעת הקול שלך, אבל היא גדולה מדי לעיבוד. אנא שלח הודעת קול קצרה יותר (פחות מ-2MB או כ-2 דקות) או הקלד את בקשתך כטקסט."
            ],
            'ur' => [
                'image' => "مجھے آپ کی تصویر موصول ہوئی، لیکن یہ پروسیس کرنے کے لیے بہت بڑی ہے۔ براہ کرم چھوٹی تصویر بھیجیں (5MB سے کم) یا اپنی درخواست کو ٹیکسٹ میں لکھیں۔",
                'audio' => "مجھے آپ کا وائس میسیج موصول ہوا، لیکن یہ پروسیس کرنے کے لیے بہت بڑا ہے۔ براہ کرم مختصر وائس میسیج بھیجیں (2MB سے کم یا تقریباً 2 منٹ) یا اپنی درخواست کو ٹیکسٹ میں لکھیں۔"
            ]
        ];
        
        return $messages[$language][$type] ?? $messages['en'][$type];
    }
    
    /**
     * Media processing error message in different languages
     */
    public static function getMediaProcessingErrorMessage($language = 'en', string $type): string
    {
        $messages = [
            'en' => [
                'image' => "I received your image, but couldn't download it. Could you please send a text message instead?",
                'audio' => "I received your voice message, but couldn't fetch the audio. Could you please send a text message instead?"
            ],
            'he' => [
                'image' => "קיבלתי את התמונה שלך, אבל לא הצלחתי להוריד אותה. האם תוכל לשלוח הודעת טקסט במקום?",
                'audio' => "קיבלתי את הודעת הקול שלך, אבל לא הצלחתי לקבל את האודיו. האם תוכל לשלוח הודעת טקסט במקום?"
            ],
            'ur' => [
                'image' => "مجھے آپ کی تصویر موصول ہوئی، لیکن میں اسے ڈاؤن لوڈ نہیں کر سکا۔ کیا آپ براہ کرم اس کے بجائے ٹیکسٹ میسیج بھیج سکتے ہیں؟",
                'audio' => "مجھے آپ کا وائس میسیج موصول ہوا، لیکن میں آڈیو حاصل نہیں کر سکا۔ کیا آپ براہ کرم اس کے بجائے ٹیکسٹ میسیج بھیج سکتے ہیں؟"
            ]
        ];
        
        return $messages[$language][$type] ?? $messages['en'][$type];
    }

    /**
     * Audio transcription error message in different languages
     */
    public static function getAudioTranscriptionErrorMessage($language = 'en'): string
    {
        $messages = [
            'en' => "I couldn't understand your voice message. Could you please try again or send a text message?",
            'he' => "לא הצלחתי להבין את הודעת הקול שלך. האם תוכל לנסות שוב או לשלוח הודעת טקסט?",
            'ur' => "میں آپ کا وائس میسیج نہیں سمجھ سکا۔ کیا آپ دوبارہ کوشش کر سکتے ہیں یا ٹیکسٹ میسیج بھیج سکتے ہیں؟"
        ];
        
        return $messages[$language] ?? $messages['en'];
    }

    /**
     * Audio processing error message in different languages
     */
    public static function getAudioProcessingErrorMessage($language = 'en'): string
    {
        $messages = [
            'en' => "I'm sorry, I had trouble processing your voice message. Could you please send a text message instead?",
            'he' => "סליחה, נתקלתי בבעיה בעיבוד הודעת הקול שלך. האם תוכל לשלוח הודעת טקסט במקום?",
            'ur' => "معذرت، مجھے آپ کے وائس میسیج پر کام کرنے میں دشواری ہوئی۔ کیا آپ اس کے بجائے ٹیکسٹ میسیج بھیج سکتے ہیں؟"
        ];
        
        return $messages[$language] ?? $messages['en'];
    }

    /**
     * Image extraction error message in different languages
     */
    public static function getImageExtractionErrorMessage($language = 'en'): string
    {
        $messages = [
            'en' => "I couldn't extract any text from the image. Could you please describe what you need in a text message?",
            'he' => "לא הצלחתי לחלץ טקסט מהתמונה. האם תוכל לתאר מה אתה צריך בהודעת טקסט?",
            'ur' => "میں تصویر سے کوئی متن نہیں نکال سکا۔ کیا آپ براہ کرم بتا سکتے ہیں کہ آپ کو ٹیکسٹ میسیج میں کیا درکار ہے؟"
        ];
        
        return $messages[$language] ?? $messages['en'];
    }

    /**
     * Image processing error message in different languages
     */
    public static function getImageProcessingErrorMessage($language = 'en'): string
    {
        $messages = [
            'en' => "I'm sorry, I had trouble processing your image. Could you please send the information in a text message?",
            'he' => "סליחה, נתקלתי בבעיה בעיבוד התמונה שלך. האם תוכל לשלוח את המידע בהודעת טקסט?",
            'ur' => "معذرت، مجھے آپ کی تصویر پر کام کرنے میں دشواری ہوئی۔ کیا آپ براہ کرم معلومات کو ٹیکسٹ میسیج میں بھیج سکتے ہیں؟"
        ];
        
        return $messages[$language] ?? $messages['en'];
    }

    
}