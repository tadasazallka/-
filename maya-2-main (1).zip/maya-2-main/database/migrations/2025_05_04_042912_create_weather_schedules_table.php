<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('weather_schedules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('location');
            $table->time('schedule_time'); // e.g., "09:00"
            $table->enum('frequency', ['daily', 'weekly', 'monthly'])->default('daily');
            $table->timestamp('last_sent_at')->nullable();
            $table->timestamps();
        });

        Schema::create('weather_schedule_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('weather_schedule_id')->constrained()->onDelete('cascade');
            $table->timestamp('sent_at');
            $table->json('weather_data')->nullable();
            $table->string('status'); // success, failed, etc.
            $table->text('error_message')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('weather_schedule_logs');
        Schema::dropIfExists('weather_schedules');
    }
};
