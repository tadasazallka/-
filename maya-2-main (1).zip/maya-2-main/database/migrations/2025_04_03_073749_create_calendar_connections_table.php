<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('calendar_connections', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('calendar_account_id')->nullable()->constrained()->onDelete('cascade');
            $table->string('provider'); // 'default', 'google', 'apple', etc.
            $table->string('provider_calendar_id')->nullable();
            $table->boolean('is_primary')->default(false);
            $table->json('provider_metadata')->nullable();
            $table->string('name')->nullable();
            $table->string('color')->nullable();
            $table->boolean('is_active')->default(false);
            $table->timestamps();
        });

        // Add a conditional unique index with a WHERE clause
        // This ensures only one primary calendar per user, but allows multiple non-primary calendars
        if (env('DB_CONNECTION') === 'pgsql') {
            // PostgreSQL syntax for partial index
            DB::statement('CREATE UNIQUE INDEX unique_primary_calendar_per_user ON calendar_connections (user_id) WHERE is_primary = true');
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('calendar_connections');
    }
};