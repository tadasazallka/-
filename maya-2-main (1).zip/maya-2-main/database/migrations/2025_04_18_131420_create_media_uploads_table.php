<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('media_uploads', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('media_type'); // 'image', 'audio', 'document', etc.
            $table->string('public_id'); // Cloudinary public ID
            $table->string('url'); // Cloudinary URL
            $table->json('metadata')->nullable(); // Any additional metadata
            $table->boolean('is_processed')->default(false); // Flag to indicate if processed
            $table->boolean('is_deleted')->default(false); // Flag to indicate if deleted from Cloudinary
            $table->timestamps();
            $table->index('user_id');
            $table->index('media_type');
            $table->index('public_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('media_uploads');
    }
};