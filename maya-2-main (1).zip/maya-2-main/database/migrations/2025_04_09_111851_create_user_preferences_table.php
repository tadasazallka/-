<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_preferences', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->enum('measurement_system', ['imperial', 'metric'])->default('metric');
            $table->boolean('event_notifications')->default(true);
            $table->boolean('other_notifications')->default(true);
            $table->boolean('daily_agenda_overview')->default(false);
            $table->boolean('smart_timing')->default(false);
            $table->integer('event_duration')->default(60); // Default to 60 minutes
            $table->integer('event_alert')->default(15); // Default to 15 minutes before
            $table->integer('all_day_event_alert')->default(180); // Default to 180 minutes before noon - 09 AM
            $table->boolean('time_conflict_detection')->default(false);
            $table->boolean('google_meet_links')->default(false);
            $table->string('language')->default('he');
            $table->boolean('language_auto_detect')->default(true);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_preferences');
    }
};
