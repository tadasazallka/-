<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('feature_usages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('feature'); // e.g., 'events_per_week', 'whatsapp_reminders'
            $table->integer('usage')->default(0);
            $table->timestamp('period_start');
            $table->timestamps();
            
            // Unique constraint to ensure only one record per user/feature/period
            $table->unique(['user_id', 'feature', 'period_start']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('feature_usages');
    }
};