<?php

namespace Database\Seeders;

use App\Models\Plan;
use Illuminate\Database\Seeder;

class PlanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create free plan
        Plan::updateOrCreate(
            ['slug' => 'free'],
            [
                'name' => 'Free Plan',
                'description' => 'Free tier with basic scheduling features',
                'price' => 0,
                'interval' => 'monthly',
                'features' => [
                    'events_per_week' => 7,
                    'whatsapp_reminders' => 15,
                    'calendar_sync_limit' => 1,
                    'create_events_via_text_voice_image' => true,
                    'time_conflict_detection' => false,
                    'daily_agenda_overview' => false,
                    'google_meet_links' => false,
                    'early_access_features' => false,
                ],
                'is_active' => true,
                'sort_order' => 1,
            ]
        );
        
        // Create Plus plan
        Plan::updateOrCreate(
            ['slug' => 'plus'],
            [
                'name' => 'Plus Plan',
                'description' => 'More events, reminders, and smart features',
                'price' => 9.99,
                'interval' => 'monthly',
                'features' => [
                    'events_per_week' => 25,
                    'whatsapp_reminders' => 50,
                    'calendar_sync_limit' => 15,
                    'create_events_via_text_voice_image' => true,
                    'time_conflict_detection' => true,
                    'daily_agenda_overview' => true,
                    'google_meet_links' => true,
                    'early_access_features' => true,
                ],
                'is_active' => true,
                'sort_order' => 2,
            ]
        );
        
        // Create Pro plan
        Plan::updateOrCreate(
            ['slug' => 'pro'],
            [
                'name' => 'Pro Plan',
                'description' => 'Top tier plan with full features and unlimited tools',
                'price' => 19.99, // or keep 95.88/year if it's a discounted annual plan
                'interval' => 'monthly', // change to 'yearly' if you're going for yearly billing
                'features' => [
                    'events_per_week' => 140,
                    'whatsapp_reminders' => -1, // -1 for Unlimited
                    'calendar_sync_limit' => 15,
                    'create_events_via_text_voice_image' => true,
                    'time_conflict_detection' => true,
                    'daily_agenda_overview' => true,
                    'google_meet_links' => true,
                    'early_access_features' => true,
                ],
                'is_active' => true,
                'sort_order' => 3,
            ]
        );
        
    }
}