<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset</title>
    <style>
        /* General email styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .email-container {
            background-color: #ffffff;
            max-width: 600px;
            margin: 50px auto;
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            text-align: center;
        }

        p {
            font-size: 16px;
            line-height: 1.5;
        }

        h3 {
            font-size: 24px;
            text-align: center;
            color: #2c3e50;
            margin-top: 20px;
        }

        /* Copy button styles */
        .btn-copy {
            display: block;
            background-color: #3498db;
            color: #fff;
            padding: 12px 18px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            margin: 20px auto;
            width: 150px;
        }

        .btn-copy:hover {
            background-color: #2980b9;
        }

        /* Footer styles */
        .footer {
            text-align: center;
            font-size: 14px;
            color: #777;
            margin-top: 30px;
        }

    </style>
</head>
<body>
    <div class="email-container">
        <h1>Password Reset Request</h1>

        <p>Hello,</p>

        <p>We have received a request to reset your password. Please copy the following OTP/token and paste in your app to reset your password:</p>

        <!-- Display the reset token -->
        <h3>{{ $token }}</h3>

        <!-- Copy button -->
        {{-- <button id="copy-token" class="btn-copy" onclick="copyToClipboard('{{ $token }}')">Copy</button> --}}

        <p>If you did not request a password reset, you can safely ignore this email.</p>

        <!-- Footer with company name -->
        <div class="footer">
            <p>&copy; {{ date('Y') }} Your Company Name. All rights reserved.</p>
        </div>
    </div>

    <script>
        // function copyToClipboard(token) {
        //     navigator.clipboard.writeText(token).then(function() {
        //         var copyButton = document.getElementById("copy-token");
        //         copyButton.innerHTML = "Copied";
                
        //         setTimeout(function() {
        //             copyButton.innerHTML = "Copy";
        //         }, 3000);
        //     }).catch(function(error) {
        //         console.error("Could not copy text: ", error);
        //     });
        // }
    </script>
</body>
</html>
