<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\MessageProcessorService;
use App\Services\WhatsappAPIService;
use App\Utils\ChatLogger;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Redis;
use Tests\TestCase;

class WhatsappConversationTest extends TestCase
{
    use RefreshDatabase;
    
    protected $messageProcessor;
    protected $whatsappService;
    protected $chatLogger;
    protected $user;
    
    /**
     * Set up the test
     */
    public function setUp(): void
    {
        parent::setUp();
        
        // Create services
        $this->messageProcessor = $this->app->make(MessageProcessorService::class);
        $this->whatsappService = $this->app->make(WhatsappAPIService::class);
        
        // Create a test user
        $this->user = User::factory()->create([
            'whatsapp_id' => '1234567890',
            'name' => 'Test User',
            'is_signed_up' => false,
            'timezone' => 'UTC',
        ]);
        
        // Initialize the chat logger
        $this->chatLogger = new ChatLogger('test_chat_logs');
        
        // Flush Redis DB to start clean
        Redis::flushdb();
    }
    
    /**
     * Test a random conversation flow
     */
    public function testRandomConversation()
    {
        // Generate random conversation of 5-10 messages
        $conversationLength = rand(5, 10);
        
        $this->logTestInfo("Starting random conversation with {$conversationLength} messages");
        
        for ($i = 0; $i < $conversationLength; $i++) {
            // Generate a random message
            $message = $this->generateRandomMessage();
            
            // Log user message
            $this->chatLogger->logUserMessage(
                $this->user->id, 
                $this->user->whatsapp_id, 
                $message
            );
            
            // Process the message
            $response = $this->messageProcessor->processTextMessage($this->user, $message);
            
            // Log assistant response
            $this->chatLogger->logAssistantResponse(
                $this->user->id, 
                $this->user->whatsapp_id, 
                $response
            );
            
            // Log chat history state
            $chatHistory = $this->getChatHistory();
            $this->chatLogger->logChatHistory($this->user->id, $chatHistory);
            
            // Short pause to simulate real conversation timing
            sleep(1);
        }
        
        $this->logTestInfo("Conversation completed. Log file: " . $this->chatLogger->getCurrentLogPath());
        
        // Output the log file path for easy reference
        echo "\nChat log file: " . storage_path('app/' . $this->chatLogger->getCurrentLogPath()) . "\n";
        
        $this->assertTrue(true); // Simple assertion to mark test as passing
    }
    
    /**
     * Generate a random user message
     */
    protected function generateRandomMessage()
    {
        $messages = [
            "Hello, who are you?",
            "What can you help me with?",
            "Can you schedule a meeting for tomorrow at 2pm?",
            "Tell me about my calendar events",
            "I need to send an email to john@example.com",
            "What's the weather like today?",
            "Can you help me plan my day?",
            "Tell me a joke",
            "What time is it?",
            "Create a reminder for me",
            "How do I use the calendar feature?",
            "Where can I find my settings?",
            "Is there a premium plan available?",
            "Can you speak Spanish?",
            "What's the difference between free and paid plans?",
            "I need help with setting up my account",
            "Can you search the web for information?",
            "What languages do you support?",
            "How do I add events to my calendar?",
            "Tell me about yourself"
        ];
        
        return $messages[array_rand($messages)];
    }
    
    /**
     * Get current chat history from Redis
     */
    protected function getChatHistory()
    {
        $redisKey = "user:{$this->user->id}";
        $messagesJson = Redis::lrange($redisKey, 0, -1);
        
        if (empty($messagesJson)) {
            return [];
        }
        
        $messages = [];
        foreach ($messagesJson as $json) {
            $messages[] = json_decode($json, true);
        }
        
        return $messages;
    }
    
    /**
     * Log test information
     */
    protected function logTestInfo($message)
    {
        $this->chatLogger->writeToLog("\n*** TEST INFO: {$message} ***\n");
    }
}