<?php

namespace Tests\Feature;

use App\Utils\WhatsappPayloadGenerator;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Redis;
use Tests\TestCase;

class TestWhatsappWebhook extends TestCase
{
    use RefreshDatabase;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Clear Redis for clean testing
        Redis::flushdb();
    }
    
    /**
     * Test the webhook with a text message
     */
    public function testWebhookWithTextMessage()
    {
        $whatsappId = '123456' . rand(1000, 9999);
        $message = 'Hello, who are you?';
        
        $payload = WhatsappPayloadGenerator::generateTextMessagePayload($whatsappId, $message);
        
        $response = $this->postJson('/api/whatsapp/webhook', $payload);
        
        $response->assertStatus(200)
                 ->assertJson(['status' => 'success']);
        
        // You can add more assertions here like checking if a user was created in the database
        $this->assertDatabaseHas('users', [
            'whatsapp_id' => $whatsappId
        ]);
    }
    
    /**
     * Test a simple conversation flow
     */
    public function testSimpleConversationFlow()
    {
        $whatsappId = '123456' . rand(1000, 9999);
        
        // First message
        $message1 = 'Hello, who are you?';
        $payload1 = WhatsappPayloadGenerator::generateTextMessagePayload($whatsappId, $message1);
        $response1 = $this->postJson('/api/whatsapp/webhook', $payload1);
        $response1->assertStatus(200);
        
        // Wait briefly to ensure processing completes
        usleep(500000); // 0.5 seconds
        
        // Second message
        $message2 = 'What can you help me with?';
        $payload2 = WhatsappPayloadGenerator::generateTextMessagePayload($whatsappId, $message2);
        $response2 = $this->postJson('/api/whatsapp/webhook', $payload2);
        $response2->assertStatus(200);
        
        // Wait briefly
        usleep(500000);
        
        // Third message
        $message3 = 'Can you schedule a meeting for tomorrow?';
        $payload3 = WhatsappPayloadGenerator::generateTextMessagePayload($whatsappId, $message3);
        $response3 = $this->postJson('/api/whatsapp/webhook', $payload3);
        $response3->assertStatus(200);
        
        // Check that a user exists with this WhatsApp ID
        $this->assertDatabaseHas('users', [
            'whatsapp_id' => $whatsappId
        ]);
        
        // Verify messages were added to Redis
        $user = \App\Models\User::where('whatsapp_id', $whatsappId)->first();
        $redisKey = "user:{$user->id}";
        $messagesJson = Redis::lrange($redisKey, 0, -1);
        
        // Should have at least 4 messages (system + 3 user messages)
        $this->assertGreaterThanOrEqual(4, count($messagesJson));
    }
    
    /**
     * Test handling of multiple messages in a single webhook
     */
    public function testMultipleMessagesInSingleWebhook()
    {
        $whatsappId = '123456' . rand(1000, 9999);
        
        $messages = [
            'Hello, this is message 1',
            'This is message 2, which should be ignored',
            'This is message 3, which should also be ignored'
        ];
        
        $payload = WhatsappPayloadGenerator::generateMultipleMessagesPayload($whatsappId, $messages);
        
        $response = $this->postJson('/api/whatsapp/webhook', $payload);
        
        $response->assertStatus(200)
                 ->assertJson(['status' => 'success']);
        
        // Verify user was created
        $this->assertDatabaseHas('users', [
            'whatsapp_id' => $whatsappId
        ]);
        
        // Verify only one message was processed (only process first message)
        $user = \App\Models\User::where('whatsapp_id', $whatsappId)->first();
        $redisKey = "user:{$user->id}";
        $messagesJson = Redis::lrange($redisKey, 0, -1);
        
        // Should have exactly 2 messages (system + first user message)
        $this->assertGreaterThanOrEqual(2, count($messagesJson));
        
        // Verify content of user message is from the first message only
        $foundUserMessage = false;
        foreach ($messagesJson as $json) {
            $message = json_decode($json, true);
            if ($message['role'] === 'user') {
                $this->assertEquals($messages[0], $message['content']);
                $foundUserMessage = true;
            }
        }
        
        $this->assertTrue($foundUserMessage, 'Could not find user message in Redis');
    }
    
    /**
     * Test voice message handling
     */
    public function testVoiceMessageHandling()
    {
        $whatsappId = '123456' . rand(1000, 9999);
        
        $payload = WhatsappPayloadGenerator::generateVoiceMessagePayload($whatsappId);
        
        $response = $this->postJson('/api/whatsapp/webhook', $payload);
        
        $response->assertStatus(200)
                 ->assertJson(['status' => 'success']);
        
        // Verify user was created
        $this->assertDatabaseHas('users', [
            'whatsapp_id' => $whatsappId
        ]);
    }
    
    /**
     * Test image message handling
     */
    public function testImageMessageHandling()
    {
        $whatsappId = '123456' . rand(1000, 9999);
        
        $payload = WhatsappPayloadGenerator::generateImageMessagePayload($whatsappId);
        
        $response = $this->postJson('/api/whatsapp/webhook', $payload);
        
        $response->assertStatus(200)
                 ->assertJson(['status' => 'success']);
        
        // Verify user was created
        $this->assertDatabaseHas('users', [
            'whatsapp_id' => $whatsappId
        ]);
    }
}