<?php

namespace Tests\Load;

use App\Models\User;
use App\Services\MessageQueueService;
use App\Jobs\ProcessUserMessagesJob;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Redis;
use Tests\TestCase;

class WhatsAppLoadTest extends TestCase
{
    use RefreshDatabase;

    protected $messageQueueService;
    protected $testUsers = [];
    
    protected function setUp(): void
    {
        parent::setUp();
        $this->messageQueueService = app(MessageQueueService::class);
        
        // Create test users
        for ($i = 1; $i <= 100; $i++) {
            $this->testUsers[] = User::factory()->create([
                'whatsapp_id' => "test_user_{$i}",
                'name' => "Test User {$i}"
            ]);
        }
    }

    /**
     * Test concurrent message queuing from multiple users
     */
    public function test_concurrent_message_queuing()
    {
        $messageCount = 1000;
        $userCount = count($this->testUsers);
        $messagesPerUser = intval($messageCount / $userCount);
        
        $startTime = microtime(true);
        
        // Simulate concurrent messages from multiple users
        foreach ($this->testUsers as $index => $user) {
            for ($j = 1; $j <= $messagesPerUser; $j++) {
                $messageData = [
                    'id' => "msg_{$index}_{$j}",
                    'type' => 'text',
                    'content' => "Test message {$j} from user {$index}",
                    'timestamp' => time(),
                    'from' => $user->whatsapp_id
                ];
                
                $this->messageQueueService->addMessageToQueue($user, $messageData);
            }
        }
        
        $endTime = microtime(true);
        $duration = $endTime - $startTime;
        
        // Assertions
        $this->assertLessThan(5.0, $duration, "Queuing {$messageCount} messages took too long");
        
        // Verify all messages were queued
        $totalQueuedMessages = 0;
        foreach ($this->testUsers as $user) {
            $totalQueuedMessages += $this->messageQueueService->countQueuedMessages($user);
        }
        
        $this->assertEquals($messageCount, $totalQueuedMessages);
        
        echo "\nQueued {$messageCount} messages in {$duration} seconds\n";
        echo "Rate: " . round($messageCount / $duration) . " messages/second\n";
    }

    /**
     * Test Redis performance under load
     */
    public function test_redis_performance_under_load()
    {
        $operations = 10000;
        $startTime = microtime(true);
        
        // Test Redis SET operations
        for ($i = 1; $i <= $operations; $i++) {
            Redis::setex("load_test_key_{$i}", 300, "test_value_{$i}");
        }
        
        $setTime = microtime(true);
        
        // Test Redis GET operations
        for ($i = 1; $i <= $operations; $i++) {
            Redis::get("load_test_key_{$i}");
        }
        
        $getTime = microtime(true);
        
        // Cleanup
        for ($i = 1; $i <= $operations; $i++) {
            Redis::del("load_test_key_{$i}");
        }
        
        $cleanupTime = microtime(true);
        
        $setDuration = $setTime - $startTime;
        $getDuration = $getTime - $setTime;
        
        echo "\nRedis Performance Test:\n";
        echo "SET operations: {$operations} in {$setDuration} seconds (" . round($operations / $setDuration) . " ops/sec)\n";
        echo "GET operations: {$operations} in {$getDuration} seconds (" . round($operations / $getDuration) . " ops/sec)\n";
        
        // Assert reasonable performance
        $this->assertLessThan(10.0, $setDuration, "Redis SET operations too slow");
        $this->assertLessThan(5.0, $getDuration, "Redis GET operations too slow");
    }

    /**
     * Test job processing under load
     */
    public function test_job_processing_load()
    {
        Queue::fake();
        
        $jobCount = 500;
        
        // Queue multiple jobs simultaneously
        $startTime = microtime(true);
        
        foreach ($this->testUsers as $index => $user) {
            if ($index >= $jobCount) break;
            
            // Add messages to queue first
            for ($j = 1; $j <= 5; $j++) {
                $messageData = [
                    'id' => "job_test_msg_{$index}_{$j}",
                    'type' => 'text',
                    'content' => "Job test message {$j}",
                    'timestamp' => time(),
                    'from' => $user->whatsapp_id
                ];
                
                $this->messageQueueService->addMessageToQueue($user, $messageData);
            }
            
            // Dispatch job
            ProcessUserMessagesJob::dispatch($user);
        }
        
        $endTime = microtime(true);
        $duration = $endTime - $startTime;
        
        // Verify jobs were queued
        Queue::assertPushed(ProcessUserMessagesJob::class, $jobCount);
        
        echo "\nDispatched {$jobCount} jobs in {$duration} seconds\n";
        echo "Rate: " . round($jobCount / $duration) . " jobs/second\n";
    }

    /**
     * Test memory usage during high load
     */
    public function test_memory_usage_under_load()
    {
        $initialMemory = memory_get_usage(true);
        $messageCount = 5000;
        
        // Create large number of messages
        foreach ($this->testUsers as $user) {
            for ($i = 1; $i <= 50; $i++) {
                $messageData = [
                    'id' => "memory_test_msg_{$user->id}_{$i}",
                    'type' => 'text',
                    'content' => str_repeat("This is a test message for memory usage testing. ", 10),
                    'timestamp' => time(),
                    'from' => $user->whatsapp_id
                ];
                
                $this->messageQueueService->addMessageToQueue($user, $messageData);
            }
        }
        
        $peakMemory = memory_get_peak_usage(true);
        $memoryIncrease = $peakMemory - $initialMemory;
        
        echo "\nMemory Usage Test:\n";
        echo "Initial memory: " . round($initialMemory / 1024 / 1024, 2) . " MB\n";
        echo "Peak memory: " . round($peakMemory / 1024 / 1024, 2) . " MB\n";
        echo "Memory increase: " . round($memoryIncrease / 1024 / 1024, 2) . " MB\n";
        
        // Assert reasonable memory usage (adjust threshold as needed)
        $this->assertLessThan(100 * 1024 * 1024, $memoryIncrease, "Memory usage too high");
    }

    /**
     * Test duplicate message handling under load
     */
    public function test_duplicate_message_handling_load()
    {
        $messageId = "duplicate_test_message";
        $attempts = 1000;
        
        $startTime = microtime(true);
        $successfulProcesses = 0;
        
        // Simulate rapid duplicate message attempts
        for ($i = 1; $i <= $attempts; $i++) {
            $redisKey = "whatsapp:processed:{$messageId}";
            
            // Simulate the duplicate check logic
            if (Redis::setnx($redisKey, 1)) {
                Redis::expire($redisKey, 300);
                $successfulProcesses++;
            }
        }
        
        $endTime = microtime(true);
        $duration = $endTime - $startTime;
        
        // Should only process once despite multiple attempts
        $this->assertEquals(1, $successfulProcesses, "Duplicate handling failed");
        
        echo "\nDuplicate Handling Test:\n";
        echo "Attempts: {$attempts} in {$duration} seconds\n";
        echo "Successful processes: {$successfulProcesses} (should be 1)\n";
        
        // Cleanup
        Redis::del("whatsapp:processed:{$messageId}");
    }

    /**
     * Comprehensive load test simulation
     */
    public function test_full_system_load_simulation()
    {
        $totalMessages = 2000;
        $concurrentUsers = 50;
        $messagesPerUser = intval($totalMessages / $concurrentUsers);
        
        $startTime = microtime(true);
        
        // Simulate realistic WhatsApp webhook load
        $processedMessages = 0;
        $errors = 0;
        
        foreach (array_slice($this->testUsers, 0, $concurrentUsers) as $user) {
            try {
                for ($i = 1; $i <= $messagesPerUser; $i++) {
                    // Simulate different message types
                    $messageTypes = ['text', 'audio', 'image'];
                    $messageType = $messageTypes[array_rand($messageTypes)];
                    
                    $messageData = [
                        'id' => "load_sim_msg_{$user->id}_{$i}",
                        'type' => $messageType,
                        'timestamp' => time(),
                        'from' => $user->whatsapp_id
                    ];
                    
                    switch ($messageType) {
                        case 'text':
                            $messageData['content'] = "Load test message {$i}";
                            break;
                        case 'audio':
                            $messageData['audio'] = [
                                'url' => 'https://example.com/audio.ogg',
                                'id' => "audio_{$i}",
                                'file_size' => 1024000
                            ];
                            break;
                        case 'image':
                            $messageData['image'] = [
                                'url' => 'https://example.com/image.jpg',
                                'id' => "image_{$i}",
                                'file_size' => 2048000
                            ];
                            break;
                    }
                    
                    if ($this->messageQueueService->addMessageToQueue($user, $messageData)) {
                        $processedMessages++;
                    } else {
                        $errors++;
                    }
                }
            } catch (\Exception $e) {
                $errors++;
            }
        }
        
        $endTime = microtime(true);
        $duration = $endTime - $startTime;
        
        echo "\nFull System Load Test Results:\n";
        echo "Total messages: {$totalMessages}\n";
        echo "Successfully processed: {$processedMessages}\n";
        echo "Errors: {$errors}\n";
        echo "Duration: {$duration} seconds\n";
        echo "Rate: " . round($processedMessages / $duration) . " messages/second\n";
        echo "Success rate: " . round(($processedMessages / $totalMessages) * 100, 2) . "%\n";
        
        // Assertions
        $this->assertGreaterThan(0.95 * $totalMessages, $processedMessages, "Too many failed messages");
        $this->assertLessThan(20.0, $duration, "Processing took too long");
    }
}